# Falcon Trust Research Workspace — Limited Demo Implementation Plan

## Scope freeze

The limited demo build is scoped to:

- Two domains: Law and Sandbags
- Synthetic/preloaded text-based PDFs
- One controlled live PDF upload path
- PDF text extraction, no OCR
- Chunking and embeddings
- Domain-scoped retrieval for Law-only, Sandbags-only, and Law + Sandbags
- Cited answers with source snippets and domain badges
- Tavily-powered web topic/article search or comparison
- Suggested article angle/outline, not full article generation
- Local/demo query history
- Simple unauthenticated admin/history panel
- Local-first build, AWS App Runner later after local workflow works

Out of scope for the limited demo:

- Production auth
- Real customer-sensitive documents
- Enterprise SSO
- OCR/scanned PDFs
- Production-grade monitoring/backups
- Full article generation
- Production hardening

## Current app audit

Current app state:

- Next.js 16 / React 19 single-page app.
- Existing UI is a polished mock/prototype.
- Existing domains are Law, RFP, Journal; this conflicts with the settled limited-demo scope of Law and Sandbags.
- Existing query behavior is deterministic keyword routing with mock answers.
- Existing corpus/document list is hardcoded mock data.
- No real PDF ingestion.
- No chunking/embedding pipeline.
- No vector storage/retrieval.
- No LLM provider abstraction.
- No Tavily integration.
- No admin/session history persistence.
- No API routes for ingestion/query/admin.

Reusable pieces:

- Visual direction and dark research-workspace aesthetic.
- Basic page layout patterns for hero/query/results/domain/document status sections.
- Docker/Next.js project structure.
- Existing AWS portability docs can be updated later.

Needed change posture:

- Keep the useful visual shell, but replace mock domain/data/query behavior with a real local demo pipeline.
- Avoid AWS work until local ingestion → retrieval → cited answer path works.

## Implementation tickets

### 1. Demo corpus and script

Deliverables:
- Create synthetic Law PDFs.
- Create synthetic Sandbags PDFs.
- Create 5–8 demo questions that reliably prove Law-only, Sandbags-only, and Law + Sandbags behavior.
- Create one external topic/article example for Tavily/internal comparison.

Acceptance criteria:
- Demo questions have known expected source documents/snippets.
- Synthetic docs are clearly marked as sample/demo content.

### 2. Data model and local storage

Deliverables:
- Define local data structures for domains, documents, chunks, query sessions, citations, and web comparisons.
- Choose initial local storage approach for the demo.

Recommended initial approach:
- Use file-backed JSON storage or SQLite for demo speed.
- Keep interfaces clean enough to later migrate to Postgres/pgvector.

Acceptance criteria:
- App can list domains/documents from storage, not hardcoded arrays.
- Query history is persisted locally for admin view.

### 3. PDF extraction

Deliverables:
- Add text-PDF extraction dependency and server-side extraction helper.
- Implement controlled upload API path.
- Store source metadata and extracted text.

Acceptance criteria:
- A text-based PDF uploaded into Law or Sandbags is extracted and stored.
- Extraction failure returns a clear demo-safe error.

### 4. Chunking and embedding pipeline

Deliverables:
- Implement chunking helper with source/page/document metadata.
- Implement embedding provider interface.
- Initial provider: use local/mock deterministic embeddings if provider keys are unavailable; prefer Nomic/Ollama-compatible embeddings when viable.
- Store embedding model/source with each vector.

Acceptance criteria:
- Ingested document produces chunks with metadata.
- Chunks can be embedded and re-ingested cleanly during testing.

### 5. Retrieval and domain filtering

Deliverables:
- Implement vector similarity or demo-appropriate semantic retrieval.
- Add strict domain filters for selected domains.
- Support Law-only, Sandbags-only, and Law + Sandbags queries.

Acceptance criteria:
- Law-only queries return Law chunks only.
- Sandbags-only queries return Sandbags chunks only.
- Both-domain queries may return chunks from both selected domains.
- Unselected domains do not silently leak into results.

### 6. LLM answer generation and citations

Deliverables:
- Implement LLM provider interface.
- Primary planned provider: OpenAI.
- Additional planned provider: Ollama Cloud if OAuth/API access is viable.
- Build grounded-answer prompt that uses retrieved chunks only.
- Return citations/snippets/domain badges.

Acceptance criteria:
- Answer cites source chunks.
- Weak/missing evidence is stated clearly.
- No uncited answer is presented as grounded.

### 7. Tavily web comparison flow

Deliverables:
- Add Tavily provider wrapper.
- Implement external topic/article search or pasted-topic fallback.
- Compare external topic with internal retrieved chunks.
- Return related citations, gaps/confidence, and suggested article angle/outline.

Acceptance criteria:
- Demo can run one web/topic comparison flow.
- Output includes internal support, gaps, and suggested angle/outline.

### 8. UI integration

Deliverables:
- Update UI to Falcon Trust Research Workspace.
- Replace RFP/Journal with Law/Sandbags.
- Add domain selector with multi-select.
- Add upload panel.
- Add query panel.
- Add results/citation display.
- Add web topic comparison panel.
- Add local admin/history page.

Acceptance criteria:
- User can run the full demo flow from the UI.
- Source grounding and selected domain scope are obvious.

### 9. Local verification

Deliverables:
- Add smoke-test/demo script if practical.
- Run lint/build.
- Run manual local demo script.

Acceptance criteria:
- `npm run lint` passes.
- `npm run build` passes.
- Local demo script passes end-to-end.

### 10. AWS App Runner preparation

Gate:
- Only start after local workflow is working.

Deliverables:
- Confirm Docker build.
- Define required environment variables/secrets.
- Update AWS deployment notes.

Acceptance criteria:
- App is ready to deploy to AWS App Runner for customer review.

## Current next step

Start with tickets 1–2:

1. Create synthetic demo corpus and script.
2. Define local data/storage model.

Then implement PDF extraction and ingestion.

## Interface update — client search vs admin panel

Decision: the client-facing interface should be intentionally simple.

Client search page:
- Primary page is a clean search workspace.
- It should mainly contain a question/topic box and domain selector.
- Domain selector supports multi-select by click:
  - clicking one domain highlights it and scopes search to that domain
  - clicking a second domain leaves both highlighted and searches across both
- Domain statistics, document counts, chunk counts, upload controls, and query history should not clutter the client page.

Admin page:
- Admin panel moves to `/admin`.
- Admin contains domain/document/chunk counts.
- Admin contains document list, upload/index controls, and query history.
- Top navigation provides Search/Admin tab-style switching.

Rationale:
- Client demo should focus on the “ask a question or paste a link/topic” experience.
- Admin functionality remains available for demo management without distracting from the client value proposition.

## Answer behavior update — direct answer first

Decision: client search answers should not default to article/journal framing.

Search answer behavior:
- Default output should answer the user's question directly first.
- Citations/snippets should support that answer underneath.
- Article/outline/draft framing should appear only when the user explicitly asks for an article, outline, draft, publication angle, or external-topic comparison.
- Example: "What should we say about sandbag pickup rules before a flood?" should return practical pickup-rule guidance, not multiple journal-style answer options.

Rationale:
- Falcon Trust users are asking the knowledge base for an answer.
- The app can still support article workflows, but that should be intent-driven rather than the default response posture.

## Answer type control

Decision: answer type is an explicit user choice.

Client search defaults to `Clear answer`:
- one direct answer to the user's question
- citations underneath
- no journal/article framing by default

`Create article` is a separate answer type:
- selected by an explicit button near the search box
- produces draft/article-style wording only when selected

Rationale:
- Customer expectation for normal search is a clear answer.
- Article generation is valuable, but it should be an intentional workflow and not the default interpretation of every question.

## Demo serving stability

Decision: do not run the demo directly from a mutable `.next` build directory.

Observed issue:
- `next start` was left running while `.next` was rebuilt.
- Hard reload then requested stale CSS chunk paths from the old server manifest.
- The old CSS chunks returned HTTP 500, causing raw unstyled HTML.

Stable demo mechanism:
- Build the app.
- Copy `.next/standalone`, `.next/static`, `public`, and `demo-corpus` into an immutable `.demo-server/releases/<BUILD_ID>/` directory.
- Run `node server.js` from that release directory.
- Restart the demo by replacing the release symlink and process, not by mutating the build directory underneath a running server.

Script:
- `scripts/start-stable-demo.sh`
- Default port: `3035`

Acceptance check:
- `/` hard reload should keep CSS.
- CSS chunk referenced by HTML must return `200 text/css`.
- Clear Answer / Create Article controls must be visible after hard reload.

## Local Ollama Article Generation

Decision: wire only the explicit `Create Article` path to local Ollama. Keep `Clear Answer` deterministic and fast.

Configured local model lane:
- Ollama endpoint: `http://192.168.0.168:11435`
- Default article model: `qwen3.5:35b-a3b`
- Available local models verified from `/api/tags`: `qwen3.5:35b-a3b`, `gemma4:26b-128k`, `mistral:7b-instruct`, `gemma4:26b`, `nomic-embed-text:latest`

Admin article configurator:
- endpoint
- model
- audience
- tone
- length
- structure
- extra instructions
- inline citation marker toggle

Generation behavior:
- retrieve supporting citations first
- build an Ollama prompt with the selected sources and configurator settings
- request a multi-section article: headline, deck, body, checklist/key points, caveat/limits
- cite source numbers inline when configured
- fall back to the deterministic demo article text plus a warning if Ollama is unavailable

Reasoning:
- The wow moment is article drafting, not replacing the clear answer path.
- This preserves transparent source-grounded Q&A while making article generation feel real.
