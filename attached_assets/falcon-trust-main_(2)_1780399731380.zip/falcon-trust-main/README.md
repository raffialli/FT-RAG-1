# Falcon Trust

Phase 1 local prototype for a domain-aware RAG application. This is a polished browser demo built in Next.js with mock data and deterministic retrieval results so Raffi can review the concept in the morning without needing paid APIs or a live vector database.

## What this prototype includes

- **Next.js frontend** with a clean, click-through demo layout
- **3 demo domains** (easy to expand to 5–6 later):
  - Law
  - RFP
  - Journal / Sandbag-style research
- **Mock multi-domain RAG query flow**
- **External article/topic comparison workflow**
  - “I’ve seen journals talking about X — do any of my docs talk about X?”
- **Source-grounded answer cards** with mock citations/snippets
- **AWS-portable framing** for future deployment planning
- **Dockerized production-style packaging** for App Runner/ECS/Fargate evaluation

## Why mock retrieval instead of live embeddings?

For an overnight prototype, deterministic local demo beats brittle fake infrastructure. The UI and workflow are structured so the following can be swapped in later with minimal conceptual change:

- OpenAI embeddings + chat completion
- Postgres + pgvector
- S3-backed document storage
- AWS Secrets Manager
- Real ingestion/chunking pipeline
- RBAC / tenant permissions

## Run locally

```bash
cd /home/ralli/.openclaw/workspace/projects/falcon-trust
npm install
npm run dev
```

Then open:

- `http://localhost:3000`

## Run as a container

```bash
cd /home/ralli/.openclaw/workspace/projects/falcon-trust
docker compose up --build
```

Then open:

- `http://localhost:3000`

## Verification

```bash
npm run lint
npm run build
docker build -t falcon-trust .
```

## Current architecture

### Frontend
- Next.js App Router
- Tailwind-based styling
- Single-page prototype optimized for morning review/demo

### Demo data model
The prototype currently hardcodes mock objects in `src/app/page.tsx` for:
- domain summaries
- result cards
- query workflow steps
- mock ingestion status

This keeps the prototype simple and local, but the structure maps cleanly to a real backend model:

- `domains`
- `documents`
- `document_chunks`
- `queries`
- `citations`
- `users / permissions`

### Future production path
A reasonable production evolution from this prototype:

1. **Frontend**: Keep Next.js
2. **Backend**: Add route handlers / API layer
3. **Database**: Postgres + pgvector
4. **Storage**: S3 for document source files
5. **LLM/Embeddings**: OpenAI API
6. **Deployment**: Docker -> AWS App Runner / ECS / Fargate + RDS

See `docs/aws-portability.md` for the AWS packaging path and `docs/conversation-summary.md` for the saved project discussion.

## Suggested next steps

1. Expand from 3 to 5–6 real client domains
2. Replace hardcoded mock results with:
   - upload flow
   - chunking
   - embeddings
   - filtered retrieval by domain
3. Add a real “external article compare” input workflow
4. Add basic auth / domain permissions
5. Add infrastructure-as-code for AWS deployment proof

## Notes for morning review

This is intentionally **Phase 1 only**:
- no MCP server
- no agent workflow layer
- no paid API dependency
- no real AWS deployment yet

The goal is to make the opportunity visible fast, with enough polish to discuss architecture, demo value, and client fit.
