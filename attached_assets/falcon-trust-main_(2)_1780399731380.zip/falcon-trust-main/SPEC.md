# Falcon Trust RAG Application — Working Specification

## Status
Working internal spec. This document captures decisions as Raffi and Vega define the application. A polished customer-facing version will be derived from this spec.

## Project framing
Falcon Trust wants a functioning RAG application, not just a visual prototype. The application should let users query a private document corpus, retrieve grounded answers with citations, and later support agent-driven research/article workflows.

## Phases

### Phase 1 — Functioning basic RAG application
Build a working web application that can ingest documents, organize them by domain, retrieve relevant source chunks, and answer user questions with citations.

Potential Phase 1 extension areas:
- C-RAG / corrective retrieval behavior
- Internet/web information pull-in
- External article/topic comparison against internal documents

### Phase 2 — API or MCP exposure
Expose the RAG application as a callable tool so an agent or external system can query it programmatically.

Possible interface options:
- REST/JSON API
- MCP wrapper
- Both, if justified by use case and effort

### Phase 3 — Agent workflow
Develop or configure an agent that can search the web for relevant articles/topics, query the Falcon Trust RAG application, identify internal document support/gaps, and potentially draft article outlines or articles.

Candidate agent environments:
- Claude Code
- OpenClaw
- External/cloud agent systems

## Phase 1 scope distinction

### Limited demo inside Phase 1
The near-term limited demo is a subset of Phase 1 intended to show Falcon Trust the working concept quickly.

Limited demo characteristics:
- No login/auth required for the limited demo.
- Controlled demo environment only.
- Synthetic Law and Sandbags documents.
- PDF ingestion/search behavior may be demonstrated with controlled sample files.
- The goal is to prove workflow and customer fit, not production readiness.

### Full Phase 1 application
Full Phase 1 should include login/auth so access to uploaded documents and domain-scoped retrieval is controlled.

Full Phase 1 auth expectation:
- Users can log in.
- Uploaded documents are protected behind authenticated access.
- Domain access can be constrained by user/role if required.
- The limited demo should not be represented as the final security posture.

## Phase 1 primary workflows

### 1. Chat with private documents
Users can ask natural-language questions against Falcon Trust's internal document library.

Example questions:
- "What do I have on municipality rules around disasters?"
- "Which documents discuss emergency/disaster-related guidance?"
- "Summarize what our Law documents say about this topic."

Expected output:
- Grounded answer
- Source citations
- Document/chunk snippets
- Domain badges
- Clear statement when evidence is weak or missing

### 2. External topic/article comparison
Users can paste an external topic, article, or trend and ask whether internal documents speak to that topic.

Expected output:
- Related internal documents
- Relevant cited snippets
- Gaps or missing support
- Possible article angle or outline

## Domain model
Falcon Trust has approximately 10 planned domains/classes from customer whiteboarding. Phase 1 functioning demo will include two domains:

- Law
- Sandbags

The system must be built so additional domains can be added without major code rewrites.

## Domain isolation principle
The application should default to strict domain-scoped retrieval to prevent unrelated document chunks from dirtying answers.

Users should be able to query:
- One selected domain only
- Multiple selected domains
- All permitted domains

Cross-domain retrieval should happen only when explicitly selected by the user, not silently.

If no strong result exists in the selected domain, the app may offer to expand scope, for example:

> No strong Law results found. Search other domains?

## Phase 1 document format support
Phase 1 will support PDF documents only.

Supported PDF type for the limited demo:
- Text-based PDFs with extractable/selectable text

Rationale:
- Limiting Phase 1 to PDF keeps scope controlled while matching the expected customer document format.
- The current pipeline does not need OCR based on the latest project direction.
- Other formats can be added later if the customer confirms they are needed.

OCR posture:
- OCR is out of scope for the limited demo and should not be included unless Falcon Trust later confirms that image-only/scanned PDFs are required.
- If OCR becomes required later, evaluate AWS Textract or another OCR/document-extraction provider as a scoped extension.

## Upload and ingestion requirements
Users should be able to upload documents by domain.

Examples:
- Select Law → upload all Law documents
- Select Sandbags → upload all Sandbags documents

Each ingested document and chunk must be tagged with its domain.

The UI should derive upload dropdowns/filter options from the configured domain list so future domains appear automatically once added.

## LLM and embeddings provider strategy

### Reasoning / generation LLMs

Limited demo and Phase 1 should support a provider-based LLM layer rather than hardcoding one model path.

Initial provider plan:
- OpenAI API will be available and should be treated as the primary/reliable provider for the limited demo and early Phase 1.
- Ollama Cloud should be wired in as an additional provider if practical.

Ollama Cloud preference:
- Preferred access model: OAuth/subscription-based access, if supported/viable, so the project can use the paid monthly Ollama Cloud plan rather than per-key usage only.
- Fallback access model: Ollama Cloud API access if OAuth/subscription integration is not viable within the project constraints.

Implementation requirement:
- The app should abstract LLM calls behind a provider interface so OpenAI and Ollama Cloud can be swapped or selected without rewriting the RAG workflow.
- Provider credentials must be stored securely and not committed to the repository.
- The customer-facing spec should distinguish between app capability and provider subscription/API costs.

### Embeddings

Initial embedding provider plan:
- Prefer Nomic embeddings, since Raffi has used Nomic before and it is a known direction for this project.
- Preferred path: Nomic via Ollama/Ollama Cloud or an Ollama-compatible embedding endpoint, if available and reliable for the demo.
- AWS path: if Nomic is used “via AWS,” that likely means running or hosting the embedding service on AWS infrastructure; it should not be described as a native AWS managed Nomic offering unless verified.
- Fallback path: OpenAI embeddings if Nomic/Ollama Cloud embedding access is not viable within the limited-demo timeline.

Implementation requirement:
- Keep embeddings behind a provider interface so the project can switch between Nomic/Ollama-compatible embeddings and OpenAI embeddings without redesigning ingestion or retrieval.
- Record which embedding model produced each stored vector so future re-embedding/migration is manageable.

## Authentication approach

Limited demo:
- No authentication required.
- Demo runs in a controlled environment and should not contain real customer-sensitive documents.

Full Phase 1:
- Email/password login is required.
- Authentication should protect uploaded documents, domain-scoped retrieval, search history if retained, and any generated outputs.
- Enterprise SSO is out of scope unless Falcon Trust explicitly requests it later.

Implementation note:
- Auth should be selected with AWS deployment in mind.
- AWS Cognito is a strong candidate for AWS-native email/password auth.
- A framework-level auth option may be considered if it materially speeds development, but the spec should assume email/password as the user-facing requirement.

## Article generation posture

Article generation should be treated differently across the limited demo, full Phase 1, and Phase 3.

Limited demo inside Phase 1:
- Do not promise full article generation.
- Show cited internal matches, gaps/confidence, suggested article angle, and optionally a short outline.
- Keep outputs source-grounded and review-oriented.

Full Phase 1:
- Article brief/draft assistance may be optional or extended scope.
- If included, it should generate outlines or brief-style drafts grounded in retrieved citations.
- Full polished article generation should not be required for Phase 1 unless Falcon Trust explicitly prioritizes it.

Phase 3:
- Agent-driven article generation belongs here.
- The agent can search the web, identify articles/topics, query the Falcon Trust RAG application, check internal support/gaps, and draft article content with citations.

## Live internet search requirement
Full Phase 1 should include live internet search or live external-source lookup so users can discover outside articles/topics and compare them against Falcon Trust's internal corpus.

Limited demo handling:
- The limited demo may use a controlled live-search path or a constrained provider integration if time allows.
- If live search is not stable enough for the demo window, the fallback is pasted article/topic comparison while keeping live search in the full Phase 1 spec.

Provider decision:
- Tavily will be the initial live internet search provider for Phase 1.

Rationale:
- Tavily is purpose-built for AI/search workflows.
- It gives the build a concrete API integration target instead of leaving web search abstract.
- It should be faster to wire into the functioning demo than building a custom search/scraping workflow.

Architecture note:
- Even though Tavily is the initial provider, web search should still be abstracted behind a provider interface so the implementation can switch later if cost, quality, compliance, or AWS alignment changes.
- AWS remains the hosting/deployment target, but AWS does not provide a simple general-purpose public web search API equivalent to Tavily. AWS services may still support the surrounding architecture through Lambda, Bedrock, OpenSearch, S3, RDS, and Secrets Manager.

## Demo and deployment approach

Build and verification should proceed local-first before client exposure.

Limited demo path:
1. Build and run locally during development.
2. Verify ingestion, PDF text extraction, retrieval, citations, domain filtering, and Tavily search locally.
3. Demo to Falcon Trust from a controlled hosted environment rather than requiring local access.
4. During the demo, ask Falcon Trust which access model they prefer while Phase 1 continues.

Hosted access options during Phase 1:
- **Syndicate-hosted demo:** Massive AI Systems can host the limited demo on Syndicate infrastructure for quick customer review, temporary access, and fast iteration while the Phase 1 app is still being developed. This is appropriate when Falcon Trust wants to click through the demo without committing to AWS infrastructure yet.
- **AWS-hosted Phase 1 app:** The project can instead move to AWS during the demo/Phase 1 window so Falcon Trust has persistent access while development continues. This is the better path if always-on customer access, AWS alignment, or early production-like infrastructure is important.
- The demo conversation should explicitly ask whether Falcon Trust wants access to the Syndicate-hosted demo or prefers the Phase 1 project to be deployed into AWS at that point.

AWS target for limited demo / early Phase 1:
- AWS App Runner is the recommended initial AWS hosting target because the app is already Dockerized and App Runner is simpler to operate than ECS/Fargate for a demo or early Phase 1 review.
- App Runner can provide a managed HTTPS endpoint and reduce deployment overhead while the product shape is still being validated.

Production/hardened path:
- App Runner should be treated as the simple demo/early Phase 1 deployment path, not necessarily the final production architecture.
- If Falcon Trust moves toward production use, evaluate ECS/Fargate as the more configurable production container platform.
- Production deployment may also require RDS/Postgres + pgvector, S3 document storage, Secrets Manager, Cognito, logging/monitoring, backups, and tighter network/security controls.

Cost note:
- AWS-hosted Phase 1 introduces live infrastructure costs once deployed.
- The customer-facing spec should distinguish limited-demo hosting from production/hardened hosting so Falcon Trust understands cost increases when moving from demo to production-ready Phase 1.

Deployment posture:
- Local development remains the fastest iteration loop.
- Syndicate-hosted access is acceptable for the limited demo when speed and low friction matter most.
- AWS hosting before or shortly after the client demo gives the project a more persistent/customer-ready posture if Falcon Trust wants ongoing access.
- Full Phase 1 architecture should remain AWS-portable/AWS-aligned regardless of whether the first hosted demo is Syndicate-hosted or AWS-hosted.

## AWS service split

### Limited demo AWS services
The limited demo should use the smallest credible AWS footprint needed to show Falcon Trust a working hosted application.

Recommended limited-demo services:
- AWS App Runner for the Dockerized web application.
- App Runner environment variables or AWS Secrets Manager for provider credentials, depending on deployment complexity.
- Lightweight hosted Postgres/vector database if persistent retrieval storage is needed for the demo.
- Tavily API for live internet search.
- OpenAI API for primary LLM reasoning/generation.
- Nomic embeddings via Ollama/Ollama Cloud or Ollama-compatible endpoint if viable; OpenAI embeddings as fallback.

Limited-demo posture:
- No customer-sensitive production documents.
- No full production auth.
- No production-grade monitoring/backups beyond what is needed to safely demo.
- Keep infrastructure simple enough to deploy and iterate quickly.

### Full Phase 1 AWS services
Full Phase 1 should use a more complete AWS-aligned architecture suitable for controlled customer use.

Recommended full Phase 1 services:
- App Runner or ECS/Fargate for the application container.
- RDS Postgres with pgvector for document chunks, metadata, and vector search.
- S3 for uploaded source PDFs.
- Cognito for email/password authentication.
- Secrets Manager for provider/API credentials.
- CloudWatch for application logs and operational visibility.
- Backup/retention policies for database and source documents.
- Security hardening appropriate for customer document storage and authenticated access.

Production note:
- App Runner is preferred for speed and simplicity in the limited demo.
- ECS/Fargate should be evaluated for production/hardened Phase 1 if Falcon Trust needs more control over networking, scaling, deployment, and security posture.
- Customer-facing materials should clearly separate limited-demo hosting costs from full Phase 1 production/hardened infrastructure costs.

## Limited demo acceptance criteria

The limited demo must prove a real vertical slice of the Falcon Trust RAG workflow.

Must-pass acceptance criteria:
- User can upload or ingest a text-based PDF into a selected domain: Law or Sandbags.
- The application extracts text from the PDF.
- The application chunks and embeds the extracted document text.
- User can ask a question scoped to Law only and receive an answer using Law-domain sources only.
- User can ask a question scoped to Sandbags only and receive an answer using Sandbags-domain sources only.
- User can ask a question scoped to both Law and Sandbags and receive an answer that may draw from both selected domains.
- Answers clearly show citations/snippets and source-domain badges.
- Switching domain scope changes retrieval behavior and avoids silently mixing unselected domains.
- User can run Tavily-powered live internet search for an external topic/article.
- User can compare a web result/topic against internal documents.
- The application returns related internal citations, gaps/confidence, and a suggested article angle or outline.
- The demo avoids full article generation; article generation remains Phase 3 agent-driven unless later expanded.

## Product name and UI direction

Customer-facing product/demo name:
- Falcon Trust Research Workspace

UI direction:
- The limited demo should feel like a document research workspace, not a generic chatbot.
- The interface should support document/domain context, question asking, web search/topic comparison, citations, gaps, and article-angle/outline outputs.
- Recommended layout direction: upload/manage domain documents in one area and ask/search/review cited results in another area.

Rationale:
- “Research Workspace” is less technical than “RAG application” and better communicates business value.
- The UI should make source grounding and domain scope obvious to the customer.

## Limited demo session/admin posture

The limited demo should store local/demo-session query history and expose it through a simple admin panel.

Limited demo behavior:
- Store query/session history locally or in the demo database.
- Provide an admin panel to show recent questions, selected domains, retrieved sources, web-search comparisons, and generated article angles/outlines.
- The limited-demo admin panel does not need authentication, because the entire demo is controlled and should use synthetic/non-sensitive content.

Full Phase 1 behavior:
- Query/session history should be protected behind email/password authentication.
- Admin/history access should respect user/role permissions if Falcon Trust needs multiple users or restricted domain access.

Rationale:
- Even in the limited demo, showing local session/admin history demonstrates that the application can support auditability, review, and operational visibility later.
- The limited-demo lack of admin authentication must not be represented as the final security posture.

## Limited demo ingestion posture

The limited demo should use preloaded synthetic PDFs plus one controlled live upload path.

Rationale:
- Preloaded synthetic PDFs make the demo reliable and repeatable.
- A controlled upload path proves real ingestion without making the demo depend entirely on live upload behavior.
- This balances credibility with demo safety.

Demo content approach:
- Preload representative synthetic Law PDFs.
- Preload representative synthetic Sandbags PDFs.
- Include one controlled upload flow where a user can upload a PDF into Law or Sandbags and see it become queryable.

## Customer-facing deliverables planned
The project should produce three customer-facing artifacts, created in this order:

1. One-page high-level project overview
   - Phase 1 / Phase 2 / Phase 3
   - Purpose of each phase
   - What Falcon Trust receives
   - What is deferred
   - This should be reviewed first because customer feedback here may change the Phase 1 breakdown and detailed spec.

2. One-page Phase 1 limited-demo breakdown
   - Core workflows
   - Deliverables
   - Assumptions
   - Exclusions
   - Realistic vibe-coding hour range

3. Detailed specification sheet
   - Functional requirements
   - Acceptance criteria
   - Architecture
   - Data model
   - Build phases
   - Risks/assumptions
   - Updated after customer feedback on the overview and Phase 1 breakdown.

## Initial hour-estimate posture
Use ranges, not fixed commitments, until requirements are reviewed with the customer.

Important estimating principle:
- Estimates should use realistic vibe-coding numbers, not traditional enterprise development estimates.
- The estimate should still account for unknowns, integration friction, AWS deployment work, API/provider setup, and demo polish.
- Avoid presenting Phase 1 as a 90-hour project unless scope expands materially; at $150/hour that becomes a large commitment for a first demo.

Initial placeholder estimate for the limited demo inside Phase 1:
- 25–45 hours for the limited demo, assuming synthetic PDFs, no auth, controlled upload, Tavily integration, PDF text extraction, embeddings/vector search, cited answers, domain filtering, and AWS App Runner deployment.

Initial placeholder estimate for full Phase 1 beyond the limited demo:
- Additional hours should be estimated only after Falcon Trust reviews the overview/spec and confirms production expectations such as auth, real documents, persistent storage, hardened AWS services, and production support requirements.

This range should be refined after the customer-facing overview and Phase 1 breakdown are drafted.

## Source document strategy
Phase 1 will start with synthetic but realistic documents for the two demo domains: Law and Sandbags.

Reasoning:
- Avoids customer privacy/data handling blockers during early build.
- Allows controlled test cases with clear citations.
- Lets the functioning demo prove ingestion, chunking, domain filtering, retrieval, and cited answers before real customer files are provided.

Customer follow-up:
- Ask Falcon Trust for sample documentation during the next client conversation if available.
- Real samples can replace or supplement synthetic documents without changing the application architecture.

Synthetic document requirement:
- Synthetic documents must be clearly marked as demo/sample material.
- Synthetic documents should be realistic enough to exercise retrieval and citation behavior, but must not claim to represent actual Falcon Trust policy, legal advice, or proprietary material.

## Open questions
1. Should the limited demo use Nomic embeddings through Ollama/Ollama Cloud, or fall back to OpenAI embeddings if setup friction is high?
2. What exact vibe-coding hour range should appear on the customer-facing Phase 1 limited-demo breakdown?
3. What customer feedback from the one-page overview should be required before finalizing the detailed spec?
4. What exact demo script should the limited demo support end-to-end?

## Phase 1 Article Generation Addendum

Create Article is now a distinct LLM-assisted drafting workflow for the limited demo.

- Clear Answer remains the default deterministic RAG-style answer path.
- Create Article retrieves the same scoped supporting snippets, then sends the topic, snippets, and admin article settings to local Ollama.
- Default local Ollama endpoint: `http://192.168.0.168:11435`.
- Default article model: `qwen3.5:35b-a3b`.
- Admin includes an Article Configurator for model, endpoint, audience, tone, length, structure, extra instructions, and inline citation markers.
- Article generation must not invent unsupported municipal specifics such as dates, addresses, phone numbers, statistics, or legal conclusions.
- If local Ollama is unavailable, the app returns the prior template draft plus a visible generation warning instead of failing the entire demo.
