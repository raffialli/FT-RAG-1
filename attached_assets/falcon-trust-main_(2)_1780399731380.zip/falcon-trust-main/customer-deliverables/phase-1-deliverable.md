<p align="center">
  <img src="../brand/massive-ai-systems-logo.png" alt="Massive AI Systems LLC logo" width="180" />
</p>

<p align="center"><strong>Prepared by Massive AI Systems LLC</strong></p>

# Falcon Trust Research Workspace — Phase 1 Deliverable

## Phase 1 Objective

Phase 1 establishes the first working version of Falcon Trust Research Workspace: a source-grounded document research application that can ingest PDFs, organize documents by domain, answer questions with citations, and compare outside topics/articles against Falcon Trust's internal material.

Phase 1 is split into two parts:

1. **Limited Demo** — a near-term, hosted demonstration used to validate workflow, user experience, and customer fit.
2. **Full Phase 1 Completion** — the production-oriented expansion of the same application after Falcon Trust reviews and approves the direction.

---

## Part 1 — Limited Demo

### Purpose

The limited demo is intended to show Falcon Trust a functioning version of the core workflow without waiting for production hardening, real customer data handling, or full authentication.

The demo should prove that the system can:
- Ingest sample PDF documents
- Organize documents by domain
- Answer questions using selected domains only
- Return cited source snippets
- Search the web for outside topics/articles
- Compare web topics/articles against internal documents
- Suggest article angles or outlines based on internal support

### Demo Domains

The limited demo will use two initial domains:

- **Law**
- **Sandbags**

The application should be designed so additional domains can be added later without rewriting the system.

### Demo Document Strategy

The limited demo will use synthetic/sample PDFs rather than sensitive customer documents.

Demo content approach:
- Preloaded synthetic Law PDFs
- Preloaded synthetic Sandbags PDFs
- One controlled PDF upload path to prove live ingestion

This gives the demo predictable behavior while still showing real ingestion and retrieval capability.

### Limited Demo Capabilities

The limited demo should include:

- PDF text extraction for text-based PDFs
- Document chunking and embedding
- Domain tagging for documents and chunks
- Law-only search
- Sandbags-only search
- Law + Sandbags combined search
- Citation snippets and source-domain badges
- Tavily-powered live internet search
- External topic/article comparison against internal documents
- Gaps/confidence notes
- Suggested article angle or short outline
- Local/demo query history
- Simple unauthenticated admin panel for demo review/history
- AWS-hosted demo using AWS App Runner before customer review

### Limited Demo Exclusions

The limited demo does **not** include:

- Production authentication
- Real customer-sensitive documents
- Enterprise SSO
- Full production monitoring/backups
- OCR for image-only/scanned PDFs unless later added as a scoped change
- Full article generation
- Final production infrastructure hardening

### Limited Demo Estimate

Estimated effort depends on how polished and resilient the demo needs to be.

- **Lean limited demo:** approximately **8–15 hours**
- **Robust hosted limited demo:** approximately **18–30 hours**

Recommended estimate for customer planning:

> **18–30 hours** for a robust hosted limited demo, including implementation, test/tune cycles, AWS demo deployment, and walkthrough preparation.

A leaner 8–15 hour version is possible if the demo is highly scripted, uses mostly preloaded content, and minimizes AWS/deployment polish.

---

## Part 2 — Full Phase 1 Completion

### Purpose

Full Phase 1 takes the validated limited demo and expands it into a more complete application suitable for controlled Falcon Trust use.

### Full Phase 1 Capabilities

Full Phase 1 is expected to add or harden:

- Email/password login
- Protected document access
- Persistent document storage
- Persistent database/vector search
- Production-ready domain management
- More complete upload and ingestion workflows
- User/session history behind authentication
- Admin/history access with appropriate controls
- AWS-aligned deployment and security posture
- Provider configuration for OpenAI, Ollama Cloud, Nomic embeddings, and Tavily
- More complete error handling and operational logging
- Cost-aware infrastructure planning

### Recommended AWS Direction

Limited demo / early Phase 1:
- AWS App Runner for the Dockerized application
- Environment variables or Secrets Manager for provider keys
- Lightweight hosted vector/database option as needed

Full Phase 1 / hardened path:
- App Runner or ECS/Fargate for application hosting
- RDS Postgres with pgvector
- S3 for uploaded PDFs
- Cognito for email/password authentication
- Secrets Manager for credentials
- CloudWatch for logs/visibility
- Backup and retention planning
- Security hardening appropriate for customer documents

App Runner is recommended for demo speed and simplicity. ECS/Fargate should be evaluated if Falcon Trust moves toward production and needs more control over networking, scaling, deployment, and security.

### Full Phase 1 Estimate

The full Phase 1 estimate should be finalized after Falcon Trust reviews the limited demo and confirms production expectations.

Items that materially affect the final estimate include:
- Real document volume and quality
- Whether OCR is needed
- Authentication requirements
- Number of domains/users
- Production storage and retention needs
- AWS security and monitoring expectations
- Desired UI polish
- Whether article drafting remains out of scope or becomes part of Phase 1

For planning purposes, the limited demo should be treated as the decision point before committing to a full Phase 1 production estimate.

---

## Recommended Next Step

Proceed with the robust hosted limited demo.

This gives Falcon Trust a real application to review before finalizing the complete Phase 1 production scope. Feedback from the demo should drive the final specification, infrastructure choices, and full Phase 1 estimate.
