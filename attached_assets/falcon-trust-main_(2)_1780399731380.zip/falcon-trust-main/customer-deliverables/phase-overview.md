<p align="center">
  <img src="../brand/massive-ai-systems-logo.png" alt="Massive AI Systems LLC logo" width="180" />
</p>

<p align="center"><strong>Prepared by Massive AI Systems LLC</strong></p>

# Falcon Trust Research Workspace — Project Overview

## Purpose

Falcon Trust Research Workspace is a phased application initiative for turning Falcon Trust documents into a searchable, source-grounded research system. The goal is to let users ask questions against internal documents, control which document domains are searched, compare outside topics/articles against internal material, and later expose the system to agents for automated research workflows.

This project is intentionally phased so Falcon Trust can first review a functioning limited demo, then decide how far to take the system toward production and agent-driven automation.

---

## Phase 1 — Functioning RAG Application

**Goal:** Build a working web application that can ingest Falcon Trust documents, organize them by domain, retrieve relevant source material, and answer questions with citations.

**Core capabilities:**
- PDF document ingestion
- Domain-based organization, starting with **Law** and **Sandbags**
- Strict domain-scoped search to avoid unrelated documents influencing answers
- Ability to search one domain, multiple selected domains, or all permitted domains
- Natural-language Q&A over internal documents
- Source citations, snippets, and domain badges
- Tavily-powered live internet search for outside topics/articles
- Internal-corpus comparison against web topics/articles
- Suggested article angle or outline, without full article generation in the initial demo

**Near-term limited demo:**
- Uses synthetic/sample PDFs, not sensitive customer documents
- No login/auth for the demo environment
- Includes preloaded Law and Sandbags documents plus one controlled upload path
- Runs locally during development, then moves to AWS App Runner before customer review
- Demonstrates the workflow before committing to production hardening

**Full Phase 1 expansion:**
- Email/password login
- Protected document storage
- Persistent database/vector search
- AWS-aligned deployment and security posture
- Production cost and infrastructure planning

---

## Phase 2 — API or MCP Exposure

**Goal:** Expose the Research Workspace as a callable tool so agents or other systems can query Falcon Trust's private knowledge base programmatically.

**Possible paths:**
- REST/JSON API
- MCP wrapper
- Both, if the use case justifies it

**Why it matters:**
Phase 2 lets the same document intelligence built in Phase 1 become a service that outside automation or internal agents can use without rebuilding the RAG system.

---

## Phase 3 — Agent-Assisted Research Workflow

**Goal:** Build or configure an agent that can search the web, identify relevant articles/topics, query Falcon Trust Research Workspace, find internal support or gaps, and help draft article material.

**Potential agent workflow:**
1. Search the web for relevant articles or topics.
2. Identify themes Falcon Trust may want to respond to or write about.
3. Query Falcon Trust's internal corpus by domain.
4. Return supporting documents, citations, and gaps.
5. Produce an article brief, outline, or draft for human review.

**Candidate agent environments:**
- Claude Code
- OpenClaw
- External/cloud agent systems

---

## Recommended Starting Point

Start with the limited demo inside Phase 1:

- Prove PDF ingestion, domain filtering, retrieval, citations, web-topic comparison, and article-angle output.
- Use synthetic Law and Sandbags documents for safety and speed.
- Host the demo on AWS before review.
- Use the demo feedback to refine the full Phase 1 scope, hours, and production architecture.

This approach gives Falcon Trust something concrete to react to quickly while keeping the longer-term architecture aligned with API/MCP exposure and future agent workflows.
