# DEMO SAMPLE — Public Claims and Publication Risk Note

This synthetic document is for Falcon Trust Research Workspace demonstration only. It is not legal advice and does not represent Falcon Trust confidential material.

## Summary

Falcon Trust publications should distinguish between documented evidence, operational experience, and opinion. When drafting public-facing articles, the organization should avoid unsupported superiority claims, broad safety guarantees, or statements that imply regulatory endorsement.

## Evidence-grounded writing

A safe article angle should cite the internal record and clearly describe the limits of the evidence. If the organization only has operational notes or local examples, the article should say so. If broader public claims are needed, the draft should identify evidence gaps before publication.

## Disaster preparation language

For sandbag-related disaster content, recommended language should explain that sandbags are one mitigation tool. The article may discuss planning, distribution logistics, and public education, but should not imply sandbags are sufficient for severe flood events.

## Review checklist

Before publication, reviewers should check: source support, claim strength, audience, legal sensitivity, and whether the draft makes promises that Falcon Trust cannot substantiate.
