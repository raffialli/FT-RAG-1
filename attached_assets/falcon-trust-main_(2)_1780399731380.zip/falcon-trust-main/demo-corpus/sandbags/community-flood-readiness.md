# DEMO SAMPLE — Community Flood Readiness Notes

This synthetic document is for Falcon Trust Research Workspace demonstration only. It does not represent Falcon Trust confidential material.

## Summary

Community flood readiness depends on early communication, clear pickup instructions, volunteer coordination, and realistic public expectations. Sandbags work best when residents understand when they help and when evacuation or other mitigation is more important.

## Distribution priorities

Distribution plans may prioritize critical facilities, elderly residents, low-lying neighborhoods, and areas with repeated nuisance flooding. A documented prioritization plan helps reduce confusion when supplies are limited.

## Public education

Residents should receive guidance on how many bags are likely needed, how to place them, and what sandbags cannot do. Outreach should emphasize that sandbags are temporary and do not replace flood insurance, evacuation orders, drainage maintenance, or structural mitigation.

## After-action review

After a flood event, coordinators should review demand, wait times, supply shortages, volunteer staffing, traffic management, and public complaints. Lessons learned should update the next distribution plan.
