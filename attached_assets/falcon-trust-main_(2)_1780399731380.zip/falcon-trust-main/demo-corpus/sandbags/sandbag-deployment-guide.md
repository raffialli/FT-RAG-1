# DEMO SAMPLE — Sandbag Deployment Guide

This synthetic document is for Falcon Trust Research Workspace demonstration only. It does not represent Falcon Trust confidential material.

## Summary

Sandbags are useful for redirecting shallow moving water and reducing minor flood intrusion around doors, garage openings, low vents, and other vulnerable entry points. They are not designed to stop deep floodwater, storm surge, or structural flooding.

## Site setup

A practical sandbag site should include clear entry and exit lanes, staging pallets, shovel stations, volunteer safety instructions, and a visible limit per household. Sites should be placed outside expected flood zones and near major travel routes when possible.

## Placement guidance

Sandbags should be filled about one-half to two-thirds full so they can conform to surfaces. Bags should be staggered like bricks and tamped into place. Plastic sheeting may improve performance when placed between the structure and the sandbag wall.

## Disposal

Used sandbags may contain petroleum, sewage, chemicals, or other contaminants. Public instructions should tell residents not to reuse contaminated sand in playgrounds, gardens, or sandboxes. Disposal rules should follow local waste guidance.
