# Falcon Trust Research Workspace — Limited Demo Script

## Goal

Prove the limited demo can answer domain-scoped questions over synthetic Law and Sandbags documents, cite sources, compare an outside topic, and show local admin/history evidence.

## Preloaded demo documents

Law:
- Municipal Emergency Authority Brief
- Public Claims and Publication Risk Note

Sandbags:
- Sandbag Deployment Guide
- Community Flood Readiness Notes

## Must-pass demo questions

### Law-only

Question:
> What legal or public-claims risks should we keep in mind when writing about sandbags?

Expected behavior:
- Search Law only.
- Cite Public Claims and Publication Risk Note.
- Mention avoiding unsupported guarantees and using evidence-grounded language.
- May cite Municipal Emergency Authority Brief for public communication risk.

### Sandbags-only

Question:
> What should residents know about using and disposing of sandbags?

Expected behavior:
- Search Sandbags only.
- Cite Sandbag Deployment Guide.
- Mention half/two-thirds filling, staggered placement, limitations, and contaminated disposal concerns.

### Law + Sandbags

Question:
> Can we write an article about municipal sandbag distribution before a flood, and what should it say?

Expected behavior:
- Search Law and Sandbags.
- Cite at least one Law document and one Sandbags document.
- Mention distribution logistics, prioritization, realistic expectations, and legal/public-claim caution.

### Weak evidence / gap

Question:
> Do these documents prove sandbags prevent all flood damage?

Expected behavior:
- State no.
- Cite Sandbag Deployment Guide and/or legal/public communication risk notes.
- Explain that sandbags reduce minor intrusion risk but do not guarantee protection.

## External topic comparison

Topic:
> Local news reports say residents are frustrated by confusing sandbag pickup rules before major storms.

Expected behavior:
- Compare topic against internal documents.
- Cite Community Flood Readiness Notes for distribution priorities/public education.
- Cite Municipal Emergency Authority Brief for eligibility/public notices.
- Return a suggested article angle: clear sandbag pickup rules reduce confusion and improve emergency readiness.
- Identify gaps/confidence: documents support logistics and communication, but do not include real resident survey data.

## Admin/history demo

Expected behavior:
- Show recent questions.
- Show selected domains.
- Show retrieved source documents/snippets.
- Show whether query was internal Q&A or external comparison.
