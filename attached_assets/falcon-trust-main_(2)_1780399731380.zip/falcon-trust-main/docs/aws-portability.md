# AWS Portability Notes

## Current status

The prototype is now packaged as a production-style Dockerized Next.js app. It is not a full AWS production deployment yet, but it is shaped so the UI/demo can be moved to AWS without rewriting the app shell.

## What is ready now

- Next.js app builds successfully.
- `next.config.ts` uses `output: "standalone"` for container runtime.
- `Dockerfile` builds a small production runtime image.
- `docker-compose.yml` provides a local container smoke path.
- No paid API keys or cloud resources are required for the current mock demo.

## Good AWS targets for Phase 1 demo hosting

### Option A: AWS App Runner
Best for fastest client-visible container demo.

- Push image to ECR.
- Create App Runner service from ECR image.
- Set port to `3000`.
- Add environment variables/secrets later when real APIs are introduced.

### Option B: ECS Fargate
Best when we know this is becoming a fuller production app.

- Push image to ECR.
- Run as ECS/Fargate service behind an ALB.
- Add RDS Postgres + pgvector later.
- Add S3 for source documents later.
- Add Secrets Manager for OpenAI/API keys later.

## Production RAG evolution

The app should evolve behind the same interface:

1. Replace hardcoded mock data with API route handlers.
2. Add Postgres schema:
   - `domains`
   - `documents`
   - `document_chunks`
   - `citations`
   - `queries`
   - `users`
   - `permissions`
3. Add pgvector for embeddings.
4. Store uploaded source files in S3.
5. Use OpenAI for embeddings and answer synthesis.
6. Add auth and domain-level RBAC before any real client data.
7. Add audit logs for queries, citations, and generated article drafts.

## Article-writing use case

The prototype already includes the key workflow concept:

> External article/topic → extract theme → compare against internal domain-tagged corpus → return matching internal snippets/citations → suggest safe article angle.

For production, this should become a first-class workflow:

- User pastes a journal URL, excerpt, or topic.
- System extracts themes/entities/claims.
- User chooses domains or accepts suggested domains.
- Retrieval searches only permitted domains.
- Answer identifies:
  - internal support
  - citation snippets
  - gaps/no-support areas
  - safe writing angles
  - claims needing review
- Optional later step: draft outline/article section grounded only in cited internal docs.

## Not included yet

- Real ingestion/chunking pipeline
- Real vector search
- Real OpenAI calls
- Auth/RBAC
- AWS infrastructure-as-code
- CI/CD
- MCP or external agent layer

Those are Phase 1 hardening / Phase 2+ items, not needed for the morning prototype review.
