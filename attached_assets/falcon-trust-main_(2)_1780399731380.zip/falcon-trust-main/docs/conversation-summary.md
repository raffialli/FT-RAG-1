# Falcon Trust RAG App Conversation Summary

Date: 2026-05-07 early morning

## Opportunity

Raffi identified Falcon Trust as the actual company name for the RAG application opportunity. This may be an opportunity to fund The Syndicate. The client need appears more involved than a basic “drop docs in a folder and chat with them” app.

## Core Phase 1 concept

Build a browser-based domain-aware RAG app:

- Next.js frontend
- local prototype first
- AWS-portable packaging
- domain-tagged document corpus
- multi-domain retrieval
- citations/source snippets
- external article/topic comparison workflow
- no MCP or agent layer in Phase 1

## Domain model discussed

The app should support separate document domains without needing separate vector databases for each domain.

Possible domains mentioned:

- Law
- RFP
- Sandbag/Product/Patent-style domain
- Journal/research domain
- potentially 5–6 domains in the real client version

Isolation options discussed:

- one vector DB with metadata filtering
- collections/namespaces
- Postgres + pgvector with `domain_id`
- domain router before retrieval
- user-selected domains plus optional smart suggestions

Preferred Phase 1 direction:

- one app
- one Postgres-compatible model later
- chunks tagged with `domain_id`
- query scoped by selected/allowed domains
- cross-domain retrieval allowed only when intended/authorized

## Cross-domain query behavior

Users may ask questions spanning two or more domains, for example legal requirements plus patent/product material.

Recommended behavior:

1. user asks a question or pastes article/topic
2. app recommends likely domains
3. permissions filter allowed domains
4. retrieval searches selected domains
5. answer synthesizes results with citations by source/domain

Do not rely only on the raw prompt; use explicit domain selection plus routing/classification.

## Article-writing use case

Important client requirement Raffi restated before bed:

Clients want to write articles based on:

- documents they already have
- articles/journals/trends they are seeing in their field
- popular things happening externally

Codified workflow:

> External Signal → Internal Corpus Check → Article Draft Assist

Phase 1 should show:

- user enters/pastes an external article topic or journal excerpt
- system asks: “Do any of my documents talk about X?”
- system finds matching internal material across selected domains
- result shows citations/snippets
- system suggests safe article angles and gaps

Production later could add article outline/draft generation grounded only in cited internal docs.

## MCP / agent discussion

MCP is not needed for the Phase 1 browser app.

Phase framing:

1. Phase 1: browser-based domain-aware RAG app
2. Phase 2: expose RAG app as MCP/API tool
3. Phase 3: agent workflows using the RAG system

If Phase 2/3 never happen, users can still use the Next.js frontend for normal queries.

MCP only matters if an external agent needs the RAG system as a tool, such as:

- Claude Desktop / Claude Code
- OpenClaw-style agent
- custom backend automation agent
- IDE assistant or other MCP-capable client

Recommended product framing:

> secure, domain-aware knowledge platform that humans, apps, and agents can all query.

But for the client prototype, lead with the human-facing web app.

## AWS portability discussion

The client may prefer AWS hosting. We can build locally in The Syndicate lab and ship later to AWS.

Preferred portability practices:

- Dockerized app
- environment-variable configuration
- no hardcoded local paths
- migrations later
- S3-compatible document storage abstraction later
- RDS Postgres + pgvector later
- OpenAI API key via AWS Secrets Manager later
- App Runner or ECS/Fargate for container hosting

The current prototype is mock-only but should be packaged in a way that proves the deployment direction.

## Effort estimate discussion

For Phase 1 prototype only:

- Internal realistic estimate discussed: roughly 35–60 hours for tight local prototype, or higher once real requirements/client feedback enter.
- Customer-facing conservative range discussed: 60–80 hours for Phase 1 prototype.
- At $150/hr:
  - 16 hours = $2,400
  - 60 hours = $9,000
  - 80 hours = $12,000

## Current prototype status

Prototype path:

`/home/ralli/.openclaw/workspace/projects/falcon-trust`

It includes:

- Next.js frontend
- 3 mock domains: Law, RFP, Journal/Sandbag-style research
- mock RAG query workspace with a real textarea/search interaction
- deterministic keyword routing
- source-grounded citations/snippets
- external article/topic comparison concept
- Docker/AWS portability notes

Local URL while dev server is running:

`http://localhost:3000/`

Network URL observed from Next dev server:

`http://172.22.2.10:3000/`

Live proof performed:

- curl to `http://localhost:3000/` returned HTTP 200
- after adding the query box, curl returned HTTP 200 and page contained `Ask the prototype`

## Morning review checklist

- Click through prototype UI.
- Confirm the search box / query workspace feels obvious enough.
- Expand mock domains from 3 to 5–6 if useful.
- Tune wording for client-facing demo.
- Decide whether to add a live upload mock screen.
- Decide whether to create a simple builder materials/proposal doc.
- Keep Phase 2 MCP and Phase 3 agents parked unless client asks for automation.
