# Falcon Trust Overnight Autonomy Notes — 2026-05-08

## Purpose

Durable handoff for the overnight Falcon Trust demo-hardening run. This file captures the operational state, decisions, QA findings, and safe next steps so the demo does not depend on chat context.

## Non-negotiable anchors

- Preserve the current ready demo on `3035` unless Raffi explicitly asks to replace it.
- Use only open firewall ports in `3000–3341`.
- Use `3036` for continuation/patched testing.
- Use `3037`, `3038`, and optionally `3039` for alternate limited-demo UI skins.
- Alternate UIs must stay at limited-demo scope: same function, different look/layout only.
- Avoid overbuilding before the customer presentation.

## Live lanes

| Lane | Purpose | Notes |
| --- | --- | --- |
| `3035` | Preserved ready-demo anchor | Stable limited demo; do not disturb. |
| `3036` | Continuation/patched lane | Used for safe fixes and verification. |
| `3037` | UI variant slot 1 | Planned for best alternate skin. |
| `3038` | UI variant slot 2 | Planned for second alternate skin. |
| `3039` | Optional UI variant slot 3 | Only keep if genuinely useful. |

## Commits and remote branch

Local workspace commits:

- `a7ab6b93` — `Add Ollama-backed article generator`
- `b07599c1` — `Polish demo intent matching and admin loading`

Exported/pushed to `raffialli/falcon-trust` branch `spec/phase-1`:

- `792341f0` — exported article-generator commit
- `31ef9f5e` — exported polish commit

## Completed work

### Stable demo serving

Problem found: running `next start` from a mutable `.next` while rebuilding caused stale CSS chunk references and hard-refresh failures.

Resolution:

- Demo serving now uses immutable release copies under `.demo-server/releases/...`.
- Hard reload/static CSS paths verified 200 after stable start.
- `.demo-server/**` excluded from eslint.
- Added `demo:stable` script.

### Article generation

- `Create Article` now calls local Ollama while `Clear Answer` remains deterministic/template-backed.
- Default endpoint: `http://192.168.0.168:11435`.
- Default model: `qwen3.5:35b-a3b`.
- Added Admin article configurator for endpoint/model/audience/tone/length/structure/extra instructions/inline citations.
- Updated `SPEC.md` and `IMPLEMENTATION_PLAN.md`.

Important model behavior:

- `qwen3.5:35b-a3b` returned hidden thinking but empty response unless request includes `think:false`.
- With `think:false`, article generation succeeded and returned multi-section article content.

### Functional polish

- Fixed query intent bug where generic `proof`/`prove` triggered the absolute flood-prevention caution answer.
- Example fixed: `proof of residency for sandbag pickup` now returns pickup-rule guidance.
- True absolute query still works: `Do these documents prove sandbags prevent all flood damage?` returns caution/gaps.
- Admin metrics now show `Loading…` during hydration rather than misleading zeroes.
- Upload copy explicitly says simple text PDFs only; scanned/image-only PDFs are out of scope.

## QA findings

### Product/spec review

Best guidance: good demo base, do not overbuild.

Safe polish ideas:

- Align example prompts to demo script.
- Clean query history before showing Admin if noisy.
- Make selected scope more visible.
- Spotlight weak-evidence/gap behavior as a feature.
- Clarify external-topic comparison only if it will be shown.

Reject before demo:

- Real vector DB/embeddings.
- Auth.
- OCR/richer upload workflows.
- Enterprise admin features.
- Full dashboard expansion.
- LLM-backed `Clear Answer`.

### Functional QA

Fixed:

- Generic `proof` intent bug.

Remaining non-blocking notes:

- Admin is client-hydrated. Loading state helps, but true server-side initial data is later work.
- Article generation latency depends on local Ollama.
- Upload route is text-PDF only; copy now says this.
- `/api/compare` may need wording cleanup if shown live.
- Query history is noisy from tests; clean if showing Admin.

### Stress QA on 3035

- `/` 200 OK.
- `/admin` 200 OK.
- Sampled static assets all 200.
- `/api/admin/article-config`, `/api/corpus`, `/api/admin/history` all 200 and fast.
- `GET /api/query` returns 405 as expected; POST-only.
- Clear-answer sequential/concurrent checks pass quickly.
- Create Article sequential/concurrent checks pass with Ollama.
- Article generation latency varied about 6–20 seconds; not demo-blocking, but frame as active drafting.

## Alternate UI variant lane

Raffi requested alternate UIs so the customer can choose a look.

Prepared isolated source copies:

- `variants/editorial` — premium legal/editorial research desk; warm ivory/ink/burgundy/gold.
- `variants/civic` — public-service command center; light blue/white/navy.
- `variants/modern` — modern AI SaaS/glassmorphism; black/violet/electric blue.

Rules:

- Variants are design skins only.
- Preserve functional behavior/API routes.
- Do not change parent demo or 3035.
- Build and serve only good variants on `3037–3039`.
- Judge before recommending to Raffi/customer.

## Recommended morning path

1. Verify `3035` is still serving the preserved demo.
2. Verify `3036` only if using the patched continuation lane.
3. Review variant outputs and serve the best 2–3 on `3037–3039`.
4. Clean query history if Admin will be shown live.
5. Do not add major features before the presentation; polish and proof are higher value now.

