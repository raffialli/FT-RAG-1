# FalconTrust RAG Before-Change Baseline Suite - 2026-05-30

## Scope

This suite captures the before-change RAG retrieval/generation baseline for branch `rag-retrieval-generation-dev-20260530` at `16db861d49153399cc24c03fcd69895431e4fea4`.

Proof level: local offline fixture and diagnostics proof. It does not call AWS, App Runner, Bedrock, S3, staging, demo, production, or a live vector index.

Harness:

```bash
FALCON_RAG_DIAGNOSTICS_MODE=offline \
FALCON_RAG_DIAGNOSTICS_ENV=before-change-local \
FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR=docs/rag-quality/runs/20260530-before \
npm run test:rag-diagnostics
```

Local paths inspected:

- `scripts/rag-diagnostics.mjs`
- `tests/rag/regression-harness.mjs`
- `tests/rag/fixtures/rag-diagnostics-queries.json`
- `tests/rag/fixtures/rag-eval-cases.json`
- `src/lib/falcon/retrieval.ts`
- `src/lib/falcon/retrieval-backends.ts`
- `src/lib/falcon/retrieval-ranking.ts`

## Coverage Map

- Manufactured housing retrieval: `manufactured-housing-retrieval` verifies the offline baseline returns a gap/no-support result unless local corpus evidence explicitly discusses manufactured housing eligibility or protections.
- Reference leakage: `sandbag-pickup-rules`, `niger-wmo-reference`, `wri-flood-exposure-reference`, `index-reference-false-positive`, `citation-count-confidence-trap`, `index-reference-filter-preserves-body`, `academic-reference-list-excluded-preserves-body`.
- OCR/layout: `mobile-warning-artifact`, `technology-exclusion-joined-heading`, `page-header-author-artifact`, `ocr-layout-noise-baseline`.
- Metadata visibility: `metadata-source-display` plus fixture debug trace fields for chunk id, document id, score, content type, source path, and metadata.
- Hybrid/reranking: fixture diagnostics preserve scores, selected/final chunks, filtered reference counts, selected body citation counts, and recommended work buckets, but no live hybrid backend is called in this baseline.
- Negative hallucination control: `sandbags-prevent-all-damage`, `bridge-inspection-contractor`, `fema-current-policy`, `unanswerable-no-support`, `weak-coincidental-answerability`.

## Golden Diagnostic Queries

Each query is evaluated by the diagnostics harness for expected behavior, known bad patterns, support level, evidence health, and failure class.

| ID | Category | Support Level | Question | Expected / Pass-Fail Criterion |
| --- | --- | --- | --- | --- |
| mobile-warning-artifact | ocr-heavy | supported-with-artifact-risk | What does the corpus say about mobile flood early warning systems? | Capture known figure/OCR artifact baseline without fixing it. |
| sandbags-prevent-all-damage | unsupported | unsupported | Do these documents prove sandbags prevent all flood damage? | Return bounded no/gap behavior; avoid complete-protection overclaim. |
| sandbag-pickup-rules | reference-leakage | weak-or-unsupported | What should we say about sandbag pickup rules before a flood? | Avoid WMO/Niger/WRI bibliography evidence; gap if unsupported. |
| fews-mobile-warning | supported | supported | What does the mobile warning or FEWS evidence say about reaching people before floods? | Use FEWS/mobile warning body evidence without frontmatter/reference/OCR leakage. |
| legal-public-claims-sandbags | weakly-supported | weak-or-unsupported | What legal cautions apply to public claims about sandbag protection? | Low confidence acceptable unless direct legal/public-claim support is found. |
| current-flood-warning-japan | supported | supported | What does the Japan flood warning system paper say about warning effectiveness? | Cite body evidence from Japan warning-system document. |
| community-resilience-recovery | supported | supported | What recovery or resilience lessons appear after a major flood? | Retrieve substantive community resilience body evidence. |
| hazus-flood-loss-model | supported | supported | Which software or model helps estimate flood losses for hazard mitigation planning? | Retrieve HAZUS-MH body evidence. |
| life-safety-model-fatalities | supported | supported | What kinds of fatalities does the life safety model discuss? | Retrieve body evidence from life-safety modeling. |
| preparedness-workshop-kits | supported | supported | What changed after the preparedness workshop about emergency kits? | Retrieve body evidence from preparedness curriculum material. |
| south-sudan-local-measures | supported | supported | What locally driven flood risk reduction measures were used in South Sudan? | Retrieve South Sudan body evidence about structural or non-structural measures. |
| contract-law-basics | supported | supported | What are the basic elements of contract law relevant to emergency management contracts? | Retrieve legal duties/contracts body evidence. |
| bridge-inspection-contractor | unsupported | unsupported | Which bridge inspection contractor signed the 2026 renewal? | Return a gap/no-support answer. |
| fema-current-policy | unsupported | unsupported | What is FEMA's current 2026 policy for sandbag reimbursement? | Do not invent current policy from local documents. |
| frontmatter-title-pages | frontmatter-leakage | unsupported-or-filtered | What is the ISBN or catalog record for Flood Risk Management Global Case Studies? | Frontmatter/catalog chunks should not become final operational answer evidence. |
| table-of-contents-query | frontmatter-leakage | unsupported-or-filtered | What does the table of contents list for flood risk management case studies? | TOC/list chunks should be detected as index-like evidence. |
| figure-list-query | frontmatter-leakage | unsupported-or-filtered | What figures are listed in the flood risk management case studies document? | Figure-list chunks should be detected as index-like evidence. |
| niger-wmo-reference | reference-leakage | reference-only-risk | What does the corpus say about Niger flood early warning progress? | Bibliography-only WMO/Niger material should be flagged and not treated as support. |
| wri-flood-exposure-reference | reference-leakage | supported-with-reference-risk | Which countries have the highest exposure to river flood risk? | Prefer body evidence; flag WRI bibliography-only reliance. |
| technology-exclusion-joined-heading | ocr-heavy | supported-with-artifact-risk | What does the corpus say about technological exclusion in flood warnings? | Flag joined-heading artifacts while preserving useful body evidence. |
| page-header-author-artifact | ocr-heavy | supported-with-artifact-risk | What does Abigail Tevera say about flood warning systems? | Flag page header/author artifacts in final evidence. |
| mid-word-boundary | chunk-readability | supported-with-boundary-risk | What does the corpus say about flood preparedness and economic loss? | Flag snippets that start/end mid-word where avoidable. |
| duplicate-overlap-evidence | chunk-readability | supported-with-overlap-risk | What are the steps in the flood warning chain? | Flag excessive duplicate or overlapping citation evidence. |
| metadata-source-display | metadata | supported | Which document discusses public engagement, governance, and policy in international flood case studies? | Require chunk id/title/index/source metadata for source display. |
| manufactured-housing-retrieval | manufactured-housing | unsupported | What does the corpus say about manufactured housing eligibility or protections? | Return a gap/no-support answer unless local corpus evidence explicitly discusses manufactured housing eligibility or protections. |

## Offline Fixture Cases

Each fixture records exact synthetic chunks/context, current answer text, citation ids, expected booleans/criteria, debug trace fields, and failure classes in the generated JSON results.

| ID | Category | Question | Expected / Pass-Fail Criterion |
| --- | --- | --- | --- |
| answerable-body-evidence | answerable-body-evidence | What did the Harbor Civic Center advisory say about voluntary evacuation? | Answerable, supported, section-separated, high confidence. |
| unanswerable-no-support | unanswerable-no-support | Which bridge inspection contractor signed the 2026 renewal? | Not answerable, unsupported, not high confidence. |
| index-reference-false-positive | index-reference-false-positive | What does the Harbor Civic Center evacuation advisory say? | Detect index/reference false positive and reference-only citations; not high confidence. |
| weak-coincidental-answerability | answerability-weak-evidence | Which contractor signed the 2026 bridge inspection renewal? | Return insufficient-support behavior for weak coincidental evidence. |
| strong-direct-answerability | answerability-direct-evidence | Which contractor signed the 2026 bridge inspection renewal? | Preserve direct body-evidence answerability and high confidence. |
| citation-count-confidence-trap | citation-count-confidence-trap | What percentage of residents had emergency kits after the workshop? | Citation count alone must not produce high confidence. |
| template-vs-evidence-separation | template-vs-evidence-separation | What should residents do before road closures? | Keep document-supported claims separate from general guidance. |
| confidence-two-citation-strong-support | confidence-scoring | What did the readiness update say about evacuation routes and shelter timing? | Two strong direct citations should score high confidence. |
| confidence-one-citation-moderate-support | confidence-scoring | What did the sandbag bulletin say about pickup identification? | One supported citation should score medium, not high. |
| index-reference-filter-preserves-body | index-reference-filtering | What did the shelter memo say about evacuation bus pickup locations? | Filter reference material while preserving body citation. |
| academic-reference-list-excluded-preserves-body | bibliography-reference-filtering | What percentage of respondents had personal emergency kits one year after the preparedness workshop? | Exclude bibliography/reference list while preserving body citation. |
| ocr-layout-noise-baseline | ocr-layout-noise | What does the logistics bulletin say about sandbag pickup hours? | Capture OCR/layout noise baseline; do not normalize in this run. |

## Result Requirements

The before-change run must write:

- `docs/rag-quality/runs/20260530-before/baseline.json`
- `docs/rag-quality/runs/20260530-before/baseline.md`
- timestamped `baseline-offline-*.json` and `baseline-offline-*.md`
- `latest-offline.json`

The JSON result is the canonical detailed artifact for actual answers, chunks/context, citations, diagnostics/scores, metadata, pass/fail or inconclusive state, and failure category.

## Hard Exclusions

This baseline must not include implementation fixes, AWS commands, deployment, staging/demo/prod mutation, merge work, index/vector mutation, customer document export, or secret printing.
