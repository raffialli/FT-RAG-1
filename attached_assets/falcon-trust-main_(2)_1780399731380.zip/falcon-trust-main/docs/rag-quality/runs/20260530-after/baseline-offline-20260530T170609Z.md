# RAG Diagnostics Baseline
Generated: 2026-05-30T17:06:09.898Z
Mode: offline
Environment: after-runtime-local
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
## Recommended Work Buckets
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
- Not run; set FALCON_RAG_DIAGNOSTICS_MODE=live and live URL/auth env vars to enable.
## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.