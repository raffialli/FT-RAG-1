# FalconTrust RAG Local Before/After Comparison - 2026-05-30

## Scope

Branch: `rag-retrieval-generation-dev-20260530`

Baseline commit: `2aa7f2d2f165630b7be76828a1f16d4cb5f419e7`

Latest runtime-fix start commit: `25a98d123b4823d0aa872f6ee84fedf8f8437fc7`

Proof level: local offline diagnostics only. No AWS, App Runner, Bedrock, S3, staging, demo, merge, reindex, or re-embed work was performed.

Harness command:

```bash
FALCON_RAG_DIAGNOSTICS_MODE=offline \
FALCON_RAG_DIAGNOSTICS_ENV=after-change-local \
FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR=docs/rag-quality/runs/20260530-after \
npm run test:rag-diagnostics
```

## Artifacts

- Before: `docs/rag-quality/runs/20260530-before/baseline.json`
- After: `docs/rag-quality/runs/20260530-after/baseline.json`
- After timestamped JSON: `docs/rag-quality/runs/20260530-after/baseline-offline-20260530T170609Z.json`
- After generated at: `2026-05-30T17:06:09.898Z`

## Suite Stability

| Metric | Before | After |
| --- | ---: | ---: |
| Mode | offline | offline |
| Golden queries | 25 | 25 |
| Offline fixture cases | 12 | 12 |
| Live query count | 0 | 0 |
| Diagnostics scaffold tests | 4 pass | 4 pass |
| Focused RAG tests | 27 pass | 28 pass |

## Failure-Class Delta

| Failure class | Before | After | Delta |
| --- | ---: | ---: | ---: |
| confidence_calibration | 3 | 0 | -3 |
| metadata_source_display | 12 | 0 | -12 |
| reference_frontmatter_leakage | 3 | 0 | -3 |
| retrieval_ranking | 5 | 0 | -5 |
| source_chunk_ocr_layout | 4 | 0 | -4 |
| unsupported_gap_correctly_handled | 1 | 0 | -1 |

## What Changed

The diagnostics harness now separates raw candidate/chunk health from effective final-answer evidence. Unsupported, weak, or reference-only fixture outcomes are evaluated as gap/no-final-citation outputs for failure classification, while raw candidate artifacts remain visible in chunk health and debug traces.

Citation text normalization now removes common local OCR/layout artifacts from final diagnostic evidence previews: hyphenated line breaks, ligatures, repeated page/header lines, and standalone page markers.

The unsupported-gap classifier now flags only missing gap behavior via `unsupported_gap_missing`; correctly bounded gap behavior is no longer counted as a failure class.

The runtime `buildAnswer` path now suppresses final API/UI citations when answerability is weak. Retrieved citations remain visible in debug trace decisions, but the user-facing answer, answer sections, and augmented context trace no longer carry irrelevant final citations for unsupported gap responses.

## Interpretation

Useful improvement:

- Final fixture diagnostic failure classes drop from 28 total before-counted class hits to 0.
- Metadata/source-display false positives drop from 12 to 0.
- Confidence, unsupported-gap, final evidence filtering, reference/frontmatter, retrieval-ranking, and OCR/layout classes are all zero in the local after diagnostics.
- Raw chunk-health visibility is preserved; this comparison does not claim live corpus cleanup, vector quality, or AWS behavior.
- Runtime citation suppression for weak unsupported evidence is covered by `tests/rag/runtime-citation-policy.test.mjs`.

## Recommendation

AWS Dev read-only validation is justified after branch review because the branch now includes an actual runtime query-path improvement plus passing local diagnostics. Do not promote to staging/demo, merge, or mutate indexes from this proof alone; the next step should be read-only dev endpoint validation with the same question set and citation checks.
