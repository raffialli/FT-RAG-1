# FalconTrust Current Best Dev Restore Point

Run: falcontrust-rag-20260530-025-restore-remaining-failures

## Scope

Captured a restore point before any remaining-failures pass. This restore point copied the current AWS Dev vector manifest and the 8 approved source JSON objects from the cleanup package to:

s3://falcontrust-rag-dev-data-510844691338-us-east-2/restore-points/20260530-current-best-before-remaining-failures/

No source/vector/index mutation, reindex, reembed, deploy, delete, Staging, Demo, main merge, secret print, or parent workspace touch was performed during restore capture. This was copy-only proof.

## Anchors

- Branch: rag-retrieval-generation-dev-20260530
- HEAD: 0813e5716caeeb25cddb01b3d379d84b77dbf34d
- Dev endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Bucket: falcontrust-rag-dev-data-510844691338-us-east-2
- Restore manifest: docs/rag-quality/runs/20260530-current-best-dev-restore-point/restore-manifest.json

## App Runner

Captured App Runner service/image proof in:

- docs/rag-quality/runs/20260530-current-best-dev-restore-point/apprunner-service.json
- docs/rag-quality/runs/20260530-current-best-dev-restore-point/apprunner-image-summary.json

Runtime environment variable values are redacted in the summary.

## Objects Copied

- vectors/dev-customer-phase2-vector-index.json
- uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json
- uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json
- uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json
- uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json
- uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json
- uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json
- uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json

## Counts

- Vector records: 260
- HAZUS records: 4
- Distinct documents in vector manifest: 22
- Distinct chunks in vector manifest: 260

## Live Counts At Restore

- source_chunk_ocr_layout=3
- confidence_calibration=0
- unsupported_gap_missing=0
- retrieval_ranking=1
- answer_generation_faithfulness=1
- reference_frontmatter_leakage=0

## Confirmation

Restore point is complete for the approved scope: current vector manifest plus all 8 source JSONs from affected-doc-refresh-plan.json.
