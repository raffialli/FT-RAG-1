# 2026-05-30 Dev Partial Corpus Refresh Corrected

## Outcome

Outcome B: approved Dev-only partial refresh was executed and validated, but validation is mixed. Retrieval ranking and answer faithfulness improved from 3 to 1 each, confidence/unsupported stayed clean, source/OCR remained 15, and one reference/frontmatter regression appeared. Do not promote.

## Scope And Identity

- AWS profile: falcontrust-temp-admin
- AWS principal: arn:aws:iam::510844691338:user/vega-temp-admin
- Bucket: falcontrust-rag-dev-data-510844691338-us-east-2
- Region: us-east-2
- App HEAD: 16cb50b18ca1cd20b8d78d3b22e837402d930c8e
- Approved document count: 8
- Approved source key count: 8
- Vector key: vectors/dev-customer-phase2-vector-index.json

## Rollback Proof

- Rollback local root: /home/ralli/falcontrust-dev-partial-refresh-20260530-021/rollback
- Rollback source JSONs: 8
- Rollback vector index: rollback/vector/dev-customer-phase2-vector-index.json
- Rollback manifest: docs/rag-quality/runs/20260530-dev-partial-refresh-corrected/rollback-manifest.json
- Pre-mutation object heads are captured in the rollback manifest with ETags, sizes, and timestamps. No object version IDs were observed in HeadObject output.

## Exact Mutations

Uploaded only these Dev objects:

- uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json
- uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json
- uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json
- uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json
- uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json
- uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json
- uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json
- vectors/dev-customer-phase2-vector-index.json

No other source keys, document IDs, vector records, environments, or services were intentionally changed.

## Vector Counts

- Old active vector record count: 219
- Removed affected record count: 219
- Retained unrelated record count: 0
- New affected record count: 260
- New active vector record count: 260
- Note: the active Dev vector index contained only the 8 approved affected documents, so retained unrelated record count is 0 while scope still remained exactly the approved 8 document IDs.

## Per-Document Counts

- sandbags-upload-flood-risk-management-global-case-studies: 152 -> 182 records; source key uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json
- sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness: 10 -> 13 records; source key uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json
- sandbags-upload-life-safety-modeling-for-flood-emergency-management: 9 -> 10 records; source key uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json
- sandbags-upload-personal-preparedness-curriculum-for-public-health-workers: 15 -> 19 records; source key uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json
- sandbags-upload-community-resilience-and-recovery-after-major-flood: 12 -> 12 records; source key uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json
- sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model: 5 -> 4 records; source key uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan: 12 -> 17 records; source key uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json
- law-upload-legal-duties-and-emergency-management-contracts: 4 -> 3 records; source key uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json

## Post-Upload Heads

- uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json: 619779 bytes, ETag "996a94b2b9d41fda4e6ee10c26aad305", LastModified 2026-05-30T22:34:38+00:00
- uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json: 42425 bytes, ETag "defaefca4acf95d27690e498ed4d289f", LastModified 2026-05-30T22:34:40+00:00
- uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json: 29855 bytes, ETag "8c57bbf6a36d5e94118339755db9d54f", LastModified 2026-05-30T22:34:41+00:00
- uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json: 59646 bytes, ETag "f133d5297d290937886e7d0b96c4927d", LastModified 2026-05-30T22:34:43+00:00
- uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json: 39697 bytes, ETag "a406db51dff1e497a49850a639d35961", LastModified 2026-05-30T22:34:45+00:00
- uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json: 20151 bytes, ETag "f10f6fae9b40921faac9d70539247de3", LastModified 2026-05-30T22:34:46+00:00
- uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json: 62482 bytes, ETag "7d7816ed3636c0c6b00e9cab9e6c7767", LastModified 2026-05-30T22:34:48+00:00
- uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json: 10134 bytes, ETag "20ec086e0823e210a1e85d59fdd7f866", LastModified 2026-05-30T22:34:49+00:00
- vectors/dev-customer-phase2-vector-index.json: 9220836 bytes, ETag "d65bd8dec7b8bbfdc529382db1f7cd89-2", LastModified 2026-05-30T22:34:50+00:00

## Validation

- First validation attempt with password header: 25/25 HTTP 401; kept as auth-path evidence only.
- Cookie-auth validation: 25/25 live /api/query calls returned HTTP 200.
- Cookie-auth report JSON: docs/rag-quality/runs/20260530-dev-partial-refresh-validation-cookie/baseline-live-live-aws-dev-partial-refresh-cookie-20260530-20260530T223656Z.json
- Cookie-auth report Markdown: docs/rag-quality/runs/20260530-dev-partial-refresh-validation-cookie/baseline-live-live-aws-dev-partial-refresh-cookie-20260530-20260530T223656Z.md

### Failure Counts

| Failure class | Before | After |
| --- | ---: | ---: |
| source_chunk_ocr_layout | 15 | 15 |
| confidence_calibration | 0 | 0 |
| unsupported_gap_missing | 0 | 0 |
| retrieval_ranking | 3 | 1 |
| answer_generation_faithfulness | 3 | 1 |
| reference_frontmatter_leakage | 0 | 1 |

### Remaining/Regressed Failures

- mobile-warning-artifact: source_chunk_ocr_layout; status 200; confidence Medium; citations 3
- fews-mobile-warning: source_chunk_ocr_layout; status 200; confidence Medium; citations 3
- current-flood-warning-japan: source_chunk_ocr_layout; status 200; confidence Medium; citations 4
- community-resilience-recovery: source_chunk_ocr_layout; status 200; confidence Medium; citations 5
- hazus-flood-loss-model: source_chunk_ocr_layout, reference_frontmatter_leakage; status 200; confidence Medium; citations 5
- life-safety-model-fatalities: source_chunk_ocr_layout; status 200; confidence Medium; citations 5
- preparedness-workshop-kits: source_chunk_ocr_layout; status 200; confidence Medium; citations 5
- south-sudan-local-measures: source_chunk_ocr_layout; status 200; confidence Medium; citations 4
- contract-law-basics: source_chunk_ocr_layout; status 200; confidence Medium; citations 3
- wri-flood-exposure-reference: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness; status 200; confidence Medium; citations 5
- technology-exclusion-joined-heading: source_chunk_ocr_layout; status 200; confidence Medium; citations 3
- page-header-author-artifact: source_chunk_ocr_layout; status 200; confidence Medium; citations 4
- mid-word-boundary: source_chunk_ocr_layout; status 200; confidence Medium; citations 5
- duplicate-overlap-evidence: source_chunk_ocr_layout; status 200; confidence Medium; citations 4
- metadata-source-display: source_chunk_ocr_layout; status 200; confidence Medium; citations 4

## Recommendation

Do not promote this Dev state to staging/demo or merge based on this proof. The refresh proved the exact partial mutation path and improved ranking/faithfulness, but it did not reduce source/OCR failures and introduced one reference/frontmatter failure. Recommended next step is a targeted follow-up on the HAZUS/life-safety reference/frontmatter case and stronger source-quality scoring, or rollback using the captured rollback package if Dev must return to the previous no-reference-regression baseline.

## Safety Confirmations

- No Staging deploy.
- No Demo deploy.
- No main merge.
- No full reindex/reembed.
- No unrelated source/chunk/vector mutation beyond the approved 8 source keys/document IDs and one vector index key.
- No permanent deletes.
- No secrets committed.
- Parent workspace dirt untouched.