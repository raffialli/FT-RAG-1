# FalconTrust RAG Dev Partial Refresh Follow-up

Run: falcontrust-rag-20260530-022-dev-post-refresh-tuning

## Scope

This was a focused AWS Dev-only post-refresh tuning pass from app commit 48fb0e22b424bea0b474faeca9f7f04b63ec4835. The active Dev partial-refresh state from run 021 was treated as the baseline. No Staging, Demo, main merge, full reindex, unrelated document mutation, permanent delete, secret exposure, or parent workspace edit was performed.

## Current Failure Re-anchor

Current live diagnostics from the post-021 cookie-auth run showed:

- source_chunk_ocr_layout: 15
- reference_frontmatter_leakage: 1
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
- confidence_calibration: 0
- unsupported_gap_missing: 0

Inspected current failing IDs:

- source_chunk_ocr_layout: mobile-warning-artifact, fews-mobile-warning, current-flood-warning-japan, community-resilience-recovery, hazus-flood-loss-model, life-safety-model-fatalities, preparedness-workshop-kits, south-sudan-local-measures, contract-law-basics, wri-flood-exposure-reference, technology-exclusion-joined-heading, page-header-author-artifact, mid-word-boundary, duplicate-overlap-evidence, metadata-source-display
- reference_frontmatter_leakage: hazus-flood-loss-model
- retrieval_ranking: wri-flood-exposure-reference
- answer_generation_faithfulness: wri-flood-exposure-reference

## Fix Applied

One narrow, already-approved 8-doc Dev data tweak was applied to the HAZUS document only:

- Source JSON key: uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- Vector index key: vectors/dev-customer-phase2-vector-index.json
- Document ID: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model

The source text was cleaned to remove or normalize the first-chunk artifact:

- Removed leading AbstrAct
- Normalized IntroductIon to Introduction
- Normalized preand to pre- and

The HAZUS vector records were rebuilt and replaced only for that document. The HAZUS vector record count changed from 4 to 6, and the Dev vector index total changed from 260 to 262.

## Rollback Extension

Rollback copies were written before mutation under:

- /home/ralli/falcontrust-dev-partial-refresh-20260530-022/rollback/source/uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- /home/ralli/falcontrust-dev-partial-refresh-20260530-022/rollback/vector/dev-customer-phase2-vector-index.json

Committed evidence summary:

- docs/rag-quality/runs/20260530-dev-partial-refresh-followup/rollback-extension-summary.json

## Validation

Command harness:

FALCON_RAG_DIAGNOSTICS_MODE=live FALCON_RAG_DIAGNOSTICS_ENV=live-aws-dev-post-refresh-followup-20260530 FALCON_RAG_DIAGNOSTICS_LIVE_URL=https://b5kkjsgsnm.us-east-2.awsapprunner.com FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR=docs/rag-quality/runs/20260530-dev-partial-refresh-followup FALCON_RAG_DIAGNOSTICS_INCLUDE_DEBUG=true FALCON_RAG_DIAGNOSTICS_TIMEOUT_MS=45000 FALCON_RAG_DIAGNOSTICS_COOKIE=<redacted> node scripts/rag-diagnostics.mjs

Generated artifacts:

- docs/rag-quality/runs/20260530-dev-partial-refresh-followup/baseline-live-live-aws-dev-post-refresh-followup-20260530-20260530T225324Z.json
- docs/rag-quality/runs/20260530-dev-partial-refresh-followup/baseline-live-live-aws-dev-post-refresh-followup-20260530-20260530T225324Z.md
- docs/rag-quality/runs/20260530-dev-partial-refresh-followup/baseline.json
- docs/rag-quality/runs/20260530-dev-partial-refresh-followup/baseline.md

Live counts after the follow-up remained:

- source_chunk_ocr_layout: 15
- reference_frontmatter_leakage: 1
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
- confidence_calibration: 0
- unsupported_gap_missing: 0

The top HAZUS citation text is cleaner after the tweak, but the aggregate diagnostic classes did not improve.

## Recommendation

Do not promote this as meeting the 022 target. Keep the Dev state only if preserving the cleaner HAZUS source/citation text is desired; otherwise use the rollback extension for HAZUS source JSON and the vector index. The next useful move is either a more targeted HAZUS diagnostic-rule/code fix for why the cleaned chunk still trips reference_frontmatter_leakage, or a rollback before any further Dev data mutation.

Confirmations: no Staging deploy, no Demo deploy, no main merge, no full reindex, no unrelated document/chunk/vector mutation, no permanent delete, no parent workspace touch.
