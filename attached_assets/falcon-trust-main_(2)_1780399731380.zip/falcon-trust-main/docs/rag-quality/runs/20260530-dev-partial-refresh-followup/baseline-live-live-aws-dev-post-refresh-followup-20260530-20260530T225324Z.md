# RAG Diagnostics Baseline
Generated: 2026-05-30T22:53:24.024Z
Mode: live
Environment: live-aws-dev-post-refresh-followup-20260530
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 15
- reference_frontmatter_leakage: 1
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
## Recommended Work Buckets
- #28 OCR/layout cleanup: 15
- #28/#29 evidence filtering: 1
- retrieval/ranking diagnostics: 1
- answer-generation/faithfulness diagnostics: 1
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181608187-dp65n6 createdAt=2026-05-30T22:53:28.187Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.756, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.742, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.699

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181612300-nuy565 createdAt=2026-05-30T22:53:32.300Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: Low
- Session: session-1780181616105-7pn98p createdAt=2026-05-30T22:53:36.105Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fews-mobile-warning
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181619910-4rdm22 createdAt=2026-05-30T22:53:39.910Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.714, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.675

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: Low
- Session: session-1780181623699-bua0ye createdAt=2026-05-30T22:53:43.699Z
- Failure classes: none
- Recommended work: none
- Citations: none

### current-flood-warning-japan
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181627501-p12cnz createdAt=2026-05-30T22:53:47.501Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.937, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.777, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.683, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-11@0.657

### community-resilience-recovery
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181631490-zy3w96 createdAt=2026-05-30T22:53:51.490Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.048, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.981, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181635288-doifr7 createdAt=2026-05-30T22:53:55.288Z
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage
- Recommended work: #28 OCR/layout cleanup, #28/#29 evidence filtering
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.883, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.761, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-4@0.726, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.703, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.658

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181639089-pydou8 createdAt=2026-05-30T22:53:59.089Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.84, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-7@0.785, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.749, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.68, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.633

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181643084-47yuai createdAt=2026-05-30T22:54:03.084Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-14@0.93, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11@0.83, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-8@0.819, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13@0.787, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-16@0.72

### south-sudan-local-measures
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181646792-8uvl14 createdAt=2026-05-30T22:54:06.792Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.059, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-4@0.686

### contract-law-basics
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181649987-z8rorl createdAt=2026-05-30T22:54:09.987Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.874, law-upload-legal-duties-and-emergency-management-contracts-chunk-3@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780181653685-a5jlfp createdAt=2026-05-30T22:54:13.685Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780181657588-0gyncz createdAt=2026-05-30T22:54:17.588Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780181661201-3z9mgz createdAt=2026-05-30T22:54:21.201Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780181664786-g4vcym createdAt=2026-05-30T22:54:24.786Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780181668299-587gke createdAt=2026-05-30T22:54:28.299Z
- Failure classes: none
- Recommended work: none
- Citations: none

### niger-wmo-reference
- Status: 200 ok
- Confidence: Low
- Session: session-1780181672004-4j5zec createdAt=2026-05-30T22:54:32.004Z
- Failure classes: none
- Recommended work: none
- Citations: none

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181675888-ytymxw createdAt=2026-05-30T22:54:35.888Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-154@0.614, sandbags-upload-flood-risk-management-global-case-studies-chunk-68@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-108@0.57, sandbags-upload-flood-risk-management-global-case-studies-chunk-55@0.555, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.509

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181679587-cqfq0q createdAt=2026-05-30T22:54:39.587Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.722, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.621, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181683300-w2dwgf createdAt=2026-05-30T22:54:43.300Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.735, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.706, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.702, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.671

### mid-word-boundary
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181687097-sunx4v createdAt=2026-05-30T22:54:47.097Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.76, sandbags-upload-flood-risk-management-global-case-studies-chunk-148@0.645, sandbags-upload-flood-risk-management-global-case-studies-chunk-143@0.629, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-6@0.572, sandbags-upload-flood-risk-management-global-case-studies-chunk-145@0.527

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181690586-eb5evb createdAt=2026-05-30T22:54:50.586Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.808, sandbags-upload-flood-risk-management-global-case-studies-chunk-106@0.769, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.752, sandbags-upload-flood-risk-management-global-case-studies-chunk-124@0.729

### metadata-source-display
- Status: 200 ok
- Confidence: Medium
- Session: session-1780181694686-svvx40 createdAt=2026-05-30T22:54:54.686Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-14@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-27@0.69, sandbags-upload-flood-risk-management-global-case-studies-chunk-163@0.621

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780181698300-aqxtdn createdAt=2026-05-30T22:54:58.300Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.