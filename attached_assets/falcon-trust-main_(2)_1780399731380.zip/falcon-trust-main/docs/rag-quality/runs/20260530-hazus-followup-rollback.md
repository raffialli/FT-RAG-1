# FalconTrust RAG HAZUS Follow-up Rollback

Run: falcontrust-rag-20260530-023-hazus-followup-rollback

## Scope

Rolled back only the run 022 HAZUS follow-up while preserving the earlier 8-doc Dev partial refresh. App worktree was anchored at commit 5e5e39e8b09b91738ba84a2ccb75519ee1fc7b26 on branch rag-retrieval-generation-dev-20260530 with a clean status before the rollback evidence was created.

AWS profile falcontrust-temp-admin resolved to account 510844691338 as arn:aws:iam::510844691338:user/vega-temp-admin. Target bucket was falcontrust-rag-dev-data-510844691338-us-east-2.

## Restored Objects

Only these two Dev objects were uploaded:

- uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- vectors/dev-customer-phase2-vector-index.json

Rollback source files:

- /home/ralli/falcontrust-dev-partial-refresh-20260530-022/rollback/source/uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- /home/ralli/falcontrust-dev-partial-refresh-20260530-022/rollback/vector/dev-customer-phase2-vector-index.json

## Pre/Post Proof

Source object:

- Pre: ETag "78e13ab6869eea36bc9442746d1c6b59", size 20435, modified 2026-05-30T22:52:59+00:00
- Post: ETag "f10f6fae9b40921faac9d70539247de3", size 20151, modified 2026-05-30T23:07:09+00:00

Vector object:

- Pre: ETag "5c73c4d199d57c862c37e8e577ae8159-2", size 9294638, modified 2026-05-30T22:53:00+00:00
- Post: ETag "d65bd8dec7b8bbfdc529382db1f7cd89-2", size 9220836, modified 2026-05-30T23:07:10+00:00

Vector rollback count proof:

- Total records: 260
- HAZUS records: 4
- Document ID: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model

## Live Validation

Command harness:

FALCON_RAG_DIAGNOSTICS_MODE=live FALCON_RAG_DIAGNOSTICS_ENV=live-aws-dev-hazus-rollback-20260530 FALCON_RAG_DIAGNOSTICS_LIVE_URL=https://b5kkjsgsnm.us-east-2.awsapprunner.com FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR=docs/rag-quality/runs/20260530-hazus-followup-rollback FALCON_RAG_DIAGNOSTICS_INCLUDE_DEBUG=true FALCON_RAG_DIAGNOSTICS_TIMEOUT_MS=45000 FALCON_RAG_DIAGNOSTICS_COOKIE=<redacted> node scripts/rag-diagnostics.mjs

Artifacts:

- docs/rag-quality/runs/20260530-hazus-followup-rollback/baseline-live-live-aws-dev-hazus-rollback-20260530-20260530T230845Z.json
- docs/rag-quality/runs/20260530-hazus-followup-rollback/baseline-live-live-aws-dev-hazus-rollback-20260530-20260530T230845Z.md
- docs/rag-quality/runs/20260530-hazus-followup-rollback/baseline.json
- docs/rag-quality/runs/20260530-hazus-followup-rollback/baseline.md

Live diagnostics completed with 25 total queries, 25 OK, and 0 endpoint errors.

Failure counts after rollback:

- source_chunk_ocr_layout: 15
- confidence_calibration: 0
- unsupported_gap_missing: 0
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
- reference_frontmatter_leakage: 1

The HAZUS citation is back to the pre-022 text beginning with "AbstrAct", and the vector index is back to 260 records. This restores the exact 022 rollback state while leaving the earlier 8-doc partial refresh in place.

## Recommendation

Keep this rollback. The 022 HAZUS tweak did not improve aggregate live counts, and this rollback returns Dev to the previously documented 260-record vector state. Remaining work should target the persistent source/OCR cleanup and diagnostic classification issues through a separately approved narrow lane.

Confirmations: no Staging deploy, no Demo deploy, no main merge, no full reindex, no unrelated document/chunk/vector mutation, no permanent delete, no secret print in committed artifacts, no parent workspace touch, no internal worker.
