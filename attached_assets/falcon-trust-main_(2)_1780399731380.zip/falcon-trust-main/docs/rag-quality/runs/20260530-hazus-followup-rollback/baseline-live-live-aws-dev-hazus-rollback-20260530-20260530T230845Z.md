# RAG Diagnostics Baseline
Generated: 2026-05-30T23:08:45.623Z
Mode: live
Environment: live-aws-dev-hazus-rollback-20260530
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 15
- reference_frontmatter_leakage: 1
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
## Recommended Work Buckets
- #28 OCR/layout cleanup: 15
- #28/#29 evidence filtering: 1
- retrieval/ranking diagnostics: 1
- answer-generation/faithfulness diagnostics: 1
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182528599-39jjzl createdAt=2026-05-30T23:08:48.599Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.756, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.742, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.699

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182532384-5pxqj1 createdAt=2026-05-30T23:08:52.384Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: Low
- Session: session-1780182535898-zg69rt createdAt=2026-05-30T23:08:55.898Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fews-mobile-warning
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182539602-6mc16c createdAt=2026-05-30T23:08:59.602Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.714, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.675

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: Low
- Session: session-1780182543711-9skiog createdAt=2026-05-30T23:09:03.711Z
- Failure classes: none
- Recommended work: none
- Citations: none

### current-flood-warning-japan
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182546807-p46btt createdAt=2026-05-30T23:09:06.807Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.937, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.777, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.683, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-11@0.657

### community-resilience-recovery
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182550789-mb8u0b createdAt=2026-05-30T23:09:10.789Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.048, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.981, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182554502-3jm06a createdAt=2026-05-30T23:09:14.502Z
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage
- Recommended work: #28 OCR/layout cleanup, #28/#29 evidence filtering
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.9, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.761, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2@0.737, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.703, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.658

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182557799-rghkjz createdAt=2026-05-30T23:09:17.799Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.84, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-7@0.785, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.749, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.68, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.633

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182561498-5j17qb createdAt=2026-05-30T23:09:21.498Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-14@0.93, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11@0.83, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-8@0.819, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13@0.787, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-16@0.72

### south-sudan-local-measures
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182565200-ijek1m createdAt=2026-05-30T23:09:25.200Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.059, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-4@0.686

### contract-law-basics
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182568505-xopybs createdAt=2026-05-30T23:09:28.505Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.874, law-upload-legal-duties-and-emergency-management-contracts-chunk-3@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780182572197-oopp7l createdAt=2026-05-30T23:09:32.197Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780182575705-rajl43 createdAt=2026-05-30T23:09:35.705Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780182579303-b45ky0 createdAt=2026-05-30T23:09:39.303Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780182583084-utrp8y createdAt=2026-05-30T23:09:43.084Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780182586685-2oj0ei createdAt=2026-05-30T23:09:46.685Z
- Failure classes: none
- Recommended work: none
- Citations: none

### niger-wmo-reference
- Status: 200 ok
- Confidence: Low
- Session: session-1780182590305-h6lhk5 createdAt=2026-05-30T23:09:50.305Z
- Failure classes: none
- Recommended work: none
- Citations: none

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182594094-dfvtjs createdAt=2026-05-30T23:09:54.094Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-154@0.614, sandbags-upload-flood-risk-management-global-case-studies-chunk-68@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-108@0.57, sandbags-upload-flood-risk-management-global-case-studies-chunk-55@0.555, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.509

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182597295-i8bcol createdAt=2026-05-30T23:09:57.295Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.722, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.621, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182601096-o8comq createdAt=2026-05-30T23:10:01.096Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.735, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.706, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.702, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.671

### mid-word-boundary
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182605087-fpkydn createdAt=2026-05-30T23:10:05.087Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.781, sandbags-upload-flood-risk-management-global-case-studies-chunk-148@0.645, sandbags-upload-flood-risk-management-global-case-studies-chunk-143@0.629, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-6@0.572, sandbags-upload-flood-risk-management-global-case-studies-chunk-145@0.527

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182608893-nodhf9 createdAt=2026-05-30T23:10:08.893Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.808, sandbags-upload-flood-risk-management-global-case-studies-chunk-106@0.769, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.752, sandbags-upload-flood-risk-management-global-case-studies-chunk-124@0.729

### metadata-source-display
- Status: 200 ok
- Confidence: Medium
- Session: session-1780182612485-ocdg3q createdAt=2026-05-30T23:10:12.485Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-14@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-27@0.69, sandbags-upload-flood-risk-management-global-case-studies-chunk-163@0.621

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780182616004-qlew0t createdAt=2026-05-30T23:10:16.004Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.