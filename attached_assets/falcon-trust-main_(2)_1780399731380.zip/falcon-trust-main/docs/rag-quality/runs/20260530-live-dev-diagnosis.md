# FalconTrust RAG Live Dev Diagnosis - 2026-05-30

## Scope

- Lane: falcontrust-rag-retrieval-generation-dev-20260530
- Branch/SHA: rag-retrieval-generation-dev-20260530 at f0e5ef228a87ca3cd6c25e44534de5cc7836f45b
- Dev endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Service: falcontrust-rag-dev-web
- Image digest: sha256:91e8f56b439867ff277d9fafe08c8d2331c5714ebf2ecd8e757b1518f29e3bb6
- Hard gates observed: diagnosis only; no staging, demo, merge, reindex, reembed, AWS vector/index mutation, secrets printing, or broad code changes.

## Dev Proof

- App Runner service ARN: arn:aws:apprunner:us-east-2:510844691338:service/falcontrust-rag-dev-web/6a23c349f3dd43a0bfa92c2ca20956a3
- Status: RUNNING
- Image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-f0e5ef2-20260530171747
- Image digest: sha256:91e8f56b439867ff277d9fafe08c8d2331c5714ebf2ecd8e757b1518f29e3bb6
- Rollback image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:dev-issue29-reranking-cae1f9d-20260530063239
- Rollback digest: sha256:bffc060be68165cd6806a9e2cc8a88fc632ae485c48f3dd7d7e34eb2500017ab
- Live diagnostics auth path: /api/auth/login cookie, then /api/query. All 25 live requests returned HTTP 200.

## Non-Secret Dev Config

- FALCON_ENV=dev
- FALCON_RETRIEVAL_BACKEND=bedrock-s3-vector
- FALCON_STORAGE_BACKEND=s3
- FALCON_STORAGE_BUCKET=falcontrust-rag-dev-data-510844691338-us-east-2
- FALCON_VECTOR_INDEX_KEY=vectors/dev-customer-phase2-vector-index.json
- FALCON_EMBEDDINGS_ENABLED=true
- FALCON_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
- FALCON_EMBEDDING_REGION=us-east-2
- FALCON_MANIFEST_PATH=/app/manifests/customer-corpus.seed.json
- FALCON_MANIFEST_CHUNK_MAP_PATH=/app/seed-reports/customer-chunk-map.json
- Auth and external API secret variables were present and redacted.

## Proof-Level Mismatch

The local/offline after result is not equivalent to the AWS Dev live result.

- Local/offline after file: docs/rag-quality/runs/20260530-after/baseline.json
- Local/offline mode: offline
- Local generated at: 2026-05-30T17:06:09.898Z
- Local query count: 25 golden questions listed
- Local fixture cases: 12 synthetic fixture diagnostics
- Local live diagnostics: absent
- AWS Dev live file: /tmp/falcon-rag-diagnostics-dev-cookie/baseline.json
- AWS Dev live mode: live
- AWS Dev generated at: 2026-05-30T17:22:39.093Z
- AWS Dev live queries: 25 browser-equivalent API calls against /api/query

The offline run improved synthetic fixture/harness checks. The live Dev run exercises deployed runtime code against the Bedrock/S3 vector index and real uploaded corpus chunks. The live failures are therefore not contradicted by the offline zero-fixture-failure result.

## Live Aggregate Failures

- source_chunk_ocr_layout: 24
- confidence_calibration: 21
- unsupported_gap_missing: 8
- retrieval_ranking: 6
- answer_generation_faithfulness: 6
- reference_frontmatter_leakage: 6

## Selected Cases

### bridge-inspection-contractor

- Question: Which bridge inspection contractor signed the 2026 renewal?
- Category/support: unsupported / unsupported
- Live result: HTTP 200, Low confidence, 0 citations, no failure classes.
- Interpretation: runtime weak-evidence citation suppression works for at least one low-overlap unsupported case.

### sandbags-prevent-all-damage

- Question: Do these documents prove sandbags prevent all flood damage?
- Category/support: unsupported / unsupported
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, confidence_calibration.
- Top citations: flood-risk chunks 27, 25, 115 from uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json.
- Interpretation: answer text is bounded, but confidence/final citation policy still overstates evidence for unsupported absolute-claim questions.

### fema-current-policy

- Question: What is FEMA's current 2026 policy for sandbag reimbursement?
- Category/support: unsupported / unsupported
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing.
- Top citations: flood-risk chunks 71, 132, 74.
- Interpretation: runtime answerability does not recognize freshness/current-policy gaps when the vector backend returns broadly policy-like but non-current evidence.

### manufactured-housing-retrieval

- Question: What does the corpus say about manufactured housing eligibility or protections?
- Category/support: manufactured-housing / unsupported
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing.
- Top citations: flood-risk chunks 105, 106, 111.
- Interpretation: the live vector backend retrieves semantically adjacent flood-risk chunks, and runtime treats them as answerable despite absent manufactured-housing evidence.

### mobile-warning-artifact

- Question: What does the corpus say about mobile flood early warning systems?
- Category/support: ocr-heavy / supported-with-artifact-risk
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage, retrieval_ranking, answer_generation_faithfulness, confidence_calibration.
- Top citations: flood-risk chunk 97, Japan warning-system chunk 1, flood-risk chunk 85.
- Interpretation: live corpus chunk quality and final-evidence filtering are still too permissive for OCR-heavy chunks.

### fews-mobile-warning

- Question: What does the mobile warning or FEWS evidence say about reaching people before floods?
- Category/support: supported / supported
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage, retrieval_ranking, answer_generation_faithfulness, confidence_calibration.
- Top citations: flood-risk chunks 91, 85, 90.
- Interpretation: relevant evidence exists, but retrieval/reranking/final-citation policy does not sufficiently demote noisy chunks.

### frontmatter-title-pages

- Question: What is the ISBN or catalog record for Flood Risk Management Global Case Studies?
- Category/support: frontmatter-leakage / unsupported-or-filtered
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing.
- Top citations: flood-risk chunks 5, 4, 13.
- Interpretation: frontmatter/reference filtering remains insufficient on live vector results.

### table-of-contents-query

- Question: What does the table of contents list for flood risk management case studies?
- Category/support: frontmatter-leakage / unsupported-or-filtered
- Live result: HTTP 200, High confidence, 5 citations.
- Failure classes: source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing.
- Top citations: flood-risk chunks 5, 54, 133.
- Interpretation: the live path needs stronger final evidence filtering and confidence caps for frontmatter/reference-query patterns.

## Root Cause Classification

Primary root cause: proof-level mismatch plus runtime live-vector evidence filtering limits.

1. Local/offline after diagnostics do not run the same proof path as AWS Dev live diagnostics. They validate synthetic fixture behavior and diagnostics/harness expectations, not live /api/query behavior against bedrock-s3-vector.
2. AWS Dev is running the intended committed image and uses the expected bedrock-s3-vector backend and vector index key, so this is not explained by deploying the wrong image or endpoint.
3. The deployed runtime fix suppresses citations for some weak cases, proven by bridge-inspection-contractor, but it does not consistently suppress or down-rank citations when live vector retrieval returns semantically adjacent but unsupported chunks.
4. OCR/layout and frontmatter/reference-tainted chunks remain eligible as final answer evidence in live results.
5. Confidence calibration remains too optimistic when the answer is textually grounded in retrieved chunks but the question's required support level is unsupported, current-policy-specific, or frontmatter/reference-filtered.

## Reindex/Reembed Decision

Do not reindex or reembed from this diagnosis alone.

Evidence:

- The live Dev backend is active: FALCON_RETRIEVAL_BACKEND=bedrock-s3-vector.
- The expected vector index key is active: vectors/dev-customer-phase2-vector-index.json.
- Live queries return corpus chunk IDs, titles, source paths, and metadata from the expected S3-backed uploaded documents.
- The failure pattern is not no vectors or wrong corpus only; it includes relevant-but-noisy supported cases and unsupported cases where broadly adjacent flood-risk chunks are overaccepted.
- Reindex/reembed may become justified later only if the next runtime fix changes chunk generation, OCR normalization, metadata schema, or vector records. That mutation is not indicated as the smallest next action from this evidence.

## Smallest Next Action

Make one narrow runtime-app fix before any vector/index mutation:

1. Add a live-equivalent local diagnostic mode or fixture generated from saved Dev debug traces so the same 25 golden questions can fail locally for the same reasons as AWS Dev.
2. Tighten runtime final-evidence policy for unsupported/current-policy/manufactured-housing/frontmatter-reference cases: cap confidence, suppress final citations, and return a gap when retrieved chunks are only semantically adjacent or metadata-tainted.
3. Strengthen OCR/reference/frontmatter penalties in reranking/final citation selection before answer synthesis.
4. Rerun the unchanged 25-question suite locally and against AWS Dev after redeploy approval.

## Hard-Gate Confirmation

This diagnosis did not run staging, demo, merge, reindex, reembed, AWS vector/index mutation, cleanup, or broad code changes. Secrets were not printed.
