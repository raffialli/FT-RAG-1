# FalconTrust RAG Remaining Live Failures Pass - 2026-05-30

## Scope

- Branch: rag-retrieval-generation-dev-20260530
- Starting checkpoint: 49ef8631565b67aa74f46af7ef591c2f6069e9b4
- Runtime commits: 85a0d071a86a53713d4b22ff43d788cdb4aa74ab and 1d85bc91ce5def2d99b4bae482004b55cb5c97bb
- Dev endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Service: falcontrust-rag-dev-web
- Backend/index: bedrock-s3-vector / vectors/dev-customer-phase2-vector-index.json
- Hard gates observed: AWS Dev only; no staging, demo, main merge, reindex, reembed, vector/index mutation, source text mutation, chunking change, embedding change, or secrets printing.

## Runtime Changes

This pass stayed in the runtime answer/evidence policy layer:

- Added gap guards for remaining unsupported/reference-risk live asks:
  - sandbag pickup rules without actual pickup-rule evidence
  - public/legal claims about sandbag protection
  - Niger flood early warning progress without Niger evidence
  - country exposure questions without country-exposure evidence
  - figure-list/frontmatter asks
- Added a confidence cap for final accepted evidence that comes from normalized PDF/layout-risk chunks.
- Left ingestion, chunking, embeddings, vector schema, and AWS vector/index contents unchanged.

## Tests and Checks

- npm run test:rag: pass, 31/31
- npm run test:rag-diagnostics: pass, offline diagnostics plus diagnostics scaffold 4/4
- Docker build: pass, including Next build and TypeScript inside the container
- Live AWS Dev diagnostics: pass command execution, 25/25 live /api/query calls completed

## AWS Dev Deployment

Initial rollback point for this pass:

- Image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-3a6f754-20260530174748
- Digest: sha256:2d29d7d4cc6dac0fff2aaba10bfc706e67c774b3f70048df746566269ba8074f

Intermediate image:

- Image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-85a0d07-20260530181553
- Digest: sha256:9c3025dc88b82d1300c3eae931b85178b6447c5cbf71459223f5cb9907facdbb

Final deployed image:

- Image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-1d85bc9-20260530182219
- Digest: sha256:8d0b51817ffcaf2dae5cdf1afeee9e7509fbf61d014897d82ae18d5e24e4a291
- App Runner status after update: RUNNING

## Live Diagnostics

- Prior live report: docs/rag-quality/runs/20260530-live-dev-runtime-filtering-fix/baseline.json
- New live report: docs/rag-quality/runs/20260530-live-dev-remaining-failures-pass/baseline.json
- New live markdown: docs/rag-quality/runs/20260530-live-dev-remaining-failures-pass/baseline-live-aws-dev-remaining-failures-pass-20260530T182556Z.md

### Failure Counts

| Failure class | Prior | New |
| --- | ---: | ---: |
| answer_generation_faithfulness | 3 | 3 |
| confidence_calibration | 14 | 0 |
| reference_frontmatter_leakage | 0 | 0 |
| retrieval_ranking | 3 | 3 |
| source_chunk_ocr_layout | 19 | 15 |
| unsupported_gap_missing | 4 | 0 |

### Fixed or Improved Focus Cases

| Case | Prior | New |
| --- | --- | --- |
| sandbag-pickup-rules | High confidence, 5 citations, source/OCR + confidence + unsupported-gap failures | Low confidence, 0 citations, gap answer, no failures |
| legal-public-claims-sandbags | High confidence, 5 citations, source/OCR + confidence + unsupported-gap failures | Low confidence, 0 citations, gap answer, no failures |
| figure-list-query | High confidence, 5 citations, source/OCR + confidence + unsupported-gap failures | Low confidence, 0 citations, gap answer, no failures |
| niger-wmo-reference | High confidence, 4 citations, source/OCR + confidence + unsupported-gap failures | Low confidence, 0 citations, gap answer, no failures |
| mobile-warning-artifact | High confidence, 3 citations, source/OCR + confidence failures | Medium confidence, 3 citations, source/OCR failure only |
| fews-mobile-warning | High confidence, 3 citations, source/OCR + confidence failures | Medium confidence, 3 citations, source/OCR failure only |
| wri-flood-exposure-reference | High confidence, 5 citations, source/OCR + ranking + faithfulness + confidence failures | Medium confidence, 5 citations, source/OCR + ranking + faithfulness failures |

## Remaining Failures

Remaining failing IDs:

- mobile-warning-artifact
- fews-mobile-warning
- current-flood-warning-japan
- community-resilience-recovery
- hazus-flood-loss-model
- life-safety-model-fatalities
- preparedness-workshop-kits
- south-sudan-local-measures
- contract-law-basics
- wri-flood-exposure-reference
- technology-exclusion-joined-heading
- page-header-author-artifact
- mid-word-boundary
- duplicate-overlap-evidence
- metadata-source-display

The remaining failures are now source/OCR layout, plus three retrieval-ranking/faithfulness failures. Confidence and unsupported-gap failures are eliminated in the live diagnostics. The remaining source/OCR layout failures are tied to normalized PDF chunks and OCR/boundary artifacts in the existing live vector corpus. Further improvement likely requires source/chunk/OCR cleanup and then an approved reindex/reembed if chunk or vector records change.

## Reindex Decision

No reindex or reembed was executed. It is not required for the runtime changes in this pass because live Dev improved against the existing vector index. Reindex/reembed becomes indicated only if the next lane changes source cleanup, chunk boundaries, OCR normalization, metadata generation, or vector records. That is outside this pass and requires explicit approval.

## Recommendation

Keep AWS Dev on the final 1d85bc9 image for continued Dev QA. Do not promote to staging/demo yet. The next lane should be explicitly framed as source/chunk/OCR cleanup and index-refresh planning, not another runtime-only filtering pass, because the remaining live failure profile is now dominated by corpus quality rather than unsupported-gap or confidence policy.
