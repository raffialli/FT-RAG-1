# RAG Diagnostics Baseline
Generated: 2026-05-30T18:25:56.579Z
Mode: live
Environment: aws-dev-remaining-failures-pass
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 15
- retrieval_ranking: 3
- answer_generation_faithfulness: 3
## Recommended Work Buckets
- #28 OCR/layout cleanup: 15
- retrieval/ranking diagnostics: 3
- answer-generation/faithfulness diagnostics: 3
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165561089-f6so7x createdAt=2026-05-30T18:26:01.089Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.754, sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.747, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.727

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165564601-vi7g19 createdAt=2026-05-30T18:26:04.601Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: Low
- Session: session-1780165567685-zsossw createdAt=2026-05-30T18:26:07.685Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fews-mobile-warning
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165570996-pmhpd4 createdAt=2026-05-30T18:26:10.996Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.731, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.68

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: Low
- Session: session-1780165574000-nnquso createdAt=2026-05-30T18:26:14.000Z
- Failure classes: none
- Recommended work: none
- Citations: none

### current-flood-warning-japan
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165577185-5unrrs createdAt=2026-05-30T18:26:17.185Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.987, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.786, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.754, sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.685

### community-resilience-recovery
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165580200-05zguk createdAt=2026-05-30T18:26:20.200Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.111, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.965, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165583192-4eneqw createdAt=2026-05-30T18:26:23.192Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.785, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.731, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.66, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2@0.638, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-4@0.635

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165586203-s1m7jz createdAt=2026-05-30T18:26:26.203Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.756, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.754, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-6@0.603, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.562

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165589201-6o72am createdAt=2026-05-30T18:26:29.201Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11@0.804, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-9@0.758, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-10@0.74, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-14@0.739, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.71

### south-sudan-local-measures
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165592385-fdzmvx createdAt=2026-05-30T18:26:32.385Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.011, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-3@0.626

### contract-law-basics
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165594506-j9zuzq createdAt=2026-05-30T18:26:34.506Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.894, law-upload-legal-duties-and-emergency-management-contracts-chunk-4@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780165598204-j90dh7 createdAt=2026-05-30T18:26:38.204Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780165601287-57j7jv createdAt=2026-05-30T18:26:41.287Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780165604293-h8bqil createdAt=2026-05-30T18:26:44.293Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780165606802-459t8x createdAt=2026-05-30T18:26:46.802Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780165609884-3xebs5 createdAt=2026-05-30T18:26:49.884Z
- Failure classes: none
- Recommended work: none
- Citations: none

### niger-wmo-reference
- Status: 200 ok
- Confidence: Low
- Session: session-1780165612787-q8knnn createdAt=2026-05-30T18:26:52.787Z
- Failure classes: none
- Recommended work: none
- Citations: none

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165615695-nt236x createdAt=2026-05-30T18:26:55.695Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-88@0.606, sandbags-upload-flood-risk-management-global-case-studies-chunk-127@0.598, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-128@0.569, sandbags-upload-flood-risk-management-global-case-studies-chunk-13@0.555

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165618798-apru65 createdAt=2026-05-30T18:26:58.798Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.723, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.626, sandbags-upload-flood-risk-management-global-case-studies-chunk-95@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165622101-l3r2fv createdAt=2026-05-30T18:27:02.101Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.734, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.71, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.709, sandbags-upload-flood-risk-management-global-case-studies-chunk-86@0.684

### mid-word-boundary
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165625293-e5eeyc createdAt=2026-05-30T18:27:05.293Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.748, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.644, sandbags-upload-flood-risk-management-global-case-studies-chunk-117@0.629, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.588, sandbags-upload-flood-risk-management-global-case-studies-chunk-8@0.585

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165628211-k2o21i createdAt=2026-05-30T18:27:08.211Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.819, sandbags-upload-flood-risk-management-global-case-studies-chunk-86@0.806, sandbags-upload-flood-risk-management-global-case-studies-chunk-101@0.729, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.725

### metadata-source-display
- Status: 200 ok
- Confidence: Medium
- Session: session-1780165630802-fs5uf3 createdAt=2026-05-30T18:27:10.802Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-19@0.779, sandbags-upload-flood-risk-management-global-case-studies-chunk-11@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-5@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.686, sandbags-upload-flood-risk-management-global-case-studies-chunk-55@0.667

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780165633903-9xhbhf createdAt=2026-05-30T18:27:13.903Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.