# FalconTrust RAG Dev Runtime Filtering Fix - 2026-05-30

## Scope

- Branch: rag-retrieval-generation-dev-20260530
- Implementation commit: 3a6f754376565aa01534df45d700c7065abf5e53
- Dev endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Service: falcontrust-rag-dev-web
- Backend/index: bedrock-s3-vector / vectors/dev-customer-phase2-vector-index.json
- Hard gates observed: AWS Dev only; no staging, demo, main merge, reindex, reembed, vector/index mutation, dependency install, or secrets printing.

## Runtime Change

The runtime answer path now selects final-eligible citations before answerability and confidence scoring. It filters OCR/layout-tainted, reference/frontmatter, and metadata-tainted evidence before final answer acceptance, then applies query-specific guards for:

- unsupported absolute flood-prevention claims
- current/FEMA policy questions without current policy evidence
- manufactured-housing questions without manufactured-housing evidence
- frontmatter, catalog, ISBN, table-of-contents, and reference-list questions

For these cases, runtime now caps confidence, suppresses final citations, or returns a gap answer instead of presenting semantically adjacent chunks as final evidence.

## Tests and Checks

- npm run test:rag: pass, 30/30
- npm run test:rag-diagnostics: pass, offline diagnostics plus diagnostics scaffold 4/4
- npm run typecheck: not runnable in host worktree because tsc is not installed locally
- npm run build: not runnable in host worktree because next is not installed locally
- Docker build: pass, Next build completed inside the container image

## AWS Dev Deployment

- Rollback image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-f0e5ef2-20260530171747
- Rollback digest: sha256:91e8f56b439867ff277d9fafe08c8d2331c5714ebf2ecd8e757b1518f29e3bb6
- New image: 510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-3a6f754-20260530174748
- New image digest: sha256:2d29d7d4cc6dac0fff2aaba10bfc706e67c774b3f70048df746566269ba8074f
- App Runner status after update: RUNNING
- App Runner URL: https://b5kkjsgsnm.us-east-2.awsapprunner.com

## Live Diagnostics

- Prior live report: /tmp/falcon-rag-diagnostics-dev-cookie/baseline.json
- New live report: docs/rag-quality/runs/20260530-live-dev-runtime-filtering-fix/baseline.json
- New live markdown: docs/rag-quality/runs/20260530-live-dev-runtime-filtering-fix/baseline-live-aws-dev-runtime-filtering-fix-20260530T175208Z.md

### Failure Counts

| Failure class | Prior | New |
| --- | ---: | ---: |
| answer_generation_faithfulness | 6 | 3 |
| confidence_calibration | 21 | 14 |
| reference_frontmatter_leakage | 6 | 0 |
| retrieval_ranking | 6 | 3 |
| source_chunk_ocr_layout | 24 | 19 |
| unsupported_gap_missing | 8 | 4 |

### Focus Cases

| Case | Prior confidence/citations/failures | New confidence/citations/failures |
| --- | --- | --- |
| bridge-inspection-contractor | Low / 0 / none | Low / 0 / none |
| sandbags-prevent-all-damage | High / 5 / source_chunk_ocr_layout, confidence_calibration | Medium / 0 / none |
| fema-current-policy | High / 5 / source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing | Low / 0 / none |
| manufactured-housing-retrieval | High / 5 / source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing | Low / 0 / none |
| mobile-warning-artifact | High / 5 / source_chunk_ocr_layout, reference_frontmatter_leakage, retrieval_ranking, answer_generation_faithfulness, confidence_calibration | High / 3 / source_chunk_ocr_layout, confidence_calibration |
| fews-mobile-warning | High / 5 / source_chunk_ocr_layout, reference_frontmatter_leakage, retrieval_ranking, answer_generation_faithfulness, confidence_calibration | High / 3 / source_chunk_ocr_layout, confidence_calibration |
| frontmatter-title-pages | High / 5 / source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing | Low / 0 / none |
| table-of-contents-query | High / 5 / source_chunk_ocr_layout, reference_frontmatter_leakage, confidence_calibration, unsupported_gap_missing | Low / 0 / none |

## Result

The focused runtime fix improved live Dev behavior without reindexing:

- reference/frontmatter leakage dropped from 6 to 0
- unsupported gap failures dropped from 8 to 4
- confidence calibration failures dropped from 21 to 14
- retrieval ranking failures dropped from 6 to 3
- answer generation faithfulness failures dropped from 6 to 3
- source/OCR layout failures dropped from 24 to 19

The biggest focused wins were:

- sandbags-prevent-all-damage: High confidence with 5 citations to Medium confidence with 0 citations and no failures
- fema-current-policy: High confidence with 5 citations and 4 failures to Low confidence, 0 citations, gap answer, no failures
- manufactured-housing-retrieval: High confidence with 5 citations and 3 failures to Low confidence, 0 citations, gap answer, no failures
- frontmatter-title-pages and table-of-contents-query: both now Low confidence, 0 citations, gap answer, no failures

## Remaining Risks

Mobile/FEWS supported cases still retain source_chunk_ocr_layout and confidence_calibration failures because the live corpus contains OCR-normalized chunks whose remaining text can still be noisy. The runtime now filters the worst final evidence and removes reference/frontmatter failures, but true cleanup of the remaining OCR/layout class likely requires chunk/OCR/index work.

## Reindex Decision

No reindex or reembed was executed. Reindex/reembed is still not required for this runtime filtering fix because the deployed behavior improved against the existing live vector index. A future reindex/reembed should only be considered if the next approved lane changes ingestion, chunking, OCR normalization, metadata schema, or vector records.

## Recommendation

Keep AWS Dev on the new image for continued Dev QA. Do not promote to staging/demo yet. The next smallest action is a separate OCR/chunk-quality lane or a narrower runtime cleanup for the remaining supported mobile/FEWS source_chunk_ocr_layout and confidence_calibration failures.
