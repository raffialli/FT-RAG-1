# RAG Diagnostics Baseline
Generated: 2026-05-30T17:52:08.246Z
Mode: live
Environment: aws-dev-runtime-filtering-fix
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 19
- confidence_calibration: 14
- unsupported_gap_missing: 4
- retrieval_ranking: 3
- answer_generation_faithfulness: 3
## Recommended Work Buckets
- #28 OCR/layout cleanup: 19
- confidence/calibration diagnostics: 14
- unsupported/gap behavior: 4
- retrieval/ranking diagnostics: 3
- answer-generation/faithfulness diagnostics: 3
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: High
- Session: session-1780163533374-ty128r createdAt=2026-05-30T17:52:13.374Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.754, sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.747, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.727

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780163537264-pql1ri createdAt=2026-05-30T17:52:17.264Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: High
- Session: session-1780163541273-471eh5 createdAt=2026-05-30T17:52:21.273Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics, unsupported/gap behavior
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-8@0.45, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.441, sandbags-upload-flood-risk-management-global-case-studies-chunk-94@0.438, sandbags-upload-flood-risk-management-global-case-studies-chunk-19@0.418, sandbags-upload-flood-risk-management-global-case-studies-chunk-119@0.407

### fews-mobile-warning
- Status: 200 ok
- Confidence: High
- Session: session-1780163544862-syzwgg createdAt=2026-05-30T17:52:24.862Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.731, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.68

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: High
- Session: session-1780163548175-ak3oq4 createdAt=2026-05-30T17:52:28.175Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics, unsupported/gap behavior
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-19@0.436, law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.43, sandbags-upload-flood-risk-management-global-case-studies-chunk-20@0.419, sandbags-upload-flood-risk-management-global-case-studies-chunk-15@0.397, sandbags-upload-flood-risk-management-global-case-studies-chunk-11@0.367

### current-flood-warning-japan
- Status: 200 ok
- Confidence: High
- Session: session-1780163551376-k3vwc1 createdAt=2026-05-30T17:52:31.376Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.987, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.786, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.754, sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.685

### community-resilience-recovery
- Status: 200 ok
- Confidence: High
- Session: session-1780163554658-o1pjbg createdAt=2026-05-30T17:52:34.658Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.111, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.965, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: High
- Session: session-1780163557958-gc3can createdAt=2026-05-30T17:52:37.958Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.785, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.731, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.66, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2@0.638, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-4@0.635

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: High
- Session: session-1780163561456-u87fgw createdAt=2026-05-30T17:52:41.456Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.756, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.754, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-6@0.603, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.562

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: High
- Session: session-1780163564572-nfupvy createdAt=2026-05-30T17:52:44.572Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11@0.804, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-9@0.758, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-10@0.74, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-14@0.739, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.71

### south-sudan-local-measures
- Status: 200 ok
- Confidence: High
- Session: session-1780163567856-urz9wc createdAt=2026-05-30T17:52:47.856Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.011, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-3@0.626

### contract-law-basics
- Status: 200 ok
- Confidence: High
- Session: session-1780163570658-mrsr3g createdAt=2026-05-30T17:52:50.658Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.894, law-upload-legal-duties-and-emergency-management-contracts-chunk-4@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780163573764-01gs8m createdAt=2026-05-30T17:52:53.764Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780163576864-f06rke createdAt=2026-05-30T17:52:56.864Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780163580075-oc26x3 createdAt=2026-05-30T17:53:00.075Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780163583463-tzek7l createdAt=2026-05-30T17:53:03.463Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: High
- Session: session-1780163586867-c22vxy createdAt=2026-05-30T17:53:06.868Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics, unsupported/gap behavior
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-5@0.74, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.653, sandbags-upload-flood-risk-management-global-case-studies-chunk-23@0.63, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.629, sandbags-upload-flood-risk-management-global-case-studies-chunk-138@0.62

### niger-wmo-reference
- Status: 200 ok
- Confidence: High
- Session: session-1780163589879-1k1g83 createdAt=2026-05-30T17:53:09.879Z
- Failure classes: source_chunk_ocr_layout, confidence_calibration, unsupported_gap_missing
- Recommended work: #28 OCR/layout cleanup, confidence/calibration diagnostics, unsupported/gap behavior
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.744, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.741, sandbags-upload-flood-risk-management-global-case-studies-chunk-101@0.715, sandbags-upload-flood-risk-management-global-case-studies-chunk-103@0.702

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: High
- Session: session-1780163593059-heep2f createdAt=2026-05-30T17:53:13.059Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics, confidence/calibration diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-88@0.606, sandbags-upload-flood-risk-management-global-case-studies-chunk-127@0.598, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-128@0.569, sandbags-upload-flood-risk-management-global-case-studies-chunk-13@0.555

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: High
- Session: session-1780163596174-j8dvh1 createdAt=2026-05-30T17:53:16.174Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics, confidence/calibration diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.723, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.626, sandbags-upload-flood-risk-management-global-case-studies-chunk-95@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: High
- Session: session-1780163598971-qyg4zp createdAt=2026-05-30T17:53:18.971Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.734, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.71, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.709, sandbags-upload-flood-risk-management-global-case-studies-chunk-86@0.684

### mid-word-boundary
- Status: 200 ok
- Confidence: High
- Session: session-1780163602360-ekmj4g createdAt=2026-05-30T17:53:22.360Z
- Failure classes: source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness, confidence_calibration
- Recommended work: #28 OCR/layout cleanup, retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics, confidence/calibration diagnostics
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.748, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.644, sandbags-upload-flood-risk-management-global-case-studies-chunk-117@0.629, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.588, sandbags-upload-flood-risk-management-global-case-studies-chunk-8@0.585

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: High
- Session: session-1780163605466-4o7ra2 createdAt=2026-05-30T17:53:25.466Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.819, sandbags-upload-flood-risk-management-global-case-studies-chunk-86@0.806, sandbags-upload-flood-risk-management-global-case-studies-chunk-101@0.729, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.725

### metadata-source-display
- Status: 200 ok
- Confidence: High
- Session: session-1780163608654-kmvnuq createdAt=2026-05-30T17:53:28.654Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-19@0.779, sandbags-upload-flood-risk-management-global-case-studies-chunk-11@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-5@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.686, sandbags-upload-flood-risk-management-global-case-studies-chunk-55@0.667

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780163611857-b5zge1 createdAt=2026-05-30T17:53:31.857Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.