# FalconTrust RAG Parked Resume Note

Date: 2026-05-30

## Final Local State

- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Park-start HEAD: `9f329065255102ded18d964ce900acf3265821d5`
- Latest restore report: `docs/rag-quality/runs/20260530-current-best-dev-restore-point.md`
- Latest remaining-failures report: `docs/rag-quality/runs/20260530-remaining-failures-pass.md`

## AWS Dev Known State

- Dev endpoint: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
- App Runner service: `falcontrust-rag-dev-web`
- Current known App Runner image: `falcontrust-rag-app:rag-retrieval-generation-dev-20260530-1d85bc9-20260530182219`
- Restore point: `s3://falcontrust-rag-dev-data-510844691338-us-east-2/restore-points/20260530-current-best-before-remaining-failures/`
- Restore manifest: `docs/rag-quality/runs/20260530-current-best-dev-restore-point/restore-manifest.json`
- Restore contents: current Dev vector manifest plus 8 approved source JSON objects.
- Vector count at restore: `260`
- HAZUS record count at restore: `4`

## Current Live Diagnostic Counts

Latest live diagnostics artifact:

- `docs/rag-quality/runs/20260530-remaining-failures-pass/baseline.json`

Counts:

- `source_chunk_ocr_layout`: `1`
- `confidence_calibration`: `0`
- `unsupported_gap_missing`: `0`
- `retrieval_ranking`: `1`
- `answer_generation_faithfulness`: `1`
- `reference_frontmatter_leakage`: `0`

## What Improved

- The current-best Dev restore point was captured before the last remaining-failures pass.
- Diagnostic OCR/layout noise was reduced from `3` to `1` by avoiding false continuation-boundary flags for valid `From` and `While` sentence starts.
- Frontmatter leakage remains at `0`.
- No additional Dev deploy was performed for the diagnostics-only changes.

## Remaining Known Issues

- `south-sudan-local-measures` still has one real source/chunk OCR-layout issue.
- `wri-flood-exposure-reference` still fails retrieval ranking and answer-generation faithfulness because the selected chunks do not answer the country-exposure question.
- Current Dev may be too conservative for some real queries; exact manual query/selected domains should be added as a regression case before more tuning.

## Morning Resume Step

Before making changes, capture the exact manual query that looked too conservative, including:

- selected filters/domains;
- actual answer;
- retrieved chunks;
- filtered-out chunks;
- confidence/evidence-policy diagnostics;
- citations shown or suppressed;
- comparison against the older or better answer behavior.

Use that as a new regression case before changing gating, ranking, source text, or vector state.

## Holds

- Do not promote to Staging or Demo.
- Do not merge to main.
- Do not reindex or reembed without explicit approval.
- Do not mutate AWS source/vector/index data without first deciding whether to use the captured restore point.
