# FalconTrust RAG Persistent OCR/Layout Diagnosis

Run: falcontrust-rag-20260530-024-persistent-ocr-layout-diagnosis

## Scope

This run re-anchored the FalconTrust app worktree at 4fee07d78a21ef9f2160f72e9f453ff509e1d991 on branch rag-retrieval-generation-dev-20260530, with a clean git status before changes. It used only current AWS Dev live diagnostics from the HAZUS rollback state.

No S3 source, vector, index, reindex, reembed, Staging, Demo, main merge, delete, secret print, or parent workspace mutation was performed. The earlier 8-doc Dev partial refresh remains active.

## Current Baseline

Current live rollback diagnostics:

- Source: docs/rag-quality/runs/20260530-hazus-followup-rollback/baseline.json
- Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Counts: source_chunk_ocr_layout=15, confidence_calibration=0, unsupported_gap_missing=0, retrieval_ranking=1, answer_generation_faithfulness=1, reference_frontmatter_leakage=1

Failing IDs before this run:

- OCR/layout: mobile-warning-artifact, fews-mobile-warning, current-flood-warning-japan, community-resilience-recovery, hazus-flood-loss-model, life-safety-model-fatalities, preparedness-workshop-kits, south-sudan-local-measures, contract-law-basics, wri-flood-exposure-reference, technology-exclusion-joined-heading, page-header-author-artifact, mid-word-boundary, duplicate-overlap-evidence, metadata-source-display
- Frontmatter/reference: hazus-flood-loss-model
- Retrieval/faithfulness: wri-flood-exposure-reference

## Diagnosis

Most OCR/layout failures were diagnostic overreach, not proven source/OCR corruption. The classifier treated every citation preview ending in a lowercase letter, comma, semicolon, or colon as badSentenceEnding, then counted that flag alone as source_chunk_ocr_layout. Live /api/query citations are snippets/previews and often end mid-sentence because they are clipped, so this inflated OCR/layout from real defect signals into a preview-length artifact.

The HAZUS frontmatter/reference failure was also diagnostic overreach. hazus-flood-loss-model cited a body chunk containing the product phrase ArcGIS Map Publisher; the diagnostic regex treated any publisher token as frontmatter leakage. That is not a frontmatter/copyright/source artifact in this context.

Persistent post-refinement failures are more precise:

- south-sudan-local-measures: real data/layout issue. Top chunks include page/header-like text such as 91 In South Sudan and journal/page footer fragments.
- duplicate-overlap-evidence: still has a continuation-start chunk at rank 4, but top evidence is otherwise body evidence. This is partly diagnostic and partly chunk-boundary quality.
- metadata-source-display: rank 3 starts with While, a continuation-style boundary. This is a small chunk-boundary issue, not metadata loss.
- wri-flood-exposure-reference: retrieval/ranking and faithfulness remain. The retrieved chunks do not answer the country-exposure question; this needs ranking/source corpus work, not OCR classifier work.

## Code Fix

Changed scripts/rag-diagnostics.mjs only:

- badSentenceEnding is still recorded on citations, but no longer creates source_chunk_ocr_layout by itself.
- Frontmatter detection no longer treats generic publisher or series text as leakage; it now requires stronger frontmatter terms such as Table of Contents, copyright, ISBN, Cataloging-in-Publication, or Published by.

Added test coverage in tests/rag/diagnostics-scaffold.test.mjs for the HAZUS ArcGIS Map Publisher false positive and clipped-preview badSentenceEnding behavior.

## Tests

- npm run test:rag: pass, 31/31
- npm run test:rag-diagnostics: pass, diagnostics scaffold 4/4

No Dev deploy was performed because the app runtime path did not change; this was a diagnostics-harness refinement and live validation used the changed local diagnostics script against the unchanged Dev endpoint.

## Live Validation After Fix

Live diagnostics rerun:

- docs/rag-quality/runs/20260530-persistent-ocr-layout-diagnosis/baseline-live-live-aws-dev-persistent-ocr-layout-diagnosis-20260530-20260530T232435Z.json
- docs/rag-quality/runs/20260530-persistent-ocr-layout-diagnosis/baseline-live-live-aws-dev-persistent-ocr-layout-diagnosis-20260530-20260530T232435Z.md

After counts:

- source_chunk_ocr_layout=3
- confidence_calibration=0
- unsupported_gap_missing=0
- retrieval_ranking=1
- answer_generation_faithfulness=1
- reference_frontmatter_leakage=0

Remaining failure IDs:

- OCR/layout: south-sudan-local-measures, duplicate-overlap-evidence, metadata-source-display
- Retrieval/faithfulness: wri-flood-exposure-reference

## Recommendation

Keep this diagnostics refinement. It makes the live failure count reflect actual remaining issues instead of clipped citation-preview artifacts. Do not mutate S3/vector data or deploy based on this run. The next narrow lane should target wri-flood-exposure-reference ranking/answerability and the three remaining real chunk-boundary/layout cases.

Confirmations: no S3/source/vector/index mutation, no reindex/reembed/full reindex, no Staging deploy, no Demo deploy, no main merge, no deletes, no secrets, no parent workspace dirt, no internal worker.
