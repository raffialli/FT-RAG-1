# FalconTrust Remaining Failures Pass

Run: falcontrust-rag-20260530-025-restore-remaining-failures

## Scope

Performed one narrow remaining-failures pass after capturing the required restore point. The change was diagnostics-harness only; no runtime app deploy was performed.

No S3/source/vector/index mutation, reindex, reembed, full reindex, Staging, Demo, main merge, delete, secret print, or parent workspace touch was performed after the restore point.

## Before

Current counts before the pass:

- source_chunk_ocr_layout=3
- confidence_calibration=0
- unsupported_gap_missing=0
- retrieval_ranking=1
- answer_generation_faithfulness=1
- reference_frontmatter_leakage=0

Failing IDs before the pass:

- OCR/layout: south-sudan-local-measures, duplicate-overlap-evidence, metadata-source-display
- Retrieval/faithfulness: wri-flood-exposure-reference

## Diagnosis And Fix

The remaining duplicate-overlap-evidence and metadata-source-display OCR/layout flags came from the diagnostic classifier treating citations starting with From or While as continuation-boundary defects. In the current live evidence these are valid sentence starts in body prose, not reliable OCR/chunk-boundary defects.

Changed scripts/rag-diagnostics.mjs so continuationStart no longer treats from or while as automatic continuation starts. Added mock live diagnostics coverage in tests/rag/diagnostics-scaffold.test.mjs to protect valid From and While body evidence.

No WRI ranking/code fix was made because the current evidence shows a real retrieval/answerability miss: the selected chunks do not answer the country-exposure question. That requires a separate ranking/source-data lane, not a broader classifier change.

## Tests

- npm run test:rag: pass, 31/31
- npm run test:rag-diagnostics: pass, diagnostics scaffold 4/4

## Live Validation After Pass

Live diagnostics rerun:

- docs/rag-quality/runs/20260530-remaining-failures-pass/baseline-live-live-aws-dev-remaining-failures-pass-20260530-20260530T234542Z.json
- docs/rag-quality/runs/20260530-remaining-failures-pass/baseline-live-live-aws-dev-remaining-failures-pass-20260530-20260530T234542Z.md

After counts:

- source_chunk_ocr_layout=1
- confidence_calibration=0
- unsupported_gap_missing=0
- retrieval_ranking=1
- answer_generation_faithfulness=1
- reference_frontmatter_leakage=0

Remaining failures:

- south-sudan-local-measures: source/chunk/OCR layout remains. Top evidence includes page/header artifacts such as 91 In South Sudan and journal/page footer fragments.
- wri-flood-exposure-reference: retrieval ranking and answer-generation faithfulness remain. The retrieved chunks do not answer which countries have the highest river flood risk exposure.

## Recommendation

Keep this diagnostics refinement. It reduces OCR/layout noise from 3 to 1 without hiding the remaining real South Sudan source/chunk issue. Do not deploy or mutate Dev data from this run. Next narrow lane should target WRI retrieval/answerability and the single remaining South Sudan source/chunk cleanup with the restore point available.

Confirmations: restore point captured first; no S3/source/vector/index mutation after restore; no reindex/reembed/full reindex; no deploy; no Staging/Demo/main; no delete; no secrets; no parent workspace dirt; no internal worker.
