# RAG Diagnostics Baseline
Generated: 2026-05-30T23:45:42.883Z
Mode: live
Environment: live-aws-dev-remaining-failures-pass-20260530
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 1
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
## Recommended Work Buckets
- #28 OCR/layout cleanup: 1
- retrieval/ranking diagnostics: 1
- answer-generation/faithfulness diagnostics: 1
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184746186-dclv60 createdAt=2026-05-30T23:45:46.186Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.756, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.742, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.699

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184749899-c8llpt createdAt=2026-05-30T23:45:49.899Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: Low
- Session: session-1780184753506-0kj682 createdAt=2026-05-30T23:45:53.506Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fews-mobile-warning
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184757486-pzhiet createdAt=2026-05-30T23:45:57.486Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.714, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.675

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: Low
- Session: session-1780184761200-ftbxkf createdAt=2026-05-30T23:46:01.200Z
- Failure classes: none
- Recommended work: none
- Citations: none

### current-flood-warning-japan
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184765387-9oif50 createdAt=2026-05-30T23:46:05.387Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.937, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.777, sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.683, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-11@0.657

### community-resilience-recovery
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184769095-yepzfa createdAt=2026-05-30T23:46:09.095Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.048, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.981, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184772395-3cv57b createdAt=2026-05-30T23:46:12.395Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.9, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.761, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2@0.737, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.703, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.658

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184775798-2c31hz createdAt=2026-05-30T23:46:15.798Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.84, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-7@0.785, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.749, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.68, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.633

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184779491-euvtca createdAt=2026-05-30T23:46:19.491Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-14@0.93, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11@0.83, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-8@0.819, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13@0.787, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-16@0.72

### south-sudan-local-measures
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184782897-w54iq5 createdAt=2026-05-30T23:46:22.897Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.059, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-4@0.686

### contract-law-basics
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184785685-jv00jb createdAt=2026-05-30T23:46:25.685Z
- Failure classes: none
- Recommended work: none
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.874, law-upload-legal-duties-and-emergency-management-contracts-chunk-3@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780184789798-lskyu4 createdAt=2026-05-30T23:46:29.798Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780184793287-5acwah createdAt=2026-05-30T23:46:33.287Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780184796690-p1pyvr createdAt=2026-05-30T23:46:36.690Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780184800392-y7mh6g createdAt=2026-05-30T23:46:40.392Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780184804007-t50paj createdAt=2026-05-30T23:46:44.007Z
- Failure classes: none
- Recommended work: none
- Citations: none

### niger-wmo-reference
- Status: 200 ok
- Confidence: Low
- Session: session-1780184807685-kphpud createdAt=2026-05-30T23:46:47.685Z
- Failure classes: none
- Recommended work: none
- Citations: none

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184811592-p88web createdAt=2026-05-30T23:46:51.592Z
- Failure classes: retrieval_ranking, answer_generation_faithfulness
- Recommended work: retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-154@0.614, sandbags-upload-flood-risk-management-global-case-studies-chunk-68@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-108@0.57, sandbags-upload-flood-risk-management-global-case-studies-chunk-55@0.555, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.509

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184815088-jr1u3j createdAt=2026-05-30T23:46:55.088Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-110@0.722, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.621, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184819093-cxiy5g createdAt=2026-05-30T23:46:59.093Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.735, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.706, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.702, sandbags-upload-flood-risk-management-global-case-studies-chunk-115@0.671

### mid-word-boundary
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184822896-keesvv createdAt=2026-05-30T23:47:02.896Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.781, sandbags-upload-flood-risk-management-global-case-studies-chunk-148@0.645, sandbags-upload-flood-risk-management-global-case-studies-chunk-143@0.629, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-6@0.572, sandbags-upload-flood-risk-management-global-case-studies-chunk-145@0.527

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184827090-07tbwu createdAt=2026-05-30T23:47:07.090Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-105@0.808, sandbags-upload-flood-risk-management-global-case-studies-chunk-106@0.769, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.752, sandbags-upload-flood-risk-management-global-case-studies-chunk-124@0.729

### metadata-source-display
- Status: 200 ok
- Confidence: Medium
- Session: session-1780184830792-j5kdrz createdAt=2026-05-30T23:47:10.792Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-14@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-6@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-27@0.69, sandbags-upload-flood-risk-management-global-case-studies-chunk-163@0.621

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780184835197-d2mw3w createdAt=2026-05-30T23:47:15.197Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.