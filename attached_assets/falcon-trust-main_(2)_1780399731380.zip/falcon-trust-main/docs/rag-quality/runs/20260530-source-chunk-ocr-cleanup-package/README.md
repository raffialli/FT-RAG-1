# Source/Chunk/OCR Cleanup Package

Actual reviewable local cleanup package for the affected Dev RAG corpus documents.

This package is generated from the read-only local export at `/home/ralli/falcontrust-dev-corpus-export-20260530`. It does not edit the export in place and does not contain full exported corpus files.

## Contents

- `cleaned-candidates/`: JSON candidates with original excerpts, cleaned excerpts, rules, metadata changes, and split/merge/downrank/exclude decisions.
- `old-new-diffs/`: Markdown old/new excerpt diffs for review.
- `partial-refresh-plan.md`: exact Dev-only mutation approval plan.
- `affected-doc-refresh-plan.json`: machine-readable partial refresh plan.

## Scope

- affected documents: 8
- candidate files: 8
- diff files: 8
- vector index source: `vectors/dev-customer-phase2-vector-index.json`
- partial reindex/reembed: required for affected docs if approved source/chunk text changes
- full reindex/reembed: not requested and not justified by this package

## Safety

No S3 write/delete/sync-back, vector/index mutation, reindex, reembed, deploy, merge, or exported-corpus commit was performed.