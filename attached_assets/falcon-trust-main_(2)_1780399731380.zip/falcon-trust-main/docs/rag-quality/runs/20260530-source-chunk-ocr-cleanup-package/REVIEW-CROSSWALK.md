# Review Crosswalk

This supplemental crosswalk keeps the detailed JSON cleanup package intact while adding concise Markdown entry points for reviewer scanning.

Primary package files:

- `README.md`
- `partial-refresh-plan.md`
- `affected-doc-refresh-plan.json`
- `cleaned-candidates/*.json`
- `old-new-diffs/*.md`

Supplemental Markdown summaries:

- `cleaned-candidates/community-resilience.md`
- `cleaned-candidates/global-case-studies.md`
- `cleaned-candidates/hazus-mh.md`
- `cleaned-candidates/japan-warning.md`
- `cleaned-candidates/legal-duties-contracts.md`
- `cleaned-candidates/life-safety.md`
- `cleaned-candidates/preparedness-curriculum.md`
- `cleaned-candidates/south-sudan.md`
- `old-new-diffs/japan-warning.md`
- `old-new-diffs/life-safety.md`

The supplemental files do not replace the richer machine-readable candidate JSON or the original old/new diffs. They are review aids for the same Dev-only partial refresh proposal.
