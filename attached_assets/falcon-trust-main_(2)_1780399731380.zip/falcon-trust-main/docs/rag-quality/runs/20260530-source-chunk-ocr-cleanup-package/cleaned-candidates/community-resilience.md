# Cleaned Candidate: Community Resilience and Recovery After Major Flood

- Document ID: `sandbags-upload-community-resilience-and-recovery-after-major-flood`
- Source key: `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- Source file: `bdevito67,+JEM_V6N5_9.pdf`
- Original chunks: `1`, `5`, `7`, `8`, `9`
- Proposed action: split frontmatter/abstract from body and preserve resilience strategy chunks.

## Original Excerpt

`chunk-1`: `# Community Resilience and Recovery After Major Flood ABSTRACT Resilience refers to the capacity to withstand, overcome, or recover from serious threat, such as a natural disaster...`

## Cleaned Candidates

### Candidate 1A - Abstract Chunk

- Content type: `abstract`
- Retrieval priority: low for answer generation.

`The article defines resilience as the capacity to withstand, overcome, or recover from serious threat such as a natural disaster, and studies recovery in small towns after major flooding.`

### Candidate 7A - Body Lessons Chunk

- Content type: `body`
- Retrieval priority: normal.

`Community resilience lessons include working with outside agencies, adapting recovery plans to local needs, recognizing flood vulnerability, staying united, and sustaining hope during the long recovery period.`

## Cleanup Rules Applied

- Split title/abstract lead-in from body evidence.
- Preserve quote/strategy sections as answerable body chunks.
- Repair metadata so abstract chunks are not treated as ordinary body evidence.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `community-resilience-recovery`.
- Keeps useful recovery lesson evidence in retrieval while avoiding answer openings with abstract text.

## Refresh Need

Requires rechunk, metadata repair, and partial reembed/reindex for this document.
