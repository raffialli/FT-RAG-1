# Cleaned Candidate: Flood Risk Management Global Case Studies

- Document ID: `sandbags-upload-flood-risk-management-global-case-studies`
- Source key: `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- Source file: `Flood Risk Management-OCR.pdf`
- Original chunks: `5`, `8`, `11`, `13`, `19`, `54`, `55`, `85`, `86`, `88`, `90`, `95`, `98`, `101`, `117`, `121`, `127`, `128`
- Proposed action: normalize source text, rechunk affected sections, repair metadata, and downrank/exclude reference-like transitions.

## Original Excerpts

`chunk-90`: `These bureaucratic inefficiencies have been cited as a key reason for delays in the warning processes of developing countries... Flood warnings in the developing world 121 Institutionalimpediments Well-structured institutional frameworks are required...`

`chunk-121`: `Hydroloiical Processes,26(11), 1748-1175. E E Motivations for floodplain occupation Laura West Fischer Introduction Floods are frequent phenomena...`

`chunk-13`: `The Free Press, New York. LEGAL GE GRAPHY A D FLOO ERMA Y MANAGEMENT IN Matilda Becker Introduction RISK Flood risk management...`

## Cleaned Candidates

### Candidate 90A - Institutional Impediments Body Chunk

- Content type: `body`
- Replace/split original: replace original `chunk-90` section after removing page header.

`These bureaucratic inefficiencies have been cited as a key reason for delays in warning processes in developing countries. Institutional impediments. Well-structured institutional frameworks are required to match the location of flood management control with the transitioning location of knowledge. In developing countries, weakened frameworks, unstable politics, and frequent change can limit warning effectiveness.`

### Candidate 95A - Technology Exclusion Body Chunk

- Content type: `body`
- Replace/split original: keep and favor over noisy `chunk-90` for technology-exclusion queries.

`Technology issues can be addressed by involving communities in system design and implementation. Where warning technology is unevenly available, communities may be excluded from effective warning access unless local preferences, communications infrastructure, and trusted dissemination routes are considered.`

### Candidate 121A - Floodplain Occupation Body Chunk

- Content type: `body`
- Replace/split original: remove dangling reference transition before heading.

`Motivations for floodplain occupation. Floods are frequent phenomena in the United States. Residents are exposed to fluvial, pluvial, and coastal flood hazards, yet populations in flood-prone areas continue to increase.`

### Candidate Reference Transition

- Content type: `reference`
- Retrieval priority: exclude from answerable retrieval.

`Hydrological Processes, 26(11), 1748-1175.`

## Cleanup Rules Applied

- Remove page/chapter headers like `Flood warnings in the developing world 121`.
- Repair OCR joins such as `Institutionalimpediments`.
- Normalize obvious OCR errors such as `Hydroloiical`.
- Split reference tail text away from next body section.
- Add metadata flags for `contentType: reference`, `contentType: heading`, or lower-priority layout fragments.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` across the largest remaining failure cluster.
- Reduces `retrieval_ranking` and `answer_generation_faithfulness` for `technology-exclusion-joined-heading`, `mid-word-boundary`, and `wri-flood-exposure-reference`.
- Improves citation quality for `fews-mobile-warning`, `mobile-warning-artifact`, `duplicate-overlap-evidence`, and `metadata-source-display`.

## Refresh Need

Requires source normalization, rechunk, metadata repair, and partial reembed/reindex for this document.
