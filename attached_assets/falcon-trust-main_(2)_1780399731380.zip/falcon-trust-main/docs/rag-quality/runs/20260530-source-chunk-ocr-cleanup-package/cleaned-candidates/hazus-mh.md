# Cleaned Candidate: Hazard Mitigation Planning Using HAZUS-MH Flood Model

- Document ID: `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model`
- Source key: `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- Source file: `bdevito67,+JEM_V3N2_3.pdf`
- Original chunks: `1`, `2`, `4`
- Proposed action: split abstract/title from body and preserve direct HAZUS loss-estimation evidence.

## Original Excerpt

`chunk-1`: `# Hazard Mitigation Planning Using HAZUS-MH Flood Model AbstrAct This study uses FEMA's new flood model software, HAZUS-MH (Multi-Hazard), to assess the socioeconomic damages following floods...`

## Cleaned Candidates

### Candidate 1A - Abstract Chunk

- Content type: `abstract`
- Retrieval priority: low for answer generation.

`The study uses FEMA's HAZUS-MH Flood Model to assess socioeconomic damages following floods, including estimates of land-use impacts and direct and indirect losses.`

### Candidate 1B - HAZUS Body Chunk

- Content type: `body`
- Retrieval priority: normal.

`HAZUS-MH is FEMA's flood model software for assessing flood losses. It provides estimates that can support hazard mitigation planning by evaluating direct and indirect social, economic, and environmental losses from flood hazards.`

## Cleanup Rules Applied

- Split title/abstract from direct body evidence.
- Preserve direct HAZUS evidence as body.
- Retest ranking after Life Safety figure/table cleanup; this document may need less source surgery than the adjacent noisy documents.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `hazus-flood-loss-model`.
- Supports reranking direct HAZUS chunks above adjacent Life Safety figure/table chunks.

## Refresh Need

Requires rechunk and partial reembed/reindex if abstract/body split is applied.
