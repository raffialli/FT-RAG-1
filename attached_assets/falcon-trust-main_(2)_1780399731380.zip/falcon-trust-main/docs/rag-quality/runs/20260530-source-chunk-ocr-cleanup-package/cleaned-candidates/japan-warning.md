# Cleaned Candidate: Current Flood Warning System in Japan

- Document ID: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness`
- Source key: `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- Source file: `bdevito67,+JEM_21-1-04-Huang.pdf`
- Original chunk: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1`
- Proposed action: split and relabel.

## Original Excerpt

`# Current Flood Warning System in Japan and Evacuation Effectiveness Current flood warning system in Japan and its effectiveness in mobilizing evacuation: Lessons from case studies Guangwei Huang, PhD Juan Fan ABSTRACT An effective flood warning system is crucial for successful flood management...`

## Cleaned Candidates

### Candidate 1A - Title Metadata Chunk

- Content type: `frontmatter`
- Retrieval priority: exclude from answerable retrieval, retain for citation/source display.

`Current Flood Warning System in Japan and Evacuation Effectiveness. Current flood warning system in Japan and its effectiveness in mobilizing evacuation: Lessons from case studies. Guangwei Huang, PhD; Juan Fan.`

### Candidate 1B - Abstract Summary Chunk

- Content type: `abstract`
- Retrieval priority: low for answer generation unless the question asks for the abstract or paper scope.

`The paper evaluates Japan's flood warning practices and warning effectiveness through case studies and a SWOT assessment. It discusses strengths, weaknesses, opportunities, threats, and directions for improving flood warning practice.`

### Candidate 1C - Answerable Body Chunk

- Content type: `body`
- Retrieval priority: normal.

`Japan has a long history of flood management, and the paper uses case studies to assess how current warning practices help mobilize evacuation. The analysis highlights strengths and weaknesses of the warning system and identifies directions for refinement.`

## Cleanup Rules Applied

- Remove title/authors/abstract lead-in from body chunk.
- Preserve title and abstract as non-body metadata/abstract chunks.
- Repair metadata: `contentType` should not be `body` for frontmatter/abstract segments.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `current-flood-warning-japan`, `mobile-warning-artifact`, `page-header-author-artifact`, and `duplicate-overlap-evidence`.
- Prevents answers from opening with title/authors/abstract text.

## Refresh Need

Requires rechunk and partial reembed/reindex for this document.
