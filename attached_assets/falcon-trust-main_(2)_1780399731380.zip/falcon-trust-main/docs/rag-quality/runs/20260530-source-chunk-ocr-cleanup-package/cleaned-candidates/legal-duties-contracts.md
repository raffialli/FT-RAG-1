# Cleaned Candidate: Legal Duties and Emergency Management Contracts

- Document ID: `law-upload-legal-duties-and-emergency-management-contracts`
- Source key: `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- Source file: `bdevito67,+JEM_V3N3_3.pdf`
- Original chunks: `1`, `2`, `4`
- Proposed action: strip legal desk header residue and prefer direct contract guidance.

## Original Excerpt

`chunk-2`: `Nicholson, JD JEM Legal desk health services; rescue; engineering; warning services; communications; radiological, chemical, and other special weapons defense...`

## Cleaned Candidates

### Candidate 2A - Emergency Duties Body Chunk

- Content type: `body`

`Emergency management duties can include health services, rescue, engineering, warning services, communications, evacuation, welfare services, emergency transportation, infrastructure protection, and restoration of utility services.`

### Candidate 4A - Contract Modification Body Chunk

- Content type: `body`
- Retrieval priority: high for contract-law questions.

`Contract modifications that benefit emergency managers can address prompt performance by adding incentives for timely completion and by defining contractual steps that support emergency response needs.`

## Cleanup Rules Applied

- Remove `Nicholson, JD JEM Legal desk` header residue.
- Keep broad legal-duty context separate from direct contract modification guidance.
- Add metadata/reranking preference for direct contract chunks on contract-law questions.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `contract-law-basics`.
- Improves faithfulness by grounding contract answers in direct contract guidance rather than header-contaminated broad emergency duty text.

## Refresh Need

Requires partial reembed/reindex if source/chunk text or metadata is changed.
