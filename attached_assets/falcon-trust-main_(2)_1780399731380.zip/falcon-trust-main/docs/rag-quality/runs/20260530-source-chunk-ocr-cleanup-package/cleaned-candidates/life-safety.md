# Cleaned Candidate: Life Safety Modeling for Flood Emergency Management

- Document ID: `sandbags-upload-life-safety-modeling-for-flood-emergency-management`
- Source key: `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- Source file: `bdevito67,+JEMv9n1_7.pdf`
- Original chunks: `2`, `3`, `6`, `8`
- Proposed action: normalize control glyph bullets and separate figure/table captions from body chunks.

## Original Excerpts

`chunk-2`: `[control glyph] Floodwater depths, velocities, and travel times that affect the fate of people and vehicles are based on large-scale average values. [control glyph] Factors that change with time are often not represented...`

`chunk-8`: `Generally, Figure 7. Variation in the percentage of people reaching the exit after 8 hours... Table 1. Number of fatalities calculated against the reduction of the people's physical condition parameter...`

## Cleaned Candidates

### Candidate 2A - Clean Limitation List

- Content type: `body`
- Replace original chunk subsection after glyph cleanup.

`Limitations of empirical loss-of-life models include using large-scale average floodwater depths, velocities, and travel times; limited representation of factors that change over time; simplified treatment of the population at risk; limited treatment of evacuation as a separate process; and limited accounting for flood warning dissemination.`

### Candidate 8A - Figure/Table Caption Chunk

- Content type: `table`
- Retrieval priority: answerable only for table/figure/fatality-count queries.

`Figure 7 and Table 1 report modeled fatalities under different reductions in people's physical condition parameter, including fatalities due to drowning and exhaustion.`

### Candidate 8B - Body Conclusion Chunk

- Content type: `body`
- Retrieval priority: normal.

`The Life Safety Model provides a scientifically robust method for assessing residual risk behind flood defenses and downstream of dams in terms of fatalities. It can support detailed emergency planning more directly than first-order evacuation and loss-of-life models.`

## Cleanup Rules Applied

- Convert control-glyph bullets to plain list text.
- Split figure/table captions and numeric rows from prose conclusions.
- Add metadata to downrank table/caption chunks when the query is not asking for table content.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `life-safety-model-fatalities`.
- Reduces noisy outranking for `hazus-flood-loss-model` and `mid-word-boundary`.

## Refresh Need

Requires source cleanup, rechunk, metadata repair, and partial reembed/reindex for this document.
