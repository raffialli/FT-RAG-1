# Cleaned Candidate: Personal Preparedness Curriculum for Public Health Workers

- Document ID: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`
- Source key: `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- Source file: `bdevito67,+JEM-12-1-04-Kohn.pdf`
- Original chunks: `9`, `10`, `11`, `14`
- Proposed action: represent answer-bearing tables as table-aware chunks instead of flattened prose.

## Original Excerpt

`chunk-11`: `42 100.0 17 100.0 6 85.7 42 100.0 Table 6. Percent of respondents with "yes" responses to personal emergency preparedness questions by EPPM category...`

## Cleaned Candidates

### Candidate 11A - Table Summary Chunk

- Content type: `table`
- Retrieval priority: normal only for questions about workshop outcomes, emergency kits, and preparedness measures.

`Table 6 reports "yes" responses to personal emergency preparedness questions across pretraining, post-training, and one-year follow-up. It includes rows for knowing what should be included in a family emergency kit, having a family emergency plan, and knowing where to find more emergency-kit resources.`

### Candidate 11B - Answerable Outcome Chunk

- Content type: `body`
- Retrieval priority: normal.

`One year after the preparedness workshop, the study reports improved practical preparedness outcomes, including a higher share of participants reporting personal emergency kits compared with baseline.`

## Cleanup Rules Applied

- Remove orphan numeric row fragments before the table caption.
- Preserve caption, table meaning, and answer-bearing percentages.
- Add `contentType: table` or equivalent metadata for table chunks.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `preparedness-workshop-kits` without losing answer-bearing evidence.

## Refresh Need

Requires table-aware rechunk and partial reembed/reindex for this document.
