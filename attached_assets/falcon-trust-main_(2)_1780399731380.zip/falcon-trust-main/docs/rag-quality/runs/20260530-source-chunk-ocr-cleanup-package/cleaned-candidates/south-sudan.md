# Cleaned Candidate: Practical Flood Risk Reduction Strategies in South Sudan

- Document ID: `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan`
- Source key: `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- Source file: `bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf`
- Original chunks: `3`, `8`, `10`, `12`
- Proposed action: strip journal/page header residue while preserving direct numbered recommendations.

## Original Excerpt

`chunk-8`: `These long-term measures are not consistently 129 Journal of Emergency Management Vol. 20, No. 8 Georgetown University Special Issue maintained because they are expensive to manage...`

## Cleaned Candidates

### Candidate 8A - Long-Term Measures Body Chunk

- Content type: `body`

`These long-term measures are not consistently maintained because they are expensive to manage and many people see no immediate benefits. After repeated flooding, communities may see the value of investing in flood risk reduction.`

### Candidate 12A - Numbered Recommendation Chunk

- Content type: `body`
- Retrieval priority: high for local-measure questions.

`Recommended local flood risk reduction measures include implementing structural mitigation using accessible systems such as Trapbag or Gabion wall systems, procuring international funding, and investing in nationwide critical infrastructure.`

## Cleanup Rules Applied

- Remove journal/page header residue.
- Preserve numbered recommendations.
- Keep this as lower-risk cleanup because the best direct chunk already ranks first.

## Expected Diagnostic Improvement

- Reduces `source_chunk_ocr_layout` for `south-sudan-local-measures`.

## Refresh Need

Requires partial reembed/reindex only if header-stripped text is applied to source/chunks.
