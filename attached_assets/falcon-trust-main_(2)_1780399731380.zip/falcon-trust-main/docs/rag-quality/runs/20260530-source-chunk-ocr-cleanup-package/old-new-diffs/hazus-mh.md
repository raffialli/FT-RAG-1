# Hazard Mitigation Planning Using HAZUS-MH Flood Model

- documentId: `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model`
- source key: `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- source file: `bdevito67,+JEM_V3N2_3.pdf`
- rules: `ranking-retst-after-life-safety`, `tighten-if-needed`
- decisions:
  - split: only if broad HAZUS chunks still rank poorly
  - merge: none
  - downrank: non-direct HAZUS mentions
  - exclude: none

## sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1

- original length: 3585
- proposed content type: `body`
- metadata changes: none

~~~diff
- # Hazard Mitigation Planning Using HAZUS-MH Flood Model AbstrAct This study uses FEMA’s new flood model software, HAZUS-MH (Multi-Hazard), to assess the socioeconomic damages following floods. HAZUS-MH provides dollar figures for land use planners, flood managers, and emergency planners to utilize in their preand post-disaster planning of the economical, social, and environmental consequences of flooding. HAZUS-MH estimates financial losses resulting from a 100-year flood by analyzing the potential direct and indirect economic damages that could occur in a local jurisdiction. HAZUS-MH Flood Model and Hurricane Wind Model was used to estimate losses in the Parish of East Baton Rouge, Louisiana, as part of the jurisdiction’s hazard mitigation planning process. Depth grid maps and flood loss maps are explained and displayed to show the results of the flood hazard and loss analysis. The article evaluates HAZUS-MH against the criteria of quality, timeliness, and completeness. The different levels of HAZUS-MH are explained within the context of accuracy. The article also explains how geographic information system (GIS) data layers can be made available to public officials by use of a fre
+ # Hazard Mitigation Planning Using HAZUS-MH Flood Model AbstrAct This study uses FEMA’s new flood model software, HAZUS-MH (Multi-Hazard), to assess the socioeconomic damages following floods. HAZUS-MH provides dollar figures for land use planners, flood managers, and emergency planners to utilize in their preand post-disaster planning of the economical, social, and environmental consequences of flooding. HAZUS-MH estimates financial losses resulting from a 100-year flood by analyzing the potential direct and indirect economic damages that could occur in a local jurisdiction. HAZUS-MH Flood Model and Hurricane Wind Model was used to estimate losses in the Parish of East Baton Rouge, Louisiana, as part of the jurisdiction’s hazard mitigation planning process. Depth grid maps and flood loss maps are explained and displayed to show the results of the flood hazard and loss analysis. The article evaluates HAZUS-MH against the criteria of quality, timeliness, and completeness. The different levels of HAZUS-MH are explained within the context of accuracy. The article also explains how geographic information system (GIS) data layers can be made available to public officials by use of a fre
~~~

## sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2

- original length: 2971
- proposed content type: `body`
- metadata changes: none

~~~diff
- This paper provides an illustration of how a local community used HAZUS-MH to assess and reduce the direct and indirect social, economic, and environmental losses from flood hazards. The latest version of HAZUS-MH extends natural hazard modeling from a single focus on earthquake hazards to a multihazard analysis system including earthquake, flood, and wind hazards. HAZUS-MH helps emergency managers to determine the potential damage from inland and coastal flooding, hurricane winds, earthquakes, and chemical hazards. 5 Local, state, and federal officials can improve community emergency preparedness, response, recovery, and mitigation activities by enhancing the ability to characterize the economic and social consequences from flood, wind, and coastal hazards.6 Officials at all levels of government have long recognized the need to more accurately estimate the escalating costs associated with natural hazards. 4 The Hazard Mitigation Act of 2000 requires that local jurisdictions complete a comprehensive analysis as a part of their hazard mitigation plan in order to qualify for FEMA mitigation funds. HAZUS-MH provides needed tools to estimate the adverse economic impact of a flood, wind
+ This paper provides an illustration of how a local community used HAZUS-MH to assess and reduce the direct and indirect social, economic, and environmental losses from flood hazards. The latest version of HAZUS-MH extends natural hazard modeling from a single focus on earthquake hazards to a multihazard analysis system including earthquake, flood, and wind hazards. HAZUS-MH helps emergency managers to determine the potential damage from inland and coastal flooding, hurricane winds, earthquakes, and chemical hazards. 5 Local, state, and federal officials can improve community emergency preparedness, response, recovery, and mitigation activities by enhancing the ability to characterize the economic and social consequences from flood, wind, and coastal hazards.6 Officials at all levels of government have long recognized the need to more accurately estimate the escalating costs associated with natural hazards. 4 The Hazard Mitigation Act of 2000 requires that local jurisdictions complete a comprehensive analysis as a part of their hazard mitigation plan in order to qualify for FEMA mitigation funds. HAZUS-MH provides needed tools to estimate the adverse economic impact of a flood, wind
~~~

## sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-4

- original length: 3586
- proposed content type: `body`
- metadata changes: none

~~~diff
- ArcGIS increases understanding by providing a tool to share map layers to anyone interested in viewing the HAZUS-MH study results. Having the capability to share many mapping layers from HAZUS-MH allows others associated with hazard mitigation to examine the risks and view the estimated losses such as flood depth grids, DEMs, high-resolution photos, streets, water features, critical infrastructures (schools, shelters, bridges, and government buildings), and political boundaries. Figure 4 provides an example of the format of the ArcReader mapping program. Critical map layers from HAZUS-MH are saved using ArcGIS Map Publisher and are opened in ArcReader. The data layers are then ready to be viewed by local officials (e.g., public works officials, engineering, public safety, fire, police and emergency medical, planning, city management, elected officials, and members of the public). The ability to use the ArcReader software to share HAZUS-MH GIS layers with many local departments is an essential component for the preparation of a local hazard mitigation plan. Figure 4 shows a sample screen in ArcReader with the East Baton Rouge HAZUS-MH layers. usIng HAZus-MH for rIsk AssessMent FEMA 
+ ArcGIS increases understanding by providing a tool to share map layers to anyone interested in viewing the HAZUS-MH study results. Having the capability to share many mapping layers from HAZUS-MH allows others associated with hazard mitigation to examine the risks and view the estimated losses such as flood depth grids, DEMs, high-resolution photos, streets, water features, critical infrastructures (schools, shelters, bridges, and government buildings), and political boundaries. Figure 4 provides an example of the format of the ArcReader mapping program. Critical map layers from HAZUS-MH are saved using ArcGIS Map Publisher and are opened in ArcReader. The data layers are then ready to be viewed by local officials (e.g., public works officials, engineering, public safety, fire, police and emergency medical, planning, city management, elected officials, and members of the public). The ability to use the ArcReader software to share HAZUS-MH GIS layers with many local departments is an essential component for the preparation of a local hazard mitigation plan. Figure 4 shows a sample screen in ArcReader with the East Baton Rouge HAZUS-MH layers. usIng HAZus-MH for rIsk AssessMent FEMA 
~~~
