# Old/New Diff: Current Flood Warning System in Japan

## Replace/Split

```diff
- # Current Flood Warning System in Japan and Evacuation Effectiveness Current flood warning system in Japan and its effectiveness in mobilizing evacuation: Lessons from case studies Guangwei Huang, PhD Juan Fan ABSTRACT An effective flood warning system is crucial...
+ [frontmatter] Current Flood Warning System in Japan and Evacuation Effectiveness. Current flood warning system in Japan and its effectiveness in mobilizing evacuation: Lessons from case studies. Guangwei Huang, PhD; Juan Fan.
+ [abstract] The paper evaluates Japan's flood warning practices and warning effectiveness through case studies and a SWOT assessment.
+ [body] Japan has a long history of flood management, and the paper uses case studies to assess how current warning practices help mobilize evacuation.
```

## Metadata Diff

```diff
- contentType: body
+ contentType: frontmatter | abstract | body
+ sectionRole: title-authors | abstract | findings
+ answerable: false for frontmatter; low for abstract; true for body
```

## Expected Improvement

Prevents title/authors/abstract from being used as final answer text while preserving source display.
