# Legal Duties and Emergency Management Contracts

- documentId: `law-upload-legal-duties-and-emergency-management-contracts`
- source key: `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- source file: `bdevito67,+JEM_V3N3_3.pdf`
- rules: `frontmatter-check`, `metadata-only-if-correctness-ok`
- decisions:
  - split: title/introduction from legal-duty body if quality scoring must clear
  - merge: none
  - downrank: title-leading intro for non-title queries
  - exclude: none

## law-upload-legal-duties-and-emergency-management-contracts-chunk-1

- original length: 2280
- proposed content type: `body`
- metadata changes: none

~~~diff
- # Legal Duties and Emergency Management Contracts IntroductIon Local and state emergency management (EM) directors have many legal duties. These duties are based on specific EM law and other laws of general application, such as Occupational Safety and Health Administration (OSHA) law, contract law, personnel law, and government ethics law. They also have the responsibility for purchasing systems and equipment that best meet the needs of their departments while staying within the confines of time and budget. This article will present guidelines for successfully negotiating EM contracts. State emergency management law Every state has some form of EM law. Such laws typically relate to: n setting up a state emergency or disaster management agency, n specifying state and local organization roles in responding to disasters, n assigning executive authority to declare a state of emergency, n explaining special executive powers that result from such a declaration, n allowing cooperation in the form of mutual aid with neighboring jurisdictions, n drafting emergency plans and keeping them current, n compiling and distributing a list of emergency duties for all officials, and n documenting the
+ # Legal Duties and Emergency Management Contracts IntroductIon Local and state emergency management (EM) directors have many legal duties. These duties are based on specific EM law and other laws of general application, such as Occupational Safety and Health Administration (OSHA) law, contract law, personnel law, and government ethics law. They also have the responsibility for purchasing systems and equipment that best meet the needs of their departments while staying within the confines of time and budget. This article will present guidelines for successfully negotiating EM contracts. State emergency management law Every state has some form of EM law. Such laws typically relate to: n setting up a state emergency or disaster management agency, n specifying state and local organization roles in responding to disasters, n assigning executive authority to declare a state of emergency, n explaining special executive powers that result from such a declaration, n allowing cooperation in the form of mutual aid with neighboring jurisdictions, n drafting emergency plans and keeping them current, n compiling and distributing a list of emergency duties for all officials, and n documenting the
~~~

## law-upload-legal-duties-and-emergency-management-contracts-chunk-2

- original length: 3326
- proposed content type: `body`
- metadata changes: none

~~~diff
- Nicholson, JD JEM Legal desk health services; rescue; engineering; warning services; communications; radiological, chemical, and other special weapons defense; evacuation; emergency welfare services; emergency transportation; infrastructure protection; and restoration of utility services. As is readily apparent, although the enumerated duties at the state level are limited, their scope is all-inclusive. Keeping EM plans current is another specific responsibility, and the failure to fulfill it may expose the emergency manager and his or her jurisdiction to liability. local emergency management ordInance The local emergency manager is obliged to understand and obey all relevant local ordinances related to his or her functions. Local EM ordinance serves a number of purposes: n It “fills in the blanks” in EM state law. n It creates a structure for governmental EM activities. n It delineates the local line of succession. n It specifies grants of emergency authority to the leaders of the unit of government. n It provides a structure for EM activities. n It acts as a teaching tool to help public employees understand their roles during a disaster. n It provides legal support to the emergen
+ Nicholson, JD JEM Legal desk health services; rescue; engineering; warning services; communications; radiological, chemical, and other special weapons defense; evacuation; emergency welfare services; emergency transportation; infrastructure protection; and restoration of utility services. As is readily apparent, although the enumerated duties at the state level are limited, their scope is all-inclusive. Keeping EM plans current is another specific responsibility, and the failure to fulfill it may expose the emergency manager and his or her jurisdiction to liability. local emergency management ordInance The local emergency manager is obliged to understand and obey all relevant local ordinances related to his or her functions. Local EM ordinance serves a number of purposes: n It “fills in the blanks” in EM state law. n It creates a structure for governmental EM activities. n It delineates the local line of succession. n It specifies grants of emergency authority to the leaders of the unit of government. n It provides a structure for EM activities. n It acts as a teaching tool to help public employees understand their roles during a disaster. n It provides legal support to the emergen
~~~

## law-upload-legal-duties-and-emergency-management-contracts-chunk-4

- original length: 586
- proposed content type: `body`
- metadata changes: none

~~~diff
- For legal advice, consult your own attorney. Contract modifications that benefit emergency managers Prompt performance is often a big concern. Several contractual steps can be taken that provide a big incentive for rapid completion of the work or delivery of the goods: 1. Scheduled delivery dates with partial payments upon acceptance of the goods or services. 2. Penalties for late performance. 3. Rewards for early performance (e.g., extra pay). 4. Detailed operation standards for equipment. 5. Ordering turnkey systems (built, supplied, or installed complete and ready to operate).
+ For legal advice, consult your own attorney. Contract modifications that benefit emergency managers Prompt performance is often a big concern. Several contractual steps can be taken that provide a big incentive for rapid completion of the work or delivery of the goods: 1. Scheduled delivery dates with partial payments upon acceptance of the goods or services. 2. Penalties for late performance. 3. Rewards for early performance (e.g., extra pay). 4. Detailed operation standards for equipment. 5. Ordering turnkey systems (built, supplied, or installed complete and ready to operate).
~~~
