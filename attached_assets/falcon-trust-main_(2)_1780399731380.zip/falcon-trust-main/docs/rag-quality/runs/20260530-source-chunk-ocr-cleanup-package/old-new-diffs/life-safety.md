# Old/New Diff: Life Safety Modeling

## Normalize Bullets And Split Tables

```diff
- [control glyph] Floodwater depths, velocities, and travel times... [control glyph] Factors that change with time...
+ Limitations include use of large-scale average floodwater depths, velocities, and travel times; limited representation of changing factors; simplified treatment of population at risk; and limited accounting for flood warning dissemination.

- Generally, Figure 7. Variation in the percentage of people reaching the exit after 8 hours... Table 1. Number of fatalities...
+ [table] Figure 7 and Table 1 report modeled fatalities under different reductions in physical condition parameters, including fatalities due to drowning and exhaustion.
+ [body] The Life Safety Model provides a method for assessing residual risk behind flood defenses and downstream of dams in terms of fatalities.
```

## Metadata Diff

```diff
- contentType: body
+ contentType: body | table
+ layoutRisk: control-glyph | table-caption where applicable
+ answerable: table only for table/fatality queries; body for general model conclusions
```

## Expected Improvement

Prevents figure/table chunks from outranking HAZUS evidence for unrelated flood-loss questions while preserving fatality evidence.
