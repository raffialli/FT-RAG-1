# Practical Flood Risk Reduction Strategies in South Sudan

- documentId: `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan`
- source key: `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- source file: `bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf`
- rules: `strip-layout-residue`, `tighten-local-measures`
- decisions:
  - split: local measures prose from table/layout residue
  - merge: nearby short local-measure fragments if needed
  - downrank: layout/table residue
  - exclude: none

## sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-3

- original length: 2895
- proposed content type: `body`
- metadata changes: none

~~~diff
- “During emergencies such as conflicts or natural disasters, the risk of violence, exploitation, and abuse is heightened, particularly for women and girls.”26 In the United States, local community leaders and decision-makers play a critical role in mitigating risk from hazards by integrating hazard mitigation in their local disaster management plans.28-30 Local leaders can set priorities, provide policy outreach, and invite stakeholders to work together to discuss community safety and resilience while effectively communicating mitigation methodologies to large groups of local actors.18 Conversely, South Sudan’s local leaders lack the critical knowledge and ability to mitigate significant disaster outcomes due to an ill-managed governmental system, corruption, tribalism, and resource mismanagement.31 This government system relies on assistance from international organizations, eg, United Nations, US Agency for International Development (USAID), and others, to mitigate disaster risk and subsidize basic needs. 32,33 Within this context, the purpose of this study is to explore and then recommend accessible, locally empowered, and implementable flood risk reduction strategies for South S
+ “During emergencies such as conflicts or natural disasters, the risk of violence, exploitation, and abuse is heightened, particularly for women and girls.”26 In the United States, local community leaders and decision-makers play a critical role in mitigating risk from hazards by integrating hazard mitigation in their local disaster management plans.28-30 Local leaders can set priorities, provide policy outreach, and invite stakeholders to work together to discuss community safety and resilience while effectively communicating mitigation methodologies to large groups of local actors.18 Conversely, South Sudan’s local leaders lack the critical knowledge and ability to mitigate significant disaster outcomes due to an ill-managed governmental system, corruption, tribalism, and resource mismanagement.31 This government system relies on assistance from international organizations, eg, United Nations, US Agency for International Development (USAID), and others, to mitigate disaster risk and subsidize basic needs. 32,33 Within this context, the purpose of this study is to explore and then recommend accessible, locally empowered, and implementable flood risk reduction strategies for South S
~~~

## sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8

- original length: 3596
- proposed content type: `body`
- metadata changes: none

~~~diff
- These long-term measures are not consistently 129 Journal of Emergency Management Vol. 20, No. 8 Georgetown University Special Issue maintained because they are expensive to manage, and many people see no immediate benefits. However, after being devastated by several disasters, the country decided to shift its response efforts from reactive to a more proactive disaster preparedness model. The National Policy on Disaster Management details “a strategy of preparedness and preventive measures, such as, hazard and risk analysis, land use zoning, building codes and disaster preparedness training; optimum coordination of government and NGO efforts; and inclusion of nonstructural measures such as community disaster preparedness, training and public awareness.”65 In Bangladesh, improvements to roads and EWS complement evacuation procedures, and earthen embankments provide a buffer to mitigate storm flooding—but one of the greatest assets is an increase in local disaster planning.67 Bangladesh is facing a real threat from several disasters, just like South Sudan and many countries worldwide that are bearing the impacts of climate change. Bangladesh made progress in poverty reduction by stim
+ These long-term measures are not consistently 129 Journal of Emergency Management Vol. 20, No. 8 Georgetown University Special Issue maintained because they are expensive to manage, and many people see no immediate benefits. However, after being devastated by several disasters, the country decided to shift its response efforts from reactive to a more proactive disaster preparedness model. The National Policy on Disaster Management details “a strategy of preparedness and preventive measures, such as, hazard and risk analysis, land use zoning, building codes and disaster preparedness training; optimum coordination of government and NGO efforts; and inclusion of nonstructural measures such as community disaster preparedness, training and public awareness.”65 In Bangladesh, improvements to roads and EWS complement evacuation procedures, and earthen embankments provide a buffer to mitigate storm flooding—but one of the greatest assets is an increase in local disaster planning.67 Bangladesh is facing a real threat from several disasters, just like South Sudan and many countries worldwide that are bearing the impacts of climate change. Bangladesh made progress in poverty reduction by stim
~~~

## sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10

- original length: 3557
- proposed content type: `body`
- metadata changes: none

~~~diff
- Finally, since South Sudan is a relatively young country the international long-term commitment cannot be assessed over the last 40 years, for example, like the case study in Bangladesh. However, it is notable that South Sudan has 78 NGOs operating in the country as of 2018 34 while Bangladesh has over 2,500 registered NGOs in the same year.64 The critical infrastructure for managing flood risk in South Sudan, ie, drainage systems, canals, urban planning, roads, bridges, dams, building codes, seawalls, and levees, is underdeveloped. The area now known as South Sudan has been in economic distress, fighting civil wars, and experiencing political tension from 1955-1972, 1983-2005, and 2013-2017.27 This history of instability has impeded the development of the types of critical infrastructure that support DRR and meets the UN mandate for sustainable development goals.55 These conditions have also created impediments in building capabilities and providing geospatial analysis to help decision-makers at the local and national government levels. The use of geospatial analysis tools, like ArcGIS Online, in the hands of local stakeholders have the potential to judiciously allocate resources 
+ Finally, since South Sudan is a relatively young country the international long-term commitment cannot be assessed over the last 40 years, for example, like the case study in Bangladesh. However, it is notable that South Sudan has 78 NGOs operating in the country as of 2018 34 while Bangladesh has over 2,500 registered NGOs in the same year.64 The critical infrastructure for managing flood risk in South Sudan, ie, drainage systems, canals, urban planning, roads, bridges, dams, building codes, seawalls, and levees, is underdeveloped. The area now known as South Sudan has been in economic distress, fighting civil wars, and experiencing political tension from 1955-1972, 1983-2005, and 2013-2017.27 This history of instability has impeded the development of the types of critical infrastructure that support DRR and meets the UN mandate for sustainable development goals.55 These conditions have also created impediments in building capabilities and providing geospatial analysis to help decision-makers at the local and national government levels. The use of geospatial analysis tools, like ArcGIS Online, in the hands of local stakeholders have the potential to judiciously allocate resources 
~~~

## sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12

- original length: 2821
- proposed content type: `body`
- metadata changes: none

~~~diff
- 4. Implement structural flood mitigation strategies using simple but accessible methods like the Trapbag or Gabion wall systems. 5. Procure funding through international resources like the World Bank to invest in building nationwide critical infrastructure that includes urban planning, land use, hospitals, roads, building codes, bridges, floodwalls, levees, flood barriers, and dams. CONCLUSION The ongoing conflict, safety concerns, and travel insecurity prohibited interviewing or gathering other empirical data for this study which may have led to, for example, determining the viability of a low-elevation property buyout program as another means of sustainable flood mitigation in South Sudan. However, this study has produced five actionable and practical recommendations as a meaningful starting point for ongoing flood mitigation efforts for this country that is just beginning only its second decade in existence. Opposite the forces of climate change, flooding in South Sudan will be worse in the next decade. Therefore, a focused effort to use structural and nonstructural means to mitigate this ongoing threat to begin to improve local resilience by moving the people of South Sudan awa
+ 4. Implement structural flood mitigation strategies using simple but accessible methods like the Trapbag or Gabion wall systems. 5. Procure funding through international resources like the World Bank to invest in building nationwide critical infrastructure that includes urban planning, land use, hospitals, roads, building codes, bridges, floodwalls, levees, flood barriers, and dams. CONCLUSION The ongoing conflict, safety concerns, and travel insecurity prohibited interviewing or gathering other empirical data for this study which may have led to, for example, determining the viability of a low-elevation property buyout program as another means of sustainable flood mitigation in South Sudan. However, this study has produced five actionable and practical recommendations as a meaningful starting point for ongoing flood mitigation efforts for this country that is just beginning only its second decade in existence. Opposite the forces of climate change, flooding in South Sudan will be worse in the next decade. Therefore, a focused effort to use structural and nonstructural means to mitigate this ongoing threat to begin to improve local resilience by moving the people of South Sudan awa
~~~
