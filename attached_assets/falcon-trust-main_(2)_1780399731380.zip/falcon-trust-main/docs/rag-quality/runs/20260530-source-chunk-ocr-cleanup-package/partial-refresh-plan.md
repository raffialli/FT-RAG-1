# Dev-Only Partial Refresh Plan

## Proposed Mutation Scope After Approval

Only these Dev data mutations are requested next:

1. Create a local staging copy from the exported source JSONs.
2. Apply the reviewed cleanup candidates to the 8 listed source JSON keys only.
3. Rechunk only the 8 listed document IDs.
4. Replace vector records only for those document IDs in `vectors/dev-customer-phase2-vector-index.json`.
5. Reembed only those document IDs.
6. Run the same local diagnostics and then live Dev diagnostics.

## Explicitly Excluded

- no full reindex/reembed
- no staging/demo deploy
- no main merge
- no broad S3 sync
- no delete operations
- no changes outside the listed source keys and document IDs

## Document Order

1. `sandbags-upload-flood-risk-management-global-case-studies` — source `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`; chunks 11; rules strip-page-headers+fix-ocr-joins+split-figure-table-blocks+reduce-adjacent-overlap+keep-fews-wri-body-evidence
2. `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness` — source `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`; chunks 1; rules frontmatter-to-metadata+start-body-after-abstract
3. `sandbags-upload-life-safety-modeling-for-flood-emergency-management` — source `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`; chunks 4; rules split-figure-table-blocks+preserve-narrative-findings+downrank-table-only-blocks
4. `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers` — source `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`; chunks 4; rules table-aware-cleanup+remove-control-glyphs+preserve-percentages
5. `sandbags-upload-community-resilience-and-recovery-after-major-flood` — source `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`; chunks 5; rules tighten-body-boundaries+frontmatter-check+ranking-retst
6. `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model` — source `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`; chunks 3; rules ranking-retst-after-life-safety+tighten-if-needed
7. `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan` — source `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`; chunks 4; rules strip-layout-residue+tighten-local-measures
8. `law-upload-legal-duties-and-emergency-management-contracts` — source `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`; chunks 3; rules frontmatter-check+metadata-only-if-correctness-ok

## Approval Wording Needed

Approve AWS Dev partial corpus refresh for the 8 listed source JSON keys/document IDs, including cleaned source upload, affected-doc rechunk, affected-doc vector replacement, affected-doc reembed, and same-suite diagnostics. Do not approve full reindex/reembed, deploy, merge, delete, or broad sync.