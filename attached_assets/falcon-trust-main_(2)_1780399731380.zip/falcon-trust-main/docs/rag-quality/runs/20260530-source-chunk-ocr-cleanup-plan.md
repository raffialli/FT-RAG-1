# FalconTrust RAG Source/Chunk/OCR Cleanup Plan - 2026-05-30

## Scope

- Branch: rag-retrieval-generation-dev-20260530
- Planning checkpoint: b38efa97ea248f09119724b8333fa5ebe1e37b67
- Dev endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
- Dev service: falcontrust-rag-dev-web
- Dev image digest: sha256:8d0b51817ffcaf2dae5cdf1afeee9e7509fbf61d014897d82ae18d5e24e4a291
- Backend/index: bedrock-s3-vector / vectors/dev-customer-phase2-vector-index.json
- Inputs inspected: docs/rag-quality/runs/20260530-live-dev-remaining-failures-pass/baseline.json, docs/testing/rag-chunking-policy.md, tests/unit/chunking-policy.test.mjs, src/lib/falcon/corpus.ts
- Hard gates observed: planning only; no deploy, staging, demo, main merge, source mutation, chunk mutation, vector/index mutation, reindex, reembed, or secrets.

## Current Live Failure Shape

Latest live diagnostics after runtime filtering:

- source_chunk_ocr_layout: 15
- retrieval_ranking: 3
- answer_generation_faithfulness: 3
- confidence_calibration: 0
- unsupported_gap_missing: 0
- reference_frontmatter_leakage: 0

Conclusion: unsupported-gap, confidence, and reference/frontmatter policy are now handled at runtime. Remaining failures are dominated by source/chunk/OCR quality in the live uploaded PDF corpus, plus three ranking/faithfulness misses that depend on corrected chunk quality and better evidence ordering.

## Source-Of-Truth Conclusion

The affected live citations point to uploaded document JSON paths and the active S3 vector index, not files present in this checkout:

- uploads/ is absent locally
- manifests/ is absent locally
- seed-reports/ is absent locally
- data/ is absent locally
- FALCON_VECTOR_INDEX_KEY on Dev is vectors/dev-customer-phase2-vector-index.json
- Dev manifest paths are /app/manifests/customer-corpus.seed.json and /app/seed-reports/customer-chunk-map.json

Therefore the next cleanup lane needs access to the Dev S3 uploaded JSON objects and vector/index artifacts, or an approved export of them, before source/chunk fixes can be performed. This report does not mutate those artifacts.

## Fix Type Legend

- A: Source/OCR normalization cleanup in uploaded document JSON before chunking.
- B: Chunk boundary cleanup or content-type classification update that changes chunk text/chunk IDs.
- C: Retrieval/ranking tuning after source/chunk cleanup, without changing source text.
- D: Runtime answer/faithfulness policy only.
- E: Partial reindex/reembed for affected documents after A/B changes.
- F: Full reindex/reembed if shared chunking policy or global OCR normalization changes affect many documents.
- G: No action in this lane; runtime already handles the failure class or current evidence is acceptable.

## Affected Documents And Chunks

### Flood Risk Management Global Case Studies

- documentId: sandbags-upload-flood-risk-management-global-case-studies
- sourceFileName: Flood Risk Management-OCR.pdf
- sourcePath: uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json
- affected chunks observed: 5, 8, 11, 13, 19, 54, 55, 85, 86, 88, 90, 95, 98, 101, 117, 121, 127, 128
- failing cases using this document: mobile-warning-artifact, fews-mobile-warning, current-flood-warning-japan, wri-flood-exposure-reference, technology-exclusion-joined-heading, page-header-author-artifact, mid-word-boundary, duplicate-overlap-evidence, metadata-source-display, plus mixed support in several model/policy cases
- observed defects:
  - normalizedPdfText=true with removedPageMarkerCount=226 across affected chunks
  - chapter/page heading fragments remain in body evidence, for example "Flood warnings in the developing world 121"
  - OCR joins and broken words remain, for example "Institutionalimpe", "infom1ation", "rec1m1cectto", "Hydroloiical"
  - figure/table text still enters final evidence for warning-chain and technology-exclusion questions
  - adjacent but less direct flood-risk chunks outrank or accompany more direct evidence
- recommended fix type: A + B first, then C if ranking failures remain, then E.
- reindex/reembed need: partial reindex/reembed required after cleanup of this document; full reindex only if the global chunker/normalizer is changed for all uploaded PDFs.

### Current Flood Warning System in Japan and Evacuation Effectiveness

- documentId: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness
- sourceFileName: bdevito67,+JEM_21-1-04-Huang.pdf
- sourcePath: uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json
- affected chunk observed: 1
- failing cases using this document: mobile-warning-artifact, current-flood-warning-japan, duplicate-overlap-evidence
- observed defects:
  - title/abstract/front matter remains in chunk 1 as body evidence
  - answer starts with title block instead of substantive answer text
  - normalizedPdfText=true with removedPageMarkerCount=13
- recommended fix type: A + B; split title/abstract/frontmatter from body or mark title-only leading material so final answer generation does not treat it as the answer.
- reindex/reembed need: partial reindex/reembed for this document after cleanup.

### Community Resilience and Recovery After Major Flood

- documentId: sandbags-upload-community-resilience-and-recovery-after-major-flood
- sourceFileName: bdevito67,+JEM_V6N5_9.pdf
- sourcePath: uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json
- affected chunks observed: 1, 5, 7, 8, 9
- failing case: community-resilience-recovery
- observed defects:
  - title/abstract leading text remains in first answer evidence
  - normalizedPdfText=true with removedPageMarkerCount=10
  - quotes and body material are useful, but answer generation starts from title/abstract instead of distilled resilience lessons
- recommended fix type: B + C; source is mostly usable, but chunk boundaries and ranking should favor body findings/strategies over title/abstract.
- reindex/reembed need: partial reindex/reembed if chunk boundaries/content are changed.

### Life Safety Modeling for Flood Emergency Management

- documentId: sandbags-upload-life-safety-modeling-for-flood-emergency-management
- sourceFileName: bdevito67,+JEMv9n1_7.pdf
- sourcePath: uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json
- affected chunks observed: 2, 3, 6, 8
- failing cases: hazus-flood-loss-model, life-safety-model-fatalities, mid-word-boundary
- observed defects:
  - figure/table captions and bullet glyphs remain in body evidence
  - chunk 8 begins with "Generally, Figure 7..." and ranks above direct HAZUS evidence for a HAZUS query
  - normalizedPdfText=true with removedPageMarkerCount=9
- recommended fix type: A + B for figure/table cleanup and C for reranking direct-document evidence over adjacent model text.
- reindex/reembed need: partial reindex/reembed for this document after cleanup.

### Hazard Mitigation Planning Using HAZUS-MH Flood Model

- documentId: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model
- sourceFileName: bdevito67,+JEM_V3N2_3.pdf
- sourcePath: uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json
- affected chunks observed: 1, 2, 4
- failing case: hazus-flood-loss-model
- observed defects:
  - direct evidence exists, especially chunk 1, but other life-safety chunks can outrank it
  - title/abstract material is useful but should be separated from noisy neighboring evidence
- recommended fix type: C first, then B only if direct chunk boundaries remain too broad.
- reindex/reembed need: partial reindex/reembed only if chunk boundaries/content are changed; ranking-only changes may not require reembed.

### Personal Preparedness Curriculum for Public Health Workers

- documentId: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers
- sourceFileName: bdevito67,+JEM-12-1-04-Kohn.pdf
- sourcePath: uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json
- affected chunks observed: 9, 10, 11, 14
- failing case: preparedness-workshop-kits
- observed defects:
  - table-number fragments remain in answer evidence
  - answer is substantively correct, but source_chunk_ocr_layout remains due table/OCR residue
  - normalizedPdfText=true with removedPageMarkerCount=19
- recommended fix type: A + B for table cleanup or table-aware chunk metadata; keep body findings.
- reindex/reembed need: partial reindex/reembed after cleanup.

### Practical Flood Risk Reduction Strategies in South Sudan

- documentId: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan
- sourceFileName: bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf
- sourcePath: uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json
- affected chunks observed: 3, 8, 10, 12
- failing case: south-sudan-local-measures
- observed defects:
  - normalized PDF body chunks are useful, but likely include page/header/table artifacts that trigger source_chunk_ocr_layout
- recommended fix type: A + B after inspecting full source JSON; likely partial cleanup only.
- reindex/reembed need: partial reindex/reembed if source/chunks change.

### Legal Duties and Emergency Management Contracts

- documentId: law-upload-legal-duties-and-emergency-management-contracts
- sourceFileName: bdevito67,+JEM_V3N3_3.pdf
- sourcePath: uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json
- affected chunks observed: 1, 2, 4
- failing case: contract-law-basics
- observed defects:
  - legal body evidence is present but normalized PDF title/author/header fragments and broad emergency-management prose can enter final evidence
  - source_chunk_ocr_layout remains; confidence policy is now capped correctly
- recommended fix type: A + B; possibly C if contract-law chunk does not outrank broad legal-duty chunks after cleanup.
- reindex/reembed need: partial reindex/reembed if source/chunks change.

## Remaining Failure IDs And Recommended Action

| ID | Current failures | Recommended fix type |
| --- | --- | --- |
| mobile-warning-artifact | source_chunk_ocr_layout | A+B+E for Japan + Global Case Studies; remove title/figure/OCR residue |
| fews-mobile-warning | source_chunk_ocr_layout | A+B+E for Global Case Studies FEWS chunks |
| current-flood-warning-japan | source_chunk_ocr_layout | A+B+E for Japan title/abstract split and Global Case Studies secondary chunks |
| community-resilience-recovery | source_chunk_ocr_layout | B+C, then E if chunks change |
| hazus-flood-loss-model | source_chunk_ocr_layout | C first; A/B/E for Life Safety and HAZUS if noisy chunks persist |
| life-safety-model-fatalities | source_chunk_ocr_layout | A+B+E for figure/table cleanup |
| preparedness-workshop-kits | source_chunk_ocr_layout | A+B+E for table/OCR cleanup |
| south-sudan-local-measures | source_chunk_ocr_layout | A+B+E after source JSON inspection |
| contract-law-basics | source_chunk_ocr_layout | A+B+E, possible C |
| wri-flood-exposure-reference | source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness | A+B+E for Global Case Studies plus C; likely missing/direct WRI source issue |
| technology-exclusion-joined-heading | source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness | A+B+E for joined heading/OCR cleanup, then C |
| page-header-author-artifact | source_chunk_ocr_layout | A+B+E for header/author artifact removal |
| mid-word-boundary | source_chunk_ocr_layout, retrieval_ranking, answer_generation_faithfulness | A+B+E for boundary cleanup, then C |
| duplicate-overlap-evidence | source_chunk_ocr_layout | B+C; overlap reduction or citation dedupe may help after source cleanup |
| metadata-source-display | source_chunk_ocr_layout | G for answer correctness, A/B only if source quality score must be cleared |

## Reindex/Reembed Plan

Recommended sequence:

1. Export or inspect the live uploaded JSON source artifacts for the eight affected documents.
2. Apply OCR/source cleanup to those specific uploaded JSON records or regenerate them from source PDFs using improved normalization.
3. Rechunk only the affected documents and compare chunk IDs/text for the listed chunks.
4. Run local/live-equivalent diagnostics against the changed chunk map before touching AWS Dev vectors.
5. If affected document chunk text or chunk IDs change, perform a partial reindex/reembed for only affected documents under explicit approval.
6. Use full reindex/reembed only if the global chunking/normalization code changes in a way that can alter many uploaded PDFs beyond these affected documents.

Partial reindex/reembed is likely required for A/B fixes because vector text must match cleaned chunk text. It was not executed in this planning lane.

## Tests For The Cleanup Lane

Before requesting vector mutation approval:

- Add/extend unit fixtures in tests/unit/chunking-policy.test.mjs for:
  - title/abstract split from body for Current Flood Warning System in Japan
  - figure/table caption filtering for Life Safety Modeling
  - joined heading cleanup for Technology exclusion
  - page header/author artifact removal for Abigail Tevera
  - table-heavy preparedness chunks preserving 77 percent / 40 percent evidence
- Run npm run test:rag and npm run test:rag-diagnostics.
- Run a local/live-equivalent diagnostic against exported affected chunks.
- After approved Dev partial reindex, rerun live AWS Dev diagnostics and compare the same 25 questions.

## Recommendation

Do not run another runtime-only filtering pass for these remaining failures. The next useful lane is an approved source/chunk/OCR cleanup and partial reindex planning lane for the affected uploaded documents. Keep Dev on the current runtime image until source artifacts are cleaned and a rollback/reindex packet is approved.
