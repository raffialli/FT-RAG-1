# Source/Chunk/OCR Cleanup Proposal

Reviewable local proposal artifacts for the 2026-05-30 FalconTrust Dev RAG source/chunk/OCR cleanup lane.

This directory contains proposal artifacts only. It does not contain the exported corpus and does not mutate S3, vectors, indexes, embeddings, or deployed services.

## Contents

- `affected-doc-refresh-plan.json`: machine-readable Dev-only partial refresh plan for the 8 affected documents.
- `refresh-plan.md`: human-readable execution and approval plan.
- `old-new-diffs/`: per-document old/new excerpt diffs from selected affected chunks.
- `proposed-cleaned-samples/`: per-document cleaned chunk candidate excerpts for review.

## Scope Summary

- affected documents: 8
- selected affected chunks represented in proposal: 19
- highest-priority document: `sandbags-upload-flood-risk-management-global-case-studies`
- partial reindex/reembed needed: yes, for affected documents whose source/chunk text changes
- full reindex/reembed needed: no, unless a global chunking/OCR normalization change is approved

## Safety

No exported corpus files are committed here. The local export remains at `/home/ralli/falcontrust-dev-corpus-export-20260530/` and is used only as read-only input.