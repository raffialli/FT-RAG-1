# Flood Risk Management Global Case Studies

- documentId: `sandbags-upload-flood-risk-management-global-case-studies`
- source key: `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- source file: `Flood Risk Management-OCR.pdf`
- affected chunks: `sandbags-upload-flood-risk-management-global-case-studies-chunk-85`, `sandbags-upload-flood-risk-management-global-case-studies-chunk-90`, `sandbags-upload-flood-risk-management-global-case-studies-chunk-121`, `sandbags-upload-flood-risk-management-global-case-studies-chunk-127`, `sandbags-upload-flood-risk-management-global-case-studies-chunk-128`
- proposed actions: A, B, C, E, H, J, K
- root cause: FEWS/WRI/body evidence is mixed with page headers, OCR joins, table/figure residue, and overlapping chunks.
- cleanup strategy: Normalize OCR joins, strip recurring page/header artifacts, split body evidence from figures/tables, and reduce overlapping adjacent citations.

## Old/New Diff Samples

### sandbags-upload-flood-risk-management-global-case-studies-chunk-85

- contentType: `body`
- old length: 3009

~~~diff
- Recognising this, a global imperative to enhance early warning systems in developing countries was instigated by the UN Hyogo Framework for Disaster Reduction (2005-2015) and continues under the Sendai Framework (2015-2030) and Sustainable Development Goals. Despite such impetus, FEWS remain underdeveloped. In the 2010 Indus floods in Pakistan, for example, an effective FEWS could have provided six days' notice of approaching floodwaters. The floods killed 2,000 people, cost US$40 billion and directly impacted 18 million people (BBC, 2010). Where FEWS do exist, research frequently demonstrates that lead times are inadequate, warnings fail to reach at- risk communities and response behaviour is deficient. Achieving an effective FEWS is therefore universally challenging. Even countries like Australia and the UK continue to face well-researched failures and inefficiencies within their FEWS 
+ Recognising this, a global imperative to enhance early warning systems in developing countries was instigated by the UN Hyogo Framework for Disaster Reduction (2005-2015) and continues under the Sendai Framework (2015-2030) and Sustainable Development Goals. Despite such impetus, FEWS remain underdeveloped. In the 2010 Indus floods in Pakistan, for example, an effective FEWS could have provided six days' notice of approaching floodwaters. The floods killed 2,000 people, cost US$40 billion and directly impacted 18 million people (BBC, 2010). Where FEWS do exist, research frequently demonstrates that lead times are inadequate, warnings fail to reach at- risk communities and response behaviour is deficient. Achieving an effective FEWS is therefore universally challenging. Even countries like Australia and the UK continue to face well-researched failures and inefficiencies within their FEWS 
~~~

### sandbags-upload-flood-risk-management-global-case-studies-chunk-90

- contentType: `body`
- old length: 3213

~~~diff
- These bureaucratic inefficiencies have been cited as a key reason for delays in the warning processes of developing countries (Keoduangsine and Goodwin, 2012). Flood warnings in the developing world 121 Institutionalimpediments Well-structured institutional frameworks are required to match the location of flood management control with the transitioning location of knowledge. This presents a challenge in developing countries, where controlling institutions are often weakened ineffective frameworks, unstable politics and frequent change (Parker and Handmer, 1998). Here, national government institutions are generally the sole issuers of official warnings. Reliance on such national-level processes (see chapter 11) limits the effectiveness of warnings to successfully transition down through institutional hierarchies to alert threatened communities (WMO, 2008), as national agencies often lack 
+ These bureaucratic inefficiencies have been cited as a key reason for delays in the warning processes of developing countries (Keoduangsine and Goodwin, 2012). Institutional impediments Well-structured institutional frameworks are required to match the location of flood management control with the transitioning location of knowledge. This presents a challenge in developing countries, where controlling institutions are often weakened ineffective frameworks, unstable politics and frequent change (Parker and Handmer, 1998). Here, national government institutions are generally the sole issuers of official warnings. Reliance on such national-level processes (see chapter 11) limits the effectiveness of warnings to successfully transition down through institutional hierarchies to alert threatened communities (WMO, 2008), as national agencies often lack local knowledge of flood impacts, appropri
~~~

### sandbags-upload-flood-risk-management-global-case-studies-chunk-121

- contentType: `body`
- old length: 3575

~~~diff
- Hydroloiical Processes,26(11), 1748-1175. E E Motivations for floodplain occupation Laura West Fischer Introduction Floods are frequent phenomena in the United States of America. Residents across the country are exposed to numerous flood hazards, including fluvial, pluvial, and coastal flooding. Despite the well-documented risk, populations in flood-prone areas continue to increase. In 2015, the Brookings Institution reported that nearly half of all flood loss claims submitted to the Federal Emergency Management Agency (FEMA) since 1978 have come from just 25 of the USA's counties (Kane and Puentes, 2015). Since 2000, these same 25 counties have grown by about 2.5 million people, or about 100,000 far exceeding the average population growth rate across all US counties of about With increased population comes increased development and more assets exposed to flood-related damage and the nee
+ Hydrological Processes,26(11), 1748-1175. E E Motivations for floodplain occupation Laura West Fischer Introduction Floods are frequent phenomena in the United States of America. Residents across the country are exposed to numerous flood hazards, including fluvial, pluvial, and coastal flooding. Despite the well-documented risk, populations in flood-prone areas continue to increase. In 2015, the Brookings Institution reported that nearly half of all flood loss claims submitted to the Federal Emergency Management Agency (FEMA) since 1978 have come from just 25 of the USA's counties (Kane and Puentes, 2015). Since 2000, these same 25 counties have grown by about 2.5 million people, or about 100,000 far exceeding the average population growth rate across all US counties of about With increased population comes increased development and more assets exposed to flood-related damage and the nee
~~~

### sandbags-upload-flood-risk-management-global-case-studies-chunk-127

- contentType: `body`
- old length: 3525

~~~diff
- With minority move-in, the reasoning is more complicated and akin to the context of the flood hazard. In both the cases, involuntary acceptance of risk would result from some external consideration preventing the residents from living elsewhere (i.e. affordability, cultural connections) or adversely influencing their perception of the risk. Moreover, it is hardly reasonable to assume that individuals would voluntarily choose to live near a hazardous area, particularly if doing so exposes them to greater risk without some additional benefit and decreases neighbourhood quality (Zhang, 2010). That being said, unlike with polluting facilities, proximity to the flood hazard may bring benefits, which must be taken into account before determining the voluntariness of a residency decision. One conclusion of this chapter, therefore, is that holistic frameworks for understanding the diversity of m
+ With minority move-in, the reasoning is more complicated and akin to the context of the flood hazard. In both the cases, involuntary acceptance of risk would result from some external consideration preventing the residents from living elsewhere (i.e. affordability, cultural connections) or adversely influencing their perception of the risk. Moreover, it is hardly reasonable to assume that individuals would voluntarily choose to live near a hazardous area, particularly if doing so exposes them to greater risk without some additional benefit and decreases neighbourhood quality (Zhang, 2010). That being said, unlike with polluting facilities, proximity to the flood hazard may bring benefits, which must be taken into account before determining the voluntariness of a residency decision. One conclusion of this chapter, therefore, is that holistic frameworks for understanding the diversity of m
~~~

### sandbags-upload-flood-risk-management-global-case-studies-chunk-128

- contentType: `body`
- old length: 3446

~~~diff
- 2014) and Montgomery and Chakraborty (2015) reported that black and Hispanic residents were significantly more likely to reside in areas exposed to inland flood risk. These areas possessed lower median housing values, lower numbers of vacation homes and less access to the water-based amenities that coastal areas provide (Chakraborty et al., 2014). In other words, they carry many of the costs associated with flood risk, but offer fewer benefits. By contrast, Chakraborty et al. (2014) found that coastal flood risk was associated with higher median household income. Likewise, Montgomery and Chakraborty (2015) found that coastal areas in Miami were associated with less economic insecurity, more vacation homes, and greater access to water-based amenities. Maldonado et al. (2016) found that, in the aggregate in Motivations for floodplain occupation 173 Miami, higher socioeconomic status was as
+ 2014) and Montgomery and Chakraborty (2015) reported that black and Hispanic residents were significantly more likely to reside in areas exposed to inland flood risk. These areas possessed lower median housing values, lower numbers of vacation homes and less access to the water-based amenities that coastal areas provide (Chakraborty et al., 2014). In other words, they carry many of the costs associated with flood risk, but offer fewer benefits. By contrast, Chakraborty et al. (2014) found that coastal flood risk was associated with higher median household income. Likewise, Montgomery and Chakraborty (2015) found that coastal areas in Miami were associated with less economic insecurity, more vacation homes, and greater access to water-based amenities. Maldonado et al. (2016) found that, in the aggregate in Motivations for floodplain occupation 173 Miami, higher socioeconomic status was as
~~~
