# Personal Preparedness Curriculum for Public Health Workers

- documentId: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`
- source key: `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- source file: `bdevito67,+JEM-12-1-04-Kohn.pdf`
- affected chunks: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11`, `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-9`
- proposed actions: H, A, B, E
- root cause: Correct preparedness evidence is embedded in table-heavy chunks with control glyph/table residue.
- cleanup strategy: Preserve meaningful percentages and kit/training evidence while separating table rows from prose chunks.

## Old/New Diff Samples

### sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11

- contentType: `body`
- old length: 3459

~~~diff
- 42 100.0 17 100.0 6 85.7 42 100.0 Table 6. Percent of respondents with “yes” responses to personal emergency preparedness questions by EPPM category on a) pretraining administration (n = 131), b) post-training administration (n = 129), and c) 1-year follow-up administration (n = 69) (continued) Low threat, low efficacy Low threat, high efficacy High threat, low efficacy High threat, high efficacy No.* Percent* No. Percent No. Percent No. Percent I feel confident that I know where to find more resources and information on what should be included in a family emergency kit. 42 100.0 18 100.0 6 85.7 44 100.0 I have a family emergency plan. 24 58.5 7 38.9 1 14.3 27 61.4 I feel confident that I know what should be included in a family emergency plan. 41 100.0 18 100.0 6 85.7 43 100.0 I feel confident that I know where to find more resources and information on what should be included in a famil
+ 42 100.0 17 100.0 6 85.7 42 100.0 [table block split into table metadata] Percent of respondents with “yes” responses to personal emergency preparedness questions by EPPM category on a) pretraining administration (n = 131), b) post-training administration (n = 129), and c) 1-year follow-up administration (n = 69) (continued) Low threat, low efficacy Low threat, high efficacy High threat, low efficacy High threat, high efficacy No.* Percent* No. Percent No. Percent No. Percent I feel confident that I know where to find more resources and information on what should be included in a family emergency kit. 42 100.0 18 100.0 6 85.7 44 100.0 I have a family emergency plan. 24 58.5 7 38.9 1 14.3 27 61.4 I feel confident that I know what should be included in a family emergency plan. 41 100.0 18 100.0 6 85.7 43 100.0 I feel confident that I know where to find more resources and information on wha
~~~

### sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-9

- contentType: `body`
- old length: 3544

~~~diff
- Table 5. Percent agreement for attitude/belief statements by EPPM category with respect to a major flood on a) pretraining administration (n = 131), b) post-training administration (n = 129), and c) 1-year follow-up administration (n = 69) Low threat, low efficacy Low threat, high efficacy High threat, low efficacy High threat, high efficacy No.* Percent* No. Percent No. Percent No. Percent a) EPPM category (pretest) If it occurs, a moderate flood in this region is likely to have severe consequences for myself and my family. 20 48.8 9 37.5 16 59.3 18 56.2 I feel confident that I know what actions to take to protect myself and my family in the event of a moderate flood. 30 73.2 25 100.0 20 74.1 31 96.9 By successfully performing protective actions for myself and my family, I am also improving my ability to successfully perform my job during a moderate flood. 32 82.1 25 100.0 24 92.3 32 10
+ [table block split into table metadata] Percent agreement for attitude/belief statements by EPPM category with respect to a major flood on a) pretraining administration (n = 131), b) post-training administration (n = 129), and c) 1-year follow-up administration (n = 69) Low threat, low efficacy Low threat, high efficacy High threat, low efficacy High threat, high efficacy No.* Percent* No. Percent No. Percent No. Percent a) EPPM category (pretest) If it occurs, a moderate flood in this region is likely to have severe consequences for myself and my family. 20 48.8 9 37.5 16 59.3 18 56.2 I feel confident that I know what actions to take to protect myself and my family in the event of a moderate flood. 30 73.2 25 100.0 20 74.1 31 96.9 By successfully performing protective actions for myself and my family, I am also improving my ability to successfully perform my job during a moderate flood.
~~~
