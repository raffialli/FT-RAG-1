# Practical Flood Risk Reduction Strategies in South Sudan

- documentId: `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan`
- source key: `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- source file: `bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf`
- affected chunks: `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12`, `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10`
- proposed actions: A, B, E
- root cause: Local-measures evidence is useful but mixed with layout/table residue.
- cleanup strategy: Strip layout/table residue and rechunk local measures into concise body evidence.

## Old/New Diff Samples

### sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12

- contentType: `body`
- old length: 2821

~~~diff
- 4. Implement structural flood mitigation strategies using simple but accessible methods like the Trapbag or Gabion wall systems. 5. Procure funding through international resources like the World Bank to invest in building nationwide critical infrastructure that includes urban planning, land use, hospitals, roads, building codes, bridges, floodwalls, levees, flood barriers, and dams. CONCLUSION The ongoing conflict, safety concerns, and travel insecurity prohibited interviewing or gathering other empirical data for this study which may have led to, for example, determining the viability of a low-elevation property buyout program as another means of sustainable flood mitigation in South Sudan. However, this study has produced five actionable and practical recommendations as a meaningful starting point for ongoing flood mitigation efforts for this country that is just beginning only its sec
+ 4. Implement structural flood mitigation strategies using simple but accessible methods like the Trapbag or Gabion wall systems. 5. Procure funding through international resources like the World Bank to invest in building nationwide critical infrastructure that includes urban planning, land use, hospitals, roads, building codes, bridges, floodwalls, levees, flood barriers, and dams. CONCLUSION The ongoing conflict, safety concerns, and travel insecurity prohibited interviewing or gathering other empirical data for this study which may have led to, for example, determining the viability of a low-elevation property buyout program as another means of sustainable flood mitigation in South Sudan. However, this study has produced five actionable and practical recommendations as a meaningful starting point for ongoing flood mitigation efforts for this country that is just beginning only its sec
~~~

### sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10

- contentType: `body`
- old length: 3557

~~~diff
- Finally, since South Sudan is a relatively young country the international long-term commitment cannot be assessed over the last 40 years, for example, like the case study in Bangladesh. However, it is notable that South Sudan has 78 NGOs operating in the country as of 2018 34 while Bangladesh has over 2,500 registered NGOs in the same year.64 The critical infrastructure for managing flood risk in South Sudan, ie, drainage systems, canals, urban planning, roads, bridges, dams, building codes, seawalls, and levees, is underdeveloped. The area now known as South Sudan has been in economic distress, fighting civil wars, and experiencing political tension from 1955-1972, 1983-2005, and 2013-2017.27 This history of instability has impeded the development of the types of critical infrastructure that support DRR and meets the UN mandate for sustainable development goals.55 These conditions have
+ Finally, since South Sudan is a relatively young country the international long-term commitment cannot be assessed over the last 40 years, for example, like the case study in Bangladesh. However, it is notable that South Sudan has 78 NGOs operating in the country as of 2018 34 while Bangladesh has over 2,500 registered NGOs in the same year.64 The critical infrastructure for managing flood risk in South Sudan, ie, drainage systems, canals, urban planning, roads, bridges, dams, building codes, seawalls, and levees, is underdeveloped. The area now known as South Sudan has been in economic distress, fighting civil wars, and experiencing political tension from 1955-1972, 1983-2005, and 2013-2017.27 This history of instability has impeded the development of the types of critical infrastructure that support DRR and meets the UN mandate for sustainable development goals.55 These conditions have
~~~
