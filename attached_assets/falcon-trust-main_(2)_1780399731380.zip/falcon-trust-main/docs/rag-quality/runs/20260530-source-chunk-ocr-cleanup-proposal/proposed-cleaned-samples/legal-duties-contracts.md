# Proposed Cleaned Chunk Candidates: Legal Duties and Emergency Management Contracts

These are review samples only. They are not replacement corpus files.

## law-upload-legal-duties-and-emergency-management-contracts-chunk-1

[front matter/title/abstract stored as metadata; body evidence begins here] Legal Duties and Emergency Management Contracts IntroductIon Local and state emergency management (EM) directors have many legal duties. These duties are based on specific EM law and other laws of general application, such as Occupational Safety and Health Administration (OSHA) law, contract law, personnel law, and government ethics law. They also have the responsibility for purchasing systems and equipment that best meet the needs of their departments while staying within the confines of time and budget. This article will present guidelines for successfully negotiating EM contracts. State emergency management law Every state has some form of EM law. Such laws typically relate to: n setting up a state emergency or disaster management agency, n specifying state and local organization roles in responding to disaste

## law-upload-legal-duties-and-emergency-management-contracts-chunk-2

[front matter/title/abstract stored as metadata; body evidence begins here] Nicholson, JD JEM Legal desk health services; rescue; engineering; warning services; communications; radiological, chemical, and other special weapons defense; evacuation; emergency welfare services; emergency transportation; infrastructure protection; and restoration of utility services. As is readily apparent, although the enumerated duties at the state level are limited, their scope is all-inclusive. Keeping EM plans current is another specific responsibility, and the failure to fulfill it may expose the emergency manager and his or her jurisdiction to liability. local emergency management ordInance The local emergency manager is obliged to understand and obey all relevant local ordinances related to his or her functions. Local EM ordinance serves a number of purposes: n It “fills in the blanks” in EM state la
