# Dev-Only Partial Refresh Plan

## Proposed Order

1. `sandbags-upload-flood-risk-management-global-case-studies` — actions A+B+C+E+H+J+K; chunks 5; FEWS/WRI/body evidence is mixed with page headers, OCR joins, table/figure residue, and overlapping chunks.
2. `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness` — actions I+B+E; chunks 1; Title, authors, and abstract are embedded in the first evidence chunk.
3. `sandbags-upload-life-safety-modeling-for-flood-emergency-management` — actions H+B+C+E; chunks 2; Figure/table-heavy chunk 8 outranks narrative HAZUS/life-safety evidence.
4. `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers` — actions H+A+B+E; chunks 2; Correct preparedness evidence is embedded in table-heavy chunks with control glyph/table residue.
5. `sandbags-upload-community-resilience-and-recovery-after-major-flood` — actions B+C+E; chunks 3; Useful resilience evidence is present, but broad chunk boundaries and noisy starts keep source-quality failures alive.
6. `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model` — actions C+B+E; chunks 2; Direct HAZUS evidence exists but competes with noisy life-safety figure/table chunks.
7. `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan` — actions A+B+E; chunks 2; Local-measures evidence is useful but mixed with layout/table residue.
8. `law-upload-legal-duties-and-emergency-management-contracts` — actions I+B+E+G; chunks 2; Answer correctness is acceptable, but quality scoring flags broad/title-leading legal chunks.

## Approval Needed Next

Explicit AWS Dev mutation approval is required before any of these actions:

- update the 8 listed uploaded source JSON objects in the Dev bucket;
- regenerate chunks for only the affected documents;
- replace vector records for only the affected documents;
- reembed only the affected documents;
- run before/after diagnostics against the same suite.

Not included without separate approval: full reindex/reembed, staging/demo deployment, main merge, broad S3 sync, or source artifact deletion.

## Validation Plan

1. Make proposed source cleanup in a local staging copy, not in the export directory.
2. Rechunk affected documents and compare old/new chunk text for listed chunks.
3. Run local RAG diagnostics against the changed chunk map.
4. If improved, request explicit Dev S3/vector partial refresh approval.
5. After approved partial refresh, rerun live Dev diagnostics and compare the same failure IDs.