# 2026-05-30 Dev Source/Chunk/OCR Export Access Verification

## Outcome

Outcome B: AWS identity is valid, but the `falcontrust-deploy` profile cannot read or list the Dev data bucket. A safe exact-key local export script was prepared, but it cannot succeed until the profile has S3 read permissions or the script is run by an approved read-capable profile.

## Read-Only Checks

- STS account: `510844691338`
- STS principal: `arn:aws:iam::510844691338:user/massiveai-falcontrust-rag-deploy`
- Dev bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`
- Intended region: `us-east-2`
- `aws s3api get-bucket-location`: blocked, `AccessDenied` for `s3:GetBucketLocation`
- `aws s3 ls s3://falcontrust-rag-dev-data-510844691338-us-east-2/`: blocked, `AccessDenied` for `s3:ListBucket`
- Top-level prefixes: not observable with this profile
- `aws s3api head-object` for `vectors/dev-customer-phase2-vector-index.json`: blocked, `403 Forbidden`
- `aws s3 cp` for `vectors/dev-customer-phase2-vector-index.json` to local `/tmp`: blocked, `403 Forbidden` during `HeadObject`

## Sanitized Locations And References

- Bucket: `s3://falcontrust-rag-dev-data-510844691338-us-east-2/`
- Vector index key: `vectors/dev-customer-phase2-vector-index.json`
- Runtime backend: `bedrock-s3-vector`
- Runtime manifest refs from App Runner env: `/app/manifests/customer-corpus.seed.json`, `/app/seed-reports/customer-chunk-map.json`

The runtime manifest refs are container paths, not confirmed S3 keys. They are recorded for follow-up, but the prepared export script only copies exact S3 keys observed from live vector metadata plus the known vector index key.

## Exact Affected Source JSON Keys

- `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`

## Affected Chunks

- `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness`: chunk 1
- `sandbags-upload-flood-risk-management-global-case-studies`: chunks 5, 8, 11, 13, 19, 54, 55, 85, 86, 88, 90, 95, 98, 101, 117, 121, 127, 128
- `sandbags-upload-community-resilience-and-recovery-after-major-flood`: chunks 1, 5, 7, 8, 9
- `sandbags-upload-life-safety-modeling-for-flood-emergency-management`: chunks 2, 3, 6, 8
- `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model`: chunks 1, 2, 4
- `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`: chunks 9, 10, 11, 14
- `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan`: chunks 3, 8, 10, 12
- `law-upload-legal-duties-and-emergency-management-contracts`: chunks 1, 2, 4

## Export Script

- Script path: `docs/rag-quality/runs/20260530-source-chunk-ocr-export-readonly.sh`
- Destination: `/home/ralli/falcontrust-dev-corpus-export-20260530/`
- Object count: 9 exact S3 keys: 8 affected upload/source JSON files plus 1 vector index JSON.
- Estimated size: unavailable because `HeadObject`/`ListBucket` are denied.

Exact next command after read permission is granted:

```bash
AWS_PROFILE=falcontrust-deploy bash docs/rag-quality/runs/20260530-source-chunk-ocr-export-readonly.sh
```

The script uses only `aws s3 cp` from the Dev bucket to the local export directory. It contains no S3 write, overwrite, delete, sync-back, reindex, reembed, deploy, or merge command.

## Required Access To Unblock

Minimum read-only S3 access needed for this lane:

- `s3:GetBucketLocation` on `arn:aws:s3:::falcontrust-rag-dev-data-510844691338-us-east-2`
- `s3:ListBucket` scoped to the exact prefixes needed for validation, if prefix discovery is required
- `s3:GetObject` on:
  - `arn:aws:s3:::falcontrust-rag-dev-data-510844691338-us-east-2/vectors/dev-customer-phase2-vector-index.json`
  - `arn:aws:s3:::falcontrust-rag-dev-data-510844691338-us-east-2/uploads/sandbags/*` for the seven affected sandbags JSON keys, or exact-object ARNs
  - `arn:aws:s3:::falcontrust-rag-dev-data-510844691338-us-east-2/uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`

## Safety Confirmations

No S3 overwrite/delete/sync-back was run. No vector/index mutation, reindex, reembed, deploy, merge, staging, demo, or secret printing occurred.
