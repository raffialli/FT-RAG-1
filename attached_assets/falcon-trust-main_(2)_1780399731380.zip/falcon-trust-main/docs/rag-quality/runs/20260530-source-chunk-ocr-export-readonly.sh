#!/usr/bin/env bash
set -euo pipefail

# Read-only Dev corpus export for the 2026-05-30 source/chunk/OCR cleanup lane.
# This script copies exact affected Dev artifacts from S3 to a local directory only.
# It intentionally contains no aws s3 sync, put-object, rm, delete, reindex, reembed, deploy, or merge command.

PROFILE="${AWS_PROFILE:-falcontrust-deploy}"
REGION="${AWS_REGION:-us-east-2}"
BUCKET="falcontrust-rag-dev-data-510844691338-us-east-2"
DEST="/home/ralli/falcontrust-dev-corpus-export-20260530"

OBJECT_KEYS=(
"vectors/dev-customer-phase2-vector-index.json"
"uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json"
"uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json"
"uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json"
"uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json"
"uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json"
"uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json"
"uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json"
"uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json"
)

mkdir -p "$DEST"

for key in "${OBJECT_KEYS[@]}"; do
  target="$DEST/$key"
  mkdir -p "$(dirname "$target")"
  aws s3 cp "s3://$BUCKET/$key" "$target" --profile "$PROFILE" --region "$REGION" --only-show-errors
done

find "$DEST" -type f -print | sort
