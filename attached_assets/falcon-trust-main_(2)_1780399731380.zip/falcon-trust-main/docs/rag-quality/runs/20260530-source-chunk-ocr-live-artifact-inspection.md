# FalconTrust Live Dev Source/Chunk/OCR Artifact Inspection - 2026-05-30

## Scope

- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Inspection base: `c8113f4fd34d79fd26584d8b324975eca72f4dcc`
- Dev endpoint: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
- Dev service: `falcontrust-rag-dev-web`
- Backend/index: `bedrock-s3-vector` / `vectors/dev-customer-phase2-vector-index.json`
- Evidence directory: `docs/rag-quality/runs/20260530-source-chunk-ocr-live-artifact-inspection/`
- Hard gates observed: read-only only; no S3 overwrite, vector/index mutation, reindex, reembed, deploy, merge, or secret output.

## Read-Only Locations Identified

Sanitized Dev target evidence is saved in:

- `docs/rag-quality/runs/20260530-source-chunk-ocr-live-artifact-inspection/aws-dev-target-sanitized.json`

Identified locations:

- AWS service: App Runner service `falcontrust-rag-dev-web`, region `us-east-2`
- Storage backend: S3
- Storage bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`
- Vector index key: `vectors/dev-customer-phase2-vector-index.json`
- Runtime manifest path: `/app/manifests/customer-corpus.seed.json`
- Runtime chunk map path: `/app/seed-reports/customer-chunk-map.json`
- Runtime image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-1d85bc9-20260530182219`

Classification:

- Uploaded JSON records under `uploads/...`: source-of-truth or near-source artifacts for the live indexed corpus.
- Runtime manifest and chunk map: derived indexing artifacts used by the deployed app.
- Vector index key: derived vector/index metadata for live retrieval.
- Live `/api/documents` output: safe read-only runtime view of current chunks and metadata, useful for targeted inspection but not a replacement for raw S3 source artifact export.

## Export Result

Targeted local evidence exported:

- `aws-dev-target-sanitized.json`: App Runner, storage, index, and manifest locations without secrets.
- `targeted-live-vector-excerpts.json`: targeted live `/api/documents` excerpts for eight affected documents and 42 selected chunks.
- `s3-direct-read-blocker.json`: direct S3 read blocker proof.

Direct S3 source-object inspection is blocked:

- Attempted operation: `aws s3api head-object` against affected upload/vector keys.
- Result: `403 Forbidden`.
- Implication: the deploy profile can prove App Runner/ECR and use the app API, but direct source JSON/vector artifact export requires a different read grant or an approved export path.

## Live Failure Baseline

Latest live Dev failure counts from the remaining-failures pass:

- `source_chunk_ocr_layout`: 15
- `retrieval_ranking`: 3
- `answer_generation_faithfulness`: 3
- `confidence_calibration`: 0
- `unsupported_gap_missing`: 0
- `reference_frontmatter_leakage`: 0

## Affected Documents And Defects

### Current Flood Warning System in Japan and Evacuation Effectiveness

- Document ID: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness`
- Source path: `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- Source file: `bdevito67,+JEM_21-1-04-Huang.pdf`
- Failing cases: `current-flood-warning-japan`, `duplicate-overlap-evidence`, `mobile-warning-artifact`, `page-header-author-artifact`
- Inspected chunks: `chunk-1`
- Defects: title/abstract/frontmatter lead, page/header artifact.
- Evidence: `chunk-1` starts with the document title, article subtitle, authors, and `ABSTRACT` before answer-bearing body material; it is 3,428 characters and is treated as body evidence.
- Cleanup target: source JSON cleanup plus rechunking to separate title/abstract/frontmatter from body.
- Refresh need: partial reembed/reindex after cleanup.

### Flood Risk Management Global Case Studies

- Document ID: `sandbags-upload-flood-risk-management-global-case-studies`
- Source path: `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- Source file: `Flood Risk Management-OCR.pdf`
- Failing cases: `current-flood-warning-japan`, `duplicate-overlap-evidence`, `fews-mobile-warning`, `metadata-source-display`, `mid-word-boundary`, `mobile-warning-artifact`, `page-header-author-artifact`, `technology-exclusion-joined-heading`, `wri-flood-exposure-reference`
- Inspected chunks: `5`, `8`, `11`, `13`, `19`, `54`, `55`, `85`, `86`, `88`, `90`, `95`, `98`, `101`, `117`, `121`, `127`, `128`
- Defects: page/header pollution, OCR joins, figure/table residue, semantically adjacent but not answer-bearing chunks, direct evidence sometimes ranked below noisy adjacent chunks.
- Evidence examples: `chunk-11` includes body text interrupted by the heading/page fragment `Realities and social constructions 9`; `chunk-121` begins with OCR-corrupted reference/body transition text like `Hydroloiical Processes`; `chunk-13` shows broken OCR in a chapter heading before flood-management body text.
- Cleanup target: source OCR normalization and chunk boundary cleanup for this document first; ranking follow-up only after chunk quality improves.
- Refresh need: partial reembed/reindex after affected chunk text changes.

### Community Resilience and Recovery After Major Flood

- Document ID: `sandbags-upload-community-resilience-and-recovery-after-major-flood`
- Source path: `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- Source file: `bdevito67,+JEM_V6N5_9.pdf`
- Failing cases: `community-resilience-recovery`, `preparedness-workshop-kits`
- Inspected chunks: `1`, `5`, `7`, `8`, `9`
- Defects: title/abstract lead in first chunk, page/header residue, some table/figure-style content.
- Evidence: `chunk-1` starts with title and `ABSTRACT`; `chunk-5` includes quantified quote/table-style material that is useful but layout-sensitive.
- Cleanup target: rechunk title/abstract separately and mark body findings distinctly.
- Refresh need: partial reembed/reindex if chunk boundaries or text change.

### Life Safety Modeling for Flood Emergency Management

- Document ID: `sandbags-upload-life-safety-modeling-for-flood-emergency-management`
- Source path: `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- Source file: `bdevito67,+JEMv9n1_7.pdf`
- Failing cases: `hazus-flood-loss-model`, `life-safety-model-fatalities`, `mid-word-boundary`
- Inspected chunks: `2`, `3`, `6`, `8`
- Defects: page/header pollution, bullet/control glyphs, figure/table leakage.
- Evidence: `chunk-2` starts with control-character bullet glyphs; `chunk-6` starts from a figure discussion; `chunk-8` was previously observed ranking above direct HAZUS evidence for a HAZUS query.
- Cleanup target: remove control glyphs, separate figure/table captions from body evidence, and penalize caption-only chunks if they remain.
- Refresh need: partial reembed/reindex after cleanup.

### Hazard Mitigation Planning Using HAZUS-MH Flood Model

- Document ID: `sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model`
- Source path: `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- Source file: `bdevito67,+JEM_V3N2_3.pdf`
- Failing cases: `hazus-flood-loss-model`, `mid-word-boundary`
- Inspected chunks: `1`, `2`, `4`
- Defects: title/abstract lead, figure/table residue, page/header pollution.
- Evidence: `chunk-1` begins with title and abstract while also containing HAZUS answer-bearing text; chunks `2` and `4` include mapping/tool body content with layout residue.
- Cleanup target: split abstract/title from body and preserve HAZUS loss-estimation body evidence.
- Refresh need: partial reembed/reindex if chunks change.

### Personal Preparedness Curriculum for Public Health Workers

- Document ID: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`
- Source path: `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- Source file: `bdevito67,+JEM-12-1-04-Kohn.pdf`
- Failing case: `preparedness-workshop-kits`
- Inspected chunks: `9`, `10`, `11`, `14`
- Defects: table row/column corruption and page/header pollution.
- Evidence: `chunk-11` starts with table-number fragments before `Table 6` and response percentages; this content is answer-bearing but should be table-aware instead of flattened as ordinary prose.
- Cleanup target: table-aware cleanup/metadata, preserving 77 percent / 40 percent style evidence where relevant.
- Refresh need: partial reembed/reindex after cleanup.

### Practical Flood Risk Reduction Strategies in South Sudan

- Document ID: `sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan`
- Source path: `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- Source file: `bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf`
- Failing case: `south-sudan-local-measures`
- Inspected chunks: `3`, `8`, `10`, `12`
- Defects: page/header pollution and one figure/table-style chunk.
- Evidence: `chunk-12` contains direct numbered recommendations, while `chunk-3` includes quote/footnote-style content likely to trigger layout diagnostics.
- Cleanup target: clean page/header residue and preserve numbered recommendation chunks.
- Refresh need: partial reembed/reindex if source text or chunks change.

### Legal Duties and Emergency Management Contracts

- Document ID: `law-upload-legal-duties-and-emergency-management-contracts`
- Source path: `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- Source file: `bdevito67,+JEM_V3N3_3.pdf`
- Failing case: `contract-law-basics`
- Inspected chunks: `1`, `2`, `4`
- Defects: title/intro lead in `chunk-1`; chunks `2` and `4` are cleaner and more directly useful.
- Evidence: `chunk-1` starts with title and introduction; `chunk-4` is short, direct contract-modification evidence.
- Cleanup target: separate introductory/title material and improve ranking toward direct contract modification chunks.
- Refresh need: partial reembed/reindex if chunk boundaries change; ranking-only fix may not require reembed.

## Test Case Mapping

| Test ID | Main affected docs/chunks | Defect classification | Recommended target |
| --- | --- | --- | --- |
| `mobile-warning-artifact` | Japan `chunk-1`; Global Case Studies `85`, `90`, `98`, `101` | title/abstract lead, page/header pollution, OCR/layout residue | source JSON cleanup + rechunk + partial reembed |
| `fews-mobile-warning` | Global Case Studies `85`, `90`, `98`, `101` | page/header pollution, OCR joins, adjacent warning-system chunks | source cleanup + rechunk + partial reembed |
| `current-flood-warning-japan` | Japan `chunk-1`; Global Case Studies secondary chunks | title/abstract lead, body evidence mixed with frontmatter | source cleanup + abstract/body split |
| `community-resilience-recovery` | Community Resilience `1`, `5`, `7`, `8`, `9` | title/abstract lead and layout-sensitive quote/table content | rechunk + body-finding prioritization |
| `hazus-flood-loss-model` | Life Safety `8`; HAZUS `1`, `2`, `4` | good HAZUS evidence outranked by adjacent figure/model chunk | cleanup figure chunks, then ranking check |
| `life-safety-model-fatalities` | Life Safety `2`, `3`, `6`, `8` | bullet glyphs, figure/table leakage, page/header residue | source OCR/table cleanup |
| `preparedness-workshop-kits` | Preparedness `9`, `10`, `11`, `14` | table row corruption, page/header residue | table-aware cleanup |
| `south-sudan-local-measures` | South Sudan `3`, `8`, `10`, `12` | page/header pollution and one quote/table artifact | source cleanup, preserve recommendations |
| `contract-law-basics` | Legal Duties `1`, `2`, `4` | title/intro lead, direct evidence in shorter later chunk | split intro/title and rank direct chunks |
| `wri-flood-exposure-reference` | Global Case Studies `88`, `127`, `128` | semantically adjacent exposure discussion, likely missing direct WRI answer source | verify raw source; possible expected-source gap |
| `technology-exclusion-joined-heading` | Global Case Studies `90`, `95`, `98` | OCR joined heading and direct chunk ranked below noisy chunks | cleanup OCR heading + ranking check |
| `page-header-author-artifact` | Japan `1`; Global Case Studies `85`, `86`, `98` | title/header/author and page residue | source cleanup |
| `mid-word-boundary` | Life Safety `8`; Global Case Studies `117`, `121`; HAZUS `1` | noisy figure/reference chunks outrank direct HAZUS evidence | cleanup + ranking check |
| `duplicate-overlap-evidence` | Japan `1`; Global Case Studies `85`, `86`, `101` | overlapping adjacent chunks, title/abstract lead | overlap-aware rechunk/dedupe |
| `metadata-source-display` | Global Case Studies `5`, `11`, `19`, `54`, `55` | answer is correct; layout flags mostly from source quality | lower priority, cleanup with Global Case Studies |

## Source-Of-Truth Recommendation

The source of truth for cleanup should be the live uploaded JSON source artifacts in S3 plus their original PDFs if available through the same controlled export path. The runtime `/api/documents` excerpts are sufficient to prove that the live indexed chunks have OCR/layout problems, but they are not sufficient to perform source-safe cleanup because direct S3 source JSON export is currently blocked.

Do not treat the app repository as the source corpus. The affected uploaded JSON files and vector/index artifacts are not present in the checkout.

## Refresh And Reembed Recommendation

Partial refresh is enough if cleanup stays limited to the eight affected documents listed above.

Reembedding is required for any document whose cleaned text or chunk boundaries change, because embeddings must match the final indexed text.

Full reindex/reembed is not indicated unless the cleanup changes global OCR normalization or chunking behavior across the whole uploaded corpus.

## Proposed Next Approval

Request explicit approval for a read-only S3 export grant or controlled export path for these keys:

- `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- `vectors/dev-customer-phase2-vector-index.json`

After source export is available, run a cleanup lane that:

1. snapshots the current affected source JSON and vector index metadata;
2. cleans OCR/layout issues in affected source JSON or regenerates them from source PDFs;
3. rechunks only affected documents;
4. compares old/new chunks for the listed chunk IDs;
5. requests explicit approval before partial Dev reembed/reindex;
6. validates against the same 25 live AWS Dev diagnostics.

## Rollback And Safety

- Preserve current source JSON object versions or copies before any future mutation.
- Preserve current vector index key and object version before partial refresh.
- Write refreshed index artifacts to a new key or keep a verified rollback object version.
- Limit first mutation attempt to Dev only and to affected documents only.
- Do not deploy Staging or Demo until Dev live diagnostics improve.

## Outcome

Outcome B - read-only direct S3 export is blocked.

Useful partial live inspection is complete through the deployed app API, but direct inspection of source JSON/vector objects needs additional read permission or an approved export route before cleanup can be performed safely.
