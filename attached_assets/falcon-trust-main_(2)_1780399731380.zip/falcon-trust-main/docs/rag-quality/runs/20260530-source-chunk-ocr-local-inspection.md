# FalconTrust Source/Chunk/OCR Local Corpus Inspection - 2026-05-30

## Scope

- App worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Starting HEAD: `27ac5683baa37d7553703545a431ce83968baa62`
- Local export: `/home/ralli/falcontrust-dev-corpus-export-20260530/`
- Vector manifest: `/home/ralli/falcontrust-dev-corpus-export-20260530/vectors/dev-customer-phase2-vector-index.json`
- Source JSON count: 8 affected uploaded PDF artifacts
- Export size: 9 files / 8.4 MB
- Hard gates observed: local inspection only; no AWS write, S3 overwrite/delete, vector/index mutation, reindex, reembed, deploy, merge, or exported-corpus commit.

## Exported Files Inspected

- `vectors/dev-customer-phase2-vector-index.json`
- `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`

The source JSON files contain full uploaded PDF text under top-level `text`, plus `id`, `title`, `sourceFileName`, `uploadedAt`, and `classifiedAs`. They do not contain explicit chunk arrays. The vector manifest contains derived chunk records in `records`, each with `chunkId`, `documentId`, `title`, `domain`, `text`, `index`, `sourcePath`, `contentType`, `embedding`, and `metadata`.

The vector manifest is therefore the source of truth for the currently indexed chunk text and embeddings. The upload JSON files are the source or near-source flattened text used before chunking. Cleanup should operate on exported source JSON or on a regenerated source text pipeline, then recreate affected chunks and embeddings.

## Vector Manifest Structure

- Version: `1`
- Provider: `bedrock`
- Model: `amazon.titan-embed-text-v2:0`
- Region: `us-east-2`
- Record count: `219`
- Embedding dimension: `1024`
- Affected exported records inspected: all retrieved chunks from the latest live failure set.

Metadata fields available on chunk records include:

- `normalizedPdfText`
- `originalTextLength`
- `normalizedTextLength`
- `removedUploadedPdfHeading`
- `removedPageMarkerCount`
- `firstRemovedPageMarker`
- `sourceFileName`
- `documentId`
- `chunkId`
- `chunkIndex`
- `title`
- `domain`
- `source`
- `sourcePath`
- `uploadedAt`
- `contentType`

The affected chunks are all marked `contentType: body`, even when the text begins with title/abstract material, page headers, figure captions, table rows, or OCR artifacts. This is the core metadata quality gap.

## Remaining Failure Mapping

| Test ID | Failure class | Retrieved chunks | Root cause |
| --- | --- | --- | --- |
| `mobile-warning-artifact` | `source_chunk_ocr_layout` | Japan `chunk-1`; Global Case Studies `85`, `90` | Japan title/abstract chunk is treated as body; Global Case Studies warning chunks contain page/header and OCR-joined heading residue. |
| `fews-mobile-warning` | `source_chunk_ocr_layout` | Global Case Studies `85`, `90`, `98` | Answer-bearing FEWS chunks exist, but include page fragments and OCR errors such as joined headings and `infom1ation`. |
| `current-flood-warning-japan` | `source_chunk_ocr_layout` | Japan `chunk-1`; Global Case Studies `98`, `90`, `85` | Direct Japan chunk is relevant but starts with title/authors/abstract and should be split or labeled frontmatter/abstract. |
| `community-resilience-recovery` | `source_chunk_ocr_layout` | Community Resilience `1`, `5`, `9`, `8`, `7` | Good evidence exists in body chunks, but `chunk-1` starts with title/abstract and ranks highest. |
| `hazus-flood-loss-model` | `source_chunk_ocr_layout` | Life Safety `8`; HAZUS `1`, `2`, `4` | Good HAZUS evidence exists, but a Life Safety figure/table chunk ranks above it. |
| `life-safety-model-fatalities` | `source_chunk_ocr_layout` | Life Safety `8`, `2`, `6`, `3` | Figure/table captions and control-glyph bullets are embedded as body text. |
| `preparedness-workshop-kits` | `source_chunk_ocr_layout` | Preparedness `11`, `9`, `10`, `14`; Community Resilience `5` | Good table evidence exists, but table rows are flattened into prose and should be table-aware. |
| `south-sudan-local-measures` | `source_chunk_ocr_layout` | South Sudan `12`, `10`, `8`, `3` | Good numbered recommendation evidence exists; one retrieved chunk includes journal/page header residue. |
| `contract-law-basics` | `source_chunk_ocr_layout` | Legal Duties `2`, `1`, `4` | Good evidence exists, but `chunk-2` starts with author/header text and `chunk-1` starts with title/intro. |
| `wri-flood-exposure-reference` | `source_chunk_ocr_layout`, `retrieval_ranking`, `answer_generation_faithfulness` | Global Case Studies `88`, `127`, `54`, `128`, `13` | Retrieved chunks discuss flood risk/exposure but do not answer highest country exposure; likely expected-source gap or unsupported control case. |
| `technology-exclusion-joined-heading` | `source_chunk_ocr_layout`, `retrieval_ranking`, `answer_generation_faithfulness` | Global Case Studies `90`, `98`, `95` | `chunk-95` contains direct technology evidence but ranks below `chunk-90`, which contains OCR-joined heading residue. |
| `page-header-author-artifact` | `source_chunk_ocr_layout` | Global Case Studies `85`; Japan `1`; Global Case Studies `98`, `86` | Query is artifact-oriented and retrieves useful warning text mixed with title/header artifacts. |
| `mid-word-boundary` | `source_chunk_ocr_layout`, `retrieval_ranking`, `answer_generation_faithfulness` | Life Safety `8`; Global Case Studies `121`, `117`; HAZUS `1`; Global Case Studies `8` | Noisy figure/reference chunks outrank better HAZUS/flood-loss evidence. |
| `duplicate-overlap-evidence` | `source_chunk_ocr_layout` | Global Case Studies `85`, `86`, `101`; Japan `1` | Overlapping adjacent warning-system chunks produce repetitive evidence; Japan abstract chunk is also included. |
| `metadata-source-display` | `source_chunk_ocr_layout` | Global Case Studies `19`, `11`, `5`, `54`, `55` | Answer is correct; remaining flag is mostly source quality/page-fragment noise, not a metadata display failure. |

## Document-Level Cleanup Actions

### Current Flood Warning System in Japan and Evacuation Effectiveness

- Affected chunk: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1`
- Source key: `uploads/sandbags/sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 13`, `contentType: body`
- Good evidence: yes, but mixed with title/authors/abstract in the same chunk.
- Required cleanup: D, E, F, H, I.
- Recommendation: split title/authors/abstract into non-body or abstract-labeled chunks, then keep body discussion about warning effectiveness as separate answerable chunks.

### Flood Risk Management Global Case Studies

- Affected chunks: `5`, `8`, `11`, `13`, `19`, `54`, `55`, `85`, `86`, `88`, `90`, `95`, `98`, `101`, `117`, `121`, `127`, `128`
- Source key: `uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 226`, `contentType: body`
- Good evidence: yes, especially warning-system chunks `85`, `86`, `95`, `98`, and governance/policy chunks `11`, `19`, `54`, `55`.
- Bad evidence outranking good evidence: yes, especially `chunk-90` over `chunk-95` for technology exclusion, and `chunk-88`/`127` for WRI exposure.
- Required cleanup: A, B, C, E, F, G, H, I.
- Recommendation: remove page headings such as chapter/page markers inside chunks, repair OCR joins like `Institutionalimpediments`, isolate reference-like transitions, and add chunk quality metadata to penalize noisy chunks after partial reindex.

### Community Resilience and Recovery After Major Flood

- Affected chunks: `1`, `5`, `7`, `8`, `9`
- Source key: `uploads/sandbags/sandbags-upload-community-resilience-and-recovery-after-major-flood.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 10`, `contentType: body`
- Good evidence: yes, body chunks `7`, `8`, and `9` contain better resilience/recovery lessons than the title/abstract lead.
- Bad evidence outranking good evidence: yes, `chunk-1` ranks highest because abstract text is embedded as body.
- Required cleanup: D, E, F, H, I.
- Recommendation: split title/abstract from body and preserve quote/strategy sections as answerable body chunks.

### Life Safety Modeling for Flood Emergency Management

- Affected chunks: `2`, `3`, `6`, `8`
- Source key: `uploads/sandbags/sandbags-upload-life-safety-modeling-for-flood-emergency-management.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 9`, `contentType: body`
- Good evidence: yes, fatality categories are present.
- Bad evidence outranking good evidence: yes, figure/table chunks rank highly for HAZUS and broad preparedness/economic-loss queries.
- Required cleanup: B, C, F, G, H, I.
- Recommendation: strip control-glyph bullets, preserve bullet content as clean list text, and classify figure/table captions as table evidence or low-rank captions instead of generic body chunks.

### Hazard Mitigation Planning Using HAZUS-MH Flood Model

- Affected chunks: `1`, `2`, `4`
- Source key: `uploads/sandbags/sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount` present, `contentType: body`
- Good evidence: yes, `chunk-1` and `chunk-2` contain direct HAZUS loss-estimation evidence.
- Bad evidence outranking good evidence: yes, mainly from adjacent Life Safety chunks, not this document alone.
- Required cleanup: D, E, G, H, I.
- Recommendation: split abstract/title from body and strengthen reranking toward same-document direct HAZUS chunks after Life Safety caption cleanup.

### Personal Preparedness Curriculum for Public Health Workers

- Affected chunks: `9`, `10`, `11`, `14`
- Source key: `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 19`, `contentType: body`
- Good evidence: yes, `chunk-11` contains the emergency-kit follow-up evidence.
- Bad evidence outranking good evidence: no; the issue is that good evidence is table-flattened and flagged as layout/OCR risk.
- Required cleanup: B, F, H, I.
- Recommendation: represent tables as table-aware chunks with caption, row labels, and values; preserve the emergency-kit percentages.

### Practical Flood Risk Reduction Strategies in South Sudan

- Affected chunks: `3`, `8`, `10`, `12`
- Source key: `uploads/sandbags/sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount` present, `contentType: body`
- Good evidence: yes, `chunk-12` has direct numbered mitigation recommendations and ranks first.
- Bad evidence outranking good evidence: no significant issue; this is mostly cleanup of page/header residue in supporting chunks.
- Required cleanup: A, F, H, I.
- Recommendation: remove journal/page headers from long-term measure chunks and preserve numbered recommendations.

### Legal Duties and Emergency Management Contracts

- Affected chunks: `1`, `2`, `4`
- Source key: `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- Metadata: `normalizedPdfText: true`, `removedPageMarkerCount: 3`, `contentType: body`
- Good evidence: yes, `chunk-4` is short and direct; `chunk-1` has broad legal-duty context.
- Bad evidence outranking good evidence: yes, `chunk-2` begins with author/header text and ranks highest.
- Required cleanup: A, D, F, G, H, I.
- Recommendation: strip legal desk header/author residue, split introductory legal-duty material from contract modification guidance, and prefer direct contract chunks for contract-law questions.

## Proposed Cleaned Samples

Small sample excerpts were added under:

- `docs/rag-quality/runs/20260530-source-chunk-ocr-local-inspection/proposed-cleaned-samples/`

They are examples only, not replacements for source JSON or vector records:

- `japan-warning-title-abstract-split.md`
- `global-case-studies-joined-heading.md`
- `life-safety-control-glyphs-and-table.md`
- `preparedness-table-aware-chunk.md`
- `legal-duties-header-strip.md`

## Rechunk/Reindex Scope

Chunk cleanup alone is not enough if the cleaned chunks need to be retrieved semantically. Any source text change, chunk split/merge, or content-type metadata repair should be followed by reembedding and reindexing for the affected document.

Partial affected-document reindex is sufficient. Full reindex is not recommended unless the cleanup lane changes shared global PDF normalization/chunking behavior and must regenerate unaffected uploaded PDFs.

Recommended partial reindex scope:

- 8 affected source JSON documents
- Current vector records linked to those source paths
- Embeddings for regenerated chunks from those documents only
- Preserve old vector index object/version as rollback

## Exact Next Approval Needed

Approve a Dev-only source/chunk cleanup lane that may:

1. create proposed cleaned copies under the app worktree or a separate local working directory;
2. regenerate chunks for only the eight affected exported source JSON files;
3. compare old/new chunks for the listed failing test IDs;
4. prepare a partial Dev reembed/reindex plan with rollback;
5. stop for explicit approval before uploading changed source/chunk/vector/index artifacts to AWS.

Do not mutate AWS or the live vector index until the cleaned local chunk diff is reviewed and the partial reembed/reindex action is explicitly approved.

## Outcome

Outcome A - local corpus inspection complete.

The exported artifacts are sufficient to determine the cleanup target: source/OCR normalization plus rechunking for the eight affected documents, followed by partial affected-document reembed/reindex after approval. Runtime-only changes are not the next best step for the remaining failures.
