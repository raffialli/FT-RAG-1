# Proposed Cleaned Sample: Global Case Studies Joined Heading

- Document: `sandbags-upload-flood-risk-management-global-case-studies`
- Chunk: `sandbags-upload-flood-risk-management-global-case-studies-chunk-90`
- Rule: repair OCR-joined headings and remove page/chapter header residue.
- Expected improvement: technology-exclusion and warning-system queries should prefer direct warning content instead of noisy heading text.

## Original Excerpt

`Flood warnings in the developing world 121 Institutionalimpediments Well-structured institutional frameworks are required to match the location of flood management control...`

## Proposed Cleaned Excerpt

`Institutional impediments. Well-structured institutional frameworks are required to match the location of flood management control with the transitioning location of knowledge. In developing countries, weakened frameworks, unstable politics, and frequent change can limit warning effectiveness.`

## Cleanup Action

Remove the page/chapter header, split the joined heading `Institutionalimpediments`, and preserve the body paragraph as a section-aware chunk.
