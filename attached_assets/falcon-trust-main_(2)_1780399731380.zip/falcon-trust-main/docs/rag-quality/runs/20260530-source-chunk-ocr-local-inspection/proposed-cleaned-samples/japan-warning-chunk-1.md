# Proposed Cleaned Sample: Japan Warning Chunk 1

Source chunk: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1`

Original issue: title, authors, and abstract are embedded as final body evidence.

Proposed cleanup target:

> Store title, authors, and abstract as front matter or metadata. Body chunks should begin with substantive findings about flood warning systems and evacuation effectiveness.

Cleanup notes: keep the article title and abstract searchable, but demote them from final-answer evidence unless the query asks about bibliographic details or the abstract itself.
