# Proposed Cleaned Sample: Japan Warning Title/Abstract Split

- Document: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness`
- Chunk: `sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1`
- Rule: split title/authors/abstract from answerable body text.
- Expected improvement: answer generation should stop opening with title/authors/abstract and retrieve body findings about warning effectiveness.

## Original Excerpt

`# Current Flood Warning System in Japan and Evacuation Effectiveness Current flood warning system in Japan and its effectiveness in mobilizing evacuation: Lessons from case studies Guangwei Huang, PhD Juan Fan ABSTRACT An effective flood warning system is crucial for successful flood management...`

## Proposed Cleaned Excerpt

`Current flood warning systems are important for mobilizing evacuation. The paper evaluates Japan's flood warning practices using case studies and a SWOT assessment, then discusses strengths, weaknesses, opportunities, threats, and directions for improving warning effectiveness.`

## Cleanup Action

Create separate non-body metadata/abstract chunks for title, authors, and abstract. Keep body discussion in answerable `body` chunks with section metadata.
