# Proposed Cleaned Sample: Legal Duties Header Strip

- Document: `law-upload-legal-duties-and-emergency-management-contracts`
- Chunk: `law-upload-legal-duties-and-emergency-management-contracts-chunk-2`
- Rule: remove author/header residue and preserve legal-duty body text.
- Expected improvement: contract-law questions should rank direct contract modification guidance above broad emergency-management header text.

## Original Excerpt

`Nicholson, JD JEM Legal desk health services; rescue; engineering; warning services; communications; radiological, chemical, and other special weapons defense...`

## Proposed Cleaned Excerpt

`Emergency management duties can include health services, rescue, engineering, warning services, communications, evacuation, welfare services, emergency transportation, infrastructure protection, and restoration of utility services.`

## Cleanup Action

Strip the `Nicholson, JD JEM Legal desk` header residue, preserve the enumerated duties as body evidence, and keep contract modification guidance in a separate direct-evidence chunk.
