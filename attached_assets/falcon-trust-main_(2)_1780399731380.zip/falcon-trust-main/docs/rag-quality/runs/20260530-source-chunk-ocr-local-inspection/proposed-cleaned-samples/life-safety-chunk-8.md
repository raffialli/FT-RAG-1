# Proposed Cleaned Sample: Life Safety Chunk 8

Source chunk: `sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8`

Original issue: figure/table caption and table rows rank as final body evidence.

Proposed cleanup target:

> Narrative life-safety findings should remain in a prose chunk. Figure captions and fatality table rows should be split into table/figure metadata or demoted from final-answer evidence unless the query specifically asks for table values.

Cleanup notes: split `Figure 7` and `Table 1` blocks away from prose; preserve fatality numbers for table-specific queries; prevent the table block from outranking direct HAZUS narrative evidence.
