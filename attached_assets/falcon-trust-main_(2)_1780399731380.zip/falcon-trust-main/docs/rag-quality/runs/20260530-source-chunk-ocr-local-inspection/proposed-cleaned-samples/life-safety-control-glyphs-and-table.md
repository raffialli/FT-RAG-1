# Proposed Cleaned Sample: Life Safety Control Glyphs And Figure Table Leakage

- Document: `sandbags-upload-life-safety-modeling-for-flood-emergency-management`
- Chunks: `sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2`, `chunk-8`
- Rule: normalize control-glyph bullets and classify figure/table captions separately from body evidence.
- Expected improvement: fatality queries can still use valid model evidence, while broad HAZUS/economic-loss queries stop being led by figure captions.

## Original Excerpt

`[control glyph] Floodwater depths, velocities, and travel times that affect the fate of people and vehicles are based on large-scale average values. [control glyph] Factors that change with time are often not represented...`

## Proposed Cleaned Excerpt

`Limitations of empirical loss-of-life models include use of large-scale average floodwater depths, velocities, and travel times; limited representation of factors that change over time; and simplified treatment of the population at risk.`

## Cleanup Action

Convert control-glyph bullets to plain list text. Move figure/table captions and numeric table rows to `table` or `caption` chunks with lower answer-generation priority unless the query asks for the table.
