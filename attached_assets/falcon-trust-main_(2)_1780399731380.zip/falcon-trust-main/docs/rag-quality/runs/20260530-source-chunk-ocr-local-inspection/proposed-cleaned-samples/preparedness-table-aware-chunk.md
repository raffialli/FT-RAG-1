# Proposed Cleaned Sample: Preparedness Table-Aware Chunk

- Document: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`
- Chunk: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-11`
- Rule: preserve answer-bearing table evidence as structured table text.
- Expected improvement: the emergency-kit answer can cite the table without triggering layout/OCR failure from flattened row fragments.

## Original Excerpt

`42 100.0 17 100.0 6 85.7 42 100.0 Table 6. Percent of respondents with "yes" responses to personal emergency preparedness questions...`

## Proposed Cleaned Excerpt

`Table 6 reports "yes" responses to personal emergency preparedness questions by EPPM category at pretraining, post-training, and one-year follow-up. Rows include confidence in knowing what should be included in a family emergency kit, having a family emergency plan, and knowing where to find more resources.`

## Cleanup Action

Keep the table caption and row labels together, remove leading orphan numeric cells, and attach table metadata so table chunks are used when relevant but not treated as ordinary prose.
