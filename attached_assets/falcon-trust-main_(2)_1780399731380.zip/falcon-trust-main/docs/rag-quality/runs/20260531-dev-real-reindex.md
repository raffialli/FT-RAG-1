# AWS Dev Real Reindex Validation

Date: 2026-05-31
Lane: `rag-retrieval-generation-dev-20260530`
Dev endpoint: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
Dev bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`
Active vector key: `vectors/dev-customer-phase2-vector-index.json`

## Summary

Real Vega/OpenClaw performed the AWS Dev reindex validation path through the deployed safe job route. The candidate vector was generated under `vectors/reindex-candidates/`, verified, and then promoted to the active Dev vector key.

Dev now reflects a newly generated vector object and is ready for manual client-style testing, but the automated post-promotion diagnostics are mixed: the OCR/layout count increased from the expected `1` to `2`, while confidence, unsupported-gap, retrieval, faithfulness, and frontmatter counts matched the expected values. Treat this as a manual QA / rollback decision point, not as a confirmed quality improvement.

## Re-anchor

- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Pre-run HEAD: `c6fb43116ce3d13d54a230cad4866f8b3ac25671`
- Pre-run status: clean except new evidence artifacts after Vega completed
- Dev endpoint reachable: `/` returned `307` to `/login?next=%2F`
- Deployed Dev image remained: `rag-retrieval-generation-dev-20260531-3de8462-20260531133943`
- Deployed digest: `sha256:b2f73d355093fd9781621d8a8dcaffd5bb5df335b3095a17226e104062ae7773`
- App Runner Dev service: `falcontrust-rag-dev-web`, `RUNNING`

## Pre-reindex Active Proof

Artifact: `docs/rag-quality/runs/20260531-dev-real-reindex/preflight/active-vector-preflight.json`

- Active ETag: `"0f727bb5ca68e33df76e583180f8b7df"`
- Active size: `7930765`
- Active LastModified: `2026-05-31T00:21:46+00:00`
- Records/docs/chunks: `224 / 8 / 224`
- Version/provider/model/region: `1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2`
- Upload inventory: `8` objects, `884169` bytes
- Existing active backup: `restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`
- Existing backup ETag/size/time: `"0f727bb5ca68e33df76e583180f8b7df"` / `7930765` / `2026-05-31T13:24:23+00:00`
- Restore reference vector: `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json`
- Restore reference ETag/size/time: `"d65bd8dec7b8bbfdc529382db1f7cd89-2"` / `9220836` / `2026-05-30T23:43:02+00:00`

## Candidate Job Proof

Artifacts:

- `docs/rag-quality/runs/20260531-dev-real-reindex/candidate/status-response.json`
- `docs/rag-quality/runs/20260531-dev-real-reindex/verification/candidate-verification.json`
- `docs/rag-quality/runs/20260531-dev-real-reindex/verification/candidate-verification.md`

Candidate job:

- Job ID: `reindex-20260531-142113320`
- Mode: `candidate`
- State: `completed`
- Created: `2026-05-31T14:21:13.320Z`
- Finished: `2026-05-31T14:24:23.647Z`
- Candidate key: `vectors/reindex-candidates/reindex-20260531-142113320-dev-customer-phase2-vector-index.json`
- Job backup key: `restore-points/reindex-20260531-142113320-before-candidate/vectors/dev-customer-phase2-vector-index.json`
- Route guarantee: candidate mode wrote backup and temp vector objects, and did not promote or overwrite active during job execution.

Candidate vector:

- ETag: `"a18ccae4e15d45f4c8397baec71bf8c0"`
- Size: `7930765`
- LastModified: `2026-05-31T14:24:22+00:00`
- Records/docs/chunks: `224 / 8 / 224`
- Version/provider/model/region: `1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2`
- Embedding dimension: `1024`

Verification:

- JSON parsed: yes
- Nonempty records: yes
- Expected doc count `8`: yes
- Plausible against active `224` and restore `260`: yes
- Duplicate record IDs: `0`
- Missing required document/chunk/title/source/metadata/text/embedding fields: all `0`
- Expected embedding model: yes
- Candidate prefix safe: yes
- OCR flag count in candidate verification: `1`
- Boundary risk count in candidate verification: `3`
- Verification pass: `true`

## Promotion Proof

Artifact: `docs/rag-quality/runs/20260531-dev-real-reindex/promotion/active-promotion-proof.json`

Vega promoted the verified candidate by S3-copying:

- From: `vectors/reindex-candidates/reindex-20260531-142113320-dev-customer-phase2-vector-index.json`
- To: `vectors/dev-customer-phase2-vector-index.json`

Before active:

- ETag: `"0f727bb5ca68e33df76e583180f8b7df"`
- Size: `7930765`
- LastModified: `2026-05-31T00:21:46+00:00`

After active:

- ETag: `"a18ccae4e15d45f4c8397baec71bf8c0"`
- Size: `7930765`
- LastModified: `2026-05-31T14:25:34+00:00`
- Records/docs/chunks: `224 / 8 / 224`
- Version/provider/model/region: `1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2`
- `updatedAt`: `2026-05-31T14:24:18.147Z`
- ETag changed from old active: yes

Rollback anchors:

- Immediate pre-candidate backup: `restore-points/reindex-20260531-142113320-before-candidate/vectors/dev-customer-phase2-vector-index.json`
- Earlier active backup: `restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`
- Current-best restore point: `restore-points/20260530-current-best-before-remaining-failures/`

## Live Diagnostics

Artifacts:

- `docs/rag-quality/runs/20260531-dev-real-reindex/post-promotion-cookie/diagnostic-counts.json`
- `docs/rag-quality/runs/20260531-dev-real-reindex/post-promotion-cookie/diagnostics/baseline.json`
- `docs/rag-quality/runs/20260531-dev-real-reindex/post-promotion-cookie/diagnostics/baseline.md`

Post-promotion live diagnostics with cookie-auth:

- Queries: `25`
- OK: `25`
- Errored: `0`

Comparable counts:

| Failure class | Expected | Post-promotion |
| --- | ---: | ---: |
| `source_chunk_ocr_layout` | 1 | 2 |
| `confidence_calibration` | 0 | 0 |
| `unsupported_gap_missing` | 0 | 0 |
| `retrieval_ranking` | 1 | 1 |
| `answer_generation_faithfulness` | 1 | 1 |
| `reference_frontmatter_leakage` | 0 | 0 |

Post-promotion flagged cases:

- `south-sudan-local-measures`: `source_chunk_ocr_layout`
- `mid-word-boundary`: `source_chunk_ocr_layout`
- `wri-flood-exposure-reference`: `retrieval_ranking`, `answer_generation_faithfulness`

The OCR count is `+1` versus the previously expected live count. The retrieval and faithfulness residuals remain on the WRI flood exposure reference case.

## Manual QA Readiness

Dev is ready for manual testing at `https://b5kkjsgsnm.us-east-2.awsapprunner.com` with the newly promoted vector active.

Recommended manual checks:

- Raffi's manual query that previously became too conservative.
- Law-domain contract/emergency-management queries.
- Sandbags flood-warning, HAZUS, preparedness, South Sudan, and WRI-reference queries.
- OCR artifact and boundary cases, especially:
  - `south-sudan-local-measures`
  - `mid-word-boundary`
  - visible artifact strings such as `,.,r,-`, `vre;terence`, `infonnation`
  - mid-sentence truncation around chunk boundaries
- Confirm the UI behaves like a client flow and does not expose the old synchronous full reindex behavior.

Do not promote another candidate or restore/rollback without explicit approval.

## Recommendation

Keep the promoted candidate active temporarily for manual QA, because the candidate passed vector safety verification and Dev now reflects a real newly generated vector state. Do not call it the new quality baseline yet: the automated live diagnostics worsened on OCR/layout from `1` to `2`.

If Raffi's manual testing confirms worse OCR or answer quality, roll back the active key to one of:

1. `restore-points/reindex-20260531-142113320-before-candidate/vectors/dev-customer-phase2-vector-index.json`
2. `restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`
3. `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json`

Prefer rollback option 1 or 2 to restore the immediately previous `224`-record active state. Use option 3 only if the intended rollback is the earlier `260`-record current-best restore state.

## Safety Confirmations

- AWS Dev only: yes
- Staging mutation/deploy: no
- Demo mutation/deploy: no
- Main merge: no
- S3 delete: no
- Active vector changed: yes, promoted candidate to `vectors/dev-customer-phase2-vector-index.json`
- Full reindex active overwrite via old synchronous UI path: no
- Candidate generated under `vectors/reindex-candidates/`: yes
- Candidate promoted only after verification passed: yes
- Unrelated document/vector mutation: no evidence reported
- Parent OpenClaw workspace dirt touched: no
