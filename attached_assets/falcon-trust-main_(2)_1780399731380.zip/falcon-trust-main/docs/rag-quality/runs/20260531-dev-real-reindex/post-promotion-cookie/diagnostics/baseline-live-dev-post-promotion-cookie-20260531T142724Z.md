# RAG Diagnostics Baseline
Generated: 2026-05-31T14:27:24.637Z
Mode: live
Environment: dev-post-promotion-cookie
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- source_chunk_ocr_layout: 2
- retrieval_ranking: 1
- answer_generation_faithfulness: 1
## Recommended Work Buckets
- #28 OCR/layout cleanup: 2
- retrieval/ranking diagnostics: 1
- answer-generation/faithfulness diagnostics: 1
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237647355-8t5rvy createdAt=2026-05-31T14:27:27.355Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.756, sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.742, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.699

### sandbags-prevent-all-damage
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237650765-hm3zvf createdAt=2026-05-31T14:27:30.765Z
- Failure classes: none
- Recommended work: none
- Citations: none

### sandbag-pickup-rules
- Status: 200 ok
- Confidence: Low
- Session: session-1780237653954-1wxtmr createdAt=2026-05-31T14:27:33.954Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fews-mobile-warning
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237657047-tvhjec createdAt=2026-05-31T14:27:37.047Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.732, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.714, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.675

### legal-public-claims-sandbags
- Status: 200 ok
- Confidence: Low
- Session: session-1780237659866-oq16h8 createdAt=2026-05-31T14:27:39.866Z
- Failure classes: none
- Recommended work: none
- Citations: none

### current-flood-warning-japan
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237662853-zq06w7 createdAt=2026-05-31T14:27:42.853Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.937, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.777, sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.746, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-12@0.715

### community-resilience-recovery
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237665861-dye87d createdAt=2026-05-31T14:27:45.861Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-1@1.048, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-5@0.981, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-9@0.929, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-8@0.816, sandbags-upload-community-resilience-and-recovery-after-major-flood-chunk-7@0.814

### hazus-flood-loss-model
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237668952-82mm5b createdAt=2026-05-31T14:27:48.952Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.9, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-9@0.815, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.761, sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-4@0.737, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.703

### life-safety-model-fatalities
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237671463-r75jkt createdAt=2026-05-31T14:27:51.463Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-8@0.84, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-7@0.785, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-2@0.749, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-4@0.68, sandbags-upload-life-safety-modeling-for-flood-emergency-management-chunk-3@0.633

### preparedness-workshop-kits
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237674349-xhhmpr createdAt=2026-05-31T14:27:54.349Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13@0.93, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-10@0.83, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-7@0.819, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-12@0.787, sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-15@0.72

### south-sudan-local-measures
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237677366-z7q0ms createdAt=2026-05-31T14:27:57.366Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-12@1.059, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-13@1.002, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-10@0.943, sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan-chunk-8@0.838

### contract-law-basics
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237680166-0s7gg0 createdAt=2026-05-31T14:28:00.166Z
- Failure classes: none
- Recommended work: none
- Citations: law-upload-legal-duties-and-emergency-management-contracts-chunk-2@0.939, law-upload-legal-duties-and-emergency-management-contracts-chunk-1@0.874, law-upload-legal-duties-and-emergency-management-contracts-chunk-4@0.779

### bridge-inspection-contractor
- Status: 200 ok
- Confidence: Low
- Session: session-1780237682774-45qj92 createdAt=2026-05-31T14:28:02.774Z
- Failure classes: none
- Recommended work: none
- Citations: none

### fema-current-policy
- Status: 200 ok
- Confidence: Low
- Session: session-1780237685753-smqf0n createdAt=2026-05-31T14:28:05.753Z
- Failure classes: none
- Recommended work: none
- Citations: none

### frontmatter-title-pages
- Status: 200 ok
- Confidence: Low
- Session: session-1780237688063-159cq7 createdAt=2026-05-31T14:28:08.063Z
- Failure classes: none
- Recommended work: none
- Citations: none

### table-of-contents-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780237691255-qb7yg3 createdAt=2026-05-31T14:28:11.255Z
- Failure classes: none
- Recommended work: none
- Citations: none

### figure-list-query
- Status: 200 ok
- Confidence: Low
- Session: session-1780237694268-0q2a8m createdAt=2026-05-31T14:28:14.268Z
- Failure classes: none
- Recommended work: none
- Citations: none

### niger-wmo-reference
- Status: 200 ok
- Confidence: Low
- Session: session-1780237696656-wiowpb createdAt=2026-05-31T14:28:16.656Z
- Failure classes: none
- Recommended work: none
- Citations: none

### wri-flood-exposure-reference
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237699550-7jyxbc createdAt=2026-05-31T14:28:19.550Z
- Failure classes: retrieval_ranking, answer_generation_faithfulness
- Recommended work: retrieval/ranking diagnostics, answer-generation/faithfulness diagnostics
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-127@0.614, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.571, sandbags-upload-flood-risk-management-global-case-studies-chunk-88@0.57, sandbags-upload-flood-risk-management-global-case-studies-chunk-43@0.555, sandbags-upload-flood-risk-management-global-case-studies-chunk-128@0.546

### technology-exclusion-joined-heading
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237701964-asqir1 createdAt=2026-05-31T14:28:21.964Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-90@0.722, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.621, sandbags-upload-flood-risk-management-global-case-studies-chunk-95@0.613

### page-header-author-artifact
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237704848-x4f1wm createdAt=2026-05-31T14:28:24.848Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.735, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.706, sandbags-upload-flood-risk-management-global-case-studies-chunk-98@0.702, sandbags-upload-flood-risk-management-global-case-studies-chunk-95@0.671

### mid-word-boundary
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237708349-98kuiq createdAt=2026-05-31T14:28:28.349Z
- Failure classes: source_chunk_ocr_layout
- Recommended work: #28 OCR/layout cleanup
- Citations: sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-1@0.781, sandbags-upload-flood-risk-management-global-case-studies-chunk-121@0.645, sandbags-upload-flood-risk-management-global-case-studies-chunk-117@0.629, sandbags-upload-flood-risk-management-global-case-studies-chunk-27@0.585, sandbags-upload-flood-risk-management-global-case-studies-chunk-8@0.585

### duplicate-overlap-evidence
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237711764-hemo4j createdAt=2026-05-31T14:28:31.764Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-85@0.808, sandbags-upload-flood-risk-management-global-case-studies-chunk-86@0.769, sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness-chunk-1@0.752, sandbags-upload-flood-risk-management-global-case-studies-chunk-101@0.729

### metadata-source-display
- Status: 200 ok
- Confidence: Medium
- Session: session-1780237714066-gix5ob createdAt=2026-05-31T14:28:34.066Z
- Failure classes: none
- Recommended work: none
- Citations: sandbags-upload-flood-risk-management-global-case-studies-chunk-11@0.766, sandbags-upload-flood-risk-management-global-case-studies-chunk-5@0.7, sandbags-upload-flood-risk-management-global-case-studies-chunk-20@0.69, sandbags-upload-flood-risk-management-global-case-studies-chunk-54@0.686, sandbags-upload-flood-risk-management-global-case-studies-chunk-52@0.654

### manufactured-housing-retrieval
- Status: 200 ok
- Confidence: Low
- Session: session-1780237717068-5xugev createdAt=2026-05-31T14:28:37.068Z
- Failure classes: none
- Recommended work: none
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.