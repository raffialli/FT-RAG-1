# RAG Diagnostics Baseline
Generated: 2026-05-31T14:25:56.667Z
Mode: live
Environment: dev-post-promotion
Endpoint: https://b5kkjsgsnm.us-east-2.awsapprunner.com
## Summary
- Golden queries: 25
- Offline fixture cases: 12
- Flagged fixture chunks: 12
- RAGAS: disabled
- RAGAS disabled reason: No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.
## Failure Class Totals
- timeout_or_endpoint_error: 25
## Recommended Work Buckets
- diagnostics/live-endpoint: 25
## Golden Query Categories
- ocr-heavy: 3
- unsupported: 3
- reference-leakage: 3
- supported: 8
- weakly-supported: 1
- frontmatter-leakage: 3
- chunk-readability: 2
- metadata: 1
- manufactured-housing: 1
## Known Artifact Queries
- mobile-warning-artifact: patterns=132 Abigail Tevera, FIGURE 11.1, lnstrums, lesSOfls chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- sandbag-pickup-rules: patterns=Niger making progress, public.wmo.int, Accessed at, WRI chunks=none
- fews-mobile-warning: patterns=Technologicalexclusion, 122 Mahala Mclindin chunks=none
- current-flood-warning-japan: patterns=table of contents, copyright, ISBN chunks=none
- community-resilience-recovery: patterns=references, bibliography chunks=none
- fema-current-policy: patterns=Accessed at, http chunks=none
- frontmatter-title-pages: patterns=ISBN, Cataloging-in-Publication, All rights reserved chunks=none
- table-of-contents-query: patterns=Table of Contents, Contents, Figure chunks=none
- figure-list-query: patterns=List of Figures, FIGURE chunks=none
- niger-wmo-reference: patterns=Niger making progress, WMO, public.wmo.int chunks=none
- wri-flood-exposure-reference: patterns=WRI, World's 15 countries chunks=none
- technology-exclusion-joined-heading: patterns=Technologyexclusion, Technologicalexclusion chunks=none
- page-header-author-artifact: patterns=132 Abigail Tevera chunks=sandbags-upload-flood-risk-management-global-case-studies-chunk-90
- mid-word-boundary: patterns=economic los, flood preparati, degree of succ chunks=none
- duplicate-overlap-evidence: patterns=Flood identification, learning feedback chunks=none
- manufactured-housing-retrieval: patterns=mobile home, HUD, factory-built, chattel chunks=none
## Live Query Results
### mobile-warning-artifact
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### sandbags-prevent-all-damage
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### sandbag-pickup-rules
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### fews-mobile-warning
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### legal-public-claims-sandbags
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### current-flood-warning-japan
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### community-resilience-recovery
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### hazus-flood-loss-model
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### life-safety-model-fatalities
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### preparedness-workshop-kits
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### south-sudan-local-measures
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### contract-law-basics
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### bridge-inspection-contractor
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### fema-current-policy
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### frontmatter-title-pages
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### table-of-contents-query
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### figure-list-query
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### niger-wmo-reference
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### wri-flood-exposure-reference
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### technology-exclusion-joined-heading
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### page-header-author-artifact
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### mid-word-boundary
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### duplicate-overlap-evidence
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### metadata-source-display
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

### manufactured-housing-retrieval
- Status: 401 error
- Confidence: n/a
- Session: n/a createdAt=n/a
- Failure classes: timeout_or_endpoint_error
- Recommended work: diagnostics/live-endpoint
- Citations: none

## Log Correlation
- App response fields currently useful for correlation: session id, createdAt, optional traces.
- Explicit request/correlation IDs are captured from headers when present.
- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.