# Dev Real Reindex Preflight

- Bucket: falcontrust-rag-dev-data-510844691338-us-east-2
- Active key: vectors/dev-customer-phase2-vector-index.json
- Active ETag: "0f727bb5ca68e33df76e583180f8b7df"
- Active size: 7930765
- Active last modified: 2026-05-31T00:21:46+00:00
- Active version/provider/model/region: 1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2
- Active records/docs/chunks: 224 / 8 / 224
- Upload objects/bytes: 8 / 884169
- Backup key: restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json
- Backup ETag/size/time: "0f727bb5ca68e33df76e583180f8b7df" / 7930765 / 2026-05-31T13:24:23+00:00
- Restore reference ETag/size/time: "d65bd8dec7b8bbfdc529382db1f7cd89-2" / 9220836 / 2026-05-30T23:43:02+00:00

## Missing Required Field Counts

{
  "documentId": 0,
  "chunkId": 0,
  "title": 0,
  "sourcePath": 0,
  "metadata": 0
}
