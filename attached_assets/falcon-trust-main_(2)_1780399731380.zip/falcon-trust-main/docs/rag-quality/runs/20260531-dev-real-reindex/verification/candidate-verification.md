# Candidate Verification

- Candidate key: vectors/reindex-candidates/reindex-20260531-142113320-dev-customer-phase2-vector-index.json
- Candidate ETag: "a18ccae4e15d45f4c8397baec71bf8c0"
- Candidate size: 7930765
- Candidate last modified: 2026-05-31T14:24:22+00:00
- Version/provider/model/region: 1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2
- Records/docs/chunks: 224 / 8 / 224
- Embedding dimension: 1024
- Missing fields: {"documentId":0,"chunkId":0,"title":0,"sourcePath":0,"metadata":0,"text":0,"embedding":0}
- Duplicate record ids: 0
- OCR flag count: 1
- Boundary risk count: 3
- Verification pass: true
