# Dev Reindex Timeout Local Diagnosis

Generated: 2026-05-31T13:12:22Z

Scope: local code inspection only. No AWS, S3, vector index, reindex, reembed, deploy, merge, Staging, Demo, or parent OpenClaw workspace mutation was performed.

## Local Re-Anchor Proof

- Host: core
- User: ralli
- Workspace: `/home/ralli/.openclaw/workspace`
- App worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- `git rev-parse --show-toplevel`: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- HEAD: `d467b4c66baeb9d4e6c0dfe311f316106d8f027a`
- Expected parked/resume HEAD: matches
- Initial `git status --short`: clean
- `git status --short --branch`: `## rag-retrieval-generation-dev-20260530...origin/main [ahead 27]`
- Resume note exists: `docs/rag-quality/runs/20260530-parked-resume-note.md`

## Late Vega Read-Only Proof

Vega returned late for bridge run `falcontrust-rag-20260531-001-reindex-readonly-anchor`, after the initial five-minute Codex wait had already closed as blocked. The late response was visible in bridge channel `1505252447239799046` as messages `1510631737968037978` and continuation `1510631739192512572`.

Late Vega proof confirms:

- Real OpenClaw/Discord Vega route worked; no internal Codex worker.
- Vega runtime: `hostname=core`, `whoami=ralli`, `pwd=/home/ralli/.openclaw/workspace`, timestamp `2026-05-31T09:05:44-04:00`.
- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`.
- Branch: `rag-retrieval-generation-dev-20260530`.
- HEAD: `d467b4c66baeb9d4e6c0dfe311f316106d8f027a`.
- Vega-reported worktree status before this local report was clean.
- AWS Dev account: `510844691338`.
- AWS region: `us-east-2`.
- Profiles visible: `falcontrust-temp-admin`, `falcontrust-deploy`.
- App Runner Dev service: `falcontrust-rag-dev-web`.
- App Runner status: `RUNNING`.
- App Runner URL: `b5kkjsgsnm.us-east-2.awsapprunner.com`.
- Live image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-1d85bc9-20260530182219`.
- ECR digest: `sha256:8d0b51817ffcaf2dae5cdf1afeee9e7509fbf61d014897d82ae18d5e24e4a291`.
- Backend shape: `FALCON_ENV=dev`, `FALCON_RETRIEVAL_BACKEND=bedrock-s3-vector`, `FALCON_STORAGE_BACKEND=s3`.
- Bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`.
- Active vector key: `vectors/dev-customer-phase2-vector-index.json`.
- Embedding model: `amazon.titan-embed-text-v2:0`.
- Restore prefix: `restore-points/20260530-current-best-before-remaining-failures/`.
- Restore prefix object count: 9.
- Current upload inventory: `uploads/` has 8 keys, total `884169` bytes.
- Vega did not use or expose secrets.
- Vega reports no deploy, reindex, S3 write/delete, vector mutation, Staging/Demo/main action, or other mutation during the read-only anchor.

Unauthenticated live endpoint probes were blocked by app auth:

- `/` and `/health` redirected to login.
- `/api/health`, `/api/rag/status`, `/api/status`, `/api/diagnostics`, `/api/debug/retrieval` returned `401 App authentication required`.
- `/api/admin/status` returned `403 Admin authentication required`.

Therefore live diagnostic/admin counts still require an approved read-only authenticated probe or approved secret reference. They were not collected in this local diagnosis.

## Active Versus Restore Vector Reconciliation

Late Vega proof shows active Dev and the restore point differ:

| Object | Key | LastModified | Size | ETag | Count |
| --- | --- | --- | ---: | --- | ---: |
| Restore vector | `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json` | `2026-05-30T23:43:02+00:00` | `9220836` | `"d65bd8dec7b8bbfdc529382db1f7cd89-2"` | `260` from local restore artifacts |
| Active vector | `vectors/dev-customer-phase2-vector-index.json` | `2026-05-31T00:21:46+00:00` | `7930765` | `"0f727bb5ca68e33df76e583180f8b7df"` | `224` from Vega read-only count |

Local restore artifacts supporting the restore vector count:

- `docs/rag-quality/runs/20260530-current-best-dev-restore-point/head-vector.json` records the pre-copy active vector head at size `9220836`, ETag `"d65bd8dec7b8bbfdc529382db1f7cd89-2"`, LastModified `2026-05-30T23:07:10+00:00`.
- `docs/rag-quality/runs/20260530-current-best-dev-restore-point/restore-head-vector.json` records the restore copy at the same size and ETag, LastModified `2026-05-30T23:43:02+00:00`.
- `docs/rag-quality/runs/20260530-current-best-dev-restore-point/vector-counts.json` records `vectorCount=260`, `hazusRecordCount=4`, `distinctDocumentCount=8`, `distinctChunkCount=260`.
- The human restore report says `Distinct documents in vector manifest: 22`, which conflicts with `vector-counts.json`. Treat the machine count artifact as stronger evidence until AWS can re-count the restore object directly.

Reconciliation:

- Active Dev is not byte-identical to the restore point.
- Active Dev is not count-identical to the restore point.
- The active vector is newer than the restore copy and has a different ETag/size/count.
- Another active vector mutation likely occurred after the restore point was copied, because the active vector LastModified is `2026-05-31T00:21:46+00:00`, after the restore object LastModified `2026-05-30T23:43:02+00:00`.
- This diagnosis does not identify which actor/action wrote the `224`-record active vector. That requires read-only CloudTrail/S3 object history if available, App Runner logs, or bridge/run ledger reconciliation.

Rollback anchor assessment:

- The restore point remains a valid rollback anchor for the explicitly captured `2026-05-30T23:43:02+00:00` state, assuming AWS re-verification confirms the same 9 objects and restore vector body can be read.
- It is not the current active Dev state.
- Restoring from it would mutate active Dev from the current `224`-record vector back to the `260`-record restore vector. That must be treated as a real Dev vector mutation and must not happen without explicit approval, current-state backup proof, and rollback-forward/rollback-back commands.
- Before any reindex, restore, or partial refresh, capture a new current-state backup of the active `224`-record vector and all 8 current `uploads/` keys.

## Reindex Code Path

UI button:

- File: `src/app/admin/page.tsx`
- `reindexEmbeddings()` starts at line 158.
- It sets `reindexing`, clears UI messages, then runs `fetch("/api/admin/embeddings", { method: "POST" })`.
- The button is rendered at lines 384-386 as `Maintenance: rebuild full index` / `Rebuilding full vector index...`.
- The UI waits for the POST response before refreshing status with `loadAdmin()`.
- There is no frontend polling, job id, progress endpoint, or retry/resume UI.

API route:

- File: `src/app/api/admin/embeddings/route.ts`
- `GET` returns `getEmbeddingStatus()`.
- `POST` awaits `reindexEmbeddings()` inline and returns only after the full reindex finishes.
- Errors are logged and returned as HTTP 500 text.

Backend reindex function:

- File: `src/lib/falcon/embeddings.ts`
- `reindexEmbeddings()` starts at line 87.
- It loads all chunks with `loadChunks()`.
- It loops every chunk serially.
- Each chunk waits 350 ms before calling Bedrock embedding.
- Each chunk calls `embedText(chunk.text)`.
- After all records are built, it writes one complete vector index JSON with `writeJson()`.
- It then calls `getEmbeddingStatus()` and returns.

Storage writes:

- File: `src/lib/falcon/storage.ts`
- `writeJson()` writes either to local disk or S3.
- In Dev, prior restore proof records `FALCON_STORAGE_BACKEND=s3`, `FALCON_STORAGE_BUCKET=falcontrust-rag-dev-data-510844691338-us-east-2`, and `FALCON_VECTOR_INDEX_KEY=vectors/dev-customer-phase2-vector-index.json`.
- Therefore Dev full reindex would overwrite the active S3 vector index key, once it reaches the final write.

Auth requirements:

- File: `src/middleware.ts`
- If `FALCON_AUTH_ENABLED=true`, `/api/admin/*` and `/api/upload` require the `falcon_admin` cookie.
- Without the admin cookie, `/api/admin/embeddings` returns 403.
- The route itself has no extra per-action confirmation, CSRF token, dry-run flag, scope parameter, or admin role split beyond the admin cookie.

Incremental paths:

- `src/app/api/upload/route.ts` persists an uploaded document and then calls `indexDocumentEmbeddings(document)` inline.
- `src/app/api/admin/documents/route.ts` deletes an uploaded document and then calls `removeDocumentEmbeddings(documentId)` inline.
- These are document-level incremental mutations, but they are still HTTP-inline.

Existing CLI/script/job path:

- `package.json` has diagnostics and test scripts, but no reindex script.
- `scripts/` contains `rag-diagnostics.mjs` and `start-stable-demo.sh`; no reindex CLI wrapper exists.
- No local job queue, lock file, status file, or background worker was found for embeddings reindex.

## Timeout Behavior

The reindex path is synchronous end-to-end:

1. The browser sends `POST /api/admin/embeddings`.
2. The Next route awaits `reindexEmbeddings()`.
3. `reindexEmbeddings()` serially embeds every chunk.
4. Only after all chunks finish does it write the full vector index and return.
5. The browser waits the whole time and displays a spinner until the request resolves or fails.

The current restore evidence records a vector count of 260. The code has a fixed 350 ms wait before each embedding call, which is at least about 91 seconds of intentional delay before Bedrock latency and any throttling backoff. `embedText()` can retry throttles up to five attempts with 1s, 2s, 3s, 4s, and 5s waits. A full corpus reindex can therefore exceed common browser, proxy, platform, or App Runner request limits.

No code-level request timeout is configured in this route. The likely timeout is external to this handler: browser/proxy/platform/App Runner behavior while the server is still inside the long-running POST. If permissions were wrong, the route would likely fail quickly as 403 or a Bedrock/S3 error, not present as a long spinner followed by timeout.

## Partial Scope, Idempotency, And Failure Semantics

Partial scope:

- The UI full rebuild has no scope input.
- `POST /api/admin/embeddings` always calls full `reindexEmbeddings()`.
- The backend does have document-level helpers, `indexDocumentEmbeddings(document)` and `removeDocumentEmbeddings(documentId)`, but there is no exposed partial reindex endpoint for selected existing Dev source objects.

Idempotency:

- Full reindex is mostly deterministic for a stable corpus and embedding model, but it updates `updatedAt`, so the resulting object changes even if vector content is equivalent.
- There is no idempotency key, compare-and-skip behavior, lock guard, or active-run marker.

Resumability:

- Not resumable. If the request dies midway, progress is lost because records are only kept in memory until the final write.

Partial artifacts on failure:

- For full reindex, failure before `writeJson()` should leave the existing vector index untouched.
- Failure during the final S3 `PutObject` has no app-level rollback, conditional write, temp-key-plus-promote flow, or post-write verification in this code.
- Upload/delete incremental paths mutate source documents before attempting index changes, so those flows can leave source/index divergence if the embedding mutation fails. That is separate from the full rebuild button.

## Likely Dev UI Timeout Root Cause

Most likely: synchronous long-running HTTP request.

Supporting evidence:

- UI calls a single POST and waits.
- API route does all work inline.
- Backend serially embeds the whole corpus.
- The known Dev vector count is 260, making the built-in 350 ms delay alone longer than many interactive request budgets once real Bedrock latency and retry backoff are included.
- There is no async queue, status endpoint, progress polling, lock, or CLI job path.

Less likely based on local code alone:

- Missing admin auth: would be a 403 from middleware, not a long-running timeout.
- Missing AWS permission/config: would likely appear as Bedrock/S3 errors in logs after starting, not as a pure UI timeout. This still requires Vega/AWS log proof.
- Frontend timeout: the frontend does not set an explicit timeout; any timeout is likely from browser/network/platform behavior.
- Backend process crash: possible under App Runner or unhandled platform limits, but not proven from local code. Requires CloudWatch/App Runner proof.

## Recommendation

Best path: B with C, and optionally A for operator use. Because the active vector and restore vector now differ, add a mandatory preflight reconciliation gate before any reindex or restore.

Implement an async Dev-only reindex job path instead of increasing request timeouts:

- `POST /api/admin/embeddings/jobs` should validate admin auth, acquire a lock, create a job id/status record, and return quickly with `202`.
- The job should run outside the request/response lifecycle or be handled by a separate server-side command in a controlled operator session.
- `GET /api/admin/embeddings/jobs/:id` or a current-status endpoint should return state, startedAt, updatedAt, counts, current document/chunk, error, and final index proof.
- UI should queue the job, then poll status.
- Writes should use a temp vector key plus verification and a final promote/copy step, or another rollback-aware pattern, not a direct overwrite as the only durable step.
- Add a lock guard so two full reindexes cannot run concurrently.
- Add a dry-run/plan mode that reports chunk count, target index key, affected documents, current manifest ETag/size/timestamp, and expected scope before mutation.

If a near-term operational reindex is needed before UI work, prefer a server-side CLI/operator command over the current button, but only after Vega/AWS proof confirms:

- Dev-only account/region/profile.
- Restore point exists and is complete.
- Current active vector manifest ETag/size/timestamp/count captured.
- Current active vector is backed up to a new restore/rollback-forward prefix before mutation.
- Difference between active `224`-record vector and restore `260`-record vector is understood well enough to choose the rollback target.
- Exact affected scope is known.
- Rollback command is written and reviewed.
- The command uses a safer temp-key/verify/promote flow or otherwise records enough proof to roll back.

Do not use the current UI full rebuild button for Dev reindex validation. It is full-corpus, synchronous, unscoped, not resumable, and can time out while giving the operator weak proof about whether backend work finished.

## Code Changes

No runtime code changes were made in this local-only diagnosis.

Reason: the root cause is clear enough to avoid the button, but the safe fix needs a small design decision: job/status API versus CLI/operator command, where job state should live in App Runner, and how to perform temp-key/verify/promote against Dev S3. Implementing a half job without AWS proof would create false safety.

## Tests

No tests were run. This was report-only local inspection with no runtime code changes.

If code is changed next, run:

- `npm run test:rag`
- `npm run test:rag-diagnostics`
- reindex/job-specific tests added with the fix

## What Still Requires Vega/AWS Proof

Real Vega/AWS route is now proven for read-only anchoring. Do not perform any of the following until a fresh mutation-specific approval/proof gate is satisfied:

- Authenticated live diagnostic/admin counts.
- App Runner/CloudWatch log inspection around Raffi's failed UI click.
- Direct restore vector body count from S3, if needed to resolve the local `distinctDocumentCount` inconsistency.
- CloudTrail/S3/App Runner evidence explaining why active vector is now 224 records while the restore vector is 260.
- New current-state backup proof for the active `224`-record vector and 8 upload JSON keys.
- Rollback command proof for both directions: active-current backup and restore-point rollback.
- Any live `/api/admin/embeddings` or reindex-job invocation.
- Any S3 source/vector/index write.
- Any deploy.

## Exact Next Step Once Vega Is Available

Ask real Vega to run a read-only AWS Dev proof packet:

1. Confirm AWS identity, account, principal, and region.
2. Confirm App Runner service `falcontrust-rag-dev-web`, endpoint, status, image tag, and digest.
3. Confirm bucket `falcontrust-rag-dev-data-510844691338-us-east-2`.
4. Confirm restore prefix `restore-points/20260530-current-best-before-remaining-failures/`.
5. Capture current active vector index head for `vectors/dev-customer-phase2-vector-index.json`: ETag, size, LastModified, record count, HAZUS record count if practical.
6. Capture direct restore vector record count from the restore object, or document why local `vector-counts.json` is the best available proof.
7. Determine whether the active vector mutation after the restore point was intentional and which lane/action produced it.
8. Inspect App Runner/CloudWatch logs around Raffi's failed UI click, if timestamp is available.
9. Do not run reindex. Use the log proof to confirm whether the POST starts, how long it runs, and whether it is killed by request/platform timeout or fails with permissions/config.

## Final Local Conclusion

Outcome B: reindex timeout root cause identified, no runtime code change.

The Dev UI reindex button is a synchronous full-corpus HTTP POST. It is not a safe proof path for Dev reindex because it can time out without durable progress/status semantics, and because success would overwrite the active vector index in one final S3 write. The safe path is an async job/status flow or a controlled CLI/operator reindex with lock, dry-run proof, temp artifact, verification, and rollback gates.

Confirmations: no AWS mutation; no S3/vector/index mutation; no reindex/reembed; no deploy; no merge; no Staging/Demo; no parent OpenClaw workspace touch.
