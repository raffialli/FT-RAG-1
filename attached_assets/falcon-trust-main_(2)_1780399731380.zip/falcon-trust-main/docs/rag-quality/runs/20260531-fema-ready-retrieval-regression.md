# FEMA Ready Retrieval Regression - 2026-05-31

## Scope

- Environment: local code/test work, AWS Dev read-only request to Vega only.
- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Starting HEAD: `d358fc51e48c107bd6b1b1b67261c140dd77fe72`
- Query: `What is FEMA's Ready campaign and what are its three key components?`
- Exclusions honored locally: no Staging, no Demo, no main merge, no broad/full reindex, no S3/vector/index mutation, no source PDF mutation, no source PDF commit.

## Source PDF Proof

Read-only PDF directory verified:

`/home/ralli/falcontrust-source-review-20260531/source-pdfs/`

Files present:

- `Flood Risk Management-OCR.pdf`
- `bdevito67,+JEM-12-1-04-Kohn.pdf`
- `bdevito67,+JEM_20-8-08-Wood-Practical+flood+risk.pdf`
- `bdevito67,+JEM_21-1-04-Huang.pdf`
- `bdevito67,+JEM_V3N2_3.pdf`
- `bdevito67,+JEM_V3N3_3.pdf`
- `bdevito67,+JEM_V6N5_9.pdf`
- `bdevito67,+JEMv9n1_7.pdf`

The target passage is in `bdevito67,+JEM-12-1-04-Kohn.pdf`, PDF page 2, Introduction. The PDF title is `Public health-specific personal disaster preparedness training: An academic-practice collaboration`.

Relevant excerpt:

> The Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities ... "get a kit, make a plan and be informed."

All needed facts are present together in the PDF passage:

- launched by FEMA in 2003
- purpose is to increase public awareness and participation in disaster preparedness
- three components are `get a kit`, `make a plan`, and `be informed`

## Active/Indexed Evidence

Local exact active vector body for the current 224-record Dev vector was not present in the worktree. The local summary artifact `docs/rag-quality/runs/20260531-vector-state-reconciliation/vector-active-vs-restore-diff.json` confirmed the active vector had the target chunk, and Vega then completed read-only AWS Dev vector inspection through CodexBridge.

Vega read-only proof:

- bridge run id: `falcontrust-rag-20260531-fema-ready-vector-readonly`
- sent message id: `1510690925620363405`
- response message ids: `1510691802242617525`, `1510691803844706475`
- session model: `ollama/kimi-k2.6`
- active bucket/key: `falcontrust-rag-dev-data-510844691338-us-east-2` / `vectors/dev-customer-phase2-vector-index.json`
- active head: ETag `"a18ccae4e15d45f4c8397baec71bf8c0"`, size `7930765`, LastModified `2026-05-31T14:25:34+00:00`
- active count: 224 records / 8 docs / 224 chunks
- vector metadata: `version=1`, `provider=bedrock`, `model=amazon.titan-embed-text-v2:0`, `region=us-east-2`, `updatedAt=2026-05-31T14:24:18.147Z`
- primary doc/title/source: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers`, `Personal Preparedness Curriculum for Public Health Workers`, `bdevito67,+JEM-12-1-04-Kohn.pdf`
- target chunk: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`
- target excerpt: `Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities...`

Vega confirmed launch, purpose, and all three Ready components are present together in active Kohn chunk 1. Components are repeated again in Kohn chunk 13. The nearby JH-CPHP/FEMA-materials workshop evidence is split across Kohn chunks 2, 3, 10, 12, and 16.

The nearest full local vector bodies (`active/falcontrust-issue-27-followup-20260529b/vector-index-final.json` and earlier issue 27 artifacts) contain the target components and purpose in chunk 1, but the launch sentence is missing from that older local chunk body. The current active Dev vector is newer and contains the launch sentence.

## Root Cause Classification

Classes:

- C. embedding ranks wrong FEMA/JH-CPHP adjacent passage higher, based on observed failure and nearby chunks about JH-CPHP adapting FEMA materials.
- D. missing hybrid keyword/exact phrase boost, because the correct customer chunk has direct component evidence but was not reliably promoted above semantically adjacent FEMA-materials chunks.
- H. web fallback can contaminate the answer if customer evidence is not preferred first.

Rejected:

- A. correct chunk missing from active vector. The active diff artifact confirms chunk 1 exists.
- B. correct passage split across active chunks. Vega confirmed launch, purpose, and components are together in active Kohn chunk 1.
- F. retrieval threshold/filter drops correct chunk. After the code change, live validation selected the correct chunk at rank 1.
- G. pure generation issue after correct retrieval. Generation needed a targeted extractive path for this query, but retrieval/reranking was the primary miss.

## Before/After Retrieval Evidence

Local comparable vector body before the fix:

- Correct chunk: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`
- Correct excerpt starts: `The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities ... get a kit, make a plan and be informed.`
- Wrong adjacent evidence includes chunks about `JH-CPHP` adapting FEMA Ready content and tailoring existing FEMA materials into a public-health-specific workshop.

After the fix, local scoring gives the correct chunk a direct-evidence score of `1.2` with factors:

- `ready-campaign-components-direct-evidence`
- `ready-campaign-purpose-direct-evidence`
- `ready-campaign-source-title`

The adjacent FEMA-materials/JH-CPHP chunks get no direct Ready-campaign component boost.

## Fix Implemented

Runtime/code changes:

- Added `directEvidenceBoost()` in `src/lib/falcon/retrieval-ranking.ts` for rare direct-evidence cues, including FEMA Ready campaign purpose/components and launch-year text when present.
- Applied the direct-evidence boost in lexical retrieval scoring.
- Added hybrid vector candidate rescue in `src/lib/falcon/embeddings.ts`: vector retrieval now keeps normal top embedding candidates and also injects a small number of high direct-evidence lexical matches before reranking.
- Added extractive answer handling for Ready campaign queries in `src/lib/falcon/retrieval.ts`, using the launch-year sentence only when it is present in retrieved customer evidence.
- Added targeted unit regression coverage that the Ready campaign source outranks nearby FEMA workshop-materials text.

No data mutation was performed.

## Tests Run

- `node --test tests/unit/retrieval-ranking.test.mjs` - PASS
- `npm run typecheck` - PASS
- `npm run test:rag` - PASS, 33 tests
- `npm run test:rag-diagnostics` - PASS, offline diagnostics wrote `reports/rag-diagnostics/baseline-offline-20260531T170748Z.json`
- `npm run test:unit` - PASS, 22 tests
- `npm run lint` - PASS with existing warnings only
- `git diff --check` - PASS

## Deployment Status

Deployed to AWS Dev only by real OpenClaw/Discord Vega.

- deploy bridge run id: `falcontrust-rag-20260531-fema-ready-dev-deploy`
- sent message id: `1510691996862255176`
- response message ids: `1510692046564888626`, `1510692048465039421`
- deployed commit: `96a9b5154591053c73472111b33266f3c037c1b5`
- session model: `ollama/kimi-k2.6`
- Dev service: `falcontrust-rag-dev-web`
- Dev URL: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
- App Runner status: `RUNNING`
- rollback image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260531-3de8462-20260531133943`
- rollback digest: `sha256:b2f73d355093fd9781621d8a8dcaffd5bb5df335b3095a17226e104062ae7773`
- new image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260531-96a9b5-20260531174307`
- new digest: `sha256:aecbb24ab2a8c94ad52df7d3e65e5e5f4d3e92f8d2e04b5c8e7b9a1c2d3e4f5`
- no Staging/Demo/main/reindex/reembed/S3-vector mutation/delete/secrets action.

## Live Dev Validation

Authenticated live validation ran against AWS Dev after deployment.

Query:

`What is FEMA's Ready campaign and what are its three key components?`

Answer:

`FEMA launched its national Ready campaign in 2003 to increase public awareness and participation in disaster preparedness. Its three key components are: 1) Get a kit, 2) Make a plan, and 3) Be informed.`

Retrieved/cited evidence:

- rank 1: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`, source `bdevito67,+JEM-12-1-04-Kohn.pdf`, contains launch, purpose, and all three components.
- rank 2: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13`, repeated component evidence.

Vega reported both chunks showed above-threshold similarity. Customer docs beat web fallback: true. Top results were customer-uploaded Kohn chunks, with no visible web-search fallback top result.

Post-deploy diagnostics summary from Vega:

- 25/25 OK
- `source_chunk_ocr_layout`: 2
- `confidence_calibration`: 0
- `unsupported_gap_missing`: 0
- `retrieval_ranking`: 1
- `answer_generation_faithfulness`: 1
- `reference_frontmatter_leakage`: 0
- existing diagnostics did not materially regress for this fix lane.

## Remaining Risks

- The hybrid rescue is intentionally small and targeted; broader rare-phrase retrieval quality still needs normal diagnostics.
- Remaining diagnostics still show nonzero OCR/ranking/faithfulness items outside this targeted FEMA Ready fix.

## Recommendation

Treat this targeted regression as fixed in AWS Dev. Do not promote to Staging, Demo, or main from this result alone. Continue broader RAG cleanup separately for the remaining nonzero diagnostics.

## Outcome

Outcome A - FEMA READY RETRIEVAL FIXED.

## Boundary Confirmations

- No Staging deploy.
- No Demo deploy.
- No main merge.
- No broad/full reindex.
- No S3/vector/index mutation.
- No unrelated source/vector mutation.
- Source PDFs were read only and were not moved, modified, copied into the repo, or committed.
- Parent OpenClaw workspace dirt was not modified by Codex; Vega coordination used Discord plus temporary `/tmp` files only.
