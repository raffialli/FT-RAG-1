# FalconTrust RAG Review Handoff

Generated: 2026-05-31

## Branch

- Repository: `git@github.com:raffialli/falcon-trust.git`
- Branch: `rag-retrieval-generation-dev-20260530`
- Review evidence HEAD before this handoff commit: `6cb75e23594d41cb21c26a3e974bcf6c8dd41330`
- Published branch HEAD: see the GitHub branch/PR closeout; this handoff file is the final local commit before push.
- Base target for review: `main`
- Merge state: not merged to `main`

## Code Change Summary

Major runtime and operator changes in this branch:

- Improved RAG retrieval/runtime behavior in `src/lib/falcon/retrieval.ts`, including stricter citation/runtime filtering and diagnostics-oriented handling for known weak retrieval cases.
- Expanded RAG diagnostic tooling in `scripts/rag-diagnostics.mjs` and related tests/fixtures.
- Added runtime citation policy coverage in `tests/rag/runtime-citation-policy.test.mjs`.
- Replaced the dangerous synchronous full-reindex admin POST behavior with a safer operator job path:
  - `src/app/api/admin/embeddings/route.ts` now rejects synchronous full reindex with a 409.
  - `src/app/api/admin/embeddings/jobs/route.ts` adds dry-run/candidate job start and status.
  - `src/lib/falcon/reindex-jobs.ts` adds process-local lock/status, default dry-run mode, explicit candidate confirmation, candidate key writes, backup proof, and no automatic active promotion.
  - `src/lib/falcon/embeddings.ts` and `src/lib/falcon/storage.ts` add helpers needed to build, read, copy, and verify vector indexes by key.
  - `src/app/admin/page.tsx` changes the admin maintenance flow to safe dry-run/status behavior.
- Added reindex safety tests in `tests/rag/reindex-job-safety.test.mjs`.

## Evidence Artifacts

Primary handoff reports:

- `docs/rag-quality/runs/20260531-dev-reindex-timeout-local-diagnosis.md`
- `docs/rag-quality/runs/20260531-vector-state-reconciliation.md`
- `docs/rag-quality/runs/20260531-safe-reindex-dev-deploy.md`
- `docs/rag-quality/runs/20260531-safe-reindex-dev-manual-qa.md`
- `docs/rag-quality/runs/20260531-dev-real-reindex.md`

Important evidence directories:

- `docs/rag-quality/runs/20260531-vector-state-reconciliation/`
- `docs/rag-quality/runs/20260531-dev-real-reindex/`
- `docs/rag-quality/runs/20260530-current-best-dev-restore-point/`
- `docs/rag-quality/runs/20260530-remaining-failures-pass/`

## AWS Dev State

- Dev URL: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
- Dev App Runner service: `falcontrust-rag-dev-web`
- Safe reindex Dev image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260531-3de8462-20260531133943`
- Safe reindex Dev digest: `sha256:b2f73d355093fd9781621d8a8dcaffd5bb5df335b3095a17226e104062ae7773`
- Dev backend: `bedrock-s3-vector`
- Active vector key: `vectors/dev-customer-phase2-vector-index.json`
- Active vector after real reindex promotion:
  - ETag: `"a18ccae4e15d45f4c8397baec71bf8c0"`
  - Size: `7930765`
  - LastModified: `2026-05-31T14:25:34+00:00`
  - Records/docs/chunks: `224 / 8 / 224`
  - Model/provider/region: `amazon.titan-embed-text-v2:0 / bedrock / us-east-2`

## Restore And Rollback Anchors

- Immediate pre-candidate backup:
  - `restore-points/reindex-20260531-142113320-before-candidate/vectors/dev-customer-phase2-vector-index.json`
- Pre-reindex-path-work active backup:
  - `restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`
  - ETag: `"0f727bb5ca68e33df76e583180f8b7df"`
  - Records/docs/chunks: `224 / 8 / 224`
- Current-best restore point:
  - `restore-points/20260530-current-best-before-remaining-failures/`
  - Restore vector: `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json`
  - Restore vector ETag: `"d65bd8dec7b8bbfdc529382db1f7cd89-2"`
  - Restore vector records/docs/chunks: `260 / 8 / 260`

## Safe Reindex Path Status

- Deployed to AWS Dev only.
- Old synchronous full reindex POST is disabled.
- `/api/admin/embeddings/jobs` supports dry-run and candidate modes.
- Default job behavior is dry-run.
- Candidate mode requires explicit confirmation: `confirm=write-temp-vector`.
- Candidate output writes under `vectors/reindex-candidates/`.
- Candidate job verifies the vector and does not promote active automatically.
- A real candidate job was run and promoted manually after verification:
  - Job ID: `reindex-20260531-142113320`
  - Candidate key: `vectors/reindex-candidates/reindex-20260531-142113320-dev-customer-phase2-vector-index.json`
  - Candidate ETag: `"a18ccae4e15d45f4c8397baec71bf8c0"`
  - Candidate counts: `224 / 8 / 224`

## Current Diagnostics

Post-promotion live diagnostics:

- Queries: `25`
- OK: `25`
- Errored: `0`

Comparable failure counts:

| Failure class | Count |
| --- | ---: |
| `source_chunk_ocr_layout` | 2 |
| `confidence_calibration` | 0 |
| `unsupported_gap_missing` | 0 |
| `retrieval_ranking` | 1 |
| `answer_generation_faithfulness` | 1 |
| `reference_frontmatter_leakage` | 0 |

Known flagged post-promotion cases:

- `south-sudan-local-measures`: `source_chunk_ocr_layout`
- `mid-word-boundary`: `source_chunk_ocr_layout`
- `wri-flood-exposure-reference`: `retrieval_ranking`, `answer_generation_faithfulness`

Important context: OCR/layout count worsened from expected `1` to `2` after the real candidate reindex promotion. Treat Dev as ready for manual QA, not as a proven quality baseline.

## Manual QA Focus

Reviewers should test:

- Raffi's conservative-answer regression query.
- Law + Sandbags domain queries.
- South Sudan local measures.
- WRI flood exposure reference.
- Visible OCR artifacts, including `,.,r,-`, `vre;terence`, `infonnation`.
- Mid-sentence truncation and boundary readability.
- Whether answers are helpful to humans, not only diagnostics-clean.
- Whether the admin reindex UI presents the safe dry-run/status behavior and no longer exposes the old synchronous full reindex path.

## Known Remaining Issues

- The promoted Dev vector remains `224` records, not the earlier `260`-record current-best restore vector.
- OCR/layout diagnostics are mixed after the real reindex: `source_chunk_ocr_layout` is `2`.
- WRI flood exposure still has retrieval ranking and answer faithfulness concerns.
- Candidate promotion is still an operator action and must not be automated without an explicit promotion/rollback policy.
- `npm run typecheck` and `npm run lint` were previously blocked locally because `tsc` and `eslint` binaries were missing from `node_modules`; no package install was performed in that lane.

## Recommendation

Review this branch as a candidate baseline before merging to `main`. Use AWS Dev for manual/client-style QA first, especially for helpfulness and conservative-answer behavior.

Do not merge to `main`, deploy Staging, deploy Demo, promote another vector, restore a vector, or run another reindex until review and manual QA explicitly approve the next step.

## Explicit Safety State

- No Staging deploy yet.
- No Demo deploy yet.
- No merge to `main` yet.
- No current request performed AWS/S3/vector/index mutation.
- No current request ran reindex/reembed.
- Parent OpenClaw workspace dirt was not touched.
