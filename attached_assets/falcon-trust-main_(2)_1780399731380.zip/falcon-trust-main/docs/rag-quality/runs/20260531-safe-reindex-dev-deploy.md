# FalconTrust Safe Reindex Path Dev Deploy

Generated: 2026-05-31T13:50:00Z

## Scope

Deployed the committed safe reindex path to AWS Dev so Raffi can perform manual client-style testing.

Codex acted as orchestrator/verifier/report writer. Vega performed AWS Dev deployment through the real OpenClaw/Discord route in bridge run `falcontrust-rag-20260531-003-safe-reindex-dev-deploy`.

No Staging deploy, Demo deploy, main merge, full reindex, reembed, active vector overwrite, candidate vector promotion, unrelated document/vector mutation, S3 delete, secret print, or parent OpenClaw workspace cleanup/touch occurred.

## Repo Re-Anchor

- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Deployed commit: `3de8462b952a228f6d113844b7ee9221024fbd6c`
- Starting status: clean
- Safe reindex report exists: `docs/rag-quality/runs/20260531-vector-state-reconciliation.md`

## Pre-Deploy Test Proof

Vega reported:

- `npm run test:rag -- --test-name-pattern='reindex|embeddings POST'` passed, 33/33.

Prior local lane proof:

- `npm run test:rag` passed, 33/33.
- `npm run test:rag-diagnostics` passed.
- `npm run typecheck` and `npm run lint` were blocked locally because `tsc` and `eslint` binaries were not present in `node_modules`.

## Rollback Image

Captured before deploy:

- Image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260530-1d85bc9-20260530182219`
- Digest: `sha256:8d0b51817ffcaf2dae5cdf1afeee9e7509fbf61d014897d82ae18d5e24e4a291`

## New Dev Image

Pushed and deployed:

- Image: `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260531-3de8462-20260531133943`
- Digest: `sha256:b2f73d355093fd9781621d8a8dcaffd5bb5df335b3095a17226e104062ae7773`
- Pushed: `2026-05-31T09:40:06.675000-04:00`

## App Runner Dev Proof

Vega reported:

- Service: `falcontrust-rag-dev-web`
- URL: `b5kkjsgsnm.us-east-2.awsapprunner.com`
- Status: `RUNNING`
- `FALCON_ENV=dev`
- Deployed image is now the `20260531-3de8462` tag.

Codex unauthenticated verification:

- `/` returned `307` redirect to `/login?next=%2F`.
- `/api/admin/embeddings` returned `403` with `Admin authentication required`.
- `/api/admin/embeddings/jobs` returned `403` with `Admin authentication required`.

## Safe Reindex Validation

Vega authenticated admin proof:

- `/api/admin/embeddings` now returns `409` with `Synchronous full reindex is disabled. Use /api/admin/embeddings/jobs for dry-run or candidate reindex jobs.`
- `POST /api/admin/embeddings/jobs` accepted dry-run job `reindex-20260531-134503669`.
- Dry-run final state: `completed`.
- Dry-run mode: `dry-run`.
- Active key: `vectors/dev-customer-phase2-vector-index.json`.
- Dry-run counts: `224 / 8 / 224` for chunks/docs/chunks.
- Dry-run notes included:
  - `Dry-run computes scope only and writes no S3/vector objects.`
  - `Dry-run completed without embedding calls or writes.`

S3 no-overwrite proof:

- Active vector remained unchanged:
  - size `7930765`
  - ETag `"0f727bb5ca68e33df76e583180f8b7df"`
  - LastModified `2026-05-31T00:21:46+00:00`
- Current active vector backup remained intact:
  - `restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`
  - size `7930765`
  - ETag `"0f727bb5ca68e33df76e583180f8b7df"`
- Current-best restore vector remained intact:
  - `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json`
  - size `9220836`
  - ETag `"d65bd8dec7b8bbfdc529382db1f7cd89-2"`
- Candidate prefix check: `vectors/reindex-candidates/` KeyCount `0`.

No candidate job was run. No vector promotion occurred.

## Manual QA Note

Manual QA note:

- `docs/rag-quality/runs/20260531-safe-reindex-dev-manual-qa.md`

Summary for Raffi:

- Use https://b5kkjsgsnm.us-east-2.awsapprunner.com.
- Log in normally.
- The admin S3 vector store maintenance button is now `Maintenance: check reindex scope`.
- It should run only a dry-run scope check.
- Do not run candidate mode, promote candidate vectors, restore vectors, or overwrite `vectors/dev-customer-phase2-vector-index.json` without explicit approval.

## Recommendation

Dev is ready for manual client-style testing of the safe reindex behavior and the regression query.

Do not run candidate reindex or restore the 260-record baseline yet. First use the UI to verify the manual regression concern and collect exact query/domains/answer/citations. Candidate vectors and restore operations remain approval-gated.

## Final Confirmation

- No Staging deploy.
- No Demo deploy.
- No main merge.
- No active vector overwrite.
- No full reindex.
- No reembed.
- No vector promotion.
- No unrelated document/vector mutation.
- No S3 delete.
- No secrets printed.
- Parent OpenClaw workspace dirt was not touched.
