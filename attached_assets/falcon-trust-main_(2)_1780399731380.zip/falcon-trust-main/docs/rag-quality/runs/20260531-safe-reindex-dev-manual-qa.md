# FalconTrust Dev Manual QA - Safe Reindex Path

Dev URL: https://b5kkjsgsnm.us-east-2.awsapprunner.com

Deployed image:

- `510844691338.dkr.ecr.us-east-2.amazonaws.com/falcontrust-rag-app:rag-retrieval-generation-dev-20260531-3de8462-20260531133943`
- Digest: `sha256:b2f73d355093fd9781621d8a8dcaffd5bb5df335b3095a17226e104062ae7773`

## Safe To Click

- Log in normally.
- Open the admin page.
- In the S3 vector store card, click `Maintenance: check reindex scope`.
- Expected behavior: it starts a dry-run scope check, not a full reindex. It should report a completed job and show the chunk scope.

## Do Not Click Or Run

- Do not run candidate reindex mode unless explicitly approved.
- Do not promote any candidate vector to active.
- Do not restore vectors from any restore point without explicit approval.
- Do not run any script that overwrites `vectors/dev-customer-phase2-vector-index.json`.

## Manual Regression Query

Use the Dev UI as a normal client would. Capture:

- exact query text
- selected domains
- answer
- confidence
- citations shown
- any visible source/chunk titles

If the concern is that Dev is too conservative, compare whether the answer withholds evidence despite apparently relevant source chunks.

## Reindex UI Test

The safe reindex UI should only perform dry-run scope checking.

Expected:

- No active vector overwrite.
- No full reindex.
- No candidate promotion.
- No S3 delete.
- Active vector remains:
  - ETag `"0f727bb5ca68e33df76e583180f8b7df"`
  - size `7930765`

Candidate vectors under `vectors/reindex-candidates/` must not be promoted without explicit approval.
