# FalconTrust Dev Vector State Reconciliation And Safe Reindex Path

Generated: 2026-05-31T13:26:46Z

## Scope

This lane combined Dev vector-state reconciliation with a local safe reindex-path implementation.

Allowed AWS mutation performed: one Dev S3 copy of the current active vector to a new restore-point backup key.

No reindex, reembed, active vector overwrite, source document mutation, delete, deploy, Staging action, Demo action, main merge, secret print, or parent OpenClaw workspace cleanup/touch occurred.

## Local Re-Anchor

- Worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- Starting HEAD: `593057496ad5af8d9c5861d85e5e50ef18b3d2c9`
- Starting status: clean
- Existing diagnosis report: `docs/rag-quality/runs/20260531-dev-reindex-timeout-local-diagnosis.md`

## Vega / AWS Dev Proof

Vega completed bridge run `falcontrust-rag-20260531-002-vector-reconcile-backup-diff` through the real OpenClaw/Discord route.

- Vega identity proof: `hostname=core`, `whoami=ralli`, `pwd=/home/ralli/.openclaw/workspace`
- AWS profile: `falcontrust-temp-admin`
- AWS account: `510844691338`
- Region: `us-east-2`
- Bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`
- Active vector key: `vectors/dev-customer-phase2-vector-index.json`
- Restore vector key: `restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json`

## Current Active Backup

Backup key created:

`restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json`

Backup proof:

- Active ETag: `"0f727bb5ca68e33df76e583180f8b7df"`
- Backup ETag: `"0f727bb5ca68e33df76e583180f8b7df"`
- Active size: `7930765`
- Backup size: `7930765`
- Active LastModified: `2026-05-31T00:21:46+00:00`
- Backup LastModified: `2026-05-31T13:24:23+00:00`
- Verification: size and ETag match active

Manifest:

- `docs/rag-quality/runs/20260531-vector-state-reconciliation/active-vector-backup-manifest.json`

## Active Vs Restore Diff

Artifacts:

- `docs/rag-quality/runs/20260531-vector-state-reconciliation/vector-active-vs-restore-diff.json`
- `docs/rag-quality/runs/20260531-vector-state-reconciliation/vector-active-vs-restore-diff.md`

Summary:

| State | Records | Docs | Chunks | Size | ETag | updatedAt |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| Active | 224 | 8 | 224 | 7930765 | `"0f727bb5ca68e33df76e583180f8b7df"` | `2026-05-31T00:21:43.139Z` |
| Restore | 260 | 8 | 260 | 9220836 | `"d65bd8dec7b8bbfdc529382db1f7cd89-2"` | `2026-05-30T22:33:38.046Z` |

Diff:

- Common records: 221
- Active-only records: 3
- Restore-only records: 39
- Active-only docs: 0
- Restore-only docs: 0
- Active-only chunks: 3
- Restore-only chunks: 39
- Common records with text checksum changes: 176
- Common records with metadata checksum changes: 221
- Common records with shape field changes: 0

Per-document count changes:

| Document | Active | Restore |
| --- | ---: | ---: |
| Legal Duties and Emergency Management Contracts | 4 | 3 |
| Community Resilience and Recovery After Major Flood | 12 | 12 |
| Current Flood Warning System in Japan and Evacuation Effectiveness | 12 | 13 |
| Flood Risk Management Global Case Studies | 152 | 182 |
| Hazard Mitigation Planning Using HAZUS-MH Flood Model | 6 | 4 |
| Life Safety Modeling for Flood Emergency Management | 9 | 10 |
| Personal Preparedness Curriculum for Public Health Workers | 16 | 19 |
| Practical Flood Risk Reduction Strategies in South Sudan | 13 | 17 |

## Discrepancy Explanation

Evidence supports that the active vector was rewritten after the 20260530 restore point:

- Restore copy LastModified: `2026-05-30T23:43:02+00:00`
- Active vector LastModified: `2026-05-31T00:21:46+00:00`
- Active vector `updatedAt`: `2026-05-31T00:21:43.139Z`
- Active size, ETag, record count, and text checksums differ from restore.

The active 224-record vector is structurally valid JSON and has the same provider/model/region/version as restore, but it is not equivalent to the documented current-best restore point. It removed more records than it added, and the largest loss is in `sandbags-upload-flood-risk-management-global-case-studies` with 30 restore-only records.

No committed lane report was found that explains a deliberate move from 260 records to 224 records. The timestamp is consistent with a later unreported active vector rewrite, possibly the reported timing-out UI reindex completing after the browser/client timed out. That remains an inference, not proof.

## Baseline Decision

Treat the 20260530 restore vector as the safer documented baseline for future quality comparison and rollback planning.

Treat the current 224-record active vector as backed up but not validated as the safe baseline. Do not build further data mutations on the 224-record active vector until either:

- live authenticated diagnostics prove it is better and intentional, or
- CloudWatch/CloudTrail/bridge evidence identifies the writer and confirms it was expected.

Do not restore the 260-record vector automatically. Restoring would be an active Dev vector mutation and still needs explicit approval plus before/after live diagnostics.

## Reindex Timeout Root Cause

The prior diagnosis remains correct:

- UI button called `POST /api/admin/embeddings`.
- That route awaited a full `reindexEmbeddings()` inline.
- `reindexEmbeddings()` serially embedded every chunk with fixed delay, Bedrock latency, and retry backoff.
- The active vector was overwritten only after all records were built.
- There was no job queue, lock, status endpoint, resumability, temp key, verify step, or scoped reindex API.

## Safe Reindex Path Implemented

Code changes:

- `src/app/api/admin/embeddings/route.ts`
  - Disables synchronous full reindex POST.
  - Returns 409 with current status and points operators to the job route.
- `src/app/api/admin/embeddings/jobs/route.ts`
  - Adds a reindex job API with `GET` status/list and `POST` start.
- `src/lib/falcon/reindex-jobs.ts`
  - Adds process-local lock/status.
  - Defaults to `dry-run`.
  - Requires `confirm=write-temp-vector` for candidate mode.
  - Candidate mode backs up active vector, writes candidate vector to `vectors/reindex-candidates/`, verifies record count, and does not promote or overwrite active.
- `src/lib/falcon/embeddings.ts`
  - Splits full vector build from active write.
  - Adds helpers to write/read a vector index by key.
- `src/lib/falcon/storage.ts`
  - Adds read/copy helpers.
- `src/app/admin/page.tsx`
  - Changes the admin maintenance action from full rebuild to safe scope dry-run.
  - Polls job status instead of waiting on a long full reindex request.
- `tests/rag/reindex-job-safety.test.mjs`
  - Verifies the synchronous inline reindex call is removed.
  - Verifies dry-run default, candidate confirmation, lock, candidate key, and no active promotion markers.

Current implementation deliberately does not promote a candidate vector to active. Promotion remains an explicit future operator gate after baseline selection, backup proof, candidate verification, and live diagnostics plan are approved.

## Tests

Passed:

- `npm run test:rag`
  - 33 tests passed, including the new reindex safety tests.
- `npm run test:rag-diagnostics`
  - diagnostics command passed
  - 4 diagnostics scaffold tests passed

Blocked by missing local binaries in `node_modules`:

- `npm run typecheck`
  - failed before checking code: `tsc: not found`
- `npm run lint`
  - failed before linting code: `eslint: not found`

No package install was performed.

## Next Step

Recommended next Dev sequence:

1. Do not click the old full reindex UI. The code now removes that path, but it is not deployed.
2. Decide whether to restore the documented 260-record baseline or first run authenticated live diagnostics against the current 224-record active vector.
3. If keeping 224 is considered, require authenticated live diagnostics and writer evidence.
4. If returning to 260 is preferred, use the 20260530 restore vector, but only after explicit restore approval and before/after proof.
5. Deploy the safe reindex-path code to Dev only after the baseline decision, then use dry-run first.
6. Candidate reindex may be tested only after backup/baseline proof, and it should write only to `vectors/reindex-candidates/` until separately promoted.

## Final Confirmation

- S3 mutation occurred: one Dev-only copy of active vector to the 20260531 backup prefix.
- No active vector overwrite occurred.
- No source document mutation occurred.
- No reindex/reembed ran.
- No deploy occurred.
- No Staging mutation occurred.
- No Demo mutation occurred.
- No main merge occurred.
- No unrelated document/vector mutation occurred.
- No permanent delete occurred.
- No secrets were printed.
- Parent OpenClaw workspace dirt was not touched.
