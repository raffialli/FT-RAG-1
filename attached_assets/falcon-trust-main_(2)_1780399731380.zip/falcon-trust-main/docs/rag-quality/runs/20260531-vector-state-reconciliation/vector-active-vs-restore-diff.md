# Vector State Reconciliation - 2026-05-31

## Scope

- Environment: Dev only
- Bucket: 'falcontrust-rag-dev-data-510844691338-us-east-2'
- Mutation: copied active vector to a new backup key only
- Exclusions: no deploy, reindex, reembed, delete, staging/demo/main, or secret reads

## Backup Proof

- Active key: 'vectors/dev-customer-phase2-vector-index.json'
- Backup key: 'restore-points/20260531-active-vector-before-reindex-path-work/vectors/dev-customer-phase2-vector-index.json'
- Active ETag: '"0f727bb5ca68e33df76e583180f8b7df"'
- Backup ETag: '"0f727bb5ca68e33df76e583180f8b7df"'
- Active size: '7930765'
- Backup size: '7930765'
- Backup last modified: '2026-05-31T13:24:23+00:00'
- Size matches active: 'true'
- ETag matches active: 'true'

## Vector Summaries

### Active

- Key: 'vectors/dev-customer-phase2-vector-index.json'
- ETag: '"0f727bb5ca68e33df76e583180f8b7df"'
- Size: '7930765'
- Last modified: '2026-05-31T00:21:46+00:00'
- Version/provider/model/region: '1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2'
- Updated at: '2026-05-31T00:21:43.139Z'
- Records/docs/chunks: '224 / 8 / 224'

### Restore

- Key: 'restore-points/20260530-current-best-before-remaining-failures/vectors/dev-customer-phase2-vector-index.json'
- ETag: '"d65bd8dec7b8bbfdc529382db1f7cd89-2"'
- Size: '9220836'
- Last modified: '2026-05-30T23:43:02+00:00'
- Version/provider/model/region: '1 / bedrock / amazon.titan-embed-text-v2:0 / us-east-2'
- Updated at: '2026-05-30T22:33:38.046Z'
- Records/docs/chunks: '260 / 8 / 260'

## Diff Summary

- Common records: '221'
- Active-only records/docs/chunks: '3 / 0 / 3'
- Restore-only records/docs/chunks: '39 / 0 / 39'
- Common records with text checksum changes: '176'
- Common records with metadata checksum changes: '221'
- Common records with shape field changes: '0'

## Per-Doc Counts

| Document ID | Active records | Restore records | Active text checksum | Restore text checksum |
|---|---:|---:|---|---|
| 'law-upload-legal-duties-and-emergency-management-contracts' | 4 | 3 | '4d95241f8344c88c949aab36793d841d61736b429e006a12b735852470481fb4' | '6b4a68814be19f959b70ef1cc75f1c86a8ec0099284026887827b297563b6ea6' |
| 'sandbags-upload-community-resilience-and-recovery-after-major-flood' | 12 | 12 | '944b11da7ef3ea9a560fbd0e586084c8441dac1f10e5fa931951e468ce61b39a' | 'bf18232b3b493703d932903bfd65ead6b95a73f6c524519671bf69f11bab90cd' |
| 'sandbags-upload-current-flood-warning-system-in-japan-and-evacuation-effectiveness' | 12 | 13 | 'ad536bfc5cda813e4384dfaf4ac9caba17bca78cde5cd825e92df82f56080685' | '71ea2ddd371cb923fb9d06a8870d038e130129519d719118c0ea134b66f8b6ec' |
| 'sandbags-upload-flood-risk-management-global-case-studies' | 152 | 182 | '9bc9d8bfe64f13043630eeea27a382899238c67338249b8cc6d7bdfb7fd18b18' | '4b7a12332ddbb49f86ccf3220817b453a25449b58dd755eababfdccd596a31e2' |
| 'sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model' | 6 | 4 | 'b4920e8965a20ed585211e695e7739c7a751080e13079bb3386bb8ee6dd1a5ba' | 'eae2b4f92ab2cd6484cad118d003a7379357604e0a4b43735be51d650f430e17' |
| 'sandbags-upload-life-safety-modeling-for-flood-emergency-management' | 9 | 10 | '15811cbbf55d9ff0e36ce8d8346cb13c623b586f131bd540a8e88fdfe5770ef2' | 'e9c33bb98c07c564b8439a9a051cc6e6e8584d56e01f02c5c3e6cacb8f07dd37' |
| 'sandbags-upload-personal-preparedness-curriculum-for-public-health-workers' | 16 | 19 | '787a39f2002f331204b5c47d966df6d65196f700d0fd995e13ce8671b4accc55' | 'c646ded3ce9ca638adafca32b4054cdf067cee78ee7c15133412c04da1dc0419' |
| 'sandbags-upload-practical-flood-risk-reduction-strategies-in-south-sudan' | 13 | 17 | '8cc4055908e07371b5e06164e63919138a85a6465181a296f91305a766c5ae05' | 'fc56b8aa226b39756bbd35df2ea4706d6a6ca702e1cb36266367a481c9dc2288' |

## Metadata Diff Summary

- Active-only records: '3'
- Restore-only records: '39'
- Common records with metadata checksum changes: '221'
- Common records with text checksum changes: '176'
- Common records with shape field changes: '0'

## Baseline Recommendation

Prefer the 20260530 restore vector as the reconciliation baseline: it has records/chunks not present in active. Keep the 20260531 active backup immutable before any path-work/reindex attempt.
