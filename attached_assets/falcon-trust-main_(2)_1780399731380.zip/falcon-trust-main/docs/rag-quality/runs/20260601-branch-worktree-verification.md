# FalconTrust Branch/Worktree Verification

Generated: 2026-06-01

Scope: Git/worktree verification only. No merge, push, rebase, deploy, reindex, reembed, AWS/S3/vector/index mutation, or main branch mutation was performed.

## Main Repo / Worktree State

The current shell workspace root is the OpenClaw/Syndicate workspace repository, not the FalconTrust repository:

- path: `/home/ralli/.openclaw/workspace`
- remote: `origin git@github.com:raffialli/syndicate-workspace.git`
- branch: `skills/checkpoint-visibility-gated-workflow-20260526`
- HEAD: `a091ec1086d52f6827fe1935f8393f924cbb1f19`
- status: dirty before this task; parent workspace dirt was not edited
- upstream status: not evaluated for FalconTrust work; this is not the FalconTrust app repo
- dirty files: many pre-existing workspace files and untracked directories, including `ACTIVE_STATE.md`, `active/*`, `memory/*`, `projects/*`, `.worktrees/`, and FalconTrust active artifacts
- ahead/behind: not relevant to FalconTrust RAG branch state

The FalconTrust repo appears as multiple Git worktrees under:

`/home/ralli/.openclaw/workspace/.worktrees/`

Best candidate for the FalconTrust main/local repo worktree:

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-repo-merge`
- remote: `origin git@github.com:raffialli/falcon-trust.git`
- branch: `issue-29-hybrid-retrieval-reranking`
- HEAD: `cae1f9df218957f9fb909e86c45401af5a139ca2`
- status: dirty; upstream branch gone after prune
- upstream status: `origin/issue-29-hybrid-retrieval-reranking [gone]`
- ahead/behind: cannot compare to deleted upstream branch
- dirty files:
  - `A  docs/testing/rag-hybrid-rerank-policy.md`
  - `A  docs/testing/rag-metadata-policy.md`
  - `M  package.json`
  - `D  reports/rag-diagnostics/.gitignore`
  - `D  reports/rag-diagnostics/README.md`
  - `D  scripts/rag-diagnostics.mjs`
  - `M  src/lib/falcon/corpus.ts`
  - `M  src/lib/falcon/document-viewer.ts`
  - `M  src/lib/falcon/embeddings.ts`
  - `A  src/lib/falcon/hybrid-rerank.ts`
  - `M  src/lib/falcon/retrieval-backends.ts`
  - `D  src/lib/falcon/retrieval-ranking.ts`
  - `M  src/lib/falcon/types.ts`
  - `D  tests/rag/diagnostics-scaffold.test.mjs`
  - `D  tests/rag/fixtures/rag-diagnostics-queries.json`
  - `M  tests/rag/fixtures/rag-eval-cases.json`
  - `M  tests/rag/regression-harness.mjs`
  - `M  tests/rag/regression-harness.test.mjs`
  - `M  tests/unit/chunking-policy.test.mjs`
  - `A  tests/unit/hybrid-rerank.test.mjs`
  - `D  tests/unit/retrieval-ranking.test.mjs`

Main branch status within FalconTrust:

- local `main`: `7c34f1b27333dabcff62db02dc7f823fc6bf04e9`
- `origin/main`: `16db861d49153399cc24c03fcd69895431e4fea4`
- ahead/behind local main vs origin/main: `0 1`, so local `main` is behind origin by one commit and has no checked-out working-tree dirt in any main worktree.
- `main` is not checked out in the active RAG worktree.

## FalconTrust Worktrees

### falcon-trust-repo-merge

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-repo-merge`
- branch: `issue-29-hybrid-retrieval-reranking`
- HEAD: `cae1f9df218957f9fb909e86c45401af5a139ca2`
- status: dirty; upstream branch gone
- upstream status: `origin/issue-29-hybrid-retrieval-reranking [gone]`
- dirty files: hybrid-rerank policy/docs/code/test changes listed in the main repo/worktree section above

### falcon-trust-issue-25-confidence-scoring

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-25-confidence-scoring`
- branch: `issue-25-confidence-scoring`
- HEAD: `9a8b8179d445a3825c91e28aaddfde3df552da4e`
- status: clean
- upstream status: no upstream shown by `git status --short --branch`
- dirty files: none

### falcon-trust-issue-26-index-reference-filtering

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-26-index-reference-filtering`
- branch: `issue-26-index-reference-filtering`
- HEAD: `ddd1e568d08d7e4f1049bf2c2791fad32115c7ca`
- status: dirty; upstream branch gone
- upstream status: `origin/issue-26-index-reference-filtering [gone]`
- dirty files:
  - `?? playwright-report/`
  - `?? test-results/`

### falcon-trust-issue-27-semantic-chunking

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-27-semantic-chunking`
- branch: `issue-29-hybrid-retrieval-reranking`
- HEAD: `cae1f9df218957f9fb909e86c45401af5a139ca2`
- status: dirty; upstream branch gone
- upstream status: `origin/issue-29-hybrid-retrieval-reranking [gone]`
- dirty files:
  - `?? playwright-report/`
  - `?? reports/rag-diagnostics-final-offline/`
  - `?? reports/rag-diagnostics-live-dev-final/`
  - `?? reports/rag-diagnostics-live-dev-issue28-final-auth/`
  - `?? reports/rag-diagnostics-live-dev-issue28-final/`
  - `?? reports/rag-diagnostics-live-dev-issue29-final/`
  - `?? reports/rag-diagnostics-live-dev-issue41-final/`
  - `?? reports/rag-diagnostics-live-dev-nocookie/`
  - `?? reports/rag-diagnostics-live-staging-final/`
  - `?? reports/rag-diagnostics-live-staging-issue28-final/`
  - `?? reports/rag-diagnostics-live-staging-issue41-final/`
  - `?? reports/rag-diagnostics-parent-live-env/`
  - `?? reports/rag-diagnostics-test-contaminated-parent/`
  - `?? reports/rag-diagnostics-test-live/`
  - `?? reports/rag-diagnostics-test/`
  - `?? test-results/`

### falcon-trust-issue25-staging

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue25-staging`
- branch: detached HEAD
- HEAD: `9a8b8179d445a3825c91e28aaddfde3df552da4e`
- status: dirty
- upstream status: detached, no upstream
- dirty files:
  - `?? test-results/`

### falcon-trust-rag-retrieval-generation-dev-20260530

- path: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- branch: `rag-retrieval-generation-dev-20260530`
- HEAD: `2c43c7e0879e7de44ee5bc7decc61f8ae811f67b`
- status before writing this report: clean, ahead of origin by 3
- status after writing this report: dirty only because this report file is newly created
- upstream status: `origin/rag-retrieval-generation-dev-20260530`
- dirty files before this report: none
- dirty files after this report:
  - `?? docs/rag-quality/runs/20260601-branch-worktree-verification.md`

## RAG Branch State

Branch: `rag-retrieval-generation-dev-20260530`

- local HEAD: `2c43c7e0879e7de44ee5bc7decc61f8ae811f67b`
- origin HEAD: `d358fc51e48c107bd6b1b1b67261c140dd77fe72`
- ahead/behind versus origin RAG branch: `0 3`, meaning origin has 0 commits not pulled and local has 3 commits not pushed
- commits ahead of `origin/main`: 35
- commits not pushed:
  - `2c43c7e Record current chunk index verification`
  - `3832da9 Record FEMA Ready Dev validation proof`
  - `96a9b51 Fix FEMA Ready campaign retrieval boost`
- commits on origin not pulled: none; `git log --oneline --decorate HEAD..origin/rag-retrieval-generation-dev-20260530` produced no output
- uncommitted files before this report: none
- uncommitted files after this report: `docs/rag-quality/runs/20260601-branch-worktree-verification.md`
- `20260601-current-chunk-index-verification.md` committed?: yes, committed in `2c43c7e Record current chunk index verification`

Recent RAG branch log:

```text
2c43c7e (HEAD -> rag-retrieval-generation-dev-20260530) Record current chunk index verification
3832da9 Record FEMA Ready Dev validation proof
96a9b51 Fix FEMA Ready campaign retrieval boost
d358fc5 (origin/rag-retrieval-generation-dev-20260530) Add FalconTrust RAG review handoff
6cb75e2 Document Dev real reindex validation
c6fb431 Document safe reindex Dev deploy
3de8462 Add safe Dev vector reindex job path
5930574 Document Dev reindex timeout diagnosis
d467b4c Park FalconTrust RAG lane for resume
9f32906 Correct Dev restore point source list
```

`origin/main...HEAD` diff summary:

- `236 files changed`
- `248600 insertions(+)`
- `47 deletions(-)`
- includes RAG docs, diagnostics artifacts, retrieval/reindex code, and tests
- includes committed proof report: `docs/rag-quality/runs/20260601-current-chunk-index-verification.md`

## Conclusion

- Is current Codex/Vega work on the RAG branch? Yes. The current RAG work is on `rag-retrieval-generation-dev-20260530`.
- Is there evidence of a separate Codex-created branch? No FalconTrust branch named Codex was found. The only Codex-named branch found was in the parent Syndicate workspace, not FalconTrust: `codex/mission-control-isolated-20260526`.
- Is there evidence of a separate Vega-created branch? No FalconTrust branch named Vega was found.
- Is main untouched? Yes for working-tree purposes. No FalconTrust `main` worktree is checked out or dirty. Local FalconTrust `main` is behind `origin/main` by 1 commit, but no main merge/rebase/checkout mutation was performed.
- Is the RAG branch ready for review? Mostly yes from worktree hygiene before this report: it was clean and had no uncommitted files. It is now dirty only because this report file was created by request.
- Exact cleanup required before review/merge:
  1. Decide whether to commit this branch/worktree verification report.
  2. Push `rag-retrieval-generation-dev-20260530` so the 3 local commits become visible on GitHub/PR.
  3. Reconcile the deployment/runtime relationship separately if live Dev is expected to run the latest local RAG HEAD; prior evidence showed Dev image clue `3de8462`, while RAG local HEAD is `2c43c7e`.
  4. Do not merge to main until PR review/CI expectations are satisfied.

## Commands / Proof

Report file search:

```bash
rg -n "FalconTrust Branch/Worktree Verification|Record current chunk index verification|proof report committed" /home/ralli/.openclaw/workspace -g '*.md' -g '*.txt' -g '*.json'
find /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530/docs /home/ralli/.openclaw/workspace/docs /home/ralli/.openclaw/workspace/active -type f \( -name '*.md' -o -name '*.txt' -o -name '*.json' \) -mtime -1 -print
```

Workspace root checks:

```bash
pwd
git status --short --branch
git branch --show-current
git rev-parse HEAD
git worktree list
```

Key output:

```text
/home/ralli/.openclaw/workspace
## skills/checkpoint-visibility-gated-workflow-20260526
skills/checkpoint-visibility-gated-workflow-20260526
a091ec1086d52f6827fe1935f8393f924cbb1f19
/home/ralli/.openclaw/workspace                                a091ec10 [skills/checkpoint-visibility-gated-workflow-20260526]
/home/ralli/.openclaw/live/mission-control                     621ce061 [live/mission-control]
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-merge  5088aaf7 [mission-control/sco-long-regression-repair-20260524]
/home/ralli/.openclaw/worktrees/mission-control                621ce061 [codex/mission-control-isolated-20260526]
```

FalconTrust worktree discovery:

```bash
git worktree list
git branch -a | rg -i "codex|vega|rag-retrieval-generation-dev-20260530|main|issue"
```

Key output:

```text
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-repo-merge                             cae1f9d [issue-29-hybrid-retrieval-reranking]
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-25-confidence-scoring            9a8b817 [issue-25-confidence-scoring]
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-26-index-reference-filtering     ddd1e56 [issue-26-index-reference-filtering]
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-27-semantic-chunking             cae1f9d [issue-29-hybrid-retrieval-reranking]
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue25-staging                        9a8b817 (detached HEAD)
/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530  2c43c7e [rag-retrieval-generation-dev-20260530]
```

Per-worktree checks:

```bash
for p in /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-repo-merge /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-25-confidence-scoring /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-26-index-reference-filtering /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue-27-semantic-chunking /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-issue25-staging /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530; do
  echo "### $p"
  (cd "$p" && git status --short --branch && git branch --show-current && git rev-parse HEAD)
done
```

RAG branch checks:

```bash
git fetch --all --prune
git status --short --branch
git branch --show-current
git rev-parse HEAD
git rev-parse origin/rag-retrieval-generation-dev-20260530
git rev-list --left-right --count origin/rag-retrieval-generation-dev-20260530...HEAD
git rev-list --left-right --count origin/main...HEAD
git log --oneline --decorate HEAD..origin/rag-retrieval-generation-dev-20260530
git log --oneline --decorate origin/rag-retrieval-generation-dev-20260530..HEAD
git diff --stat origin/main...HEAD
git diff --name-status origin/main...HEAD
```

Key output:

```text
## rag-retrieval-generation-dev-20260530...origin/rag-retrieval-generation-dev-20260530 [ahead 3]
rag-retrieval-generation-dev-20260530
2c43c7e0879e7de44ee5bc7decc61f8ae811f67b
d358fc51e48c107bd6b1b1b67261c140dd77fe72
0 3
0 35
2c43c7e (HEAD -> rag-retrieval-generation-dev-20260530) Record current chunk index verification
3832da9 Record FEMA Ready Dev validation proof
96a9b51 Fix FEMA Ready campaign retrieval boost
```

## Safety Confirmation

- no merge to main
- no Staging deploy
- no Demo deploy
- no AWS/S3/vector/index mutation
- no reindex/reembed
- parent OpenClaw workspace dirt was not touched
