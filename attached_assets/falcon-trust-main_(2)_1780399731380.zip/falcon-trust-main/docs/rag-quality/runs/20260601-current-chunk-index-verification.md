# Current Chunk/Index Verification - 2026-06-01

Scope: narrow verification only. No upload behavior fix, chunking redesign, UI work, answer-generation work, deploy, reindex, S3/vector mutation, Staging/Demo touch, or main merge was performed.

## Final Classification

PASS

The active Dev index is confirmed, the current FEMA Ready source chunks are present in that active index, the Ready campaign passage is present with embeddings, and retrieval-only top-k includes the correct Ready campaign chunk at rank 1.

Runtime-code caveat: Vega reported the running App Runner image tag as `rag-retrieval-generation-dev-20260531-3de8462-20260531133943`, resolving to local commit `3de8462b952a228f6d113844b7ee9221024fbd6c`, while this local worktree HEAD is `3832da9c73cc7b348957d1e920abc2e04cdb6f9e`. Vega's retrieval-only proof used the local worktree retrieval library with the active Dev runtime env and active S3 vector key, not a live `/api/query` call. For this lane's indexing question, the active-index proof is direct and sufficient; do not treat this report as proof that the deployed image contains later local retrieval/generation code.

## Local Anchor

- Codex cwd: `/home/ralli/.openclaw/workspace`
- FalconTrust worktree: `/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`
- Branch: `rag-retrieval-generation-dev-20260530`
- HEAD: `3832da9c73cc7b348957d1e920abc2e04cdb6f9e`
- `git status --branch --short`: `## rag-retrieval-generation-dev-20260530...origin/rag-retrieval-generation-dev-20260530 [ahead 2]`
- Running Dev service: `falcontrust-rag-dev-web`
- Running Dev URL: `https://b5kkjsgsnm.us-east-2.awsapprunner.com`
- App Runner status: `RUNNING`

Vega also reported origin branch HEAD as `d358fc51e48c107bd6b1b1b67261c140dd77fe72` and the current App Runner image clue `3de8462`.

## Active Environment

Non-secret runtime env confirmed by Vega:

- `FALCON_ENV=dev`
- `FALCON_RETRIEVAL_BACKEND=bedrock-s3-vector`
- `FALCON_STORAGE_BACKEND=s3`
- `FALCON_STORAGE_BUCKET=falcontrust-rag-dev-data-510844691338-us-east-2`
- `FALCON_VECTOR_INDEX_KEY=vectors/dev-customer-phase2-vector-index.json`
- `FALCON_VECTOR_INDEX_PATH` not set
- `FALCON_VECTOR_DOCUMENT_ALLOWLIST` not set
- `FALCON_EMBEDDINGS_ENABLED=true`
- `FALCON_EMBEDDING_REGION=us-east-2`
- `FALCON_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0`
- `AWS_REGION=us-east-2`

## Read/Write Target

Files inspected locally:

- `src/lib/falcon/embeddings.ts`
- `src/lib/falcon/retrieval-backends.ts`
- `src/lib/falcon/reindex-jobs.ts`
- `src/app/api/query/route.ts`
- `src/app/api/corpus/route.ts`
- `src/app/api/admin/embeddings/route.ts`
- `src/app/api/admin/embeddings/jobs/route.ts`
- `src/lib/falcon/storage.ts`

Code-path findings:

- Retrieval reads through `getRetrievalBackend("bedrock-s3-vector")` -> `retrieveVector()` -> `readVectorIndex()` -> `listJson(vectorIndexConfig.key, ...)`.
- Full active writes use `reindexEmbeddings()` -> `writeJson(vectorIndexConfig.key, ...)`.
- Incremental document embedding mutation uses `indexDocumentEmbeddings()` / `removeDocumentEmbeddings()` -> `writeVectorIndex()` -> `writeJson(vectorIndexConfig.key, ...)`.
- Candidate reindex jobs write to `vectors/reindex-candidates/...` and do not promote to active.

With the confirmed Dev runtime env, active retrieval reads:

`s3://falcontrust-rag-dev-data-510844691338-us-east-2/vectors/dev-customer-phase2-vector-index.json`

The normal active write target is the same bucket/key. Candidate jobs are separate until explicitly promoted.

## Active Index Inspection

Direct S3 object inspected by Vega:

- Bucket: `falcontrust-rag-dev-data-510844691338-us-east-2`
- Key: `vectors/dev-customer-phase2-vector-index.json`
- LastModified: `2026-05-31T14:25:34+00:00`
- ETag: `"a18ccae4e15d45f4c8397baec71bf8c0"`
- Size: `7930765`
- Index `updatedAt`: `2026-05-31T14:24:18.147Z`
- Records: `224`
- Distinct documents: `8`
- Namespace: `vectors/dev-customer-phase2-vector-index.json`

Indexed source filenames include:

- `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- `uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json`
- six other active sandbags corpus JSON uploads

## FEMA Ready Search Result

Required active-index searches:

- `bdevito67,+JEM-12-1-04-Kohn.pdf`: matched the personal-preparedness document records; the key Ready evidence is chunk `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`.
- `Ready campaign`: matched chunk `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`.
- `FEMA launched its national Ready campaign`: no exact literal match because indexed text says `The Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003.`
- `get a kit`: matched chunks `...-chunk-1` and `...-chunk-13`.
- `make a plan`: matched chunks `...-chunk-1` and `...-chunk-13`.
- `be informed`: matched chunk `...-chunk-1` plus related records.

Key active chunk:

- Source filename/path: `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`
- Original PDF source matched by metadata/search: `bdevito67,+JEM-12-1-04-Kohn.pdf`
- Chunk ID: `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`
- Page/location metadata: not present/null
- Embedding: present, length `1024`
- Excerpt: `The Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities about different types of emergencies and their appropriate responses: "get a kit, make a plan and be informed."`

All required facts are present together in chunk 1: launch year, purpose, and the three components.

## Retrieval-Only Result

Target query:

`What is FEMA's Ready campaign and what are its three key components?`

Vega ran retrieval-only with `bedrock-s3-vector`, the active Dev bucket/key, and no answer generation.

- Inventory: `8` documents, `224` chunks, namespace `vectors/dev-customer-phase2-vector-index.json`
- Rank 1: source `uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json`, score `1.699`, chunk ID `sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1`, excerpt contains the Ready campaign sentence and all three components.
- Ranks 2-5: same document, related preparedness chunks.
- Ranks 6-10: lower-scored related flood/preparedness records.

## App/Auth Checks

- `GET https://b5kkjsgsnm.us-east-2.awsapprunner.com/api/corpus` without auth returned `401 Unauthorized` with `{"documents":[]}`.
- Public S3 access to `https://falcontrust-rag-dev-data-510844691338-us-east-2.s3.us-east-2.amazonaws.com/vectors/dev-customer-phase2-vector-index.json` returned `403 Forbidden`.

These unauthenticated failures are expected and were not used as proof of index contents.

## Commands Run

Local commands:

```bash
pwd
git -C /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530 status --branch --short
git -C /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530 rev-parse HEAD
git -C /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530 branch --show-current
git -C /home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530 log -1 --oneline --decorate
rg -n "FALCON_VECTOR_INDEX_KEY|FALCON_RETRIEVAL_BACKEND|reindexEmbeddings|indexDocumentEmbeddings|readVectorIndex|writeVectorIndex|getVectorIndexConfig|bedrock-s3-vector" src scripts tests docs/rag-quality/runs
nl -ba src/lib/falcon/embeddings.ts | sed -n '1,260p'
nl -ba src/lib/falcon/embeddings.ts | sed -n '260,460p'
nl -ba src/lib/falcon/retrieval-backends.ts | sed -n '1,260p'
nl -ba src/lib/falcon/reindex-jobs.ts | sed -n '1,240p'
nl -ba src/app/api/admin/embeddings/jobs/route.ts | sed -n '1,220p'
sed -n '1,260p' src/app/api/admin/embeddings/route.ts
sed -n '1,260p' src/app/api/query/route.ts
sed -n '1,260p' src/lib/falcon/storage.ts
find src/app/api -maxdepth 4 -type f | sort
curl -sS -D /tmp/falcontrust-dev-corpus.headers https://b5kkjsgsnm.us-east-2.awsapprunner.com/api/corpus -o /tmp/falcontrust-dev-corpus.json
curl -sS -I https://falcontrust-rag-dev-data-510844691338-us-east-2.s3.us-east-2.amazonaws.com/vectors/dev-customer-phase2-vector-index.json
```

Vega commands reported:

```bash
aws apprunner describe-service --profile falcontrust-temp-admin --region us-east-2 --service-arn arn:aws:apprunner:us-east-2:510844691338:service/falcontrust-rag-dev-web/6a23c349f3dd43a0bfa92c2ca20956a3
aws s3api head-object --profile falcontrust-temp-admin --region us-east-2 --bucket falcontrust-rag-dev-data-510844691338-us-east-2 --key vectors/dev-customer-phase2-vector-index.json
aws s3 cp --profile falcontrust-temp-admin --region us-east-2 s3://falcontrust-rag-dev-data-510844691338-us-east-2/vectors/dev-customer-phase2-vector-index.json -
```

Vega also reported a retrieval-only local library call from:

`/home/ralli/.openclaw/workspace/.worktrees/falcon-trust-rag-retrieval-generation-dev-20260530`

with `FALCON_RETRIEVAL_BACKEND=bedrock-s3-vector`, `FALCON_STORAGE_BACKEND=s3`, the active bucket/key, and AWS profile `falcontrust-temp-admin`.

Vega bridge messages:

- CodexBridge sent: `1510962754142343240` at `2026-06-01T11:06:32.918000+00:00`
- CodexBridge sent: `1510963429098258432` at `2026-06-01T11:09:13.840000+00:00`
- Vega response chunks: `1510963932842430495`, `1510963934419746826`, `1510963935476711517`, `1510963936927940729`, `1510964067261485056`, `1510964068209659954`, `1510964068893069414`, `1510964070596083802`

## Next Recommended Fix

No index/data fix is indicated by this lane. The current active index contains the Ready campaign passage and retrieval-only finds it at rank 1.

Recommended next action is to reconcile the runtime deployment drift separately: Vega reported the running App Runner image as commit clue `3de8462`, while the local branch contains later commits. That is outside this narrow index-verification lane, but it matters for live answer behavior and should be verified before making claims about deployed retrieval/generation code.

## Guardrail Confirmation

- No Staging deploy.
- No Demo deploy.
- No main merge.
- No broad/full reindex.
- No unrelated vector/index mutation.
- No S3 object deletion.
- No source PDFs moved, modified, or committed.
- No parent OpenClaw workspace dirt was edited.
