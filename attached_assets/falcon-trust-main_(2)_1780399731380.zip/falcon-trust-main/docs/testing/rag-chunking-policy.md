# RAG Chunking Policy

The local chunker uses semantic boundaries before hard-size limits:

- Start new sections at Markdown headings (\`#\` through \`####\`) when the prior section has enough body text.
- Start new sections at explicit page markers such as \`Page 2\`, \`[Page 2]\`, or \`--- page 2\`.
- Split long sections at heading, page-marker, paragraph, then sentence boundaries before falling back to the hard limit.
- Keep chunks near \`3600\` characters with up to \`360\` characters of overlap for long sections.
- Preserve deterministic chunk IDs as \`<document-id>-chunk-<n>\` within the current chunking pass.

Migration note: changing these rules changes chunk boundaries and may change chunk IDs after the changed point. Live Bedrock/S3/vector indexes must be rebuilt and validated under an explicit deploy/reindex approval gate before claiming live retrieval proof.
