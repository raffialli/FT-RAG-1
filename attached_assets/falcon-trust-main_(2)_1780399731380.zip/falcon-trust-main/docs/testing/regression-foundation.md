# Regression Foundation

This branch adds the minimum CI and regression shell needed before issue-by-issue FalconTrust remediation starts.

## Local Commands

~~~bash
npm ci
npx playwright install chromium
npm run test:ci
npm run build
~~~

`npm run test:ci` runs lint, TypeScript, production build, unit tests, RAG regression tests, and the offline Playwright browser smoke tests.

`npm run test:e2e:ci` is also safe to run by itself from a clean checkout after `npm ci`; it builds the production app before starting the local Playwright webServer.

## CI Coverage

GitHub Actions runs on pull requests and pushes to `main` with Node 20:

- `npm ci`
- `npx playwright install --with-deps chromium`
- `npm run test:ci`

The base path is offline. It does not require AWS, Bedrock, S3, database, API, or customer-document credentials.

## Test Groups

- `npm run test:unit` checks local package/script wiring.
- `npm run test:rag` checks pure RAG regression contracts using deterministic fixtures.
- `npm run test:e2e` runs Playwright against the built Next app and verifies the app shell, main search/RAG page, offline query submission UI, and citation/source/caution rendering.
- `npm run test:e2e:ci` builds the production app, then runs the same Playwright smoke pass with a concise CI reporter.

Playwright uses only Chromium in default CI, mocks the query response for submit-path UI coverage, and exercises the offline `/api/query` debug response mode. It does not call AWS, Bedrock, S3, Tavily, or live customer services.

Failure artifacts are uploaded by GitHub Actions from:

- `playwright-report/`
- `test-results/`

## Optional Live Tests

Live AWS/cloud checks are intentionally not part of base CI. They are manual/opt-in and require an explicit deployed target plus site password.

Run deployed AWS Playwright smoke against Dev or Staging with:

~~~bash
PLAYWRIGHT_BASE_URL="https://<dev-or-staging-app-runner-url>" \
FALCONTRUST_SITE_PASSWORD="<redacted-site-password>" \
npm run test:e2e:aws
~~~

`E2E_BASE_URL` is also accepted as an alias for `PLAYWRIGHT_BASE_URL`. When either deployed base URL variable is set, Playwright does not start the local `webServer`; it targets the provided URL instead. Do not commit, print, or paste the site password.

The deployed smoke covers:

- password/login gate unlocks the site;
- home/RAG shell and main navigation;
- Add-ons and FalconChat placeholder pages;
- sample prompt rendering and query text population;
- live custom query submission;
- citation/source and caution sections;
- normal `/api/query` omits `debugTrace`;
- `debug: true` and `includeDebug: true` include safe debug trace data;
- obvious browser console/page errors on the smoke path.

Expected GitHub Actions secrets for a future manual workflow:

- `PLAYWRIGHT_BASE_URL` or `E2E_BASE_URL`
- `FALCONTRUST_SITE_PASSWORD`
- any AWS credentials only if the workflow also needs AWS metadata, rollback, or deployment actions

## Adding Issue Regressions

Each future GitHub issue should add or update a focused regression before changing behavior:

1. Put pure retrieval/answer-quality fixtures under `tests/rag/fixtures/`.
2. Keep fixtures small, synthetic, and non-customer-specific unless a sanitized artifact is explicitly approved.
3. Separate document-supported claims from general guidance in expected template output.
4. Add live/AWS coverage only when the issue cannot be proven offline, and keep it manual/opt-in.

The initial issue #21 fixture set lives at `tests/rag/fixtures/rag-eval-cases.json` and covers:

- answerable body-evidence;
- unanswerable/no-support;
- index/reference false positives;
- citation-count confidence traps;
- template-vs-evidence separation;
- OCR/layout-noise examples.

Later remediation issues (#22-#29, #15, #16) should extend this fixture file or add adjacent focused fixtures before changing behavior. Default CI must remain offline-safe and must not require AWS, Bedrock, S3, Tavily, customer documents, or live vector indexes.

## Debug Trace Mode

Issue #22 adds an explicit query debug response mode for local/dev review:

~~~json
{
  "query": "What should residents know about sandbag pickup rules?",
  "domains": ["sandbags"],
  "debug": true
}
~~~

When `debug` or `includeDebug` is true, `/api/query` includes `debugTrace` with:

- retrieval backend and selected domains;
- candidate and final chunk counts;
- candidate chunks with chunk/document ids, score, content type, source path where available, safe text preview, and metadata;
- final chunks used for answer context;
- selection/filter/answerability decisions.

Debug trace output is off by default. It is intended for local/dev/admin regression review and should stay offline-safe: no secrets, API keys, live credentials, or raw private customer artifacts in default CI.

Issue #23 adds an explicit answerability threshold to the RAG response path. A normal answer requires at least one body-like citation above the minimum score threshold with direct query/evidence overlap; index/reference-only matches and weak coincidental matches are treated as insufficient support. When debug mode is enabled, the trace includes the answerability reason and threshold notes so reviewers can see why the response answered normally or returned a gap.
