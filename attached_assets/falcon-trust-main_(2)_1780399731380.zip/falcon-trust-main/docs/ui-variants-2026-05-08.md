# Falcon Trust UI Variants — 2026-05-08

## Purpose

Alternate limited-demo skins for customer presentation. These variants preserve the same app behavior/APIs and are intentionally **not** Phase 1 feature buildout.

## Live variant ports

| Port | Variant | Source path | Style | Status |
| --- | --- | --- | --- | --- |
| `3035` | Original preserved demo | parent app | dark cyan research workspace | Ready-demo anchor; do not disturb. |
| `3036` | Continuation/patched lane | parent app copy | same as original plus safe fixes | Testing lane, not primary demo anchor. |
| `3037` | Civic | `variants/civic` | public-service command center; light blue/white/navy | Live and smoke-tested. |
| `3038` | Modern | `variants/modern` | AI SaaS/glassmorphism; black/violet/electric blue | Live and smoke-tested. |
| `3039` | Editorial | `variants/editorial` | premium legal/editorial research desk; ivory/ink/burgundy/gold | Live and smoke-tested. |

## Smoke checks performed

For each variant on `3037`, `3038`, and `3039`:

- Home page loads and contains Falcon Trust / Create Article text.
- CSS asset returned 200 `text/css`.
- `POST /api/query` clear-answer flow returned 200, `confidence: High`, `generatedBy: template`.
- Original `3035` listener remained active.

## Presentation guidance

Recommended order for customer review:

1. **3037 Civic** — safest customer-facing/government-public-service feel. Best if Falcon Trust wants trustworthy, accessible, practical communications tooling.
2. **3039 Editorial** — strongest fit for law/research/article-writing positioning. Best if the customer wants premium knowledge desk / publishing confidence.
3. **3038 Modern** — flashiest AI-product feel. Best if the customer responds to modern SaaS/AI visual polish, but it may feel less sober than Civic/Editorial.
4. **3035 Original** — reliable current demo anchor and fallback if variants distract.

Do not merge any variant into the parent app until Raffi/customer picks a direction.

## Known caveat

Each variant build/start emits a non-blocking Next.js warning about multiple lockfiles / inferred workspace root and `next start` with standalone output. The variants still build and serve correctly for demo review.

