import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  serverExternalPackages: ["@napi-rs/canvas"],
  allowedDevOrigins: ["127.0.0.1", "172.22.2.10"],
};

export default nextConfig;
