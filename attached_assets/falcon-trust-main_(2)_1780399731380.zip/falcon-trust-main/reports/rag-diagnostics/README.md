# RAG diagnostics reports

npm run test:rag-diagnostics writes the offline/default diagnostics output here:

- baseline.json
- baseline.md
- baseline-offline-*.json
- baseline-offline-*.md
- latest-offline.json

Optional live Dev/Staging runs are opt-in through env vars only. Example shape:

- FALCON_RAG_DIAGNOSTICS_MODE=live
- FALCON_RAG_DIAGNOSTICS_LIVE_URL=https://...
- FALCON_RAG_DIAGNOSTICS_APP_PASSWORD=... or FALCON_RAG_DIAGNOSTICS_COOKIE=...
- FALCON_RAG_DIAGNOSTICS_ENV=dev|staging

Live reports capture answers, confidence, generatedBy/mode, citations, chunk
ids/scores/snippets/text starts, domains, timings, errors, session id,
createdAt, optional debug/retrieval traces, and request/correlation headers when
the app exposes them.

RAGAS scoring is disabled by default and reported as ragas.enabled=false.
Enable it only when a judge/provider is explicitly configured, for example:

- FALCON_RAGAS_ENABLED=true
- FALCON_RAGAS_PROVIDER=openai|local
- FALCON_RAGAS_MODEL=...
- provider-specific key or base URL env vars

The app currently exposes session id, createdAt, and optional traces, but no
explicit request id. If live diagnostics need stronger log correlation, add a
minimal x-falcon-request-id response/header/log field as a follow-up diagnostics
change. Do not bundle #28/#29 OCR/chunking remediation here.

Generated report files are ignored so the command can be rerun without creating
timestamp-only source diffs. Commit curated baseline artifacts later only when a
review packet intentionally needs to preserve a specific run.
