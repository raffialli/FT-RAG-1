#!/usr/bin/env node
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { buildRagDebugTrace, evaluateRagCase } from "../tests/rag/regression-harness.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, "..");
const queryFixturePath = join(repoRoot, "tests", "rag", "fixtures", "rag-diagnostics-queries.json");
const ragCaseFixturePath = join(repoRoot, "tests", "rag", "fixtures", "rag-eval-cases.json");

const queries = JSON.parse(readFileSync(queryFixturePath, "utf8"));
const ragCases = JSON.parse(readFileSync(ragCaseFixturePath, "utf8"));
const config = readConfig();
const querySummary = queries.map(normalizeQuery);
const fixtureReports = buildFixtureReports(ragCases);
const liveDiagnostics = config.mode === "live" ? await runLiveDiagnostics(queries, config) : null;
const report = buildReport({ querySummary, fixtureReports, liveDiagnostics, config });
const written = writeReports(report, config);

console.log(JSON.stringify({
  status: "ok",
  mode: report.mode,
  environment: config.environment,
  queryCount: report.queryCount,
  fixtureCaseCount: report.fixtureCaseCount,
  liveQueryCount: liveDiagnostics?.results.length ?? 0,
  ragasEnabled: report.ragas.enabled,
  reportJsonPath: relativePath(written.jsonPath),
  reportMarkdownPath: relativePath(written.markdownPath),
  latestJsonPath: relativePath(written.latestJsonPath),
}, null, 2));

function readConfig() {
  const mode = normalizeMode(process.env.FALCON_RAG_DIAGNOSTICS_MODE, process.env.FALCON_RAG_DIAGNOSTICS_LIVE_URL);
  const outputDir = resolve(repoRoot, process.env.FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR ?? process.env.FALCON_RAG_DIAGNOSTICS_REPORT_DIR ?? "reports/rag-diagnostics");
  const environment = process.env.FALCON_RAG_DIAGNOSTICS_ENV ?? (mode === "live" ? "live" : "local");
  const timestamp = new Date().toISOString();
  const timeoutMs = Number.parseInt(process.env.FALCON_RAG_DIAGNOSTICS_TIMEOUT_MS ?? "30000", 10);
  const includeDebug = process.env.FALCON_RAG_DIAGNOSTICS_INCLUDE_DEBUG !== "false";

  return {
    mode,
    outputDir,
    environment,
    timestamp,
    timeoutMs: Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : 30000,
    includeDebug,
    liveUrl: process.env.FALCON_RAG_DIAGNOSTICS_LIVE_URL?.replace(/\/$/, "") ?? null,
    appPassword: process.env.FALCON_RAG_DIAGNOSTICS_APP_PASSWORD ?? null,
    cookie: process.env.FALCON_RAG_DIAGNOSTICS_COOKIE ?? null,
    ragas: readRagasConfig(),
    awsLogConfig: {
      profile: process.env.AWS_PROFILE ?? null,
      region: process.env.AWS_REGION ?? null,
      appRunnerServiceArn: process.env.FALCON_RAG_DIAGNOSTICS_APPRUNNER_SERVICE_ARN ?? null,
      logGroup: process.env.FALCON_RAG_DIAGNOSTICS_LOG_GROUP ?? null,
      lookbackMinutes: Number.parseInt(process.env.FALCON_RAG_DIAGNOSTICS_LOOKBACK_MINUTES ?? "60", 10),
    },
  };
}

function normalizeMode(modeValue, liveUrl) {
  if (modeValue === "live") return "live";
  if (modeValue === "offline" || modeValue === undefined) return liveUrl ? "live" : "offline";
  throw new Error("Unsupported FALCON_RAG_DIAGNOSTICS_MODE: " + modeValue + ". Use offline or live.");
}

function readRagasConfig() {
  const provider = process.env.FALCON_RAGAS_PROVIDER ?? "none";
  const enabled = process.env.FALCON_RAGAS_ENABLED === "true" && provider !== "none";
  const model = process.env.FALCON_RAGAS_MODEL ?? null;
  const requiredEnv = provider === "openai"
    ? ["FALCON_RAGAS_ENABLED=true", "FALCON_RAGAS_PROVIDER=openai", "FALCON_RAGAS_MODEL", "OPENAI_API_KEY"]
    : provider === "local"
      ? ["FALCON_RAGAS_ENABLED=true", "FALCON_RAGAS_PROVIDER=local", "FALCON_RAGAS_MODEL", "FALCON_RAGAS_BASE_URL"]
      : ["FALCON_RAGAS_ENABLED=true", "FALCON_RAGAS_PROVIDER=openai|local", "FALCON_RAGAS_MODEL", "provider-specific API/base URL env"];

  return {
    enabled,
    provider,
    model,
    status: enabled ? "configured-not-scored-in-this-node-scaffold" : "disabled",
    disabledReason: enabled ? null : "No RAGAS judge/provider env config is enabled; default diagnostics must remain secret-free.",
    requiredEnv,
    metrics: ["context_precision", "context_recall", "faithfulness", "answer_relevancy"],
  };
}

function normalizeQuery(query) {
  return {
    id: query.id,
    category: query.category,
    supportLevel: query.supportLevel,
    query: query.query,
    domains: query.domains,
    expectedBehavior: query.expectedBehavior,
    knownBadPatterns: query.knownBadPatterns ?? [],
    knownChunkIds: query.knownChunkIds ?? [],
    handoff: query.handoff ?? [],
  };
}

function buildFixtureReports(cases) {
  return cases.map((ragCase) => {
    const evaluation = evaluateRagCase(ragCase);
    const trace = buildRagDebugTrace(ragCase);
    const effective = buildEffectiveFixtureOutput(ragCase, evaluation, trace);
    const citations = effective.finalChunks.map((chunk) => normalizeCitation(chunk, chunk.score, chunk.snippet ?? chunk.textPreview ?? ""));
    const evidenceHealth = analyzeEvidence({
      answer: effective.answer,
      citations,
      knownBadPatterns: [],
      supportLevel: effective.supportLevel,
    });
    const failureClasses = classifyResult({
      answer: effective.answer,
      supportLevel: effective.supportLevel,
      expectedBehavior: ragCase.description ?? "",
      confidence: effective.confidence,
      citations,
      evidenceHealth,
      answerSupported: evaluation.answerSupported,
      answerable: evaluation.answerable,
    });

    return {
      id: ragCase.id,
      category: ragCase.category,
      query: ragCase.query,
      futureIssue: ragCase.futureIssue ?? null,
      diagnosticAnswer: effective.answer,
      diagnosticConfidence: effective.confidence,
      diagnosticSupportLevel: effective.supportLevel,
      evaluation,
      ragasProxy: buildRagasProxy(evaluation, trace),
      chunkHealth: analyzeChunks(ragCase.chunks),
      finalChunks: trace.finalChunks.map((chunk) => ({
        chunkId: chunk.chunkId,
        title: chunk.title,
        chunkIndex: chunk.chunkIndex,
        score: chunk.score,
        contentType: chunk.contentType,
        flags: analyzeText(chunk.snippet),
      })),
      failureClasses,
      recommendedWork: recommendWork(failureClasses),
    };
  });
}

function buildEffectiveFixtureOutput(ragCase, evaluation, trace) {
  if (!evaluation.answerable && !evaluation.answerSupported) {
    return {
      answer: "The selected fixture evidence does not provide enough body-source support to answer this request. Treat it as a gap/no-support result.",
      confidence: "Low",
      supportLevel: "unsupported",
      finalChunks: [],
    };
  }

  return {
    answer: ragCase.answer?.text ?? "",
    confidence: ragCase.answer?.confidence ?? "Low",
    supportLevel: "supported",
    finalChunks: trace.finalChunks,
  };
}

async function runLiveDiagnostics(goldenQueries, runtimeConfig) {
  if (!runtimeConfig.liveUrl) {
    throw new Error("FALCON_RAG_DIAGNOSTICS_LIVE_URL is required when FALCON_RAG_DIAGNOSTICS_MODE=live.");
  }

  const results = [];
  for (const query of goldenQueries) {
    results.push(await runLiveQuery(query, runtimeConfig));
  }

  return {
    endpoint: runtimeConfig.liveUrl,
    environment: runtimeConfig.environment,
    includeDebug: runtimeConfig.includeDebug,
    results,
    aggregate: aggregateLiveResults(results),
  };
}

async function runLiveQuery(query, runtimeConfig) {
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), runtimeConfig.timeoutMs);
  const headers = {
    "content-type": "application/json",
    "user-agent": "falcon-rag-diagnostics/1.0",
    ...authHeaders(runtimeConfig),
  };

  try {
    const response = await fetch(runtimeConfig.liveUrl + "/api/query", {
      method: "POST",
      headers,
      body: JSON.stringify({
        query: query.query,
        domains: query.domains,
        includeDebug: runtimeConfig.includeDebug,
        debug: runtimeConfig.includeDebug,
      }),
      signal: controller.signal,
    });
    const elapsedMs = Date.now() - started;
    const responseText = await response.text();
    const body = parseJson(responseText);
    const responseHeaders = captureHeaders(response.headers);

    if (!response.ok || !body) {
      return buildErroredLiveResult({ query, elapsedMs, status: response.status, responseHeaders, responseText, error: body?.message ?? response.statusText });
    }

    const citations = normalizeCitations(body.citations ?? body.retrievalTrace?.finalChunks ?? body.debugTrace?.finalChunks ?? []);
    const evidenceHealth = analyzeEvidence({
      answer: body.answer ?? body.answerSections?.answer ?? "",
      citations,
      knownBadPatterns: query.knownBadPatterns ?? [],
      supportLevel: query.supportLevel,
    });
    const failureClasses = classifyResult({
      answer: body.answer ?? body.answerSections?.answer ?? "",
      supportLevel: query.supportLevel,
      expectedBehavior: query.expectedBehavior,
      confidence: body.confidence,
      citations,
      evidenceHealth,
      answerSupported: !evidenceHealth.answerHealth.flagged && citations.length > 0,
      answerable: !isUnsupportedLevel(query.supportLevel),
    });

    return {
      id: query.id,
      query: query.query,
      category: query.category,
      supportLevel: query.supportLevel,
      domains: query.domains,
      status: response.status,
      ok: response.ok,
      elapsedMs,
      sessionId: body.id ?? null,
      createdAt: body.createdAt ?? null,
      correlation: buildCorrelation(body, responseHeaders),
      answer: body.answer ?? body.answerSections?.answer ?? null,
      confidence: body.confidence ?? null,
      generatedBy: body.generatedBy ?? null,
      mode: body.mode ?? null,
      answerType: body.answerType ?? null,
      externalSearch: body.externalSearch ?? body.externalSearchEnabled ?? null,
      citations,
      traces: {
        retrievalTrace: summarizeTrace(body.retrievalTrace),
        debugTrace: summarizeTrace(body.debugTrace),
        augmentedContextTrace: summarizeTrace(body.augmentedContextTrace),
      },
      evidenceHealth,
      failureClasses,
      recommendedWork: recommendWork(failureClasses),
      error: null,
    };
  } catch (error) {
    return buildErroredLiveResult({ query, elapsedMs: Date.now() - started, status: null, responseHeaders: {}, responseText: "", error: error.name === "AbortError" ? "timeout" : error.message });
  } finally {
    clearTimeout(timer);
  }
}

function authHeaders(runtimeConfig) {
  if (runtimeConfig.cookie) return { cookie: runtimeConfig.cookie };
  if (runtimeConfig.appPassword) return { "x-falcon-app-password": runtimeConfig.appPassword };
  return {};
}

function buildErroredLiveResult({ query, elapsedMs, status, responseHeaders, responseText, error }) {
  return {
    id: query.id,
    query: query.query,
    category: query.category,
    supportLevel: query.supportLevel,
    domains: query.domains,
    status,
    ok: false,
    elapsedMs,
    sessionId: null,
    createdAt: null,
    correlation: buildCorrelation({}, responseHeaders),
    answer: null,
    confidence: null,
    generatedBy: null,
    mode: null,
    answerType: null,
    externalSearch: null,
    citations: [],
    traces: {},
    evidenceHealth: null,
    failureClasses: ["timeout_or_endpoint_error"],
    recommendedWork: ["diagnostics/live-endpoint"],
    error: {
      message: error,
      responsePreview: responseText.slice(0, 500),
    },
  };
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function captureHeaders(headers) {
  const wanted = ["x-request-id", "x-falcon-request-id", "x-amzn-trace-id", "x-amzn-requestid", "x-envoy-upstream-service-time", "date"];
  return Object.fromEntries(wanted.map((name) => [name, headers.get(name)]).filter(([, value]) => value));
}

function buildCorrelation(body, responseHeaders) {
  return {
    sessionId: body?.id ?? null,
    createdAt: body?.createdAt ?? null,
    requestId: body?.requestId ?? responseHeaders["x-request-id"] ?? responseHeaders["x-falcon-request-id"] ?? null,
    amazonTraceId: responseHeaders["x-amzn-trace-id"] ?? responseHeaders["x-amzn-requestid"] ?? null,
    responseHeaders,
  };
}

function normalizeCitations(citations) {
  return citations.map((citation) => normalizeCitation(citation, citation.score, citation.snippet ?? citation.text ?? citation.preview ?? ""));
}

function normalizeCitation(citation, score, text) {
  const preview = cleanCitationText(text ?? citation.snippet ?? citation.text ?? "");
  return {
    documentId: citation.documentId ?? citation.document_id ?? null,
    title: citation.title ?? citation.documentTitle ?? null,
    chunkId: citation.chunkId ?? citation.id ?? citation.chunk_id ?? null,
    chunkIndex: citation.chunkIndex ?? citation.chunk_index ?? null,
    score: typeof score === "number" ? score : null,
    snippet: citation.snippet ?? preview,
    textStart: preview.slice(0, 220),
    viewerUrl: citation.viewerUrl ?? citation.url ?? null,
    sourcePath: citation.sourcePath ?? citation.metadata?.sourcePath ?? null,
    contentType: citation.contentType ?? citation.kind ?? citation.metadata?.contentType ?? null,
    source: citation.source ?? citation.metadata?.source ?? null,
    sourceFileName: citation.sourceFileName ?? citation.metadata?.sourceFileName ?? null,
    metadata: citation.metadata ?? null,
    flags: analyzeText(preview),
  };
}

function cleanCitationText(text) {
  const lines = String(text ?? "")
    .replace(/[ﬁ]/g, "fi")
    .replace(/[ﬂ]/g, "fl")
    .replace(/(\w)-\s*\n\s*(\w)/g, "$1$2")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !/^Page\s+\d+$/i.test(line) && !/^FALCON COUNTY FLOOD RESPONSE BULLETIN$/i.test(line));

  return lines.join(" ").replace(/\s+/g, " ").trim();
}

function summarizeTrace(trace) {
  if (!trace) return null;
  return {
    backend: trace.backend ?? null,
    selectedDomains: trace.selectedDomains ?? null,
    candidateCount: trace.candidateCount ?? null,
    matchedCandidateCount: trace.matchedCandidateCount ?? null,
    finalChunkCount: trace.finalChunkCount ?? trace.finalChunks?.length ?? null,
    citationCount: trace.citationCount ?? null,
    chunkIds: trace.chunkIds ?? trace.finalChunks?.map((chunk) => chunk.chunkId ?? chunk.id).filter(Boolean) ?? null,
    notes: trace.notes ?? null,
  };
}

function analyzeChunks(chunks) {
  const details = chunks.map((chunk, index) => ({
    chunkId: chunk.id ?? "chunk-" + (index + 1),
    kind: chunk.kind ?? "unknown",
    length: chunk.text.length,
    metadataMissing: missingMetadata(chunk),
    flags: analyzeText(chunk.text),
  }));

  return {
    chunkCount: chunks.length,
    contentTypes: countBy(details, "kind"),
    lengthOutliers: details.filter((chunk) => chunk.length < 120 || chunk.length > 1600).map(({ chunkId, length }) => ({ chunkId, length })),
    flaggedChunks: details.filter((chunk) => chunk.metadataMissing.length || Object.values(chunk.flags).some(Boolean)),
    details,
  };
}

function analyzeEvidence({ answer, citations, knownBadPatterns, supportLevel }) {
  const answerFlags = analyzeText(answer ?? "");
  const knownPatternMatches = findKnownPatternMatches(answer ?? "", citations, knownBadPatterns);
  const citationHealth = citations.map((citation) => ({
    chunkId: citation.chunkId,
    chunkIndex: citation.chunkIndex,
    score: citation.score,
    title: citation.title,
    textStart: citation.textStart,
    sourcePath: citation.sourcePath,
    contentType: citation.contentType,
    metadata: citation.metadata,
    flags: citation.flags ?? analyzeText(citation.textStart ?? citation.snippet ?? ""),
    knownPatternMatches: knownBadPatterns.filter((pattern) => includesPattern(citation.textStart ?? citation.snippet ?? "", pattern)),
    missingMetadata: ["documentId", "title", "chunkId", "chunkIndex", "sourcePath", "contentType"].filter((field) => citation[field] === null || citation[field] === undefined),
  }));

  return {
    supportLevel,
    answerHealth: {
      flagged: Object.values(answerFlags).some(Boolean) || knownPatternMatches.answer.length > 0,
      flags: answerFlags,
      knownPatternMatches: knownPatternMatches.answer,
    },
    citationHealth,
    knownPatternMatches,
    duplicateEvidence: detectDuplicateEvidence(citations),
    poorScoreEvidence: citations.filter((citation) => typeof citation.score === "number" && citation.score < 0.2).map((citation) => citation.chunkId),
  };
}

function findKnownPatternMatches(answer, citations, patterns) {
  return {
    answer: patterns.filter((pattern) => includesPattern(answer, pattern)),
    citations: citations.flatMap((citation) => patterns
      .filter((pattern) => includesPattern(citation.textStart ?? citation.snippet ?? "", pattern))
      .map((pattern) => ({ chunkId: citation.chunkId, pattern }))),
  };
}

function includesPattern(text, pattern) {
  return String(text ?? "").toLowerCase().includes(String(pattern).toLowerCase());
}

function detectDuplicateEvidence(citations) {
  const seen = new Map();
  const duplicates = [];
  for (const citation of citations) {
    const key = String(citation.textStart ?? citation.snippet ?? "").toLowerCase().replace(/\W+/g, " ").slice(0, 120);
    if (!key) continue;
    if (seen.has(key)) duplicates.push({ first: seen.get(key), duplicate: citation.chunkId });
    else seen.set(key, citation.chunkId);
  }
  return duplicates;
}

function analyzeText(text) {
  const normalized = String(text ?? "").replace(/\s+/g, " ").trim();

  return {
    midWordStart: /^[a-z]{1,3}\b/.test(normalized) && !/^(the|and|for|but|not|yes|no)\b/i.test(normalized),
    continuationStart: /^(and|or|but|because|which|that|with|into|however),?\b/i.test(normalized),
    badSentenceEnding: /[a-z,;:]$/.test(normalized),
    ocrLayoutGarbage: /Technologyexclusion|Technologicalexclusion|lnstrums|lesSOfls|I I I|--~|➔|FDOsflood|ds,nsity|fearnt>d|\bPage\s+\d+\b/i.test(text),
    figureTableLeakage: /\b(?:figure|table)\s+\d+(?:\.\d+)?\b|List of Figures|FIGURE\s+\d/i.test(text),
    headerFooterLeakage: /All Rights Reserved|FALCON COUNTY FLOOD RESPONSE BULLETIN|\b\d{1,3}\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b/.test(text),
    referenceLeakage: /References?|Bibliography|Accessed at|public\.wmo\.int|doi:|ISBN|Cataloging-in-Publication/i.test(text),
    frontmatterLeakage: /Table of Contents|\bContents\b|copyright|ISBN|Cataloging-in-Publication|Published by/i.test(text),
    hyphenatedLineBreak: /\w-\s*\n\s*\w/.test(text),
    ligature: /[ﬁﬂ]/.test(text),
  };
}

function missingMetadata(chunk) {
  return ["documentId", "title", "domain", "sourcePath"].filter((field) => !chunk[field]);
}

function buildRagasProxy(evaluation, trace) {
  return {
    contextPrecisionProxy: trace.finalChunkCount && trace.candidateCount ? Number((trace.finalChunkCount / trace.candidateCount).toFixed(3)) : 0,
    contextRecallProxy: evaluation.supportingBodyChunkCount > 0 ? 1 : 0,
    faithfulnessProxy: evaluation.answerSupported ? 1 : 0,
    answerRelevancyProxy: evaluation.answerable ? 1 : 0,
    note: "Proxy fields are deterministic scaffold values, not full RAGAS metrics.",
  };
}

function classifyResult({ answer, supportLevel, expectedBehavior, confidence, citations, evidenceHealth, answerSupported, answerable }) {
  const classes = new Set();
  const citationFlags = evidenceHealth?.citationHealth ?? [];
  const hasSourceQuality = evidenceHealth?.answerHealth?.flags?.ocrLayoutGarbage
    || citationFlags.some((citation) => citation.flags.ocrLayoutGarbage || citation.flags.figureTableLeakage || citation.flags.headerFooterLeakage)
    || evidenceHealth?.knownPatternMatches?.answer?.length
    || evidenceHealth?.knownPatternMatches?.citations?.length;
  const hasChunkReadability = citationFlags.some((citation) => citation.flags.midWordStart || citation.flags.continuationStart);
  const hasReferenceLeakage = citationFlags.some((citation) => citation.flags.referenceLeakage || citation.flags.frontmatterLeakage);
  const hasMetadataGap = citationFlags.some((citation) => citation.missingMetadata.length > 0);
  const hasWeakRanking = (evidenceHealth?.poorScoreEvidence?.length ?? 0) > 0 || (evidenceHealth?.duplicateEvidence?.length ?? 0) > 0;

  if (hasSourceQuality || hasChunkReadability) classes.add("source_chunk_ocr_layout");
  if (hasReferenceLeakage) classes.add("reference_frontmatter_leakage");
  if (hasWeakRanking || (citations.length > 0 && !answerSupported)) classes.add("retrieval_ranking");
  if (answerable && !answerSupported) classes.add("answer_generation_faithfulness");
  if ((confidence === "High" && (hasSourceQuality || !answerSupported || isUnsupportedLevel(supportLevel))) || (confidence === "Low" && answerSupported)) {
    classes.add("confidence_calibration");
  }
  if (isUnsupportedLevel(supportLevel) && !looksLikeGapAnswer(answer)) classes.add("unsupported_gap_missing");
  if (hasMetadataGap) classes.add("metadata_source_display");
  if (/reference|frontmatter/i.test(expectedBehavior) && hasReferenceLeakage) classes.add("reference_frontmatter_leakage");

  return [...classes];
}

function isUnsupportedLevel(level) {
  return /unsupported|reference-only-risk|unsupported-or-filtered/i.test(level ?? "");
}

function looksLikeGapAnswer(answer) {
  return /\b(no|not supported|do not support|does not support|insufficient|cannot determine|do not identify|does not identify|gap)\b/i.test(answer ?? "");
}

function recommendWork(classes) {
  const work = new Set();
  for (const cls of classes) {
    if (cls === "source_chunk_ocr_layout") work.add("#28 OCR/layout cleanup");
    if (cls === "reference_frontmatter_leakage") work.add("#28/#29 evidence filtering");
    if (cls === "retrieval_ranking") work.add("retrieval/ranking diagnostics");
    if (cls === "answer_generation_faithfulness") work.add("answer-generation/faithfulness diagnostics");
    if (cls === "confidence_calibration") work.add("confidence/calibration diagnostics");
    if (cls === "unsupported_gap_missing") work.add("unsupported/gap behavior");
    if (cls === "metadata_source_display") work.add("#29 source display/readability");
    if (cls === "timeout_or_endpoint_error") work.add("diagnostics/live-endpoint");
  }
  return [...work];
}

function aggregateLiveResults(results) {
  return {
    total: results.length,
    ok: results.filter((result) => result.ok).length,
    errored: results.filter((result) => !result.ok).length,
    byFailureClass: countValues(results.flatMap((result) => result.failureClasses)),
    byRecommendedWork: countValues(results.flatMap((result) => result.recommendedWork)),
    highConfidenceFlagged: results.filter((result) => result.confidence === "High" && result.failureClasses.length > 0).map((result) => result.id),
  };
}

function buildReport({ querySummary, fixtureReports, liveDiagnostics, config: runtimeConfig }) {
  const mode = liveDiagnostics ? "live" : "offline";
  const aggregate = {
    generatedAt: runtimeConfig.timestamp,
    mode,
    environment: runtimeConfig.environment,
    endpoint: runtimeConfig.liveUrl,
    queryCount: queries.length,
    categories: countBy(queries, "category"),
    supportLevels: countBy(queries, "supportLevel"),
    fixtureCaseCount: ragCases.length,
    chunkHealthTotals: sumChunkHealth(fixtureReports),
    knownArtifactCases: queries
      .filter((query) => (query.knownBadPatterns?.length ?? 0) > 0 || (query.knownChunkIds?.length ?? 0) > 0)
      .map((query) => ({ id: query.id, category: query.category, knownBadPatterns: query.knownBadPatterns ?? [], knownChunkIds: query.knownChunkIds ?? [] })),
    ragas: runtimeConfig.ragas,
    logCorrelation: buildLogCorrelation(runtimeConfig),
  };

  return {
    ...aggregate,
    goldenQueries: querySummary,
    fixtureDiagnostics: fixtureReports,
    liveDiagnostics,
  };
}

function buildLogCorrelation(runtimeConfig) {
  return {
    availableFromApp: ["session id", "createdAt", "optional debugTrace", "optional retrievalTrace", "optional augmentedContextTrace"],
    explicitRequestIdObserved: false,
    responseHeadersCapturedWhenPresent: ["x-request-id", "x-falcon-request-id", "x-amzn-trace-id", "x-amzn-requestid", "x-envoy-upstream-service-time", "date"],
    cloudWatchPath: [
      "Use report generatedAt and per-query elapsed/status fields.",
      "Search App Runner/CloudWatch logs around the timestamp using session id, query id, and any captured request/trace headers.",
      "If no request id appears, add a minimal /api/query request id header/response/log line in a follow-up diagnostics patch.",
    ],
    awsOptional: Boolean(runtimeConfig.awsLogConfig.profile || runtimeConfig.awsLogConfig.logGroup || runtimeConfig.awsLogConfig.appRunnerServiceArn),
    awsLogConfig: redactEmpty(runtimeConfig.awsLogConfig),
  };
}

function writeReports(report, runtimeConfig) {
  const stamp = runtimeConfig.timestamp.replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const suffix = report.mode === "live" ? "live-" + runtimeConfig.environment : "offline";
  const jsonPath = join(runtimeConfig.outputDir, "baseline-" + suffix + "-" + stamp + ".json");
  const markdownPath = join(runtimeConfig.outputDir, "baseline-" + suffix + "-" + stamp + ".md");
  const latestJsonPath = join(runtimeConfig.outputDir, "latest-" + suffix + ".json");
  const baselineJsonPath = join(runtimeConfig.outputDir, "baseline.json");
  const baselineMarkdownPath = join(runtimeConfig.outputDir, "baseline.md");

  mkdirSync(runtimeConfig.outputDir, { recursive: true });
  const json = JSON.stringify(report, null, 2) + "\n";
  const markdown = renderMarkdown(report);
  writeFileSync(jsonPath, json);
  writeFileSync(markdownPath, markdown);
  writeFileSync(latestJsonPath, JSON.stringify({ report: relativePath(jsonPath), generatedAt: report.generatedAt, mode: report.mode }, null, 2) + "\n");
  writeFileSync(baselineJsonPath, json);
  writeFileSync(baselineMarkdownPath, markdown);
  return { jsonPath, markdownPath, latestJsonPath };
}

function renderMarkdown(report) {
  const liveResults = report.liveDiagnostics?.results ?? [];
  const lines = [
    "# RAG Diagnostics Baseline",
    "",
    "Generated: " + report.generatedAt,
    "Mode: " + report.mode,
    "Environment: " + report.environment,
    report.endpoint ? "Endpoint: " + report.endpoint : null,
    "",
    "## Summary",
    "",
    "- Golden queries: " + report.queryCount,
    "- Offline fixture cases: " + report.fixtureCaseCount,
    "- Flagged fixture chunks: " + report.chunkHealthTotals.flaggedChunks,
    "- RAGAS: " + (report.ragas.enabled ? "enabled/configured" : "disabled"),
    report.ragas.disabledReason ? "- RAGAS disabled reason: " + report.ragas.disabledReason : null,
    "",
    "## Failure Class Totals",
    "",
    ...Object.entries(report.liveDiagnostics?.aggregate?.byFailureClass ?? countValues(report.fixtureDiagnostics.flatMap((item) => item.failureClasses))).map(([cls, count]) => "- " + cls + ": " + count),
    "",
    "## Recommended Work Buckets",
    "",
    ...Object.entries(report.liveDiagnostics?.aggregate?.byRecommendedWork ?? countValues(report.fixtureDiagnostics.flatMap((item) => item.recommendedWork))).map(([bucket, count]) => "- " + bucket + ": " + count),
    "",
    "## Golden Query Categories",
    "",
    ...Object.entries(report.categories).map(([category, count]) => "- " + category + ": " + count),
    "",
    "## Known Artifact Queries",
    "",
    ...report.knownArtifactCases.map((query) => "- " + query.id + ": patterns=" + (query.knownBadPatterns.join(", ") || "none") + " chunks=" + (query.knownChunkIds.join(", ") || "none")),
    "",
    "## Live Query Results",
    "",
    ...(liveResults.length ? liveResults.map(renderLiveResult) : ["- Not run; set FALCON_RAG_DIAGNOSTICS_MODE=live and live URL/auth env vars to enable."]),
    "",
    "## Log Correlation",
    "",
    "- App response fields currently useful for correlation: session id, createdAt, optional traces.",
    "- Explicit request/correlation IDs are captured from headers when present.",
    "- If missing, add a minimal x-falcon-request-id response/header/log field in a follow-up diagnostics patch.",
    "",
  ].filter(Boolean);

  return lines.join("\n");
}

function renderLiveResult(result) {
  return [
    "### " + result.id,
    "- Status: " + (result.status ?? "n/a") + " " + (result.ok ? "ok" : "error"),
    "- Confidence: " + (result.confidence ?? "n/a"),
    "- Session: " + (result.sessionId ?? "n/a") + " createdAt=" + (result.createdAt ?? "n/a"),
    "- Failure classes: " + (result.failureClasses.join(", ") || "none"),
    "- Recommended work: " + (result.recommendedWork.join(", ") || "none"),
    "- Citations: " + (result.citations.map((citation) => [citation.chunkId, citation.score].filter((value) => value !== null).join("@")).join(", ") || "none"),
    "",
  ].join("\n");
}

function sumChunkHealth(reports) {
  const totals = {
    flaggedChunks: 0,
    lengthOutliers: 0,
    ocrLayoutGarbage: 0,
    figureTableLeakage: 0,
    headerFooterLeakage: 0,
    referenceLeakage: 0,
    frontmatterLeakage: 0,
    metadataMissing: 0,
  };

  for (const report of reports) {
    totals.flaggedChunks += report.chunkHealth.flaggedChunks.length;
    totals.lengthOutliers += report.chunkHealth.lengthOutliers.length;
    for (const chunk of report.chunkHealth.flaggedChunks) {
      if (chunk.flags.ocrLayoutGarbage) totals.ocrLayoutGarbage += 1;
      if (chunk.flags.figureTableLeakage) totals.figureTableLeakage += 1;
      if (chunk.flags.headerFooterLeakage) totals.headerFooterLeakage += 1;
      if (chunk.flags.referenceLeakage) totals.referenceLeakage += 1;
      if (chunk.flags.frontmatterLeakage) totals.frontmatterLeakage += 1;
      if (chunk.metadataMissing.length > 0) totals.metadataMissing += 1;
    }
  }

  return totals;
}

function countBy(items, key) {
  return items.reduce((counts, item) => {
    const value = item[key] ?? "unknown";
    counts[value] = (counts[value] ?? 0) + 1;
    return counts;
  }, {});
}

function countValues(values) {
  return values.reduce((counts, value) => {
    counts[value] = (counts[value] ?? 0) + 1;
    return counts;
  }, {});
}

function redactEmpty(value) {
  return Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== null && entry !== undefined && entry !== ""));
}

function relativePath(path) {
  return relative(repoRoot, path);
}
