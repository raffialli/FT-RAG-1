#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT="${PORT:-3035}"
HOSTNAME="${HOSTNAME:-0.0.0.0}"

cd "$APP_DIR"
npm run build

BUILD_ID="$(cat .next/BUILD_ID)"
RELEASE_ROOT="$APP_DIR/.demo-server/releases"
RELEASE="$RELEASE_ROOT/$BUILD_ID"
PID_FILE="$APP_DIR/.demo-server/current.pid"

mkdir -p "$RELEASE_ROOT"
rm -rf "$RELEASE"
mkdir -p "$RELEASE"

cp -a .next/standalone/. "$RELEASE/"
mkdir -p "$RELEASE/.next"
cp -a .next/static "$RELEASE/.next/static"
cp -a public "$RELEASE/public"
cp -a demo-corpus "$RELEASE/demo-corpus"
mkdir -p "$RELEASE/.demo-data"

if [[ -f "$PID_FILE" ]]; then
  old_pid="$(cat "$PID_FILE" || true)"
  if [[ -n "${old_pid:-}" ]] && kill -0 "$old_pid" 2>/dev/null; then
    kill "$old_pid" 2>/dev/null || true
    sleep 1
    kill -9 "$old_pid" 2>/dev/null || true
  fi
fi

ln -sfn "$RELEASE" "$APP_DIR/.demo-server/current"
cd "$RELEASE"
PORT="$PORT" HOSTNAME="$HOSTNAME" node server.js
