import Link from "next/link";
import { FalconNav } from "@/components/FalconNav";

export default function FalconChatPage() {
  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto w-full max-w-5xl px-5 py-5 lg:px-10 lg:py-8">
        <FalconNav active="addons" title="FalconChat" />

        <section className="glass-panel glow-ring rounded-[32px] p-6 md:p-8">
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-cyan-200">Placeholder only</p>
          <h2 className="mt-3 text-3xl font-semibold text-white md:text-5xl">FalconChat</h2>
          <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-200">
            Ask FalconTrust-aware questions, research officials/publications, and draft content in a future version.
          </p>

          <div className="mt-8 grid gap-3 md:grid-cols-2">
            {[
              "No model API keys",
              "No OAuth",
              "No GPT/Grok/frontier-model calls",
              "No durable chat memory",
              "No automated outreach",
              "No publishing or email sending",
            ].map((item) => (
              <div key={item} className="rounded-2xl border border-white/10 bg-black/25 p-4 text-sm font-semibold text-slate-200">
                {item}
              </div>
            ))}
          </div>

          <Link href="/addons" className="mt-8 inline-flex rounded-full border border-cyan-300/30 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:border-cyan-300/60">
            Back to add-ons
          </Link>
        </section>
      </div>
    </main>
  );
}

