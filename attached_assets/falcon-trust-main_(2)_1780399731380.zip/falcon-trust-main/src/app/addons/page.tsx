import Link from "next/link";
import { FalconNav } from "@/components/FalconNav";

const modules = [
  {
    name: "StormIntel",
    href: "/addons/stormintel",
    status: "Local MVP",
    description: "Human-review packets for Southeast flood, hurricane, tropical storm, storm surge, and sandbag-relevant events.",
  },
  {
    name: "FalconChat",
    href: "/addons/falconchat",
    status: "Placeholder",
    description: "Future FalconTrust-aware chat surface. No model APIs, OAuth, or durable memory are wired in this lane.",
  },
];

export default function AddonsPage() {
  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto w-full max-w-6xl px-5 py-5 lg:px-10 lg:py-8">
        <FalconNav active="addons" title="Add-ons" />

        <section className="mx-auto max-w-4xl pb-10">
          <div className="text-center">
            <div className="mx-auto inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.28em] text-cyan-100">
              Local-only lane
            </div>
            <h2 className="gradient-text mt-5 text-4xl font-semibold tracking-tight md:text-6xl">FalconTrust add-ons shell</h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-slate-300 md:text-lg">
              Early module area for local review. Existing Search, Documents, and Admin workflows remain separate.
            </p>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {modules.map((module) => (
              <Link key={module.name} href={module.href} className="glass-panel rounded-[28px] p-6 transition hover:border-cyan-300/35 hover:bg-white/8">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.22em] text-cyan-200">{module.status}</p>
                    <h3 className="mt-2 text-2xl font-semibold text-white">{module.name}</h3>
                  </div>
                  <span className="rounded-full border border-white/10 bg-black/30 px-3 py-1 text-xs text-slate-300">Open</span>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-300">{module.description}</p>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}

