"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { FalconNav } from "@/components/FalconNav";
import {
  eventTypeLabel,
  futureOnlyStatus,
  stormIntelStatuses,
  type StormIntelEventType,
  type StormIntelFeedResult,
  type StormIntelPacket,
  type StormIntelSourceType,
  type StormIntelStatus,
  type StormIntelTargetConfidence,
  type StormIntelVerifiedOfficial,
  type StormIntelVerifiedPublication,
} from "@/lib/falcon/stormintel";

type SourceFilter = "all" | StormIntelSourceType;
type StatusFilter = "all" | StormIntelStatus;
type EventFilter = "all" | StormIntelEventType;
type FeedMode = "auto" | "fallback";

export default function StormIntelPage() {
  const [feed, setFeed] = useState<StormIntelFeedResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [statuses, setStatuses] = useState<Record<string, StormIntelStatus>>({});
  const [query, setQuery] = useState("");
  const [feedMode, setFeedMode] = useState<FeedMode>("auto");
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>("all");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [eventFilter, setEventFilter] = useState<EventFilter>("all");

  useEffect(() => {
    let cancelled = false;

    async function loadFeed() {
      setLoading(true);
      setError("");
      try {
        const feedPath = feedMode === "fallback" ? "/api/addons/stormintel/alerts?source=fallback" : "/api/addons/stormintel/alerts";
        const response = await fetch(feedPath, { cache: "no-store" });
        if (!response.ok) throw new Error(`StormIntel feed returned HTTP ${response.status}`);
        const result = (await response.json()) as StormIntelFeedResult;
        if (cancelled) return;
        setFeed(result);
        setStatuses((current) => ({
          ...Object.fromEntries(result.packets.map((packet) => [packet.id, packet.initialStatus])),
          ...current,
        }));
        setSelectedId(result.packets[0]?.id || "");
      } catch (fetchError) {
        if (cancelled) return;
        setError(fetchError instanceof Error ? fetchError.message : "Unable to load StormIntel feed");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void loadFeed();
    return () => {
      cancelled = true;
    };
  }, [feedMode]);

  const packets = feed?.packets ?? [];
  const eventTypes = useMemo(() => Array.from(new Set(packets.map((packet) => packet.eventType))), [packets]);

  const filteredPackets = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return packets.filter((packet) => {
      const status = statuses[packet.id] ?? packet.initialStatus;
      if (sourceFilter !== "all" && packet.sourceType !== sourceFilter) return false;
      if (statusFilter !== "all" && status !== statusFilter) return false;
      if (eventFilter !== "all" && packet.eventType !== eventFilter) return false;
      if (!normalizedQuery) return true;

      const searchable = [
        packet.title,
        packet.impactedRegion,
        packet.stateRegion,
        eventTypeLabel(packet.eventType),
        packet.sourceLabel,
        packet.sourceStatus,
        packet.sandbagRelevance,
        packet.recommendedAngle,
        ...packet.counties.flatMap((county) => [county.name, ...county.cities]),
        ...packet.officials.tier1,
        ...packet.officials.tier2,
        ...packet.publicationTargets,
        ...(packet.verifiedTargets?.officials.flatMap((official) => [official.name, official.title, official.jurisdiction, official.category]) ?? []),
        ...(packet.verifiedTargets?.publications.flatMap((publication) => [publication.name, publication.type, publication.regionServed]) ?? []),
      ]
        .join(" ")
        .toLowerCase();

      return searchable.includes(normalizedQuery);
    });
  }, [eventFilter, packets, query, sourceFilter, statusFilter, statuses]);
  const selected = useMemo(() => filteredPackets.find((packet) => packet.id === selectedId) ?? filteredPackets[0], [filteredPackets, selectedId]);

  function updateStatus(packetId: string, status: StormIntelStatus) {
    setStatuses((current) => ({ ...current, [packetId]: status }));
  }

  function clearFilters() {
    setQuery("");
    setSourceFilter("all");
    setStatusFilter("all");
    setEventFilter("all");
  }

  return (
    <main className="min-h-screen overflow-x-hidden text-slate-100">
      <div className="mx-auto w-full max-w-7xl px-4 py-5 sm:px-5 lg:px-10 lg:py-8">
        <FalconNav active="addons" title="StormIntel" />

        <section className="mb-6 grid min-w-0 gap-4 rounded-[28px] border border-white/10 bg-black/25 p-4 sm:p-5 lg:grid-cols-[minmax(0,1.3fr)_minmax(280px,0.7fr)]">
          <div className="min-w-0">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-cyan-200">StormIntel demo</p>
            <h2 className="mt-2 text-3xl font-semibold text-white">Flood and sandbag opportunity review</h2>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-300">
              StormIntel helps FalconTrust identify flood, hurricane, surge, and sandbag opportunities from read-only public weather alerts, then packages them for human review. Live NWS/public alerts can change as weather conditions change; Demo Fallback mode keeps a stable labeled demo path available.
            </p>
          </div>
          <div className="min-w-0 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-300">
            <p className="font-semibold text-white">Current feed</p>
            <p className="mt-2">{feed?.notice ?? (loading ? "Loading read-only public alert feed..." : "Feed unavailable")}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <SourceBadge sourceType={feed?.source === "live" ? "live" : "fallback"} label={feed?.source === "live" ? "Live NWS/Public Alert" : "Demo Fallback"} />
              <Pill>{feedMode === "fallback" ? "Stable demo mode" : "Auto live mode"}</Pill>
              <Pill>{feed?.liveCount ?? 0} live</Pill>
              <Pill>{feed?.fallbackCount ?? 0} fallback</Pill>
            </div>
            <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-3 text-xs leading-5 text-slate-300">
              <p className="font-semibold text-white">Data provenance</p>
              <p className="mt-1">Alerts are either live public NWS records or labeled demo fallback events. Named officials and publications are curated from public sources when matched; generic target categories are seeded demo guidance.</p>
            </div>
          </div>
        </section>

        <section className="grid min-w-0 gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]">
          <div className="min-w-0 space-y-4">
            <div className="glass-panel rounded-[28px] p-5">
              <div className="grid gap-3">
                <label className="grid gap-2 text-sm font-semibold text-slate-200">
                  Search events
                  <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Search flood, tampa, county, officials, media..."
                    className="h-11 rounded-xl border border-white/10 bg-black/30 px-3 text-sm text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/60"
                  />
                </label>
                <div className="grid gap-4 md:grid-cols-2">
                  <SelectControl label="Feed mode" value={feedMode} onChange={(value) => setFeedMode(value as FeedMode)}>
                    <option value="auto">Auto live/fallback</option>
                    <option value="fallback">Demo fallback</option>
                  </SelectControl>
                  <SelectControl label="Source" value={sourceFilter} onChange={(value) => setSourceFilter(value as SourceFilter)}>
                    <option value="all">All sources</option>
                    <option value="live">Live only</option>
                    <option value="fallback">Fallback only</option>
                  </SelectControl>
                  <SelectControl label="Status" value={statusFilter} onChange={(value) => setStatusFilter(value as StatusFilter)}>
                    <option value="all">All statuses</option>
                    {stormIntelStatuses.map((status) => (
                      <option key={status.id} value={status.id}>
                        {status.label}
                      </option>
                    ))}
                  </SelectControl>
                  <SelectControl label="Event type" value={eventFilter} onChange={(value) => setEventFilter(value as EventFilter)}>
                    <option value="all">All event types</option>
                    {eventTypes.map((type) => (
                      <option key={type} value={type}>
                        {eventTypeLabel(type)}
                      </option>
                    ))}
                  </SelectControl>
                </div>
                <button type="button" onClick={clearFilters} className="h-10 rounded-xl border border-white/10 bg-white/5 px-3 text-sm font-semibold text-slate-200 transition hover:border-cyan-300/45 hover:text-white">
                  Clear search and filters
                </button>
              </div>
            </div>

            {loading ? (
              <div className="rounded-[24px] border border-white/10 bg-black/25 p-5 text-sm text-slate-300">Loading StormIntel packets...</div>
            ) : error ? (
              <div className="rounded-[24px] border border-amber-300/30 bg-amber-300/10 p-5 text-sm text-amber-100">{error}</div>
            ) : filteredPackets.length === 0 ? (
              <div className="rounded-[24px] border border-white/10 bg-black/25 p-5 text-sm text-slate-300">No packets match the current filters.</div>
            ) : (
              <div className="space-y-3">
                {filteredPackets.map((packet) => {
                  const active = selected?.id === packet.id;
                  return (
                    <button
                      key={packet.id}
                      type="button"
                      onClick={() => setSelectedId(packet.id)}
                      className={`w-full rounded-[24px] border p-4 text-left transition ${
                        active ? "border-cyan-300/50 bg-cyan-300/12 shadow-lg shadow-cyan-950/20" : "border-white/10 bg-black/25 hover:border-cyan-300/35 hover:bg-white/8"
                      }`}
                    >
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <div className="flex flex-wrap gap-2">
                            <SourceBadge sourceType={packet.sourceType} label={packet.sourceLabel} />
                            <Pill>{eventTypeLabel(packet.eventType)}</Pill>
                          </div>
                          <h3 className="mt-2 font-semibold text-white">{packet.title}</h3>
                          <p className="mt-2 text-sm text-slate-300">{packet.impactedRegion}</p>
                        </div>
                        <StatusBadge status={statuses[packet.id] ?? packet.initialStatus} />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {selected ? (
            <StormIntelDetail selected={selected} status={statuses[selected.id] ?? selected.initialStatus} onStatusChange={(status) => updateStatus(selected.id, status)} onBackToList={() => setSelectedId(filteredPackets[0]?.id ?? packets[0]?.id ?? "")} />
          ) : (
            <article className="glass-panel rounded-[32px] p-6 text-sm text-slate-300">Select an event to open its review packet.</article>
          )}
        </section>
      </div>
    </main>
  );
}

function StormIntelDetail({ selected, status, onStatusChange, onBackToList }: { selected: StormIntelPacket; status: StormIntelStatus; onStatusChange: (status: StormIntelStatus) => void; onBackToList: () => void }) {
  const targetGeography = selected.stateRegion || selected.impactedRegion || "this alert geography";
  const hasVerifiedTargets = Boolean(selected.verifiedTargets);

  return (
    <article className="glass-panel glow-ring rounded-[32px] p-5 md:p-6">
      <div className="flex flex-col gap-4 border-b border-white/10 pb-5 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="flex flex-wrap gap-2">
            <SourceBadge sourceType={selected.sourceType} label={selected.sourceLabel} />
            <Pill>{eventTypeLabel(selected.eventType)}</Pill>
          </div>
          <h2 className="mt-3 text-3xl font-semibold text-white">{selected.title}</h2>
          <p className="mt-2 text-sm text-slate-400">{selected.sourceStatus}</p>
          {selected.sourceUrl ? (
            <a href={selected.sourceUrl} target="_blank" rel="noreferrer" className="mt-3 inline-flex rounded-full border border-cyan-300/30 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:border-cyan-300/60">
              Open NWS source
            </a>
          ) : null}
        </div>
        <div className="flex flex-wrap gap-2">
          <Pill>{selected.severity} severity</Pill>
          <Pill>{selected.confidence} confidence</Pill>
          <Pill>{selected.urgency} urgency</Pill>
        </div>
      </div>

      <section className="mt-5 grid gap-4 lg:grid-cols-3">
        <InfoCard label="Affected state/region" value={selected.stateRegion} />
        <InfoCard label="Expected timing" value={selected.expectedTiming} />
        <InfoCard label="Sandbag relevance" value={selected.sandbagRelevance} />
      </section>

      <section className="mt-5 rounded-[24px] border border-white/10 bg-black/25 p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-200">Human review status</p>
            <p className="mt-1 text-sm text-slate-300">Client-local UI state only. No workflow, outreach, email, or persistence is implemented.</p>
          </div>
          <StatusBadge status={status} />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {stormIntelStatuses.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onStatusChange(item.id)}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                status === item.id ? "border-cyan-300/60 bg-cyan-300/20 text-cyan-50" : "border-white/10 bg-white/5 text-slate-300 hover:border-cyan-300/35 hover:text-white"
              }`}
            >
              {item.label}
            </button>
          ))}
          <span className="rounded-full border border-amber-300/25 bg-amber-300/10 px-3 py-1.5 text-xs font-semibold text-amber-100">{futureOnlyStatus} - future use only</span>
        </div>
      </section>

      <section className="mt-5 rounded-[24px] border border-white/10 bg-black/25 p-4">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-200">County-first impact map</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {selected.counties.map((county, index) => (
            <div key={`${county.name}-${index}`} className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <h3 className="font-semibold text-white">{county.name}</h3>
              <p className="mt-2 text-sm text-slate-300">Cities/municipalities: {county.cities.join(", ")}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-5 rounded-[24px] border border-emerald-300/20 bg-emerald-300/8 p-4">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-200">Recommended FalconTrust angle</p>
        <p className="mt-2 text-sm leading-6 text-emerald-50">{selected.recommendedAngle}</p>
      </section>

      <section className="mt-5 grid gap-4 lg:grid-cols-2">
        <VerifiedOfficialsPanel officials={selected.verifiedTargets?.officials ?? []} targetsLabel={selected.verifiedTargets?.regionLabel} lastChecked={selected.verifiedTargets?.lastChecked} targetGeography={targetGeography} />
        <VerifiedPublicationsPanel publications={selected.verifiedTargets?.publications ?? []} targetsLabel={selected.verifiedTargets?.regionLabel} lastChecked={selected.verifiedTargets?.lastChecked} targetGeography={targetGeography} />
        <ListPanel title="Fallback official categories" subtitle={selected.officials.sourceLabel} items={[...selected.officials.tier1, ...selected.officials.tier2]} />
        <ListPanel title="Fallback publication/media categories" subtitle="Seeded demo guidance, not verified records" items={selected.publicationTargets} />
        <div className="rounded-[24px] border border-white/10 bg-black/25 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-200">Boundary note</p>
          <p className="mt-2 text-sm leading-6 text-slate-300">
            Verified targets are sourced from public pages when available. Fallback categories are seeded demo guidance, not verified records. No outreach, publishing, email, scraping at scale, model API call, or external automation is implemented.
          </p>
          {!hasVerifiedTargets ? (
            <p className="mt-3 rounded-2xl border border-amber-300/20 bg-amber-300/10 p-3 text-sm leading-6 text-amber-50">
              No verified public-source targets are loaded yet for {targetGeography}. Showing seeded fallback targeting categories instead.
            </p>
          ) : null}
          {selected.verifiedTargets ? <p className="mt-3 text-xs leading-5 text-slate-400">{selected.verifiedTargets.sourceNote}</p> : null}
        </div>
      </section>

      <div className="mt-6 flex flex-wrap gap-3">
        <button type="button" onClick={onBackToList} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-slate-100 transition hover:border-cyan-300/45">
          Back to list
        </button>
        <Link href="/addons" className="rounded-full border border-cyan-300/30 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:border-cyan-300/60">
          Back to add-ons
        </Link>
      </div>
    </article>
  );
}

function SelectControl({ label, value, onChange, children }: { label: string; value: string; onChange: (value: string) => void; children: React.ReactNode }) {
  return (
    <label className="grid min-w-0 gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-slate-400">
      {label}
      <select value={value} onChange={(event) => onChange(event.target.value)} className="h-12 w-full min-w-0 rounded-xl border border-white/10 bg-black/30 px-3 pr-9 text-sm normal-case tracking-normal text-white outline-none transition focus:border-cyan-300/60">
        {children}
      </select>
    </label>
  );
}

function StatusBadge({ status }: { status: StormIntelStatus }) {
  const label = stormIntelStatuses.find((item) => item.id === status)?.label ?? status;
  return <span className="w-fit rounded-full border border-cyan-300/25 bg-cyan-300/10 px-3 py-1 text-xs font-semibold text-cyan-100">{label}</span>;
}

function SourceBadge({ sourceType, label }: { sourceType: StormIntelSourceType; label: string }) {
  const className =
    sourceType === "live"
      ? "border-emerald-300/35 bg-emerald-300/12 text-emerald-100"
      : "border-amber-300/35 bg-amber-300/12 text-amber-100";
  return <span className={`w-fit rounded-full border px-3 py-1 text-xs font-semibold ${className}`}>{label}</span>;
}

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="w-fit rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-slate-200">{children}</span>;
}

function InfoCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[22px] border border-white/10 bg-black/25 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">{label}</p>
      <p className="mt-2 text-sm leading-6 text-slate-100">{value}</p>
    </div>
  );
}

function VerifiedOfficialsPanel({ officials, targetsLabel, lastChecked, targetGeography }: { officials: StormIntelVerifiedOfficial[]; targetsLabel?: string; lastChecked?: string; targetGeography: string }) {
  return (
    <div className="rounded-[24px] border border-emerald-300/20 bg-black/25 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-emerald-200">Curated public-source officials</p>
      <h3 className="mt-1 font-semibold text-white">{targetsLabel ?? `No verified targets loaded yet for ${targetGeography}`}</h3>
      {lastChecked ? <p className="mt-1 text-xs text-slate-400">Last checked: {lastChecked}</p> : null}
      {officials.length > 0 ? (
        <div className="mt-3 space-y-3">
          {officials.map((official) => (
            <div key={`${official.name}-${official.jurisdiction}`} className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-semibold text-white">{official.name}</h4>
                <ConfidenceBadge confidence={official.confidence} />
              </div>
              <p className="mt-1 text-sm text-slate-300">{official.title}</p>
              <p className="mt-1 text-xs text-slate-400">
                {official.jurisdiction} - {official.category}
              </p>
              <a href={official.sourceUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex text-xs font-semibold text-cyan-200 underline-offset-4 hover:underline">
                Source
              </a>
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-sm leading-6 text-slate-300">
          No verified public-source officials are loaded yet for {targetGeography}. Showing seeded fallback official categories below for review guidance.
        </p>
      )}
    </div>
  );
}

function VerifiedPublicationsPanel({ publications, targetsLabel, lastChecked, targetGeography }: { publications: StormIntelVerifiedPublication[]; targetsLabel?: string; lastChecked?: string; targetGeography: string }) {
  return (
    <div className="rounded-[24px] border border-emerald-300/20 bg-black/25 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-emerald-200">Curated public-source publications/media</p>
      <h3 className="mt-1 font-semibold text-white">{targetsLabel ?? `No verified publications/media loaded yet for ${targetGeography}`}</h3>
      {lastChecked ? <p className="mt-1 text-xs text-slate-400">Last checked: {lastChecked}</p> : null}
      {publications.length > 0 ? (
        <div className="mt-3 space-y-3">
          {publications.map((publication) => (
            <div key={publication.name} className="rounded-2xl border border-white/10 bg-white/5 p-3">
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="font-semibold text-white">{publication.name}</h4>
                <ConfidenceBadge confidence={publication.confidence} />
              </div>
              <p className="mt-1 text-sm text-slate-300">{publication.type}</p>
              <p className="mt-1 text-xs text-slate-400">Region served: {publication.regionServed}</p>
              <a href={publication.sourceUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex text-xs font-semibold text-cyan-200 underline-offset-4 hover:underline">
                Source
              </a>
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-sm leading-6 text-slate-300">
          No verified public-source publications/media are loaded yet for {targetGeography}. Showing seeded fallback publication/media categories below for review guidance.
        </p>
      )}
    </div>
  );
}

function ConfidenceBadge({ confidence }: { confidence: StormIntelTargetConfidence }) {
  const label = confidence
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
  const className =
    confidence === "verified"
      ? "border-emerald-300/35 bg-emerald-300/12 text-emerald-100"
      : confidence === "likely"
        ? "border-cyan-300/35 bg-cyan-300/12 text-cyan-100"
        : "border-amber-300/35 bg-amber-300/12 text-amber-100";
  return <span className={`w-fit rounded-full border px-2.5 py-1 text-[11px] font-semibold ${className}`}>{label}</span>;
}

function ListPanel({ title, subtitle, items }: { title: string; subtitle: string; items: string[] }) {
  return (
    <div className="rounded-[24px] border border-white/10 bg-black/25 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-cyan-200">{subtitle}</p>
      <h3 className="mt-1 font-semibold text-white">{title}</h3>
      <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-300">
        {items.map((item) => (
          <li key={item} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
