"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { FalconNav } from "@/components/FalconNav";

type Domain = { id: string; name: string; description: string };
type DocumentSummary = {
  id: string;
  title: string;
  domain: string;
  path: string;
  source?: "static" | "uploaded";
  sourceFileName?: string;
  uploadedAt?: string;
  canDelete?: boolean;
  chunkCount: number;
  canonicalChunkCount?: number;
  indexedChunkCount?: number;
  indexed?: boolean;
};
type CorpusInventory = { backend: string; documentCount: number; chunkCount: number; namespace?: string; notes?: string[] };
type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  apiKey?: string;
  apiKeyConfigured: boolean;
  apiKeyMasked: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};
type EmbeddingStatus = {
  config: { provider: "bedrock"; region: string; model: string; enabled: boolean };
  vectorStore: "s3-json";
  indexPath: string;
  chunkCount: number;
  vectorCount: number;
  staleCount: number;
  lastIndexedAt?: string;
  ready: boolean;
  backend?: string;
  activeIndexKey?: string;
  displayMode?: "active-backend" | "chunk-index-match";
  notes?: string[];
};
type IndexingResult = { status: "completed" | "failed"; error?: string; embeddingStatus?: EmbeddingStatus };
type ReindexJob = {
  id: string;
  mode: "dry-run" | "candidate";
  state: "queued" | "running" | "completed" | "failed";
  chunkCount?: number;
  vectorCount?: number;
  distinctDocumentCount?: number;
  distinctChunkCount?: number;
  error?: string;
};

type AdminSession = {
  id: string;
  mode: string;
  query: string;
  selectedDomains: string[];
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: { title: string; domain: string; snippet: string; score: number }[];
  createdAt: string;
};

const freshFetchOptions: RequestInit = { cache: "no-store" };
const uploadStatusRefreshMs = 3000;
const uploadSettleRefreshes = 3;
const uploadIndexingWatchMs = 10 * 60 * 1000;

export default function AdminPage() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [corpusInventory, setCorpusInventory] = useState<CorpusInventory | null>(null);
  const [history, setHistory] = useState<AdminSession[]>([]);
  const [adminLoading, setAdminLoading] = useState(true);
  const [uploadDomain, setUploadDomain] = useState("law");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [deletingDocumentId, setDeletingDocumentId] = useState<string | null>(null);
  const [documentMessage, setDocumentMessage] = useState<string | null>(null);
  const [newDomainName, setNewDomainName] = useState("");
  const [newDomainDescription, setNewDomainDescription] = useState("");
  const [domainMessage, setDomainMessage] = useState<string | null>(null);
  const [addingDomain, setAddingDomain] = useState(false);
  const [articleConfig, setArticleConfig] = useState<ArticleConfig | null>(null);
  const [embeddingStatus, setEmbeddingStatus] = useState<EmbeddingStatus | null>(null);
  const [articleMessage, setArticleMessage] = useState<string | null>(null);
  const [modelApiKeyInput, setModelApiKeyInput] = useState("");
  const [showAllDocuments, setShowAllDocuments] = useState(false);
  const [savingArticle, setSavingArticle] = useState(false);
  const [reindexing, setReindexing] = useState(false);
  const [reindexJob, setReindexJob] = useState<ReindexJob | null>(null);
  const [embeddingMessage, setEmbeddingMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const uploadRefreshTimer = useRef<number | null>(null);

  async function loadAdmin() {
    const snapshotId = Date.now();
    const [corpusRes, historyRes, configRes, embeddingsRes] = await Promise.all([
      fetch(`/api/corpus?adminSnapshot=${snapshotId}`, freshFetchOptions),
      fetch("/api/admin/history", freshFetchOptions),
      fetch("/api/admin/article-config", freshFetchOptions),
      fetch(`/api/admin/embeddings?adminSnapshot=${snapshotId}`, freshFetchOptions),
    ]);
    if (!corpusRes.ok) throw new Error("Failed to load corpus");
    if (!historyRes.ok) throw new Error("Failed to load history");
    if (!configRes.ok) throw new Error("Failed to load article config");
    if (!embeddingsRes.ok) throw new Error("Failed to load embedding status");
    const corpus = await corpusRes.json();
    const historyData = await historyRes.json();
    const configData = await configRes.json();
    const embeddingsData = await embeddingsRes.json();
    setDomains(corpus.domains);
    setDocuments(corpus.documents);
    setCorpusInventory(corpus.inventory ?? null);
    if (!corpus.domains.some((domain: Domain) => domain.id === uploadDomain)) setUploadDomain(corpus.domains[0]?.id ?? "law");
    setHistory(historyData.sessions);
    setArticleConfig(configData.config);
    setEmbeddingStatus(embeddingsData.status);
    return { documents: corpus.documents as DocumentSummary[], embeddingStatus: embeddingsData.status as EmbeddingStatus };
  }

  function stopUploadStatusRefresh() {
    if (uploadRefreshTimer.current === null) return;
    window.clearInterval(uploadRefreshTimer.current);
    uploadRefreshTimer.current = null;
  }

  function startUploadStatusRefresh() {
    stopUploadStatusRefresh();
    uploadRefreshTimer.current = window.setInterval(() => {
      loadAdmin().catch((err) => console.warn("Upload status refresh failed", err));
    }, uploadStatusRefreshMs);
  }

  async function refreshAdminAfterUpload() {
    for (let attempt = 0; attempt < uploadSettleRefreshes; attempt += 1) {
      if (attempt > 0) await sleep(1000);
      await loadAdmin();
    }
  }

  async function watchUploadIndexing(): Promise<"complete" | "timeout" | "unknown"> {
    const deadline = Date.now() + uploadIndexingWatchMs;
    let sawPending = false;
    while (Date.now() < deadline) {
      const snapshot = await loadAdmin();
      const pending = snapshot.documents.some((document) => documentIndexStatus(document).state === "indexing");
      if (!pending) return "complete";
      sawPending = true;
      await sleep(uploadStatusRefreshMs);
    }
    return sawPending ? "timeout" : "unknown";
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadAdmin()
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize admin"))
        .finally(() => setAdminLoading(false));
    }, 0);
    return () => {
      window.clearTimeout(timer);
      stopUploadStatusRefresh();
    };
  }, []);

  const totalChunks = useMemo(() => documents.reduce((sum, doc) => sum + expectedDocumentChunks(doc), 0), [documents]);
  const totalDocuments = documents.length;
  const embeddingDetail = embeddingStatus?.displayMode === "active-backend"
    ? `${totalChunks} canonical chunks; active backend has ${embeddingStatus.vectorCount} vector records`
    : embeddingStatus?.ready ? "Index is current" : `${embeddingStatus?.staleCount ?? 0} chunks need indexing`;
  const vectorMetricValue = embeddingStatus?.displayMode === "active-backend"
    ? String(embeddingStatus.vectorCount)
    : embeddingStatus ? `${embeddingStatus.vectorCount}/${embeddingStatus.chunkCount}` : "0";
  const visibleDocuments = showAllDocuments ? documents : documents.slice(0, 5);
  const hiddenDocumentCount = Math.max(documents.length - visibleDocuments.length, 0);

  async function saveArticleConfig(event: React.FormEvent) {
    event.preventDefault();
    if (!articleConfig) return;
    setSavingArticle(true);
    setError(null);
    setArticleMessage(null);
    try {
      const res = await fetch("/api/admin/article-config", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...articleConfig, apiKey: modelApiKeyInput }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setArticleConfig(data.config);
      setModelApiKeyInput("");
      setArticleMessage("Settings saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save article config");
    } finally {
      setSavingArticle(false);
    }
  }


  async function reindexEmbeddings() {
    setReindexing(true);
    setError(null);
    setEmbeddingMessage(null);
    try {
      const res = await fetch("/api/admin/embeddings/jobs", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ mode: "dry-run" }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      const job = await waitForReindexJob(data.job);
      setReindexJob(job);
      setEmbeddingMessage(`Safe reindex dry-run ${job.state}. ${typeof job.chunkCount === "number" ? `${job.chunkCount} chunks in scope.` : ""}`);
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to start safe reindex dry-run");
    } finally {
      setReindexing(false);
    }
  }

  async function waitForReindexJob(initialJob: ReindexJob) {
    let job = initialJob;
    setReindexJob(job);
    for (let attempt = 0; attempt < 20 && (job.state === "queued" || job.state === "running"); attempt += 1) {
      await new Promise((resolve) => window.setTimeout(resolve, 500));
      const res = await fetch(`/api/admin/embeddings/jobs?id=${encodeURIComponent(job.id)}`, freshFetchOptions);
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      job = data.job;
      setReindexJob(job);
    }
    return job;
  }

  async function submitDomain(event: React.FormEvent) {
    event.preventDefault();
    setAddingDomain(true);
    setError(null);
    setDomainMessage(null);
    try {
      const res = await fetch("/api/admin/domains", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: newDomainName, description: newDomainDescription }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setDomains(data.domains);
      setUploadDomain(data.domain.id);
      setNewDomainName("");
      setNewDomainDescription("");
      setDomainMessage(`${data.domain.name} added. You can upload documents to it now; refresh Search to see it there.`);
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to add domain");
    } finally {
      setAddingDomain(false);
    }
  }

  async function submitUpload(event: React.FormEvent) {
    event.preventDefault();
    if (!uploadFile) {
      setUploadMessage("Choose a text-based PDF first.");
      return;
    }
    setUploading(true);
    setError(null);
    setUploadMessage("Uploading and indexing. Large PDFs can take several minutes; status will refresh automatically.");
    startUploadStatusRefresh();
    try {
      const form = new FormData();
      form.set("domain", uploadDomain);
      form.set("file", uploadFile);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      const indexing = data.indexing as IndexingResult | undefined;
      if (indexing?.embeddingStatus) setEmbeddingStatus(indexing.embeddingStatus);
      const title = data.document.title;
      setUploadMessage(indexingMessage("Uploaded", title, indexing));
      setUploadFile(null);
      await refreshAdminAfterUpload().catch((refreshError) => {
        console.warn("Upload completion refresh failed", refreshError);
        setUploadMessage(`${indexingMessage("Uploaded", title, indexing)} Refresh the admin snapshot if counters still look stale.`);
      });
      const settled = await watchUploadIndexing();
      setUploadMessage(uploadSettledMessage(title, settled));
      if (settled === "complete") setError(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Upload failed";
      if (!isUploadConfirmationInterruption(err)) {
        setError(message);
        setUploadMessage(`Upload failed: ${message}`);
        return;
      }

      setError(null);
      setUploadMessage("Upload confirmation was interrupted. Checking the latest document list and vector counts before you retry.");
      await refreshAdminAfterUpload().catch((refreshError) => {
        console.warn("Upload recovery refresh failed", refreshError);
      });
      const settled = await watchUploadIndexing();
      setUploadMessage(uploadInterruptedMessage(settled));
    } finally {
      stopUploadStatusRefresh();
      setUploading(false);
    }
  }

  async function deleteDocument(document: DocumentSummary) {
    if (!document.canDelete) return;
    const confirmed = window.confirm(`Delete "${document.title}" from the admin corpus? Reindexing will run afterward.`);
    if (!confirmed) return;
    setDeletingDocumentId(document.id);
    setError(null);
    setDocumentMessage(null);
    try {
      const res = await fetch(`/api/admin/documents?id=${encodeURIComponent(document.id)}`, { method: "DELETE" });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      const indexing = data.indexing as IndexingResult | undefined;
      if (indexing?.embeddingStatus) setEmbeddingStatus(indexing.embeddingStatus);
      setDocumentMessage(indexingMessage("Deleted", document.title, indexing));
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setDeletingDocumentId(null);
    }
  }

  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto w-full max-w-7xl px-5 py-5 lg:px-10 lg:py-8">
        <FalconNav active="admin" title="Admin Panel" />

        {error && <div className="mb-6 rounded-2xl border border-red-400/30 bg-red-400/10 p-4 text-red-100">{error}</div>}

        <section className="grid gap-4 md:grid-cols-3">
          <Metric label="Domains" value={adminLoading ? "Loading…" : String(domains.length)} detail="Selectable search scopes" />
          <Metric label="Documents" value={adminLoading ? "Loading…" : String(totalDocuments)} detail="Canonical corpus records" />
          <Metric label="Chunks" value={adminLoading ? "Loading…" : String(totalChunks)} detail={corpusInventory?.backend ? `${corpusInventory.backend} has ${corpusInventory.chunkCount} active chunks` : "Retrieved citation units"} />
        </section>

        <section className="mt-6 grid gap-6 xl:grid-cols-3">
          <div className="space-y-6">
            <form onSubmit={submitUpload} className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Local corpus management</p>
              <h2 className="mt-2 text-2xl font-semibold text-white">Upload text-based PDF</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">Files are extracted into the uploaded corpus and only the uploaded document is embedded into the vector index. Use simple text-based PDFs; scanned/image-only PDFs are intentionally out of scope for this limited demo.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-[0.8fr_1.2fr] xl:grid-cols-1">
                <select value={uploadDomain} onChange={(event) => setUploadDomain(event.target.value)} className="rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50">
                  {domains.map((domain) => <option key={domain.id} value={domain.id}>{domain.name}</option>)}
                </select>
                <input type="file" accept="application/pdf,.pdf" onChange={(event) => setUploadFile(event.target.files?.[0] ?? null)} className="rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-slate-200 file:mr-4 file:rounded-full file:border-0 file:bg-gradient-to-r file:from-cyan-300 file:to-violet-400 file:px-3 file:py-1 file:text-sm file:font-semibold file:text-slate-950" />
              </div>
              <button type="submit" disabled={uploading} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                {uploading ? "Extracting and indexing PDF..." : "Upload and index PDF"}
              </button>
              {uploadMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{uploadMessage}</p>}
            </form>

            <div className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Domains</p>
              <form onSubmit={submitDomain} className="mt-5 rounded-2xl border border-cyan-300/20 bg-cyan-300/8 p-4">
                <h3 className="font-semibold text-white">Add domain</h3>
                <p className="mt-1 text-sm leading-6 text-slate-300">Create a new searchable category, then upload PDFs to it above.</p>
                <div className="mt-4 grid gap-3">
                  <Field label="Domain name" value={newDomainName} placeholder="Permits" required onChange={setNewDomainName} />
                  <TextAreaField label="Description" value={newDomainDescription} placeholder="What this domain covers for search and article grounding" required onChange={setNewDomainDescription} />
                </div>
                <button type="submit" disabled={addingDomain} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                  {addingDomain ? "Adding domain..." : "Add domain"}
                </button>
                {domainMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{domainMessage}</p>}
              </form>
              <div className="mt-5 space-y-3">
                {domains.map((domain) => {
                  const domainDocs = documents.filter((doc) => doc.domain === domain.id);
                  const chunks = domainDocs.reduce((sum, doc) => sum + expectedDocumentChunks(doc), 0);
                  return (
                    <article key={domain.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold text-white">{domain.name}</h3>
                          <p className="mt-1 text-sm leading-6 text-slate-300">{domain.description}</p>
                        </div>
                        <div className="text-right text-sm text-slate-300"><div>{domainDocs.length} docs</div><div>{chunks} chunks</div></div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {articleConfig && (
              <form onSubmit={saveArticleConfig} className="glass-panel glow-ring rounded-[28px] border border-cyan-400/20 bg-cyan-400/8 p-6">
                <p className="text-sm uppercase tracking-[0.2em] text-cyan-200">Model configurator</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">LLM model settings</h2>
                <p className="mt-2 text-sm leading-6 text-slate-300">Connection settings for generated answers. API keys are stored server-side and only shown here as masked status.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                  <Field label="Provider" value={articleConfig.provider} onChange={() => undefined} />
                  <Field label="LLM endpoint" value={articleConfig.endpoint} placeholder="https://..." onChange={(value) => setArticleConfig({ ...articleConfig, endpoint: value })} />
                  <Field label="Model" value={articleConfig.model} placeholder="gpt-oss:120b-cloud" onChange={(value) => setArticleConfig({ ...articleConfig, model: value })} />
                  <SecretField label="API key" value={modelApiKeyInput} maskedValue={articleConfig.apiKeyMasked} configured={articleConfig.apiKeyConfigured} onChange={setModelApiKeyInput} onClear={() => setModelApiKeyInput("__CLEAR_API_KEY__")} />
                </div>
                <div className="mt-4 rounded-2xl border border-white/10 bg-black/25 p-4 text-sm leading-6 text-slate-300">
                  Currently used for <span className="font-semibold text-white">Create Article</span>. Retrieval embeddings are configured separately in the S3 Vector Store card.
                </div>
                <button type="submit" disabled={savingArticle} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                  {savingArticle ? "Saving model settings..." : "Save model settings"}
                </button>
                {articleMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{articleMessage}</p>}
              </form>
            )}

            {articleConfig && (
              <form onSubmit={saveArticleConfig} className="glass-panel rounded-[28px] border border-violet-400/20 bg-violet-400/8 p-6">
                <p className="text-sm uppercase tracking-[0.2em] text-violet-200">Article configurator</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">Create Article settings</h2>
                <p className="mt-2 text-sm leading-6 text-slate-300">Controls article shape and editorial guidance. Model connection details live in the Model Configurator above.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                  <Field label="Audience" value={articleConfig.audience} onChange={(value) => setArticleConfig({ ...articleConfig, audience: value })} />
                  <Field label="Tone" value={articleConfig.tone} onChange={(value) => setArticleConfig({ ...articleConfig, tone: value })} />
                  <label className="text-sm text-slate-300">
                    Length
                    <select value={articleConfig.length} onChange={(event) => setArticleConfig({ ...articleConfig, length: event.target.value as ArticleConfig["length"] })} className="mt-1 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50">
                      <option value="short">Short</option>
                      <option value="medium">Medium</option>
                      <option value="long">Long</option>
                    </select>
                  </label>
                  <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-slate-200">
                    <input type="checkbox" checked={articleConfig.includeCitations} onChange={(event) => setArticleConfig({ ...articleConfig, includeCitations: event.target.checked })} />
                    Include inline citation markers
                  </label>
                </div>
                <TextAreaField label="Structure" value={articleConfig.structure} onChange={(value) => setArticleConfig({ ...articleConfig, structure: value })} />
                <TextAreaField label="Extra instructions" value={articleConfig.extraInstructions} onChange={(value) => setArticleConfig({ ...articleConfig, extraInstructions: value })} />
                <button type="submit" disabled={savingArticle} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-violet-300 via-sky-300 to-cyan-300 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-violet-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                  {savingArticle ? "Saving article settings..." : "Save article configurator"}
                </button>
              </form>
            )}
          </div>

          <div className="space-y-6">
            {embeddingStatus && (
              <div className="glass-panel rounded-[28px] border border-emerald-400/20 bg-emerald-400/8 p-6">
                <p className="text-sm uppercase tracking-[0.2em] text-emerald-200">S3 vector store</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">Bedrock embeddings</h2>
                <p className="mt-2 text-sm leading-6 text-slate-300">Uses Amazon Bedrock Titan embeddings and stores chunk vectors as JSON in S3. Upload and delete update only the changed document; the maintenance action below runs a safe Dev verification job, and candidate index promotion remains manual.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                  <Metric label="Vectors" value={vectorMetricValue} detail={embeddingDetail} />
                  <Metric label="Model" value={embeddingStatus.config.model} detail={`${embeddingStatus.config.provider} · ${embeddingStatus.config.region}`} />
                </div>
                <div className="mt-3 space-y-2 rounded-2xl border border-white/10 bg-black/30 p-3 text-xs text-slate-300">
                  <p className="break-all">Index: {embeddingStatus.activeIndexKey ?? embeddingStatus.indexPath}</p>
                  <p>Backend: {embeddingStatus.backend ?? "embedding index"}</p>
                  {embeddingStatus.displayMode === "active-backend" && embeddingStatus.vectorCount !== totalChunks && <p className="text-amber-100">Active vector records can differ from canonical corpus chunks while uploads/deletes settle or if stale vectors remain.</p>}
                  {embeddingStatus.displayMode === "chunk-index-match" && embeddingStatus.staleCount > 0 && <p className="text-amber-100">{embeddingStatus.staleCount} chunks need indexing for this inactive/default status view.</p>}
                </div>
                <p className="mt-3 text-xs leading-5 text-slate-400">Maintenance check is dry-run diagnostics only. It counts reindex scope and does not embed, write vectors, or repair missing chunks.</p>
                <button type="button" onClick={reindexEmbeddings} disabled={reindexing} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-emerald-300 via-cyan-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                  {reindexing ? "Checking safe reindex scope..." : "Maintenance: check reindex scope"}
                </button>
                {reindexJob && <p className="mt-3 rounded-xl border border-cyan-400/20 bg-cyan-400/10 p-3 text-sm text-cyan-100">Job {reindexJob.id}: {reindexJob.state}{typeof reindexJob.chunkCount === "number" ? ` · ${reindexJob.chunkCount} chunks` : ""}</p>}
                {embeddingMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{embeddingMessage}</p>}
              </div>
            )}
          </div>
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-2">
          <div className="glass-panel rounded-[28px] p-6">
            <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Documents</p>
            {documentMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{documentMessage}</p>}
            <div className="mt-5 space-y-3">
              {visibleDocuments.map((doc) => (
                <div key={doc.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-medium text-white">{doc.title}</h3>
                      <p className="mt-1 text-sm text-slate-400">{domainName(domains, doc.domain)} · {expectedDocumentChunks(doc)} canonical chunks</p>
                      <p className="mt-1 text-xs text-slate-500">{documentSourceLabel(doc)}</p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      <span className={`rounded-full border px-3 py-1 text-xs ${documentIndexBadgeClass(doc)}`}>
                        {documentIndexStatus(doc).label}
                      </span>
                      {doc.canDelete && (
                        <button type="button" onClick={() => deleteDocument(doc)} disabled={deletingDocumentId === doc.id} className="rounded-full border border-red-300/25 px-3 py-1 text-xs font-semibold text-red-100 transition hover:bg-red-400/10 disabled:cursor-not-allowed disabled:opacity-60">
                          {deletingDocumentId === doc.id ? "Deleting..." : "Delete"}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              {documents.length > 5 && (
                <button type="button" onClick={() => setShowAllDocuments((value) => !value)} className="w-full rounded-2xl border border-white/10 bg-white/6 px-4 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10">
                  {showAllDocuments ? "Show fewer documents" : `Show ${hiddenDocumentCount} more documents`}
                </button>
              )}
            </div>
          </div>

          <div className="glass-panel rounded-[28px] p-6">
            <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Query history</p>
            <div className="mt-5 space-y-4">
              {history.length === 0 ? <p className="text-sm text-slate-400">No queries recorded yet.</p> : history.slice(0, 8).map((item) => (
                <article key={item.id} className="rounded-3xl border border-white/10 bg-black/30 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div><p className="text-xs uppercase tracking-[0.18em] text-cyan-200">{item.mode}</p><h3 className="mt-1 font-semibold text-white">{item.query}</h3></div>
                    <span className="rounded-full border border-white/10 bg-white/6 px-2 py-1 text-xs text-slate-300">{new Date(item.createdAt).toLocaleTimeString()}</span>
                  </div>
                  <p className="mt-3 text-sm leading-6 text-slate-300">{item.answer}</p>
                </article>
              ))}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({ label, value, placeholder, required, onChange }: { label: string; value: string; placeholder?: string; required?: boolean; onChange: (value: string) => void }) {
  return (
    <label className="text-sm text-slate-300">
      {label}{required && <span className="ml-1 text-red-300" aria-label="required">*</span>}
      <input required={required} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} className="mt-1 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50 placeholder:text-slate-600" />
    </label>
  );
}

function SecretField({ label, value, maskedValue, configured, onChange, onClear }: { label: string; value: string; maskedValue: string; configured: boolean; onChange: (value: string) => void; onClear: () => void }) {
  const displayValue = value === "__CLEAR_API_KEY__" ? "" : value;
  return (
    <label className="text-sm text-slate-300">
      {label}
      <input
        type="password"
        value={displayValue}
        placeholder={configured ? `Configured: ${maskedValue} — leave blank to keep` : "Paste API key; saved value will be masked"}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50 placeholder:text-slate-600"
      />
      <div className="mt-2 flex items-center justify-between gap-3 text-xs text-slate-400">
        <span>{configured ? `Stored key: ${maskedValue}` : "No API key stored"}</span>
        {configured && (
          <button type="button" onClick={onClear} className="rounded-full border border-red-300/20 px-3 py-1 text-red-100 hover:bg-red-400/10">
            Clear key
          </button>
        )}
      </div>
    </label>
  );
}

function TextAreaField({ label, value, placeholder, required, onChange }: { label: string; value: string; placeholder?: string; required?: boolean; onChange: (value: string) => void }) {
  return (
    <label className="mt-4 block text-sm text-slate-300">
      {label}{required && <span className="ml-1 text-red-300" aria-label="required">*</span>}
      <textarea required={required} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} className="mt-1 min-h-24 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm leading-6 text-white outline-none focus:border-cyan-300/50 placeholder:text-slate-600" />
    </label>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="glass-panel rounded-3xl p-5"><p className="text-sm text-slate-400">{label}</p><p className="mt-2 text-3xl font-semibold text-white">{value}</p><p className="mt-2 text-sm text-slate-300">{detail}</p></div>;
}

function domainName(domains: Domain[], id: string) {
  return domains.find((domain) => domain.id === id)?.name ?? id;
}

function expectedDocumentChunks(document: DocumentSummary) {
  return document.canonicalChunkCount ?? document.chunkCount;
}

function indexedDocumentChunks(document: DocumentSummary) {
  if (typeof document.indexedChunkCount === "number") return document.indexedChunkCount;
  if (document.indexed === false) return 0;
  return expectedDocumentChunks(document);
}

function documentIndexStatus(document: DocumentSummary): { state: "indexed" | "indexing" | "mismatch" | "needs-index"; label: string } {
  const expected = expectedDocumentChunks(document);
  const indexed = indexedDocumentChunks(document);

  if (expected > 0 && indexed > expected) return { state: "mismatch", label: "Indexed + extra vectors" };
  if (expected > 0 && indexed > 0 && indexed < expected) return { state: "indexing", label: "Indexing in progress" };
  if (document.source === "uploaded" && document.indexed === false) return { state: "indexing", label: "Indexing in progress" };
  if (document.indexed === false) return { state: "needs-index", label: "Needs index" };
  return { state: "indexed", label: "Indexed" };
}

function documentIndexBadgeClass(document: DocumentSummary) {
  const state = documentIndexStatus(document).state;
  if (state === "indexing") return "border-cyan-300/30 bg-cyan-300/10 text-cyan-100";
  if (state === "mismatch") return "border-violet-300/30 bg-violet-300/10 text-violet-100";
  if (state === "needs-index") return "border-amber-300/30 bg-amber-300/10 text-amber-100";
  return "border-white/10 bg-white/6 text-slate-200";
}

function indexingMessage(action: "Uploaded" | "Deleted", title: string, indexing?: IndexingResult) {
  if (indexing?.status === "completed") return `${action}: ${title}. Indexing completed and vector status was refreshed.`;
  if (indexing?.status === "failed") return `${action}: ${title}. Indexing did not finish: ${indexing.error ?? "unknown error"}`;
  return `${action}: ${title}. Indexing status is unknown; checking the latest backend status.`;
}

function uploadSettledMessage(title: string, settled: "complete" | "timeout" | "unknown") {
  if (settled === "complete") return `Uploaded: ${title}. Document and vector counters have settled.`;
  if (settled === "timeout") return `Uploaded: ${title}. Indexing may still be running; leave this page open or check status again before retrying.`;
  return `Uploaded: ${title}. Check document and vector status before relying on search results.`;
}

function uploadInterruptedMessage(settled: "complete" | "timeout" | "unknown") {
  if (settled === "complete") return "Upload confirmation was interrupted, but backend counters have settled. You can continue without reloading.";
  if (settled === "timeout") return "Upload confirmation was interrupted. Indexing may still be running; check status again before retrying or deleting.";
  return "Upload confirmation was interrupted. Check the document list and vector counts before retrying.";
}

function isUploadConfirmationInterruption(error: unknown) {
  if (!(error instanceof Error)) return false;
  return /failed to fetch|network|abort|timed out|timeout|interrupted/i.test(error.message);
}

function documentSourceLabel(document: DocumentSummary) {
  const source = document.source === "uploaded" ? "Uploaded" : "Seeded fallback";
  const file = document.sourceFileName ? ` · ${document.sourceFileName}` : "";
  const date = document.uploadedAt ? ` · Uploaded ${new Date(document.uploadedAt).toLocaleString()}` : "";
  const expected = expectedDocumentChunks(document);
  const indexedChunks = indexedDocumentChunks(document);
  const status = documentIndexStatus(document).state;
  const indexed = status === "indexed" && expected > 0
    ? ` · indexed ${indexedChunks}/${expected} chunks`
    : status === "mismatch"
      ? ` · active vectors ${indexedChunks}; canonical chunks ${expected}`
      : status === "indexing"
        ? ` · indexing ${indexedChunks}/${expected} chunks`
        : ` · indexed ${indexedChunks}/${expected} chunks`;
  return `${source}${file}${date}${indexed}`;
}

function sleep(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}
