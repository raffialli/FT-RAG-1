import { NextResponse } from "next/server";
import { loadStormIntelFeed } from "@/lib/falcon/stormintel";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const forceFallback = searchParams.get("source") === "fallback" || searchParams.get("mode") === "fallback";
  const feed = await loadStormIntelFeed(forceFallback);

  return NextResponse.json(feed, {
    headers: {
      "Cache-Control": "no-store",
    },
  });
}
