import { NextResponse } from "next/server";
import { publicArticleConfig, readArticleConfig, writeArticleConfig } from "@/lib/falcon/article-config";

export async function GET() {
  return NextResponse.json({ config: publicArticleConfig(await readArticleConfig()) });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const config = await writeArticleConfig(body);
  return NextResponse.json({ config: publicArticleConfig(config) });
}
