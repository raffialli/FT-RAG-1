import { NextResponse } from "next/server";
import { deleteUploadedDocument } from "@/lib/falcon/corpus";
import { removeDocumentEmbeddings } from "@/lib/falcon/embeddings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function DELETE(request: Request) {
  const id = new URL(request.url).searchParams.get("id");
  if (!id) return new NextResponse("Missing document id", { status: 400 });

  const document = await deleteUploadedDocument(id);
  if (!document) return new NextResponse("Uploaded document not found", { status: 404 });

  const indexing = await removeDocumentFromIndex(document.id);
  return NextResponse.json({ document, indexing }, { status: indexing.status === "completed" ? 200 : 202 });
}

async function removeDocumentFromIndex(documentId: string) {
  try {
    const result = await removeDocumentEmbeddings(documentId);
    return { status: "completed" as const, embeddingStatus: result.status, mutation: result };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Embedding reindex failed";
    console.error("Document deleted but incremental embedding removal failed", error);
    return { status: "failed" as const, error: message };
  }
}
