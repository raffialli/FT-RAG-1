import { NextResponse } from "next/server";
import { addDomain, loadDomains, sanitizeDomainId } from "@/lib/falcon/domains";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ domains: await loadDomains() });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const name = typeof body.name === "string" ? body.name : "";
  const description = typeof body.description === "string" ? body.description : "";
  const id = typeof body.id === "string" ? sanitizeDomainId(body.id) : undefined;

  try {
    const result = await addDomain({ name, description, id });
    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    return new NextResponse(error instanceof Error ? error.message : "Failed to add domain", { status: 400 });
  }
}
