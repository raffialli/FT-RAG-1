import { NextResponse } from "next/server";
import { getReindexJob, listReindexJobs, startReindexJob } from "@/lib/falcon/reindex-jobs";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const noStoreHeaders = { "Cache-Control": "no-store, no-cache, max-age=0, must-revalidate" };

export async function GET(request: Request) {
  const id = new URL(request.url).searchParams.get("id");
  if (id) {
    const job = getReindexJob(id);
    if (!job) return NextResponse.json({ error: "Reindex job not found" }, { status: 404, headers: noStoreHeaders });
    return NextResponse.json({ job }, { headers: noStoreHeaders });
  }

  return NextResponse.json({ jobs: listReindexJobs() }, { headers: noStoreHeaders });
}

export async function POST(request: Request) {
  try {
    const input = await request.json().catch(() => ({}));
    const job = startReindexJob({ mode: input.mode, confirm: input.confirm });
    return NextResponse.json({ job }, { status: 202, headers: noStoreHeaders });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to start reindex job";
    return NextResponse.json({ error: message }, { status: 409, headers: noStoreHeaders });
  }
}
