import { NextResponse } from "next/server";
import { getEmbeddingStatus } from "@/lib/falcon/embeddings";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const noStoreHeaders = { "Cache-Control": "no-store, no-cache, max-age=0, must-revalidate" };

export async function GET() {
  return NextResponse.json({ status: await getEmbeddingStatus() }, { headers: noStoreHeaders });
}

export async function POST() {
  return NextResponse.json(
    {
      error: "Synchronous full reindex is disabled. Use /api/admin/embeddings/jobs for dry-run or candidate reindex jobs.",
      status: await getEmbeddingStatus(),
    },
    { status: 409, headers: noStoreHeaders },
  );
}
