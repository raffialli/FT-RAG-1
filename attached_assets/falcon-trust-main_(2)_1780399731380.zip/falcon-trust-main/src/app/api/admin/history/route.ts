import { NextResponse } from "next/server";
import { readHistory } from "@/lib/falcon/history";

export async function GET() {
  return NextResponse.json({ sessions: await readHistory() });
}
