import { NextResponse } from "next/server";
import { ADMIN_COOKIE, AUTH_COOKIE, expectedAdminPassword, expectedAppPassword, verifyPassword } from "@/lib/falcon/auth";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const password = typeof body.password === "string" ? body.password : "";
  const mode = body.mode === "admin" ? "admin" : "app";
  const expected = mode === "admin" ? expectedAdminPassword() : expectedAppPassword();

  if (!(await verifyPassword(password, expected))) {
    return NextResponse.json({ error: "Invalid password" }, { status: 401 });
  }

  const response = NextResponse.json({ ok: true, mode });
  response.cookies.set(mode === "admin" ? ADMIN_COOKIE : AUTH_COOKIE, "1", {
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    path: "/",
    maxAge: 60 * 60 * 8,
  });

  if (mode === "admin") {
    response.cookies.set(AUTH_COOKIE, "1", {
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      path: "/",
      maxAge: 60 * 60 * 8,
    });
  }

  return response;
}
