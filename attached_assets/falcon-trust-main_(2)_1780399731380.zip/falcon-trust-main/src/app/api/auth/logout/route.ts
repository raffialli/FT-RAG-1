import { NextResponse } from "next/server";
import { ADMIN_COOKIE, AUTH_COOKIE } from "@/lib/falcon/auth";

export async function POST() {
  const response = NextResponse.json({ ok: true });
  response.cookies.delete(AUTH_COOKIE);
  response.cookies.delete(ADMIN_COOKIE);
  return response;
}
