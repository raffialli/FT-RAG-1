import { NextResponse } from "next/server";
import { normalizeDomains } from "@/lib/falcon/domains";
import { appendHistory } from "@/lib/falcon/history";
import { buildAnswer } from "@/lib/falcon/retrieval";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const topic = typeof body.topic === "string" ? body.topic.trim() : "";
  if (!topic) return new NextResponse("Missing topic", { status: 400 });

  const selectedDomains = await normalizeDomains(body.domains);
  const session = await appendHistory(await buildAnswer(topic, selectedDomains, "external_compare", "clear_answer", true));
  return NextResponse.json(session);
}
