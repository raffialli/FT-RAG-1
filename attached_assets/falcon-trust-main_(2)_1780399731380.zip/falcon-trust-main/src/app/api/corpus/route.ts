import { NextResponse } from "next/server";
import { chunkDocument, loadDocuments } from "@/lib/falcon/corpus";
import { loadDomains } from "@/lib/falcon/domains";
import { getRetrievalBackend } from "@/lib/falcon/retrieval-backends";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const noStoreHeaders = { "Cache-Control": "no-store, no-cache, max-age=0, must-revalidate" };

export async function GET() {
  const backend = getRetrievalBackend(process.env.FALCON_RETRIEVAL_BACKEND);
  const [domains, allDocuments, backendDocuments, backendChunks, backendInventory] = await Promise.all([
    loadDomains(),
    loadDocuments(),
    backend.listDocuments(),
    backend.listChunks(),
    backend.inventory(),
  ]);

  const backendDocumentIds = new Set(backendDocuments.map((document) => document.id));
  const backendChunkCounts = backendChunks.reduce((counts, chunk) => counts.set(chunk.documentId, (counts.get(chunk.documentId) ?? 0) + 1), new Map<string, number>());
  const backendHasDocuments = backendDocumentIds.size > 0;
  const documents = allDocuments.map((document) => {
    const canonicalChunkCount = chunkDocument(document).length;
    const indexedChunkCount = backendChunkCounts.get(document.id) ?? 0;
    return {
      id: document.id,
      title: document.title,
      domain: document.domain,
      path: document.path,
      source: document.source ?? "static",
      sourceFileName: document.sourceFileName,
      uploadedAt: document.uploadedAt,
      canDelete: document.source === "uploaded",
      chunkCount: indexedChunkCount || canonicalChunkCount,
      canonicalChunkCount,
      indexedChunkCount,
      indexed: backendHasDocuments ? backendDocumentIds.has(document.id) : true,
    };
  });

  return NextResponse.json({ domains, documents, inventory: backendInventory }, { headers: noStoreHeaders });
}
