import { NextResponse } from "next/server";
import { canViewDocument, getDocumentForViewerFromActiveBackend } from "@/lib/falcon/document-viewer";

export async function GET(request: Request) {
  const denied = canViewDocument(request);
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const documentId = searchParams.get("doc")?.trim();
  const chunkId = searchParams.get("chunk")?.trim();
  if (!documentId) return new NextResponse("Missing doc parameter", { status: 400 });

  const document = await getDocumentForViewerFromActiveBackend(documentId, chunkId);
  if (!document) return new NextResponse("Document not found", { status: 404 });

  return NextResponse.json({ document });
}
