import { NextResponse } from "next/server";
import { normalizeDomains } from "@/lib/falcon/domains";
import { generateArticleDraft } from "@/lib/falcon/article-generator";
import { appendHistory } from "@/lib/falcon/history";
import { buildAnswer } from "@/lib/falcon/retrieval";
import { runExternalSearch } from "@/lib/falcon/external-search";
import type { AnswerType } from "@/lib/falcon/types";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const query = typeof body.query === "string" ? body.query.trim() : "";
  if (!query) return new NextResponse("Missing query", { status: 400 });

  const selectedDomains = await normalizeDomains(body.domains);
  const answerType: AnswerType = body.answerType === "create_article" ? "create_article" : "clear_answer";
  const externalSearch = body.externalSearch === true;
  const debug = body.debug === true || body.includeDebug === true;
  const external = externalSearch ? await runExternalSearch(query) : null;
  const base = await buildAnswer(query, selectedDomains, externalSearch ? "external_compare" : "internal_qa", answerType, externalSearch, external?.results ?? []);
  const responseBase = debug ? base : { ...base, debugTrace: undefined };
  const externalWarnings = external?.status.warning ? [`External search warning: ${external.status.warning}`] : [];

  if (answerType === "create_article" && responseBase.citations.length > 0) {
    const generated = await generateArticleDraft({ query, citations: responseBase.citations, fallbackAnswer: responseBase.answer, externalContext: external?.summary });
    const gaps = [
      ...(responseBase.gaps ?? []),
      ...externalWarnings,
      ...("warning" in generated ? [`Article generation warning: ${generated.warning}`] : []),
    ];
    const session = await appendHistory({
      ...responseBase,
      answer: generated.answer,
      answerSections: { answer: generated.answer, gaps },
      generatedBy: generated.generatedBy,
      articleConfig: generated.config,
      externalSearch,
      externalSearchEnabled: externalSearch,
      externalResults: external?.results ?? responseBase.externalResults,
      externalSearchStatus: external?.status,
      gaps,
    });
    return NextResponse.json(session);
  }

  const session = await appendHistory({
    ...responseBase,
    answerSections: responseBase.answerSections ?? {
      answer: responseBase.answer,
      externalContext: external?.summary,
      gaps: [...(responseBase.gaps ?? []), ...externalWarnings],
    },
    externalSearch,
    externalSearchEnabled: externalSearch,
    externalResults: external?.results ?? responseBase.externalResults,
    externalSearchStatus: external?.status,
    gaps: [...(responseBase.gaps ?? []), ...externalWarnings],
  });
  return NextResponse.json(session);
}
