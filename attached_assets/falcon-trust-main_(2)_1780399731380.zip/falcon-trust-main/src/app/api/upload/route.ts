import path from "node:path";
import { NextResponse } from "next/server";
import { PDFParse } from "pdf-parse";
import { writeUploadedDocument } from "@/lib/falcon/corpus";
import { isDomainId } from "@/lib/falcon/domains";
import { indexDocumentEmbeddings } from "@/lib/falcon/embeddings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

PDFParse.setWorker(path.join(process.cwd(), "node_modules", "pdf-parse", "dist", "worker", "pdf.worker.mjs"));

export async function POST(request: Request) {
  const form = await request.formData();
  const domain = form.get("domain");
  const file = form.get("file");

  if (typeof domain !== "string" || !(await isDomainId(domain))) {
    return new NextResponse("Choose a valid domain before uploading", { status: 400 });
  }

  if (!(file instanceof File)) {
    return new NextResponse("Missing PDF file", { status: 400 });
  }

  if (!file.name.toLowerCase().endsWith(".pdf") && file.type !== "application/pdf") {
    return new NextResponse("Only text-based PDF uploads are supported in the limited demo", { status: 400 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const text = await extractPdfText(buffer);

  if (text.length < 40) {
    return new NextResponse("No usable text found. The limited demo supports text-based PDFs only; OCR is out of scope.", {
      status: 422,
    });
  }

  const title = file.name.replace(/\.pdf$/i, "").replace(/[-_]+/g, " ");
  const record = await writeUploadedDocument({ domain, title, text: `# UPLOADED DEMO PDF — ${title}\n\n${text}`, sourceFileName: file.name });
  const indexing = await indexUploadedDocument(record);
  return NextResponse.json({ document: record, indexing }, { status: indexing.status === "completed" ? 201 : 202 });
}

async function indexUploadedDocument(document: Awaited<ReturnType<typeof writeUploadedDocument>>) {
  try {
    const result = await indexDocumentEmbeddings(document);
    return { status: "completed" as const, embeddingStatus: result.status, mutation: result };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Embedding reindex failed";
    console.error("Upload persisted but incremental embedding update failed", error);
    return { status: "failed" as const, error: message };
  }
}

async function extractPdfText(buffer: Buffer) {
  const parsedText = await extractWithPdfParse(buffer);
  if (parsedText.length >= 40) return parsedText;

  const fallbackText = extractSimplePdfLiterals(buffer);
  return fallbackText.length > parsedText.length ? fallbackText : parsedText;
}

async function extractWithPdfParse(buffer: Buffer) {
  try {
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText({ lineEnforce: true, pageJoiner: "\n--- Page page_number of total_number ---" });
      return normalizeExtractedText(result.text);
    } finally {
      await parser.destroy();
    }
  } catch (error) {
    console.error("PDF text extraction failed", error);
    return "";
  }
}

function extractSimplePdfLiterals(buffer: Buffer) {
  // Controlled limited-demo fallback: enough for simple text PDFs generated for the demo.
  // It is not OCR and not a full PDF parser.
  const raw = buffer.toString("latin1");
  const matches = Array.from(raw.matchAll(/\(([^()]{3,})\)\s*Tj/g)).map((match) => decodePdfLiteral(match[1]));
  const arrayMatches = Array.from(raw.matchAll(/\[((?:\s*\([^()]*\)\s*)+)\]\s*TJ/g)).flatMap((match) =>
    Array.from(match[1].matchAll(/\(([^()]*)\)/g)).map((part) => decodePdfLiteral(part[1])),
  );
  return normalizeExtractedText([...matches, ...arrayMatches].join(" "));
}

function decodePdfLiteral(value: string) {
  return value
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\");
}

function normalizeExtractedText(text: string) {
  return text
    .replace(/\u0000/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}
