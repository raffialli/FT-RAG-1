"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";
import { FalconNav } from "@/components/FalconNav";

type ViewerDocument = {
  id: string;
  title: string;
  domain: string;
  sourceLabel: string;
  text: string;
  chunks?: ViewerChunk[] | null;
};

type ViewerChunk = {
  id: string;
  index: number;
  text: string;
  highlighted: boolean;
};

type ViewerState = {
  loading: boolean;
  document: ViewerDocument | null;
  error: string | null;
};

function normalizeText(value: string) {
  return value.replace(/\s+/g, " ").trim().toLowerCase();
}

function splitChunks(text: string, snippet: string | null, selectedChunkId: string | null, selectedChunkIndex: number | null): ViewerChunk[] {
  const snippetNeedle = snippet ? normalizeText(snippet) : null;
  return text
    .split(/\n(?=##\s+)/g)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section, index) => {
      const generatedId = `chunk-${index + 1}`;
      const highlightedBySnippet = snippetNeedle ? normalizeText(section).includes(snippetNeedle) : false;
      const highlightedById = selectedChunkId ? selectedChunkId === generatedId || selectedChunkId.endsWith(`-chunk-${index + 1}`) : false;
      const highlightedByIndex = selectedChunkIndex === index;
      return {
        id: selectedChunkId && (highlightedById || highlightedByIndex) ? selectedChunkId : generatedId,
        index,
        text: section,
        highlighted: highlightedBySnippet || highlightedById || highlightedByIndex,
      };
    });
}

function viewerChunks(document: ViewerDocument, snippet: string | null, selectedChunkId: string | null, selectedChunkIndex: number | null): ViewerChunk[] {
  if (document.chunks?.length) {
    const snippetNeedle = snippet ? normalizeText(snippet) : null;
    return document.chunks.map((chunk) => {
      const highlightedBySnippet = snippetNeedle ? normalizeText(chunk.text).includes(snippetNeedle) : false;
      const highlightedById = selectedChunkId ? chunk.id === selectedChunkId : false;
      const highlightedByIndex = selectedChunkIndex === chunk.index;
      return {
        ...chunk,
        highlighted: chunk.highlighted || highlightedBySnippet || highlightedById || highlightedByIndex,
      };
    });
  }

  return splitChunks(document.text, snippet, selectedChunkId, selectedChunkIndex);
}

function DocumentViewer() {
  const router = useRouter();
  const params = useSearchParams();
  const documentId = params.get("doc");
  const chunkId = params.get("chunk");
  const snippet = params.get("snippet");
  const chunkIndex = params.get("chunkIndex");
  const parsedChunkIndex = chunkIndex !== null && Number.isFinite(Number(chunkIndex)) ? Number(chunkIndex) : null;
  const [viewerState, setViewerState] = useState<ViewerState>({ loading: false, document: null, error: null });

  useEffect(() => {
    if (!documentId) return;

    const controller = new AbortController();

    const apiParams = new URLSearchParams({ doc: documentId });
    if (chunkId) apiParams.set("chunk", chunkId);

    fetch(`/api/documents?${apiParams.toString()}`, { signal: controller.signal })
      .then(async (res) => {
        if (!res.ok) throw new Error(await res.text());
        return res.json() as Promise<{ document: ViewerDocument }>;
      })
      .then((data) => setViewerState({ loading: false, document: data.document, error: null }))
      .catch((err) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setViewerState({ loading: false, document: null, error: err instanceof Error ? err.message : "Failed to load document" });
      });

    return () => controller.abort();
  }, [documentId, chunkId]);

  const document = viewerState.document;
  const chunks = useMemo(
    () => (document ? viewerChunks(document, snippet, chunkId, parsedChunkIndex) : []),
    [document, snippet, chunkId, parsedChunkIndex],
  );

  useEffect(() => {
    const selected = chunks.find((chunk) => chunk.highlighted);
    if (!selected) return;
    window.requestAnimationFrame(() => {
      const node = window.document.getElementById(selected.id);
      node?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }, [chunks]);

  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-5 py-5 lg:px-10 lg:py-8">
        <FalconNav
          active="search"
          title="Document viewer"
          action={
          <button
            type="button"
            onClick={() => {
              if (window.history.length > 1) {
                router.back();
                return;
              }
              router.push("/");
            }}
            className="rounded-full border border-white/10 bg-black/30 px-5 py-2 text-sm text-slate-300 transition hover:bg-white/5 hover:text-white"
          >
            Return to Search
          </button>
          }
        />

        {!document && !viewerState.error && documentId && <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-slate-300">Loading document…</div>}
        {(viewerState.error || !documentId) && <div className="rounded-2xl border border-red-400/30 bg-red-400/10 p-6 text-red-100">{viewerState.error ?? "Missing document id."}</div>}

        {document && !viewerState.error && !viewerState.loading && documentId && (
          <section className="glass-panel rounded-[32px] p-6">
            <div className="border-b border-white/10 pb-5">
              <p className="text-xs uppercase tracking-[0.2em] text-cyan-200">{document.domain}</p>
              <h2 className="mt-2 text-3xl font-semibold text-white">{document.title}</h2>
              <p className="mt-2 text-sm text-slate-400">{document.sourceLabel}</p>
              {snippet && <p className="mt-4 rounded-2xl border border-emerald-300/20 bg-emerald-400/10 p-4 text-sm text-emerald-50">Highlighted because it matches the cited chunk or snippet used in the answer.</p>}
            </div>
            <div className="mt-6 space-y-4">
              {chunks.map((chunk) => (
                <article
                  key={chunk.id}
                  id={chunk.id}
                  className={`rounded-2xl border p-4 whitespace-pre-wrap text-sm leading-7 ${chunk.highlighted ? "border-emerald-300/40 bg-emerald-400/10 shadow-lg shadow-emerald-950/20" : "border-white/10 bg-black/25 text-slate-200"}`}
                >
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <span className="rounded-full bg-white/10 px-3 py-1 text-xs uppercase tracking-[0.18em] text-slate-300">Chunk {chunk.index + 1}</span>
                    {chunk.highlighted && <span className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-200">Referenced in answer</span>}
                  </div>
                  {chunk.text}
                </article>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

function DocumentViewerFallback() {
  return <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-slate-300">Loading document…</div>;
}

export default function DocumentViewerPage() {
  return (
    <Suspense fallback={<DocumentViewerFallback />}>
      <DocumentViewer />
    </Suspense>
  );
}
