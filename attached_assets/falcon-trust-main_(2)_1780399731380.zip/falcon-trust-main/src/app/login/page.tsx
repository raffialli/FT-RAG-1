"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";

function LoginForm() {
  const params = useSearchParams();
  const isAdmin = params.get("admin") === "1" || params.get("next")?.startsWith("/admin");
  const next = params.get("next") || (isAdmin ? "/admin" : "/");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password, mode: isAdmin ? "admin" : "app" }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Login failed");
      window.location.href = next;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-5 text-slate-100">
      <form onSubmit={submit} className="glass-panel glow-ring w-full max-w-md rounded-[32px] p-7 shadow-2xl shadow-black/30">
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-200/90">Falcontrust</p>
        <h1 className="mt-3 text-3xl font-semibold text-white">{isAdmin ? "Admin access" : "Demo access"}</h1>
        <p className="mt-3 text-sm leading-6 text-slate-300">
          {isAdmin
            ? "Enter the admin password to manage uploads, history, and article settings."
            : "Enter the demo password to access the Falcontrust RAG workspace."}
        </p>
        <label className="mt-6 block text-sm font-medium text-slate-200" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          className="mt-2 w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/60"
          autoFocus
        />
        {error ? <p className="mt-4 rounded-2xl border border-rose-300/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">{error}</p> : null}
        <button
          type="submit"
          disabled={loading}
          className="mt-6 w-full rounded-2xl bg-gradient-to-r from-cyan-300 to-violet-400 px-5 py-3 font-semibold text-slate-950 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? "Signing in…" : "Continue"}
        </button>
      </form>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
