"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { FalconNav } from "@/components/FalconNav";

type Domain = {
  id: string;
  name: string;
  description: string;
};

type Citation = {
  documentId: string;
  title: string;
  domain: string;
  snippet: string;
  score: number;
  chunkId?: string;
  chunkIndex?: number;
  viewerUrl?: string;
};

type AnswerType = "clear_answer" | "create_article";

type ExternalSearchResult = {
  title: string;
  url: string;
  snippet: string;
  source: "tavily" | "demo_llm";
  score?: number;
  publishedDate?: string;
};

type ExternalSearchStatus = {
  enabled: boolean;
  provider: "tavily";
  configured: boolean;
  attempted: boolean;
  ok: boolean;
  resultCount: number;
  warning?: string;
};

type AnswerSections = {
  answer: string;
  documentEvidence?: string;
  documentSupportedClaims?: string[];
  generalGuidance?: string[];
  externalContext?: string;
  gaps?: string[];
};

type QueryResponse = {
  id: string;
  query: string;
  selectedDomains: string[];
  externalSearch?: boolean;
  externalSearchEnabled?: boolean;
  answerType: AnswerType;
  answer: string;
  answerSections?: AnswerSections;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  externalResults?: ExternalSearchResult[];
  externalSearchStatus?: ExternalSearchStatus;
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  createdAt: string;
};

type SearchStateSnapshot = {
  query: string;
  selectedDomains: string[];
  answerType: AnswerType;
  externalSearch: boolean;
  result: QueryResponse | null;
};

const searchStateStorageKey = "falcontrust.searchState.v1";

function defaultSearchState(): SearchStateSnapshot {
  return {
    query: "What should we say about sandbag pickup rules before a flood?",
    selectedDomains: ["law", "sandbags"],
    answerType: "clear_answer",
    externalSearch: false,
    result: null,
  };
}

function readStoredSearchState(): SearchStateSnapshot {
  const fallback = defaultSearchState();
  if (typeof window === "undefined") return fallback;

  try {
    const stored = window.sessionStorage.getItem(searchStateStorageKey);
    if (!stored) return fallback;
    const snapshot = JSON.parse(stored) as Partial<SearchStateSnapshot>;
    return {
      query: typeof snapshot.query === "string" ? snapshot.query : fallback.query,
      selectedDomains: Array.isArray(snapshot.selectedDomains) && snapshot.selectedDomains.every((domain) => typeof domain === "string") ? snapshot.selectedDomains : fallback.selectedDomains,
      answerType: snapshot.answerType === "clear_answer" || snapshot.answerType === "create_article" ? snapshot.answerType : fallback.answerType,
      externalSearch: typeof snapshot.externalSearch === "boolean" ? snapshot.externalSearch : fallback.externalSearch,
      result: snapshot.result && typeof snapshot.result === "object" ? normalizeQueryResponse(snapshot.result as QueryResponse) : fallback.result,
    };
  } catch {
    window.sessionStorage.removeItem(searchStateStorageKey);
    return fallback;
  }
}

const examplePrompts = [
  "What is FEMA’s Ready campaign and what are its three key components?",
  "Should emergency managers accept a contractor's standard document as-is to save time?",
  "Which clauses should emergency managers watch for in contractor standard contracts?",
  "In Japan's five-level flood warning system, what should elderly and disabled residents do at Level 3?",
];

export default function Home() {
  const [initialSearchState] = useState<SearchStateSnapshot>(() => readStoredSearchState());
  const initialExternalSearch = initialSearchState.externalSearch || Boolean(initialSearchState.result?.externalSearch || initialSearchState.result?.externalSearchEnabled || initialSearchState.result?.externalResults?.length);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<string[]>(initialSearchState.selectedDomains);
  const [query, setQuery] = useState(initialSearchState.query);
  const [answerType, setAnswerType] = useState<AnswerType>(initialSearchState.answerType);
  const [externalSearch, setExternalSearch] = useState(initialExternalSearch);
  const [result, setResult] = useState<QueryResponse | null>(() => normalizeQueryResponse(initialSearchState.result));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const resultRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const snapshot: SearchStateSnapshot = { query, selectedDomains, answerType, externalSearch, result };
    window.sessionStorage.setItem(searchStateStorageKey, JSON.stringify(snapshot));
  }, [answerType, externalSearch, query, result, selectedDomains]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetch("/api/corpus")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to load domains");
          return res.json();
        })
        .then((data) => {
          setDomains(data.domains);
          setSelectedDomains((current) => {
            const validIds = new Set((data.domains as Domain[]).map((domain) => domain.id));
            const next = current.filter((id) => validIds.has(id));
            return next.length ? next : (data.domains as Domain[]).slice(0, 2).map((domain) => domain.id);
          });
        })
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize demo"));
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  const selectedLabel = useMemo(
    () => selectedDomains.map((id) => domains.find((domain) => domain.id === id)?.name ?? id).join(" + "),
    [domains, selectedDomains],
  );

  useEffect(() => {
    if (!result) return;
    window.requestAnimationFrame(() => {
      resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      resultRef.current?.focus({ preventScroll: true });
    });
  }, [result]);

  function toggleDomain(domainId: string) {
    setSelectedDomains((current) => {
      if (current.includes(domainId)) {
        const next = current.filter((id) => id !== domainId);
        return next.length ? next : current;
      }
      return [...current, domainId];
    });
  }

  async function submitQuery(event?: React.FormEvent) {
    event?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/query", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query, domains: selectedDomains, answerType, externalSearch }),
      });
      if (!res.ok) throw new Error(await res.text());
      const nextResult = await res.json();
      setResult(normalizeQueryResponse(nextResult));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Query failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto flex min-h-screen w-full max-w-6xl flex-col px-5 py-5 lg:px-10 lg:py-8">
        <FalconNav active="search" title="Research Workspace" />

        <section className="mx-auto flex w-full max-w-4xl flex-1 flex-col justify-center gap-8 pb-12">
          <div className="text-center">
            <div className="mx-auto inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.28em] text-cyan-100">
              AWS dev/demo limited demo
            </div>
            <h2 className="gradient-text mt-5 text-4xl font-semibold tracking-tight md:text-6xl">
              Ask Falcontrust documents a question.
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-slate-300 md:text-lg">
              Choose one or more domains, then ask a question or paste an outside topic. Answers stay scoped to the highlighted domains and return cited snippets.
            </p>
          </div>

          <form onSubmit={submitQuery} className="glass-panel glow-ring rounded-[32px] p-4 md:p-5">
            <div className="mb-3 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-cyan-200">Searchable domains</p>
                <p className="mt-1 text-sm text-slate-400">Choose the document domains to include in this RAG search.</p>
              </div>
              <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">
                {selectedDomains.length} selected
              </span>
            </div>
            <div className="mb-4 flex flex-wrap items-center gap-2">
              {domains.map((domain) => {
                const selected = selectedDomains.includes(domain.id);
                return (
                  <button
                    key={domain.id}
                    type="button"
                    onClick={() => toggleDomain(domain.id)}
                    className={`rounded-md border px-3 py-1.5 text-xs font-semibold leading-none transition ${
                      selected
                        ? "border-cyan-300/50 bg-cyan-300/20 text-cyan-50"
                        : "border-white/10 bg-white/5 text-slate-300 hover:border-cyan-300/35 hover:bg-cyan-300/10 hover:text-white"
                    }`}
                    aria-pressed={selected}
                  >
                    {domain.name}
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setExternalSearch((value) => !value)}
                className={`rounded-md border px-3 py-1.5 text-xs font-semibold leading-none transition ${
                  externalSearch
                    ? "border-amber-300/55 bg-amber-300/20 text-amber-50"
                    : "border-amber-300/20 bg-white/5 text-amber-100 hover:border-amber-300/45 hover:bg-amber-300/10 hover:text-amber-50"
                }`}
                aria-pressed={externalSearch}
              >
                External Search
              </button>
            </div>

            <div className="mb-4 flex flex-wrap gap-2 border-t border-white/10 pt-4">
              <AnswerTypeButton
                active={answerType === "clear_answer"}
                title="RAG search"
                description="Search your documents"
                onClick={() => setAnswerType("clear_answer")}
              />
              <AnswerTypeButton
                active={answerType === "create_article"}
                title="Create article"
                description="Draft-style response"
                onClick={() => setAnswerType("create_article")}
              />
            </div>

            <textarea
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="min-h-40 w-full resize-y rounded-3xl border border-white/10 bg-black/35 p-5 text-base leading-7 text-white outline-none ring-cyan-300/30 placeholder:text-slate-500 focus:border-cyan-300/50 focus:ring-4"
              placeholder="Ask a question or paste a link/topic for comparison..."
            />

            <div className="mt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <p className="text-sm text-slate-400">Searching: <span className="font-semibold text-cyan-200">{selectedLabel || "selected domains"}</span>{externalSearch && <span className="font-semibold text-amber-200"> + External Search</span>}</p>
              <button
                type="submit"
                disabled={loading}
                className="rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? "Searching..." : answerType === "create_article" ? "Create article" : "Run RAG search"}
              </button>
            </div>
          </form>

          <div className="flex flex-col items-center gap-2">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Try a tested question</p>
            <div className="flex flex-wrap justify-center gap-2">
              {examplePrompts.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => setQuery(prompt)}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:border-cyan-300/40 hover:bg-white/8 hover:text-white"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {error && <div className="rounded-2xl border border-red-400/30 bg-red-400/10 p-4 text-red-100">{error}</div>}

          {result && <ResultPanel result={result} resultRef={resultRef} />}
        </section>
      </div>
    </main>
  );
}

function generationLabel(value: NonNullable<QueryResponse["generatedBy"]>) {
  if (value === "ollama") return "configured LLM";
  if (value === "template_fallback") return "fallback summary";
  return "retrieved document template";
}

function AnswerTypeButton({ active, title, description, onClick }: { active: boolean; title: string; description: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-2xl border px-4 py-3 text-left transition ${
        active ? "border-cyan-300/60 bg-gradient-to-r from-cyan-300 to-violet-400 text-slate-950 shadow-lg shadow-cyan-950/20" : "border-white/10 bg-slate-950/40 text-slate-300 hover:border-cyan-300/40 hover:text-white"
      }`}
    >
      <span className="block text-sm font-semibold">{title}</span>
      <span className={`block text-xs ${active ? "text-slate-800" : "text-slate-400"}`}>{description}</span>
    </button>
  );
}

function ResultPanel({ result, resultRef }: { result: QueryResponse; resultRef: React.RefObject<HTMLElement | null> }) {
  const resultTitle = result.answerType === "create_article" ? "Article draft" : "RAG search result";
  const sections = getAnswerSections(result);
  const cautionCount = sections.gaps.length;
  const sourceCount = result.citations.length;
  const hasExternalResults = Boolean(result.externalResults && result.externalResults.length > 0);
  const externalSearchWasUsed = Boolean(result.externalSearch || result.externalSearchEnabled || result.externalSearchStatus?.enabled || hasExternalResults || sections.externalContext);
  const hasExternalContext = Boolean(externalSearchWasUsed && (sections.externalContext || hasExternalResults));
  const hasDocumentEvidence = Boolean(sections.documentEvidence || sections.documentSupportedClaims.length > 0);
  const hasGeneralGuidance = sections.generalGuidance.length > 0;
  const [sourcesOpen, setSourcesOpen] = useState(false);

  return (
    <section ref={resultRef} tabIndex={-1} className="glass-panel scroll-mt-6 rounded-[32px] border border-emerald-300/20 bg-emerald-400/8 p-5 shadow-xl shadow-emerald-950/20 outline-none ring-cyan-300/0 transition focus:ring-4 md:p-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">{resultTitle}</p>
          <h3 className="mt-1 text-2xl font-semibold text-white">{result.confidence} confidence</h3>
          {result.generatedBy && <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-300">Generated by {generationLabel(result.generatedBy)}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {result.selectedDomains.map((domain) => (
            <span key={domain} className="rounded-full border border-white/10 bg-slate-950/35 px-3 py-1 text-xs text-slate-200">
              {domain}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <MetaBadge
          label={`${sourceCount} source${sourceCount === 1 ? "" : "s"}`}
          tone="emerald"
          onClick={() => setSourcesOpen((open) => !open)}
          expanded={sourcesOpen}
          controlsId="supporting-sources"
        />
        <MetaBadge label={`External Search ${externalSearchWasUsed ? "On" : "Off"}`} tone={externalSearchWasUsed ? "amber" : "slate"} />
        <MetaBadge label={`${cautionCount} caution${cautionCount === 1 ? "" : "s"}`} tone={cautionCount > 0 ? "amber" : "slate"} />
      </div>

      <div className="mt-5 rounded-3xl border border-white/10 bg-black/20 p-5">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-emerald-200">Answer</p>
        <MarkdownContent className="mt-3 text-base leading-7 text-slate-100" content={sections.answer} />
      </div>

      {hasDocumentEvidence && (
        <div className="mt-4 rounded-2xl border border-emerald-300/20 bg-emerald-300/8 p-4">
          <h4 className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">Document-supported evidence</h4>
          {sections.documentSupportedClaims.length > 0 && (
            <ul className="mt-3 list-disc space-y-1 pl-5 text-sm leading-6 text-emerald-50">
              {sections.documentSupportedClaims.map((claim) => <li key={claim}>{claim}</li>)}
            </ul>
          )}
          {sections.documentEvidence && sections.documentSupportedClaims.length === 0 && (
            <MarkdownContent className="mt-3 text-sm leading-6 text-emerald-50" content={sections.documentEvidence} />
          )}
        </div>
      )}

      {hasGeneralGuidance && (
        <div className="mt-4 rounded-2xl border border-cyan-300/20 bg-cyan-300/8 p-4">
          <h4 className="text-sm font-semibold uppercase tracking-[0.2em] text-cyan-100">General guidance</h4>
          <ul className="mt-3 list-disc space-y-1 pl-5 text-sm leading-6 text-cyan-50">
            {sections.generalGuidance.map((item) => <li key={item}>{item}</li>)}
          </ul>
        </div>
      )}

      {result.suggestedAngle && (
        <div className="mt-4 rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4 text-sm leading-6 text-cyan-50">
          <span className="font-semibold">Suggested angle: </span>{result.suggestedAngle}
        </div>
      )}

      <details id="supporting-sources" className="mt-6 rounded-2xl border border-white/10 bg-black/10 p-4" open={sourcesOpen}>
        <summary
          className="flex cursor-pointer list-none items-center justify-between gap-3"
          onClick={(event) => {
            event.preventDefault();
            setSourcesOpen((open) => !open);
          }}
        >
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">Customer document sources</h4>
            <p className="mt-1 text-sm text-slate-300">Grounding snippets from the selected Falcontrust documents.</p>
          </div>
          <span className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">{sourcesOpen ? "Hide" : "Show"}</span>
        </summary>
        <div className="mt-4 space-y-2 border-t border-white/10 pt-4">
          {result.citations.map((citation, index) => (
            <article key={`${citation.documentId}-${index}`} className="rounded-2xl border border-white/10 bg-black/25 p-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-white/8 px-2 py-1 text-xs text-slate-200">{citation.domain}</span>
                <h4 className="text-sm font-semibold text-white">{citation.title}</h4>
                <span className="text-xs text-slate-400">relevance {citation.score.toFixed(2)}</span>
                {citation.viewerUrl && (
                  <Link
                    href={citation.viewerUrl}
                    className="ml-auto inline-flex items-center rounded-full border border-cyan-300/30 bg-cyan-300/10 px-3 py-1 text-[11px] font-semibold text-cyan-100 transition hover:border-cyan-300/60 hover:bg-cyan-300/15"
                  >
                    Open source
                  </Link>
                )}
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-300">{citation.snippet}</p>
            </article>
          ))}
        </div>
      </details>

      <div className="mt-6 space-y-3">
        {hasExternalContext && (
          <CollapsibleSection title="External web sources" tone="amber" defaultOpen={result.externalSearchStatus?.ok ?? false}>
            <div className="space-y-3">
              {result.externalSearchStatus && (
                <p className="rounded-xl border border-amber-300/20 bg-amber-300/10 p-3 text-sm text-amber-50">
                  Tavily status: {result.externalSearchStatus.ok ? `${result.externalSearchStatus.resultCount} web results used` : result.externalSearchStatus.warning ?? "External search unavailable; internal RAG answer preserved."}
                </p>
              )}
              <MarkdownContent className="text-sm leading-6 text-amber-50" content={sections.externalContext ?? ""} />
              {result.externalResults && result.externalResults.length > 0 && (
                <div className="space-y-2">
                  {result.externalResults.map((item) => (
                    <div key={`${item.source}-${item.url}`} className="rounded-xl border border-white/10 bg-black/25 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded-full bg-amber-300/15 px-2 py-1 text-xs font-semibold text-amber-100">External web · {sourceLabel(item.source)}</span>
                        {item.score !== undefined && <span className="text-xs text-slate-400">score {item.score.toFixed(2)}</span>}
                      </div>
                      <p className="mt-2 font-semibold text-white">{item.title}</p>
                      <p className="mt-1 text-sm text-amber-100/85">{item.snippet}</p>
                      <a className="mt-2 inline-flex text-xs font-semibold text-cyan-100 underline decoration-cyan-300/40 underline-offset-4" href={item.url} target="_blank" rel="noreferrer">Open web source</a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CollapsibleSection>
        )}
        {cautionCount > 0 && (
          <CollapsibleSection title="Gaps / cautions" tone="amber" defaultOpen={false}>
            <ul className="list-disc space-y-1 pl-5 text-sm leading-6 text-amber-50">
              {sections.gaps.map((gap) => <li key={gap}>{gap}</li>)}
            </ul>
          </CollapsibleSection>
        )}
      </div>
    </section>
  );
}

function MetaBadge({
  label,
  tone,
  onClick,
  expanded,
  controlsId,
}: {
  label: string;
  tone: "emerald" | "amber" | "slate";
  onClick?: () => void;
  expanded?: boolean;
  controlsId?: string;
}) {
  const toneClass = tone === "emerald"
    ? "border-emerald-300/25 bg-emerald-300/10 text-emerald-100"
    : tone === "amber"
      ? "border-amber-300/25 bg-amber-300/10 text-amber-100"
      : "border-white/10 bg-white/5 text-slate-200";

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        aria-expanded={expanded}
        aria-controls={controlsId}
        className={`rounded-full border px-3 py-1 text-xs font-semibold transition hover:brightness-110 focus:outline-none focus:ring-2 focus:ring-cyan-300/50 ${toneClass}`}
      >
        {label}
      </button>
    );
  }

  return <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${toneClass}`}>{label}</span>;
}

function CollapsibleSection({
  title,
  tone,
  defaultOpen = false,
  children,
}: {
  title: string;
  tone: "emerald" | "amber";
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const accent = tone === "emerald" ? "text-emerald-200" : "text-amber-100";
  const border = tone === "emerald" ? "border-emerald-300/20 bg-emerald-300/8" : "border-amber-300/20 bg-amber-300/8";

  return (
    <details className={`rounded-2xl border p-4 ${border}`} open={defaultOpen}>
      <summary className={`cursor-pointer list-none text-sm font-semibold ${accent}`}>
        <span className="inline-flex items-center gap-2">{title}<span className="text-xs text-slate-400">Expand</span></span>
      </summary>
      <div className="mt-3">{children}</div>
    </details>
  );
}

function MarkdownContent({ className, content }: { className?: string; content: string }) {
  return (
    <div className={className}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          p: ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
          ul: ({ children }) => <ul className="mb-3 list-disc space-y-1 pl-5 last:mb-0">{children}</ul>,
          ol: ({ children }) => <ol className="mb-3 list-decimal space-y-1 pl-5 last:mb-0">{children}</ol>,
          li: ({ children }) => <li className="pl-1">{children}</li>,
          strong: ({ children }) => <strong className="font-semibold text-white">{children}</strong>,
          em: ({ children }) => <em className="text-slate-100">{children}</em>,
          hr: () => <div className="my-4 border-t border-white/10" />,
          a: ({ children }) => <span className="font-semibold text-cyan-100">{children}</span>,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

function normalizeQueryResponse(result: QueryResponse | null): QueryResponse | null {
  if (!result) return null;
  const hasExternalResults = Boolean(result.externalResults && result.externalResults.length > 0);
  const externalSearchEnabled = Boolean(result.externalSearch || result.externalSearchEnabled || result.externalSearchStatus?.enabled || hasExternalResults);
  return {
    ...result,
    externalSearch: externalSearchEnabled,
    externalSearchEnabled,
  };
}

function sourceLabel(source: ExternalSearchResult["source"]) {
  return source === "tavily" ? "Tavily" : source;
}

function getAnswerSections(result: QueryResponse): { answer: string; documentEvidence?: string; documentSupportedClaims: string[]; generalGuidance: string[]; externalContext?: string; gaps: string[] } {
  const fallbackGaps = result.gaps ?? [];
  const explicit = result.answerSections;
  if (explicit) {
    return {
      answer: explicit.answer.trim(),
      documentEvidence: explicit.documentEvidence?.trim() || undefined,
      documentSupportedClaims: explicit.documentSupportedClaims ?? [],
      generalGuidance: explicit.generalGuidance ?? [],
      externalContext: (result.externalSearch || result.externalSearchEnabled || (result.externalResults?.length ?? 0) > 0) ? explicit.externalContext?.trim() || undefined : undefined,
      gaps: explicit.gaps && explicit.gaps.length > 0 ? explicit.gaps : fallbackGaps,
    };
  }

  const parsed = parseStructuredAnswer(result.answer);
  return {
    answer: parsed.answer,
    documentEvidence: parsed.documentEvidence,
    documentSupportedClaims: parsed.documentEvidence ? toList(parsed.documentEvidence) : [],
    generalGuidance: [],
    externalContext: (result.externalSearch || result.externalSearchEnabled || (result.externalResults?.length ?? 0) > 0) ? parsed.externalContext : undefined,
    gaps: parsed.gaps.length > 0 ? parsed.gaps : fallbackGaps,
  };
}

function parseStructuredAnswer(raw: string): { answer: string; documentEvidence?: string; externalContext?: string; gaps: string[] } {
  const normalized = raw.replace(/\r/g, "").trim();
  const sections = splitStructuredSections(normalized);
  const answer = sections["Direct answer"] ?? normalized;
  return {
    answer: answer.trim(),
    documentEvidence: sections["From selected documents"]?.trim(),
    externalContext: sections["External context"]?.trim(),
    gaps: toList(sections["Gaps / cautions"] ?? sections["Gaps / caution"]),
  };
}

function splitStructuredSections(text: string) {
  const matches = [...text.matchAll(/^\s*(?:\*\*)?(Direct answer|From selected documents|External context|Gaps \/ cautions|Gaps \/ caution):(?:\*\*)?\s*$/gm)];

  if (matches.length === 0) return {} as Record<string, string>;

  const sections: Record<string, string> = {};
  for (let index = 0; index < matches.length; index += 1) {
    const match = matches[index];
    const heading = match[1];
    const start = match.index! + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index! : text.length;
    sections[heading] = text.slice(start, end).trim();
  }
  return sections;
}

function toList(value?: string) {
  if (!value) return [];
  return value
    .split("\n")
    .map((line) => line.replace(/^[-*•]\s*/, "").trim())
    .filter(Boolean);
}
