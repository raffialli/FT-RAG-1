import Link from "next/link";

type FalconNavProps = {
  active: "search" | "admin" | "addons";
  title: string;
  action?: React.ReactNode;
};

const navItems = [
  { id: "search", label: "Search", href: "/" },
  { id: "admin", label: "Admin", href: "/admin" },
  { id: "addons", label: "Add-ons", href: "/addons" },
] as const;

export function FalconNav({ active, title, action }: FalconNavProps) {
  return (
    <nav className="glass-panel mb-8 flex min-w-0 flex-col gap-4 rounded-[30px] px-5 py-4 lg:flex-row lg:items-center lg:justify-between lg:px-6">
      <div className="min-w-0">
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-200/90">Falcontrust</p>
        <h1 className="mt-1 text-lg font-semibold text-white">{title}</h1>
      </div>
      <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex w-fit max-w-full rounded-full border border-white/10 bg-black/30 p-1.5 text-sm shadow-lg shadow-black/20">
          {navItems.map((item) => {
            const isActive = active === item.id;
            if (isActive) {
              return (
                <span key={item.id} className="rounded-full bg-gradient-to-r from-cyan-300 to-violet-400 px-4 py-2 font-semibold text-slate-950 sm:px-5">
                  {item.label}
                </span>
              );
            }

            return (
              <Link key={item.id} href={item.href} className="rounded-full px-4 py-2 text-slate-300 transition hover:bg-white/5 hover:text-white sm:px-5">
                {item.label}
              </Link>
            );
          })}
        </div>
        {action}
      </div>
    </nav>
  );
}
