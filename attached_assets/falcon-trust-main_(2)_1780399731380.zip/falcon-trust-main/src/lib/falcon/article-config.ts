import path from "node:path";
import { listJson, writeJson } from "./storage";
import type { ArticleConfig, PublicArticleConfig } from "./types";

const dataDir = process.env.FALCON_DATA_DIR ?? path.join(process.cwd(), ".demo-data");
const configPath = path.join(dataDir, "article-config.json");
const configKey = "runtime/article-config.json";

export const defaultArticleConfig: ArticleConfig = {
  provider: "ollama",
  endpoint: process.env.OLLAMA_BASE_URL ?? "http://192.168.0.168:11435",
  model: process.env.OLLAMA_ARTICLE_MODEL ?? "qwen3.5:35b-a3b",
  apiKey: process.env.OLLAMA_API_KEY ?? "",
  audience: "Miami-Dade residents and municipal communications staff",
  tone: "clear, practical, public-service oriented",
  length: "medium",
  structure: "news-style public guidance article with headline, deck, body paragraphs, and a short limits note",
  extraInstructions: "Write a useful article, not a legal memo. Keep claims grounded in the provided sources and clearly state any limits.",
  includeCitations: true,
};

export async function readArticleConfig(): Promise<ArticleConfig> {
  try {
    const records = await listJson(configKey, configPath);
    if (!records[0]?.body) return defaultArticleConfig;
    return normalizeArticleConfig(JSON.parse(records[0].body));
  } catch {
    return defaultArticleConfig;
  }
}

export async function writeArticleConfig(config: Partial<ArticleConfig>): Promise<ArticleConfig> {
  const current = await readArticleConfig();
  const next = normalizeArticleConfig({ ...current, ...config });

  if (typeof config.apiKey === "undefined" || config.apiKey === "") {
    next.apiKey = current.apiKey ?? "";
  } else if (config.apiKey === "__CLEAR_API_KEY__") {
    next.apiKey = "";
  }

  await writeJson(configKey, configPath, next);
  return next;
}

export function publicArticleConfig(config: ArticleConfig): PublicArticleConfig {
  const apiKey = config.apiKey ?? "";
  const { apiKey: _apiKey, ...safeConfig } = config;
  void _apiKey;
  return {
    ...safeConfig,
    apiKeyConfigured: Boolean(apiKey),
    apiKeyMasked: maskSecret(apiKey),
  };
}

export function normalizeArticleConfig(input: Partial<ArticleConfig>): ArticleConfig {
  return {
    provider: "ollama",
    endpoint: stringValue(input.endpoint, defaultArticleConfig.endpoint),
    model: stringValue(input.model, defaultArticleConfig.model),
    apiKey: stringValue(input.apiKey, "", 4000),
    audience: stringValue(input.audience, defaultArticleConfig.audience),
    tone: stringValue(input.tone, defaultArticleConfig.tone),
    length: normalizeLength(input.length),
    structure: normalizeStructure(input.structure),
    extraInstructions: stringValue(input.extraInstructions, defaultArticleConfig.extraInstructions),
    includeCitations: input.includeCitations !== false,
  };
}

function normalizeStructure(value: unknown) {
  const text = stringValue(value, defaultArticleConfig.structure);
  if (/practical checklist|key points/i.test(text)) return defaultArticleConfig.structure;
  return text;
}

function stringValue(value: unknown, fallback: string, maxLength = 1000) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, maxLength) : fallback;
}

function maskSecret(value: string) {
  if (!value) return "";
  if (value.length <= 8) return "••••";
  return `${value.slice(0, 4)}••••${value.slice(-4)}`;
}

function normalizeLength(value: unknown): ArticleConfig["length"] {
  return value === "short" || value === "long" ? value : "medium";
}
