import { publicArticleConfig, readArticleConfig } from "./article-config";
import { formatCitationBlock, generateWithConfiguredLlm } from "./llm";
import type { ArticleConfig, Citation } from "./types";

type GenerateArticleInput = {
  query: string;
  citations: Citation[];
  fallbackAnswer: string;
  externalContext?: string;
};

export async function generateArticleDraft({ query, citations, fallbackAnswer, externalContext }: GenerateArticleInput) {
  const config = await readArticleConfig();
  try {
    const answer = await generateWithConfiguredLlm(buildPrompt(query, citations, config, externalContext), {
      temperature: 0.42,
      numPredict: config.length === "long" ? 2200 : config.length === "short" ? 1100 : 1700,
      timeoutMs: 120000,
    });
    return answer;
  } catch (error) {
    const reason = error instanceof Error ? error.message : "Unknown Ollama generation error";
    return {
      answer: `${fallbackAnswer}\n\n[Local LLM article generation was unavailable: ${reason}]`,
      config: publicArticleConfig(config),
      generatedBy: "template_fallback" as const,
      warning: reason,
    };
  }
}

function buildPrompt(query: string, citations: Citation[], config: ArticleConfig, externalContext?: string) {
  const sourceBlock = formatCitationBlock(citations);

  const externalBlock = externalContext ? `\nExternal context for optional background. Use only for general context and clearly avoid unsupported local specifics:\n${externalContext}\n` : "";

  return `You are drafting a complete, publication-quality customer-demo article for Falcontrust.

User request/topic:
${query}

Article configuration:
- Audience: ${config.audience}
- Tone: ${config.tone}
- Length: ${config.length}
- Structure: ${config.structure}
- Extra instructions: ${config.extraInstructions}

Grounding rules:
- Use the provided source snippets for factual claims.
- Do not invent dates, addresses, phone numbers, policy details, names, statistics, legal conclusions, or actual municipal program details not present in the sources.
- If a detail is missing, write generally and say residents should verify details with the municipality.
- Avoid promising that sandbags prevent flooding.
- Include practical, public-facing guidance.
${config.includeCitations ? "- Cite source numbers inline where useful, like [1] or [2]." : "- Do not include inline citation markers."}
${externalBlock}
Article quality rules:
- Write an actual article, not a summary of what an article should include.
- The article must feel complete enough for a client demo: headline, deck, lede, developed body, and closing caveat.
- Use paragraphs as the default. Do not use bullets unless the user's request explicitly asks for a checklist or bullet list.
- Use subheadings sparingly, like a news or public-service article. Do not create a report-style outline.
- Convert any configured checklist/key-points language into prose unless the user explicitly asks for a checklist.
- Do not include bullet-list lines beginning with -, *, or • unless the user explicitly asks for bullets.
- Do not use markdown emphasis markers such as **bold** or *italics*; write plain article copy that the UI can style.
- Do not include a separate section titled "Required output", "Article", "Checklist", or "Key points".

Required article shape:
Headline
Deck/subtitle

A lede paragraph that states the main point.
Several short body paragraphs that explain the guidance in a natural editorial flow.
A concise closing paragraph that explains limits/cautions and tells readers to confirm local details.

Source snippets:
${sourceBlock}

Write the complete article now.`;
}
