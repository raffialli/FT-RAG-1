import { NextResponse } from "next/server";

export const AUTH_COOKIE = "falcon_auth";
export const ADMIN_COOKIE = "falcon_admin";

export function authEnabled() {
  return process.env.FALCON_AUTH_ENABLED === "true";
}

export function expectedAppPassword() {
  return process.env.FALCON_APP_PASSWORD ?? "";
}

export function expectedAdminPassword() {
  return process.env.FALCON_ADMIN_PASSWORD ?? "";
}

export function isConfigured() {
  return Boolean(expectedAppPassword() && expectedAdminPassword());
}

export async function verifyPassword(password: string, expected: string) {
  if (!expected || !password) return false;
  const encoder = new TextEncoder();
  const left = encoder.encode(password);
  const right = encoder.encode(expected);
  if (left.length !== right.length) return false;

  let diff = 0;
  for (let i = 0; i < left.length; i += 1) diff |= left[i] ^ right[i];
  return diff === 0;
}

export function unauthorized(message = "Authentication required") {
  return NextResponse.json({ error: message }, { status: 401 });
}

export function forbidden(message = "Admin authentication required") {
  return NextResponse.json({ error: message }, { status: 403 });
}
