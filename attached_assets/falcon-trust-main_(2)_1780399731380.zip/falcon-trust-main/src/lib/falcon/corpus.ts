import fs from "node:fs";
import path from "node:path";
import { loadDomains } from "./domains";
import { deleteJson, listJson, writeJson } from "./storage";
import type { Chunk, DemoDocument, DomainId } from "./types";

const corpusRoot = path.join(process.cwd(), "demo-corpus");
export const uploadRoot = path.join(process.env.FALCON_DATA_DIR ?? path.join(process.cwd(), ".demo-data"), "uploads");
export const CHUNKING_POLICY = {
  maxChars: 3600,
  overlapChars: 220,
  minSectionChars: 500,
  boundaryOrder: ["heading", "page-marker", "index-reference-heading", "paragraph", "sentence", "hard-limit"],
  reindexRequired: "Changing these rules requires rebuilding local/vector chunk indexes before live validation.",
} as const;

export async function loadDocuments(): Promise<DemoDocument[]> {
  const domains = await loadDomains();
  const uploadedDocuments = await loadUploadedDocuments(domains);
  if (uploadedDocuments.length > 0) return uploadedDocuments;
  return loadStaticDocuments(domains);
}

function loadStaticDocuments(domains: { id: DomainId }[]): DemoDocument[] {
  return domains.flatMap((domain) => {
    const dir = path.join(corpusRoot, domain.id);
    if (!fs.existsSync(dir)) return [];
    return fs
      .readdirSync(dir)
      .filter((file) => file.endsWith(".md"))
      .sort()
      .map((file) => {
        const fullPath = path.join(dir, file);
        const text = fs.readFileSync(fullPath, "utf8");
        const firstHeading = text.match(/^#\s+(.+)$/m)?.[1] ?? file.replace(/\.md$/, "");
        const title = firstHeading.replace(/^DEMO SAMPLE\s+—\s+/, "");
        return {
          id: `${domain.id}-${file.replace(/\.md$/, "")}`,
          title,
          domain: domain.id,
          path: path.relative(process.cwd(), fullPath),
          text,
          source: "static",
        };
      });
  });
}

async function loadUploadedDocuments(domains: { id: DomainId }[]): Promise<DemoDocument[]> {
  const documents: DemoDocument[] = [];

  for (const domain of domains) {
    const dir = path.join(uploadRoot, domain.id);
    const prefix = `uploads/${domain.id}/`;
    const records = await listJson(prefix, dir);

    for (const item of records) {
      const record = JSON.parse(item.body) as {
        id: string;
        title: string;
        text: string;
        sourceFileName?: string;
        uploadedAt?: string;
      };
      const normalized = normalizeUploadedPdfText(record.text, {
        title: record.title,
        sourceFileName: record.sourceFileName,
      });

      documents.push({
        id: record.id,
        title: record.title,
        domain: domain.id,
        path: item.key,
        text: normalized.text,
        source: "uploaded",
        sourceFileName: record.sourceFileName,
        uploadedAt: record.uploadedAt,
        storageKey: item.storageKey,
        textMetadata: normalized.metadata,
      });
    }
  }

  return documents;
}

export async function writeUploadedDocument(input: { domain: DomainId; title: string; text: string; sourceFileName: string }) {
  const safeTitle = input.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || "uploaded-document";
  const id = `${input.domain}-upload-${Date.now()}-${safeTitle}`;
  const dir = path.join(uploadRoot, input.domain);
  const record = {
    id,
    title: input.title,
    text: input.text,
    sourceFileName: input.sourceFileName,
    uploadedAt: new Date().toISOString(),
  };
  const fullPath = path.join(dir, `${id}.json`);
  const key = `uploads/${input.domain}/${id}.json`;
  const stored = await writeJson(key, fullPath, record);
  return { ...record, domain: input.domain, path: stored.path, source: "uploaded" as const, storageKey: key };
}

export async function deleteUploadedDocument(documentId: string) {
  const domains = await loadDomains();
  const document = (await loadUploadedDocuments(domains)).find((item) => item.id === documentId);
  if (!document) return null;

  const storageKey = document.storageKey;
  if (!storageKey) throw new Error("Uploaded document is missing storage metadata");

  const localPath = path.join(uploadRoot, document.domain, `${document.id}.json`);
  await deleteJson(storageKey, localPath);
  return document;
}

export function tokenize(text: string) {
  return Array.from(
    new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, " ")
        .split(/\s+/)
        .filter((token) => token.length > 2)
        .filter((token) => !STOP_WORDS.has(token)),
    ),
  );
}

export function chunkDocument(document: DemoDocument): Chunk[] {
  const sections = splitSemanticSections(document.text);

  const chunks = sections
    .map((section) => trimReferenceEvidenceTail(section))
    .filter(Boolean)
    .flatMap((section) => splitLongSection(section))
    .filter((section) => !isReferenceEvidenceExcluded(section));

  return chunks.map((section, index) => {
    const id = `${document.id}-chunk-${index + 1}`;
    const contentType = "body" as const;
    return {
      id,
      documentId: document.id,
      title: document.title,
      domain: document.domain,
      text: section,
      index,
      sourcePath: document.path,
      contentType,
      tokens: tokenize(section),
      metadata: buildChunkMetadata(document, id, index, contentType),
    };
  });
}

function buildChunkMetadata(
  document: DemoDocument,
  chunkId: string,
  chunkIndex: number,
  contentType: Chunk["contentType"],
): Record<string, string | number | boolean | null> {
  return {
    ...(document.textMetadata ?? {}),
    documentId: document.id,
    chunkId,
    chunkIndex,
    title: document.title,
    domain: document.domain,
    source: document.source ?? "static",
    sourcePath: document.path,
    sourceFileName: document.sourceFileName ?? null,
    uploadedAt: document.uploadedAt ?? null,
    contentType: contentType ?? "unknown",
  };
}

export function normalizeUploadedPdfText(
  text: string,
  options: { title?: string; sourceFileName?: string } = {},
) {
  if (!isUploadedPdfDerivedText(text, options.sourceFileName)) {
    return {
      text,
      metadata: {
        normalizedPdfText: false,
        originalTextLength: text.length,
        normalizedTextLength: text.length,
        removedUploadedPdfHeading: false,
        removedPageMarkerCount: 0,
        firstRemovedPageMarker: null,
        sourceFileName: options.sourceFileName ?? null,
      },
    };
  }

  const originalTextLength = text.length;
  const pageMarkers = Array.from(text.matchAll(/---\s*Page\s+\d+\s+of\s+\d+\s*---/gi)).map((match) => match[0]);
  let normalized = text.replace(/\r\n/g, "\n");
  let removedUploadedPdfHeading = false;

  normalized = normalized.replace(/^#\s*UPLOADED PDF\s+[—-]\s*.+$/gim, () => {
    removedUploadedPdfHeading = true;
    return options.title ? `# ${options.title}` : "";
  });

  normalized = normalized
    .split("\n")
    .filter((line) => !isPdfLayoutArtifactLine(line))
    .join("\n")
    .replace(/^[ \t]*---\s*Page\s+\d+\s+of\s+\d+\s*---[ \t]*$/gim, "")
    .replace(/^\s*Page\s+\d+\s*$/gim, "")
    .replace(/\bJEM\s+\d+\s+/g, "")
    .replace(/\bJournal of Emergency Management\s+Vol\.\s*\d+,\s*No\.\s*\d+,\s*[^\n.]+?\s+\d{4}\s+\d+\b/gi, "")
    .replace(/\bJournal of Emergency Management\s+Vol\.\s*\d+,\s*No\.\s*\d+,\s*[^\n.]+?\s+\d{4}/gi, "")
    .replace(/^\s*FALCON COUNTY FLOOD RESPONSE BULLETIN\s*$/gim, "")
    .replace(/\bAll Rights Reserved\b/gi, "")
    .replace(/\b\d{1,3}\s+(?:Mahala\s+Mclindin|Abigail\s+Tevera)\b/g, "")
    .replace(/[\uFB00-\uFB06]/g, (match) => LIGATURE_REPLACEMENTS[match] ?? match)
    .replace(/\bTechnologyexclusion\b/gi, "Technology exclusion")
    .replace(/\bTechnologicalexclusion\b/gi, "Technological exclusion")
    .replace(/\b(Technological exclusion)\s+(Technology also plays)\b/gi, "$1. $2")
    .replace(/\b(Technology exclusion)\s+(Technology also plays)\b/gi, "$1. $2")
    .replace(/\b(?:lnstrums,nt\s+ds,nsity|lesSOflsfearnt>d)\b/gi, "")
    .replace(/\bI\s+I\s+I\s*(?:[-–—>,]+)?/g, "")
    .replace(/\s*(?:➔|->)\s*/g, " ")
    .replace(/([A-Za-z]{3,})-\n\s*([a-z]{2,})/g, "$1$2")
    .replace(/([A-Za-z]{3,})-\s+([a-z]{2,})/g, "$1$2")
    .replace(/([^\n])\n(?!\n|#{1,4}\s)/g, "$1 ")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return {
    text: normalized,
    metadata: {
      normalizedPdfText: true,
      originalTextLength,
      normalizedTextLength: normalized.length,
      removedUploadedPdfHeading,
      removedPageMarkerCount: pageMarkers.length,
      firstRemovedPageMarker: pageMarkers[0] ?? null,
      sourceFileName: options.sourceFileName ?? null,
    },
  };
}

function isPdfLayoutArtifactLine(line: string) {
  const compact = line.replace(/\s+/g, " ").trim();
  if (!compact) return false;
  if (/^\d{1,3}\s+[A-Z][A-Za-z'’-]+\s+[A-Z][A-Za-z'’-]+$/.test(compact)) return true;

  const hasKnownOcrArtifact = /\b(?:lnstrums,nt|ds,nsity|lesSOfls|fearnt>d)\b/i.test(compact);
  const hasDiagramNoise = /(?:\bI\s+I\s+I\b|[-–—]{3,}|➔|->|\bFIGURE\s+\d+(?:\.\d+)?\b)/i.test(compact);
  const bodyWordCount = (compact.match(/\b[a-z]{4,}\b/gi) ?? []).length;

  return hasKnownOcrArtifact && hasDiagramNoise && bodyWordCount <= 12;
}

function isUploadedPdfDerivedText(text: string, sourceFileName?: string) {
  return Boolean(
    sourceFileName?.toLowerCase().endsWith(".pdf") ||
      /^#\s*UPLOADED PDF\s+[—-]/im.test(text) ||
      /---\s*Page\s+\d+\s+of\s+\d+\s*---/i.test(text),
  );
}

export function splitSemanticSections(text: string) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const sections: string[] = [];
  let current: string[] = [];

  for (const line of lines) {
    const startsReferenceSection = isIndexReferenceHeading(line);
    const startsSection = isHeading(line) || isPageMarker(line) || startsReferenceSection;
    const currentLength = current.join("\n").trim().length;

    if (startsSection && (startsReferenceSection || currentLength >= CHUNKING_POLICY.minSectionChars)) {
      const section = current.join("\n").trim();
      if (section) sections.push(section);
      current = [line];
    } else {
      current.push(line);
    }
  }

  const tail = current.join("\n").trim();
  if (tail) sections.push(tail);
  return sections.length ? sections : [text.trim()].filter(Boolean);
}

export function splitLongSection(section: string, maxChars = CHUNKING_POLICY.maxChars, overlapChars = CHUNKING_POLICY.overlapChars) {
  if (section.length <= maxChars) return [section];
  const chunks: string[] = [];
  let start = 0;

  while (start < section.length) {
    const targetEnd = Math.min(start + maxChars, section.length);
    const boundary = findBoundary(section, start, targetEnd);
    const part = section.slice(start, boundary).trim();
    if (part) chunks.push(part);
    if (boundary >= section.length) break;
    start = findNextChunkStart(section, start, boundary, overlapChars);
  }

  return chunks;
}

function findNextChunkStart(text: string, currentStart: number, boundary: number, overlapChars: number) {
  const desiredStart = Math.max(currentStart + 1, boundary - overlapChars);
  const overlapWindow = text.slice(desiredStart, boundary);
  const sentenceStarts = Array.from(overlapWindow.matchAll(/[.!?]\s+["'“”‘’(\[]*([A-Z0-9])/g))
    .map((match) => desiredStart + (match.index ?? 0) + match[0].length - match[1].length)
    .filter((index) => index > desiredStart && index < boundary);

  if (sentenceStarts.length) return sentenceStarts.at(-1)!;

  const paragraphStart = text.indexOf("\n\n", desiredStart);
  if (paragraphStart >= 0 && paragraphStart < boundary) return skipChunkStartWhitespace(text, paragraphStart + 2);

  return skipChunkStartWhitespace(text, boundary);
}

function findBoundary(text: string, start: number, targetEnd: number) {
  if (targetEnd >= text.length) return text.length;
  const window = text.slice(start, targetEnd);
  const headingBreak = lastBoundaryMatch(window, /\n(?=#{1,4}\s+)/g);
  if (headingBreak > maxBoundarySearchFloor(window.length)) return start + headingBreak;
  const pageBreak = lastBoundaryMatch(window, /\n(?=(?:Page\s+\d+|\[Page\s+\d+\]|---\s*page\s+\d+))/gi);
  if (pageBreak > maxBoundarySearchFloor(window.length)) return start + pageBreak;
  const paragraphBreak = window.lastIndexOf("\n\n");
  if (paragraphBreak > maxBoundarySearchFloor(window.length)) return start + paragraphBreak;
  const sentenceBreak = Math.max(window.lastIndexOf(". "), window.lastIndexOf("? "), window.lastIndexOf("! "));
  if (sentenceBreak > maxBoundarySearchFloor(window.length)) return start + sentenceBreak + 1;
  const wordBreak = window.lastIndexOf(" ");
  if (wordBreak > maxBoundarySearchFloor(window.length)) return start + wordBreak;
  return targetEnd;
}

function maxBoundarySearchFloor(length: number) {
  return Math.floor(length * 0.6);
}

function skipChunkStartWhitespace(text: string, index: number) {
  let next = index;
  while (next < text.length && /\s/.test(text[next])) next += 1;
  return next;
}

function lastBoundaryMatch(text: string, pattern: RegExp) {
  let last = -1;
  for (const match of text.matchAll(pattern)) {
    if (typeof match.index === "number") last = match.index;
  }
  return last;
}

function isHeading(line: string) {
  return /^#{1,4}\s+\S/.test(line.trim());
}

function isPageMarker(line: string) {
  return /^(?:Page\s+\d+|\[Page\s+\d+\]|---\s*page\s+\d+)/i.test(line.trim());
}

function isIndexReferenceHeading(line: string) {
  return /^(?:#+\s*)?(?:\d+\s+)?(?:contents|table of contents|index|references?|bibliography|works cited|literature cited|cited references|reference list|citation list|source list|further reading|appendix)\b/i.test(line.trim());
}

export function isReferenceEvidenceExcluded(section: string) {
  const compact = section.replace(/\s+/g, " ").trim();
  if (!compact) return false;
  if (/^(?:#+\s*)?(?:contents|table of contents|index|references?|bibliography|works cited|literature cited|cited references|reference list|citation list|source list|further reading|appendix)\b/i.test(compact)) return true;
  if (isTocLikeSection(compact)) return true;
  if (isPublicationFrontMatter(compact)) return true;
  if (/^(?:\d+\s+)?Index\b/i.test(compact) && /\bsee\b|\.{2,}|\b\d{1,3}(?:-\d{1,3})?\b/.test(compact)) return true;
  if (isAcademicCitationList(compact)) return true;
  if (isStandaloneBibliographyChunk(compact)) return true;
  const firstWords = compact.split(/\s+/).slice(0, 16).join(" ");
  return /\bINDEX\b/.test(firstWords) && /\b(?:accountability|dredging|resilience|references?|bibliography)\b/i.test(compact);
}

function trimReferenceEvidenceTail(section: string) {
  const paragraphs = section.split(/\n{2,}/).map((part) => part.trim()).filter(Boolean);
  while (paragraphs.length > 1 && paragraphs.at(-1)!.length <= CHUNKING_POLICY.maxChars * 1.25 && isReferenceEvidenceExcluded(paragraphs.at(-1)!)) {
    paragraphs.pop();
  }

  section = paragraphs.join("\n\n");
  const markers = Array.from(section.matchAll(/\b(?:references?|bibliography|works cited|literature cited|cited references|reference list|citation list|source list|further reading|appendix)\b/gi))
    .filter((match) => isReferenceTailMarker(section, match));
  const marker = markers.at(-1);
  if (typeof marker?.index !== "number") return section;
  if (marker.index < CHUNKING_POLICY.minSectionChars) return section;

  const tail = section.slice(marker.index).replace(/\s+/g, " ").trim();
  if (!isAcademicCitationList(tail) && !/^(?:references?|bibliography|works cited|literature cited|cited references|reference list|citation list|source list|further reading)\b/i.test(tail)) {
    return section;
  }

  return section.slice(0, marker.index).trim();
}

function isReferenceTailMarker(section: string, match: RegExpMatchArray) {
  if (typeof match.index !== "number") return false;
  const before = section.slice(Math.max(0, match.index - 40), match.index);
  if (/bibliographical\s+$/i.test(before)) return false;
  if (/\n\s*(?:#+\s*)?$/.test(before)) return true;
  return match[0] === match[0].toUpperCase();
}

function isAcademicCitationList(compact: string) {
  const numberedReferenceCount = (compact.match(/(?:^|\s)\d{1,3}\.\s+[A-Z][A-Za-z'’-]+[^.]{8,180}(?:\b(?:19|20)\d{2}\b|\b(?:Int J|Journal|Proceedings|BMC|Hydrol|Water Policy|Disasters|University|Press)\b)/g) ?? []).length;
  if (numberedReferenceCount >= 3) return true;

  const citationEntryCount = (compact.match(/\b[A-Z][A-Za-z'’-]+(?:\s+[A-Z]{1,3})?(?:,\s*(?:and\s+)?[A-Z][A-Za-z'’-]+(?:\s+[A-Z]{1,3})?){0,6}:\s+[A-Z][^.]{12,220}\./g) ?? []).length;
  const academicMarkerCount = (compact.match(/\b(?:Journal|Proceedings|BMC Public Health|Hydrol Earth Syst Sci|Water Policy|Disasters|University Press|Int J|Vol\.|No\.|doi:)\b/gi) ?? []).length;

  return citationEntryCount >= 3 && academicMarkerCount >= 2;
}

function isStandaloneBibliographyChunk(compact: string) {
  const citationYearCount = (compact.match(/\b[A-Z][A-Za-z'’.-]+(?:\s+[A-Z][A-Za-z'’.-]+){0,8}\s+\((?:19|20)\d{2}\)/g) ?? []).length;
  const academicMarkerCount = (compact.match(/\b(?:Accessed at|https?:\/\/|doi:|Journal|Proceedings|Briefing Paper|University|Press|World Meteorological Organisation|World Meteorological Organization|WMO)\b/gi) ?? []).length;
  const startsLikeCitationEntry = /^(?:\(?\d{4}\)?\.|[A-Z][A-Za-z'’.-]+(?:,\s*[A-Z][A-Za-z'’.-]+){0,4}\s+\((?:19|20)\d{2}\)\.|[A-Z][A-Za-z'’.-]+\s+[A-Z]\.\s+\((?:19|20)\d{2}\)\.)/.test(compact);
  const accessedAtIndex = compact.search(/\bAccessed at\s+https?:/i);
  const firstCitationIndex = compact.search(/\b[A-Z][A-Za-z'’.-]+(?:\s+[A-Z][A-Za-z'’.-]+){0,8}\s+\((?:19|20)\d{2}\)/);

  if (accessedAtIndex >= 0 && accessedAtIndex < 500) return true;
  if (startsLikeCitationEntry && academicMarkerCount >= 1) return true;
  return citationYearCount >= 2 && academicMarkerCount >= 2 && firstCitationIndex >= 0 && firstCitationIndex < 500;
}

function isPublicationFrontMatter(compact: string) {
  if (/^All rights reserved\b/i.test(compact)) return true;
  const frontMatterIndex = compact.search(/\b(?:No part of this book may be reprinted|Library\s+(?:of|~\()\s*Con(?:g|J)ress|Cataloging-in-Publication|LCCN|ISBN|ISDN|LC record available|Routledge|Taylor\s*&\s*Francis|First published)\b/i);
  if (frontMatterIndex >= 0 && frontMatterIndex < 500) return true;
  if (frontMatterIndex >= 0 && frontMatterIndex < 2500 && compact.length <= CHUNKING_POLICY.maxChars * 1.2) return true;
  const catalogMarkerCount = (compact.match(/\b(?:copyright|publisher|published by|trademark notice|hardback|paperback|e-book|bibliographical references|classification|subjects:)\b/gi) ?? []).length;
  return catalogMarkerCount >= 3 && frontMatterIndex >= 0 && frontMatterIndex < 500;
}

function isTocLikeSection(compact: string) {
  const dotLeaderCount = (compact.match(/\.{2,}\s*\d{1,4}/g) ?? []).length;
  const pageRefCount = (compact.match(/\b(?:chapter|section|figure|table|appendix)\b[^.]{0,80}\b\d{1,4}\b/gi) ?? []).length;
  return dotLeaderCount >= 3 || pageRefCount >= 5;
}

const LIGATURE_REPLACEMENTS: Record<string, string> = {
  "\uFB00": "ff",
  "\uFB01": "fi",
  "\uFB02": "fl",
  "\uFB03": "ffi",
  "\uFB04": "ffl",
  "\uFB05": "st",
  "\uFB06": "st",
};

export async function loadChunks(): Promise<Chunk[]> {
  return (await loadDocuments()).flatMap(chunkDocument);
}

const STOP_WORDS = new Set([
  "the", "and", "for", "that", "with", "this", "from", "are", "should", "into", "when", "what", "about",
  "have", "has", "can", "may", "not", "but", "use", "using", "their", "they", "them", "our", "your",
  "documents", "document", "demo", "sample", "falcon", "trust", "research", "workspace",
]);
