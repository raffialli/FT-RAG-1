import fs from "node:fs";
import path from "node:path";
import { loadDocuments } from "./corpus";
import { authEnabled, unauthorized } from "./auth";
import { getDocumentAllowlist, readVectorIndex } from "./embeddings";
import type { Citation, DemoDocument } from "./types";

export type CitationLink = {
  href: string;
  viewerPath: string;
  chunkId?: string;
  chunkIndex?: number;
};

export function buildCitationLink(citation: Citation): CitationLink {
  const params = new URLSearchParams();
  params.set("doc", citation.documentId);
  if (citation.chunkId) params.set("chunk", citation.chunkId);
  if (typeof citation.chunkIndex === "number") params.set("chunkIndex", String(citation.chunkIndex));
  if (citation.snippet) params.set("snippet", citation.snippet.slice(0, 240));
  const href = `/documents?${params.toString()}`;
  return {
    href,
    viewerPath: "/documents",
    chunkId: citation.chunkId,
    chunkIndex: citation.chunkIndex,
  };
}

export async function getDocumentForViewer(documentId: string) {
  const documents = await loadDocuments();
  const document = documents.find((item) => item.id === documentId);
  if (!document) return null;
  return { ...serializeDocument(document), chunks: null };
}

export async function getDocumentForViewerFromActiveBackend(documentId: string, chunkId?: string | null) {
  if (process.env.FALCON_RETRIEVAL_BACKEND === "bedrock-s3-vector") {
    const vectorDocument = await getVectorDocumentForViewer(documentId, chunkId);
    if (vectorDocument) return vectorDocument;
  }

  return getDocumentForViewer(documentId);
}

async function getVectorDocumentForViewer(documentId: string, chunkId?: string | null) {
  const index = await readVectorIndex();
  const allowlist = getDocumentAllowlist();
  const records = index.records
    .filter((record) => record.documentId === documentId && (!allowlist || allowlist.has(record.documentId)))
    .sort((a, b) => a.index - b.index);

  if (!records.length) return null;

  const selected = chunkId ? records.find((record) => record.chunkId === chunkId) : undefined;
  const first = records[0];

  return {
    id: documentId,
    title: first.title,
    domain: first.domain,
    sourceLabel: `Vector index chunk source · ${records.length} chunks`,
    text: selected?.text ?? records.map((record) => record.text).join("\n\n"),
    chunks: records.map((record) => ({
      id: record.chunkId,
      index: record.index,
      text: record.text,
      highlighted: chunkId ? record.chunkId === chunkId : false,
    })),
  };
}

export function serializeDocument(document: DemoDocument) {
  const sourceLabel = classifySource(document.path);
  return {
    id: document.id,
    title: document.title,
    domain: document.domain,
    sourceLabel,
    text: document.text,
  };
}


export function canViewDocument(request: Request) {
  if (!authEnabled()) return null;
  const cookie = request.headers.get("cookie") ?? "";
  return /(?:^|;\s*)falcon_auth=1(?:;|$)/.test(cookie) ? null : unauthorized();
}

function classifySource(documentPath: string) {
  const normalized = documentPath.replace(/\\/g, "/");
  if (normalized.startsWith("demo-corpus/")) return `Demo corpus · ${path.basename(normalized)}`;
  if (normalized.startsWith("uploads/") || normalized.includes("/.demo-data/")) return `Uploaded document · ${path.basename(normalized)}`;
  if (fs.existsSync(documentPath)) return `Local file · ${path.basename(normalized)}`;
  return path.basename(normalized);
}
