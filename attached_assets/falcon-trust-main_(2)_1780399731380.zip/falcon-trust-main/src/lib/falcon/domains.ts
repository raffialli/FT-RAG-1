import path from "node:path";
import { listJson, writeJson } from "./storage";
import type { Domain, DomainId } from "./types";

const dataDir = process.env.FALCON_DATA_DIR ?? path.join(process.cwd(), ".demo-data");
const domainsDir = path.join(dataDir, "domains");
const domainsKey = "runtime/domains.json";
const domainsPath = path.join(domainsDir, "domains.json");

export const DEFAULT_DOMAINS: Domain[] = [
  {
    id: "law",
    name: "Law",
    description: "Legal authority, public-claims risk, publication review, and careful wording guidance.",
  },
  {
    id: "sandbags",
    name: "Sandbags",
    description: "Flood readiness, sandbag usage, distribution logistics, placement, and disposal guidance.",
  },
];

export async function loadDomains(): Promise<Domain[]> {
  try {
    const records = await listJson(domainsKey, domainsDir);
    const record = records.find((item) => item.key.endsWith("domains.json"));
    const stored = record?.body ? JSON.parse(record.body) : null;
    const custom = Array.isArray(stored?.domains) ? stored.domains.map(normalizeDomain).filter(Boolean) as Domain[] : [];
    return mergeDomains(DEFAULT_DOMAINS, custom);
  } catch (error) {
    console.error("Failed to load custom domains", error);
    return DEFAULT_DOMAINS;
  }
}

export async function addDomain(input: { name: string; description: string; id?: string }): Promise<{ domain: Domain; domains: Domain[] }> {
  const current = await loadDomains();
  const name = input.name.trim().slice(0, 80);
  const description = input.description.trim().slice(0, 240);
  const id = sanitizeDomainId(input.id || name);

  if (!name) throw new Error("Domain name is required");
  if (!description) throw new Error("Domain description is required");
  if (!id) throw new Error("Domain id must contain at least one letter or number");
  if (current.some((domain) => domain.id === id)) throw new Error(`Domain '${id}' already exists`);

  const domain = { id, name, description };
  const domains = mergeDomains(current, [domain]);
  await writeJson(domainsKey, domainsPath, { version: 1, domains: domains.filter((item) => !DEFAULT_DOMAINS.some((base) => base.id === item.id)), updatedAt: new Date().toISOString() });
  return { domain, domains };
}

export async function isDomainId(value: unknown): Promise<boolean> {
  if (typeof value !== "string") return false;
  const domains = await loadDomains();
  return domains.some((domain) => domain.id === value);
}

export async function normalizeDomains(input: unknown): Promise<DomainId[]> {
  const domains = await loadDomains();
  const validIds = new Set(domains.map((domain) => domain.id));
  const defaultIds = DEFAULT_DOMAINS.map((domain) => domain.id);
  if (!Array.isArray(input)) return defaultIds;
  const selected = input.filter((value): value is string => typeof value === "string" && validIds.has(value));
  return selected.length ? Array.from(new Set(selected)) : defaultIds;
}

export function sanitizeDomainId(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
}

function normalizeDomain(value: unknown): Domain | null {
  if (!value || typeof value !== "object") return null;
  const item = value as Partial<Domain>;
  const id = typeof item.id === "string" ? sanitizeDomainId(item.id) : "";
  const name = typeof item.name === "string" ? item.name.trim().slice(0, 80) : "";
  const description = typeof item.description === "string" ? item.description.trim().slice(0, 240) : "";
  if (!id || !name || !description) return null;
  return { id, name, description };
}

function mergeDomains(...groups: Domain[][]) {
  const byId = new Map<string, Domain>();
  for (const group of groups) {
    for (const domain of group) byId.set(domain.id, domain);
  }
  return Array.from(byId.values()).sort((a, b) => {
    const aBase = DEFAULT_DOMAINS.some((domain) => domain.id === a.id);
    const bBase = DEFAULT_DOMAINS.some((domain) => domain.id === b.id);
    if (aBase !== bBase) return aBase ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
}
