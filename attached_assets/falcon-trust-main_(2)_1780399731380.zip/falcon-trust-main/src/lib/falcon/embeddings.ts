import { BedrockRuntimeClient, InvokeModelCommand } from "@aws-sdk/client-bedrock-runtime";
import path from "node:path";
import { buildCitationLink } from "./document-viewer";
import { chunkDocument, isReferenceEvidenceExcluded, loadChunks, tokenize } from "./corpus";
import { directEvidenceBoost, rankEvidenceCandidate } from "./retrieval-ranking";
import { listJson, readJson, writeJson } from "./storage";
import type { Citation, DemoDocument, DomainId, EmbeddingConfig, EmbeddingMutationResult, EmbeddingRecord, PublicEmbeddingStatus, VectorIndex } from "./types";

const dataDir = process.env.FALCON_DATA_DIR ?? path.join(process.cwd(), ".demo-data");
const defaultVectorIndexPath = path.join(dataDir, "vector-index.json");
const defaultVectorIndexKey = "vectors/vector-index.json";

export function getVectorIndexConfig() {
  const configuredKey = process.env.FALCON_VECTOR_INDEX_KEY?.trim() || defaultVectorIndexKey;
  const configuredPath = process.env.FALCON_VECTOR_INDEX_PATH?.trim();
  const localPath = configuredPath
    ? path.resolve(process.cwd(), configuredPath)
    : configuredKey === defaultVectorIndexKey
      ? defaultVectorIndexPath
      : path.join(dataDir, configuredKey);

  return {
    key: configuredKey,
    localPath,
  };
}

export const defaultEmbeddingConfig: EmbeddingConfig = {
  provider: "bedrock",
  region: process.env.FALCON_EMBEDDING_REGION || process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-2",
  model: process.env.FALCON_EMBEDDING_MODEL || "amazon.titan-embed-text-v2:0",
  enabled: process.env.FALCON_EMBEDDINGS_ENABLED !== "false",
};

export async function getEmbeddingStatus(): Promise<PublicEmbeddingStatus> {
  const backend = process.env.FALCON_RETRIEVAL_BACKEND?.trim();
  if (backend === "bedrock-s3-vector") return getActiveVectorBackendStatus();

  return getChunkMatchEmbeddingStatus();
}

async function getActiveVectorBackendStatus(): Promise<PublicEmbeddingStatus> {
  const index = await readVectorIndex();
  const allowlist = getDocumentAllowlist();
  const records = index.records.filter((record) => isDocumentAllowed(record.documentId, allowlist));
  const vectorIndexConfig = getVectorIndexConfig();
  const recordCount = records.length;

  return {
    config: defaultEmbeddingConfig,
    vectorStore: "s3-json",
    indexPath: `s3://${process.env.FALCON_STORAGE_BUCKET ?? "local"}/${vectorIndexConfig.key}`,
    chunkCount: recordCount,
    vectorCount: recordCount,
    staleCount: 0,
    lastIndexedAt: index.updatedAt,
    ready: recordCount > 0,
    backend: "bedrock-s3-vector",
    activeIndexKey: vectorIndexConfig.key,
    displayMode: "active-backend",
    notes: ["Reflects the active Bedrock/S3 vector backend inventory instead of matching local chunk IDs."],
  };
}

async function getChunkMatchEmbeddingStatus(): Promise<PublicEmbeddingStatus> {
  const chunks = await loadChunks();
  const index = await readVectorIndex();
  const chunkIds = new Set(chunks.map((chunk) => chunk.id));
  const indexedRecords = index.records.filter((record) => chunkIds.has(record.chunkId));
  const vectorIndexConfig = getVectorIndexConfig();

  return {
    config: defaultEmbeddingConfig,
    vectorStore: "s3-json",
    indexPath: `s3://${process.env.FALCON_STORAGE_BUCKET ?? "local"}/${vectorIndexConfig.key}`,
    chunkCount: chunks.length,
    vectorCount: indexedRecords.length,
    staleCount: Math.max(chunks.length - indexedRecords.length, 0),
    lastIndexedAt: index.updatedAt,
    ready: indexedRecords.length > 0 && indexedRecords.length >= chunks.length,
    backend: process.env.FALCON_RETRIEVAL_BACKEND?.trim() === "pgvector" ? "pgvector" : "lexical-file",
    activeIndexKey: vectorIndexConfig.key,
    displayMode: "chunk-index-match",
  };
}

export async function reindexEmbeddings(): Promise<PublicEmbeddingStatus> {
  const vectorIndex = await buildFullVectorIndex();
  const vectorIndexConfig = getVectorIndexConfig();
  await writeJson(vectorIndexConfig.key, vectorIndexConfig.localPath, vectorIndex);
  return getEmbeddingStatus();
}

export async function buildFullVectorIndex(): Promise<VectorIndex> {
  const chunks = await loadChunks();
  const records: EmbeddingRecord[] = [];

  for (const chunk of chunks) {
    await wait(350);
    const embedding = await embedText(chunk.text);
    records.push({
      chunkId: chunk.id,
      documentId: chunk.documentId,
      title: chunk.title,
      domain: chunk.domain,
      text: chunk.text,
      index: chunk.index,
      sourcePath: chunk.sourcePath,
      contentType: chunk.contentType,
      embedding,
      metadata: chunk.metadata,
    });
  }

  const vectorIndex: VectorIndex = {
    version: 1,
    provider: defaultEmbeddingConfig.provider,
    model: defaultEmbeddingConfig.model,
    region: defaultEmbeddingConfig.region,
    updatedAt: new Date().toISOString(),
    records,
  };

  return vectorIndex;
}

export async function writeVectorIndexToKey(key: string, vectorIndex: VectorIndex) {
  const vectorIndexConfig = getVectorIndexConfig();
  const localPath = path.join(dataDir, key);
  return writeJson(key, localPath === vectorIndexConfig.localPath ? vectorIndexConfig.localPath : localPath, vectorIndex);
}

export async function readVectorIndexFromKey(key: string): Promise<VectorIndex> {
  try {
    const localPath = path.join(dataDir, key);
    const item = await readJson(key, localPath);
    const parsed = JSON.parse(item.body) as VectorIndex;
    return parsed.records ? parsed : emptyIndex();
  } catch {
    return emptyIndex();
  }
}

export async function indexDocumentEmbeddings(document: DemoDocument): Promise<EmbeddingMutationResult> {
  const index = await readVectorIndex();
  const previousVectorCount = index.records.length;
  const retainedRecords = index.records.filter((record) => record.documentId !== document.id);
  const removedVectorCount = previousVectorCount - retainedRecords.length;
  const newRecords = await embedDocument(document);
  await writeVectorIndex({
    ...indexWithDefaults(index),
    updatedAt: new Date().toISOString(),
    records: [...retainedRecords, ...newRecords],
  });
  const status = await getEmbeddingStatus();

  return {
    strategy: "incremental-upsert",
    embeddedChunkCount: newRecords.length,
    removedVectorCount,
    previousVectorCount,
    nextVectorCount: retainedRecords.length + newRecords.length,
    status,
  };
}

export async function removeDocumentEmbeddings(documentId: string): Promise<EmbeddingMutationResult> {
  const index = await readVectorIndex();
  const previousVectorCount = index.records.length;
  const retainedRecords = index.records.filter((record) => record.documentId !== documentId);
  await writeVectorIndex({
    ...indexWithDefaults(index),
    updatedAt: new Date().toISOString(),
    records: retainedRecords,
  });
  const status = await getEmbeddingStatus();

  return {
    strategy: "incremental-delete",
    embeddedChunkCount: 0,
    removedVectorCount: previousVectorCount - retainedRecords.length,
    previousVectorCount,
    nextVectorCount: retainedRecords.length,
    status,
  };
}

async function embedDocument(document: DemoDocument) {
  const records: EmbeddingRecord[] = [];
  for (const chunk of chunkDocument(document)) {
    await wait(350);
    const embedding = await embedText(chunk.text);
    records.push({
      chunkId: chunk.id,
      documentId: chunk.documentId,
      title: chunk.title,
      domain: chunk.domain,
      text: chunk.text,
      index: chunk.index,
      sourcePath: chunk.sourcePath,
      contentType: chunk.contentType,
      embedding,
      metadata: chunk.metadata,
    });
  }
  return records;
}

async function writeVectorIndex(vectorIndex: VectorIndex) {
  const vectorIndexConfig = getVectorIndexConfig();
  await writeJson(vectorIndexConfig.key, vectorIndexConfig.localPath, vectorIndex);
}

function indexWithDefaults(index: VectorIndex): VectorIndex {
  return {
    version: index.version || 1,
    provider: index.provider || defaultEmbeddingConfig.provider,
    model: index.model || defaultEmbeddingConfig.model,
    region: index.region || defaultEmbeddingConfig.region,
    updatedAt: index.updatedAt,
    records: index.records ?? [],
  };
}

export async function retrieveVector(query: string, selectedDomains: DomainId[], limit = 5): Promise<Citation[]> {
  const index = await readVectorIndex();
  return retrieveVectorFromIndex(query, selectedDomains, limit, index);
}

export async function retrieveVectorFromIndex(query: string, selectedDomains: DomainId[], limit = 5, index?: VectorIndex): Promise<Citation[]> {
  const resolvedIndex = index ?? await readVectorIndex();
  const allowlist = getDocumentAllowlist();
  const records = resolvedIndex.records.filter((record) => selectedDomains.includes(record.domain) && isDocumentAllowed(record.documentId, allowlist));
  if (records.length === 0) return [];

  const queryEmbedding = await embedText(query);
  const expandedLimit = Math.max(limit, Number(process.env.FALCON_VECTOR_CANDIDATE_LIMIT ?? 12));
  const queryLower = query.toLowerCase();
  const vectorScored = records
    .map((record) => ({ record, vectorScore: cosineSimilarity(queryEmbedding, record.embedding) }))
    .filter((item) => Number.isFinite(item.vectorScore))
    .sort((a, b) => b.vectorScore - a.vectorScore);
  const candidatePool = mergeVectorAndDirectEvidenceCandidates(vectorScored, query, expandedLimit, limit);

  return candidatePool
    .map((item) => {
      const contentType = contentTypeMetadata(item.record.contentType ?? stringMetadata(item.record.metadata, "contentType"));
      const baseScore = item.vectorScore + vectorRerankScore(queryLower, item.record.text, item.record.title);
      const ranking = rankEvidenceCandidate({
        query,
        text: item.record.text,
        title: item.record.title,
        baseScore,
        contentType,
        metadata: item.record.metadata,
      });
      return { ...item, score: ranking.adjustedScore, ranking, contentType };
    })
    .filter((item) => isCitationEvidenceEligible(item.record.text))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ record, score, ranking, contentType }) => {
      const citation: Citation = {
        documentId: record.documentId,
        title: record.title,
        domain: record.domain,
        snippet: cleanSnippet(record.text),
        score: Number(score.toFixed(3)),
        chunkId: record.chunkId,
        chunkIndex: record.index,
        sourcePath: record.sourcePath ?? stringMetadata(record.metadata, "sourcePath"),
        source: sourceMetadata(record.metadata),
        sourceFileName: stringMetadata(record.metadata, "sourceFileName"),
        contentType,
        metadata: {
          ...(record.metadata ?? {}),
          evidenceBaseScore: ranking.baseScore,
          evidenceAdjustedScore: ranking.adjustedScore,
          evidenceRankFactors: ranking.factors.join(", "),
          queryOverlap: ranking.queryOverlap,
        },
        text: record.text,
      };
      return { ...citation, viewerUrl: buildCitationLink(citation).href };
    });
}

function mergeVectorAndDirectEvidenceCandidates(
  vectorScored: { record: EmbeddingRecord; vectorScore: number }[],
  query: string,
  expandedLimit: number,
  limit: number,
) {
  const selected = new Map<string, { record: EmbeddingRecord; vectorScore: number }>();
  for (const item of vectorScored.slice(0, expandedLimit)) {
    selected.set(item.record.chunkId, item);
  }

  const directLimit = Math.max(limit, 6);
  const directMatches = vectorScored
    .map((item) => ({
      ...item,
      directScore: directEvidenceBoost({ query, text: item.record.text, title: item.record.title }).score,
    }))
    .filter((item) => item.directScore >= 0.45)
    .sort((a, b) => b.directScore - a.directScore || b.vectorScore - a.vectorScore)
    .slice(0, directLimit);

  for (const item of directMatches) {
    selected.set(item.record.chunkId, {
      record: item.record,
      vectorScore: Math.max(item.vectorScore, item.directScore),
    });
  }

  return Array.from(selected.values());
}

function stringMetadata(metadata: EmbeddingRecord["metadata"], key: string) {
  const value = metadata?.[key];
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function sourceMetadata(metadata: EmbeddingRecord["metadata"]): Citation["source"] | undefined {
  const value = metadata?.source;
  return value === "static" || value === "uploaded" ? value : undefined;
}

function contentTypeMetadata(value: unknown): Citation["contentType"] | undefined {
  return value === "body" || value === "index" || value === "reference" || value === "unknown" ? value : undefined;
}

function vectorRerankScore(queryLower: string, text: string, title: string) {
  const lowerText = text.toLowerCase();
  const lowerTitle = title.toLowerCase();
  let score = 0;

  for (const phrase of vectorCuePhrases(queryLower)) {
    if (lowerText.includes(phrase)) score += phrase.length > 10 ? 0.1 : 0.06;
  }

  if (/level 3/.test(queryLower) && /japan/.test(queryLower) && /japan/.test(lowerTitle)) {
    if (/level\s*3|aged and disabled|elderly|prepare for evacuation|evacuation of the elderly/.test(lowerText)) score += 0.25;
  }
  if (/locally driven/.test(queryLower) && /south sudan/.test(queryLower) && /south sudan/.test(lowerTitle)) {
    if (/structural|non-structural|nonstructural|local drr/.test(lowerText)) score += 0.18;
  }
  if (/percentage|share|baseline|one year/.test(queryLower) && /\b(?:77(?:\.3)?|40(?:\.8)?)\b/.test(lowerText)) score += 0.16;
  if (/100-year|flood magnitude/.test(queryLower) && /100-year flood/.test(lowerText)) score += 0.18;

  return score;
}

function vectorCuePhrases(queryLower: string) {
  const phrases = [
    "level 3",
    "elderly",
    "disabled",
    "prepare to evacuate",
    "100-year flood",
    "take action",
    "accept help",
    "self-discovery",
    "long-term perspective",
    "hope",
    "drowning",
    "exhaustion",
    "building collapse",
    "vehicles",
    "77",
    "40",
    "structural",
    "non-structural",
    "nonstructural",
  ];
  return phrases.filter((phrase) => queryLower.includes(phrase) || /level|fatalit|preparedness|south sudan|resilience|hazus/.test(queryLower));
}

export async function readVectorIndex(): Promise<VectorIndex> {
  try {
    const vectorIndexConfig = getVectorIndexConfig();
    const records = await listJson(vectorIndexConfig.key, vectorIndexConfig.localPath);
    if (!records[0]?.body) return emptyIndex();
    const parsed = JSON.parse(records[0].body) as VectorIndex;
    return parsed.records ? parsed : emptyIndex();
  } catch {
    return emptyIndex();
  }
}

export function getDocumentAllowlist(): Set<string> | null {
  const configured = process.env.FALCON_VECTOR_DOCUMENT_ALLOWLIST?.trim();
  if (!configured) return null;
  const values = configured.split(",").map((value) => value.trim()).filter(Boolean);
  return values.length ? new Set(values) : null;
}

function isDocumentAllowed(documentId: string, allowlist: Set<string> | null) {
  return !allowlist || allowlist.has(documentId);
}

function emptyIndex(): VectorIndex {
  return {
    version: 1,
    provider: defaultEmbeddingConfig.provider,
    model: defaultEmbeddingConfig.model,
    region: defaultEmbeddingConfig.region,
    records: [],
  };
}

async function embedText(text: string): Promise<number[]> {
  if (!defaultEmbeddingConfig.enabled) throw new Error("Embeddings are disabled");

  const client = new BedrockRuntimeClient({ region: defaultEmbeddingConfig.region });
  let lastError: unknown;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      const response = await client.send(
        new InvokeModelCommand({
          modelId: defaultEmbeddingConfig.model,
          contentType: "application/json",
          accept: "application/json",
          body: JSON.stringify({ inputText: text.slice(0, 24000) }),
        }),
      );

      const payload = JSON.parse(Buffer.from(response.body).toString("utf8")) as { embedding?: number[]; embeddingsByType?: { float?: number[] } };
      const embedding = payload.embedding ?? payload.embeddingsByType?.float;
      if (!embedding?.length) throw new Error("Bedrock returned no embedding vector");
      return embedding;
    } catch (error) {
      lastError = error;
      if (!isThrottle(error)) throw error;
      await wait(1000 * (attempt + 1));
    }
  }

  throw lastError instanceof Error ? lastError : new Error("Embedding request failed");
}

function isThrottle(error: unknown) {
  return error instanceof Error && /throttl|too many requests/i.test(error.message);
}

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function cosineSimilarity(a: number[], b: number[]) {
  let dot = 0;
  let aMag = 0;
  let bMag = 0;
  const length = Math.min(a.length, b.length);
  for (let i = 0; i < length; i += 1) {
    dot += a[i] * b[i];
    aMag += a[i] * a[i];
    bMag += b[i] * b[i];
  }
  return dot / (Math.sqrt(aMag) * Math.sqrt(bMag) || 1);
}

function cleanSnippet(text: string) {
  return text
    .replace(/^#+\s+/gm, "")
    .replace(/^\s*(?:Page\s+\d+|FALCON COUNTY FLOOD RESPONSE BULLETIN)\s*$/gim, "")
    .replace(/[\uFB00-\uFB06]/g, (match) => LIGATURE_REPLACEMENTS[match] ?? match)
    .replace(/\bTechnologyexclusion\b/gi, "Technology exclusion")
    .replace(/\bTechnologicalexclusion\b/gi, "Technological exclusion")
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 420);
}

function isCitationEvidenceEligible(text: string) {
  if (isReferenceEvidenceExcluded(text)) return false;
  const compact = text.replace(/\s+/g, " ").trim();
  if (/\b(table of contents|contents list|index|see page\s+\d+|chapter\s+\d+\s*\.{2,}|\.{2,}\s*\d+)\b/i.test(compact)) return false;
  const tokens = tokenize(compact);
  return tokens.length >= 8;
}

const LIGATURE_REPLACEMENTS: Record<string, string> = {
  "\uFB00": "ff",
  "\uFB01": "fi",
  "\uFB02": "fl",
  "\uFB03": "ffi",
  "\uFB04": "ffl",
  "\uFB05": "st",
  "\uFB06": "st",
};
