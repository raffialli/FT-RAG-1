import type { ExternalSearchResult, ExternalSearchStatus } from "./types";

const tavilyEndpoint = "https://api.tavily.com/search";

export type ExternalSearchSynthesis = {
  summary: string;
  results: ExternalSearchResult[];
  status: ExternalSearchStatus;
};

type TavilyResponse = {
  results?: Array<{
    title?: string;
    url?: string;
    content?: string;
    score?: number;
    published_date?: string;
  }>;
};

export async function runExternalSearch(query: string): Promise<ExternalSearchSynthesis> {
  const apiKey = process.env.TAVILY_API_KEY?.trim();
  const baseStatus: ExternalSearchStatus = {
    enabled: true,
    provider: "tavily",
    configured: Boolean(apiKey),
    attempted: false,
    ok: false,
    resultCount: 0,
  };

  if (!apiKey) {
    return {
      summary: "External Search is on, but Tavily is not configured. The answer below falls back to internal Falcontrust document evidence only.",
      results: [],
      status: {
        ...baseStatus,
        warning: "TAVILY_API_KEY is not configured.",
      },
    };
  }

  try {
    const response = await fetch(tavilyEndpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Never log this header or expose it in API responses.
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        query,
        search_depth: "advanced",
        max_results: 5,
        include_answer: false,
        include_raw_content: false,
      }),
    });

    if (!response.ok) {
      return {
        summary: `External Search is on, but Tavily returned HTTP ${response.status}. The answer below falls back to internal Falcontrust document evidence only.`,
        results: [],
        status: {
          ...baseStatus,
          attempted: true,
          warning: `Tavily search failed with HTTP ${response.status}.`,
        },
      };
    }

    const payload = await response.json().catch(() => ({})) as TavilyResponse;
    const results = (payload.results ?? [])
      .map((item): ExternalSearchResult | null => {
        const title = typeof item.title === "string" ? item.title.trim() : "";
        const url = typeof item.url === "string" ? item.url.trim() : "";
        const snippet = typeof item.content === "string" ? item.content.replace(/\s+/g, " ").trim() : "";
        if (!title || !url || !snippet) return null;
        return {
          title,
          url,
          snippet: snippet.slice(0, 700),
          source: "tavily",
          score: typeof item.score === "number" ? item.score : undefined,
          publishedDate: typeof item.published_date === "string" ? item.published_date : undefined,
        };
      })
      .filter(Boolean) as ExternalSearchResult[];

    if (!results.length) {
      return {
        summary: "External Search is on, but Tavily returned no usable web results. The answer below falls back to internal Falcontrust document evidence only.",
        results: [],
        status: {
          ...baseStatus,
          attempted: true,
          configured: true,
          warning: "Tavily returned no usable web results.",
        },
      };
    }

    return {
      summary: buildExternalSummary(results),
      results,
      status: {
        ...baseStatus,
        configured: true,
        attempted: true,
        ok: true,
        resultCount: results.length,
      },
    };
  } catch {
    return {
      summary: "External Search is on, but Tavily could not be reached. The answer below falls back to internal Falcontrust document evidence only.",
      results: [],
      status: {
        ...baseStatus,
        configured: true,
        attempted: true,
        warning: "Tavily search request failed.",
      },
    };
  }
}

function buildExternalSummary(results: ExternalSearchResult[]) {
  return results
    .slice(0, 5)
    .map((result, index) => `${index + 1}. ${result.title}: ${result.snippet} (${result.url})`)
    .join("\n");
}
