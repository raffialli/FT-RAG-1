import path from "node:path";
import { listJson, writeJson } from "./storage";
import type { QuerySession } from "./types";

const dataDir = process.env.FALCON_DATA_DIR ?? path.join(process.cwd(), ".demo-data");
const historyPath = path.join(dataDir, "query-history.json");
const historyKey = "runtime/query-history.json";

export async function readHistory(): Promise<QuerySession[]> {
  try {
    const records = await listJson(historyKey, historyPath);
    const parsed = records[0]?.body ? JSON.parse(records[0].body) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function appendHistory(session: Omit<QuerySession, "id" | "createdAt">): Promise<QuerySession> {
  const next: QuerySession = {
    ...session,
    id: `session-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  };
  const history = [next, ...(await readHistory())].slice(0, 50);
  await writeJson(historyKey, historyPath, history);
  return next;
}
