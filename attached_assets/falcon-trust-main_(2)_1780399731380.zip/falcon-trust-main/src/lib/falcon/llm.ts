import { publicArticleConfig, readArticleConfig } from "./article-config";
import type { ArticleConfig, Citation, PublicArticleConfig } from "./types";

export type LlmGenerateOptions = {
  temperature?: number;
  numPredict?: number;
  timeoutMs?: number;
};

export type LlmGenerateResult = {
  answer: string;
  config: PublicArticleConfig;
  generatedBy: "ollama";
};

export async function generateWithConfiguredLlm(prompt: string, options: LlmGenerateOptions = {}): Promise<LlmGenerateResult> {
  const config = await readArticleConfig();
  const answer = await generateWithOllama(prompt, config, options);
  return { answer, config: publicArticleConfig(config), generatedBy: "ollama" };
}

export function formatCitationBlock(citations: Citation[]) {
  return citations
    .map((citation, index) => `[${index + 1}] ${citation.title} (${citation.domain}, relevance ${citation.score})\n${citation.snippet}`)
    .join("\n\n");
}

async function generateWithOllama(prompt: string, config: ArticleConfig, options: LlmGenerateOptions) {
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (config.apiKey) headers.authorization = `Bearer ${config.apiKey}`;

  const response = await fetch(`${config.endpoint.replace(/\/$/, "")}/api/generate`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: config.model,
      prompt,
      stream: false,
      think: false,
      options: {
        temperature: options.temperature ?? 0.25,
        top_p: 0.9,
        num_predict: options.numPredict ?? 900,
      },
    }),
    signal: AbortSignal.timeout(options.timeoutMs ?? 120000),
  });

  if (!response.ok) throw new Error(`Ollama returned ${response.status}: ${await response.text()}`);
  const data = (await response.json()) as { response?: string };
  const answer = data.response?.trim();
  if (!answer) throw new Error("Ollama returned an empty response");
  return answer;
}
