import path from "node:path";
import { buildFullVectorIndex, getVectorIndexConfig, readVectorIndexFromKey, writeVectorIndexToKey } from "./embeddings";
import { loadChunks } from "./corpus";
import { copyJson } from "./storage";
import type { EmbeddingRecord, VectorIndex } from "./types";

type ReindexJobMode = "dry-run" | "candidate";
type ReindexJobState = "queued" | "running" | "completed" | "failed";

type ReindexJob = {
  id: string;
  mode: ReindexJobMode;
  state: ReindexJobState;
  createdAt: string;
  startedAt?: string;
  updatedAt: string;
  finishedAt?: string;
  activeKey: string;
  backupKey?: string;
  candidateKey?: string;
  chunkCount?: number;
  vectorCount?: number;
  distinctDocumentCount?: number;
  distinctChunkCount?: number;
  provider?: string;
  model?: string;
  region?: string;
  error?: string;
  notes: string[];
};

const jobs = new Map<string, ReindexJob>();
let runningJobId: string | null = null;

export function listReindexJobs() {
  return Array.from(jobs.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 10);
}

export function getReindexJob(id: string) {
  return jobs.get(id) ?? null;
}

export function startReindexJob(input: { mode?: string; confirm?: string } = {}) {
  const mode = normalizeMode(input.mode);
  if (mode === "candidate" && input.confirm !== "write-temp-vector") {
    throw new Error("Candidate reindex requires confirm=write-temp-vector");
  }
  if (runningJobId) throw new Error(`Reindex job already running: ${runningJobId}`);

  const now = new Date().toISOString();
  const activeKey = getVectorIndexConfig().key;
  const job: ReindexJob = {
    id: `reindex-${now.replace(/[-:.]/g, "").replace("T", "-").replace("Z", "")}`,
    mode,
    state: "queued",
    createdAt: now,
    updatedAt: now,
    activeKey,
    notes: [
      "Job is process-local; App Runner restarts clear in-memory status.",
      mode === "dry-run" ? "Dry-run computes scope only and writes no S3/vector objects." : "Candidate mode writes backup and temp vector objects, verifies the candidate shape, and leaves active promotion manual.",
    ],
  };
  jobs.set(job.id, job);

  runningJobId = job.id;
  void runReindexJob(job).finally(() => {
    runningJobId = null;
  });

  return job;
}

function normalizeMode(mode?: string): ReindexJobMode {
  if (!mode || mode === "dry-run") return "dry-run";
  if (mode === "candidate") return "candidate";
  throw new Error("Unsupported reindex job mode");
}

async function runReindexJob(job: ReindexJob) {
  mark(job, { state: "running", startedAt: new Date().toISOString() });
  try {
    const chunks = await loadChunks();
    const docIds = new Set(chunks.map((chunk) => chunk.documentId));
    job.chunkCount = chunks.length;
    job.distinctDocumentCount = docIds.size;
    job.distinctChunkCount = new Set(chunks.map((chunk) => chunk.id)).size;

    if (job.mode === "dry-run") {
      mark(job, {
        state: "completed",
        finishedAt: new Date().toISOString(),
        notes: [...job.notes, "Dry-run completed without embedding calls or writes."],
      });
      return;
    }

    const vectorIndexConfig = getVectorIndexConfig();
    const baseName = path.basename(vectorIndexConfig.key);
    job.backupKey = `restore-points/${job.id}-before-candidate/${vectorIndexConfig.key}`;
    job.candidateKey = `vectors/reindex-candidates/${job.id}-${baseName}`;
    mark(job, {});

    await copyJson(vectorIndexConfig.key, vectorIndexConfig.localPath, job.backupKey, path.join(process.cwd(), ".demo-data", job.backupKey));
    const vectorIndex = await buildFullVectorIndex();
    job.vectorCount = vectorIndex.records.length;
    job.provider = vectorIndex.provider;
    job.model = vectorIndex.model;
    job.region = vectorIndex.region;
    await writeVectorIndexToKey(job.candidateKey, vectorIndex);

    const verified = await readVectorIndexFromKey(job.candidateKey);
    verifyCandidateVectorIndex(vectorIndex, verified);

    mark(job, {
      state: "completed",
      finishedAt: new Date().toISOString(),
      notes: [...job.notes, "Candidate vector passed count, id, metadata, and embedding-shape checks. Active vector was not promoted or overwritten; promotion remains manual."],
    });
  } catch (error) {
    mark(job, {
      state: "failed",
      finishedAt: new Date().toISOString(),
      error: error instanceof Error ? error.message : "Unknown reindex job error",
    });
  }
}

function mark(job: ReindexJob, updates: Partial<ReindexJob>) {
  Object.assign(job, updates, { updatedAt: new Date().toISOString() });
}

function verifyCandidateVectorIndex(expected: VectorIndex, verified: VectorIndex) {
  if (!expected.records.length) throw new Error("Candidate verification failed: generated vector index is empty");
  if (verified.version !== expected.version || verified.provider !== expected.provider || verified.model !== expected.model || verified.region !== expected.region) {
    throw new Error("Candidate verification failed: index metadata changed during write/read verification");
  }
  if (verified.records.length !== expected.records.length) {
    throw new Error(`Candidate verification failed: expected ${expected.records.length} records, found ${verified.records.length}`);
  }

  const expectedByChunk = new Map(expected.records.map((record) => [record.chunkId, record]));
  const seenChunkIds = new Set<string>();
  const expectedDimension = embeddingDimension(expected.records[0]);
  if (!expectedDimension) throw new Error("Candidate verification failed: generated records have no embedding dimensions");

  for (const record of verified.records) {
    if (!record.chunkId || !record.documentId || !record.title || !record.domain || !record.text) {
      throw new Error("Candidate verification failed: record missing required metadata");
    }
    if (seenChunkIds.has(record.chunkId)) throw new Error(`Candidate verification failed: duplicate chunk id ${record.chunkId}`);
    seenChunkIds.add(record.chunkId);

    const expectedRecord = expectedByChunk.get(record.chunkId);
    if (!expectedRecord) throw new Error(`Candidate verification failed: unexpected chunk id ${record.chunkId}`);
    if (record.documentId !== expectedRecord.documentId || record.index !== expectedRecord.index || record.domain !== expectedRecord.domain) {
      throw new Error(`Candidate verification failed: metadata mismatch for chunk id ${record.chunkId}`);
    }

    const dimension = embeddingDimension(record);
    if (dimension !== expectedDimension) {
      throw new Error(`Candidate verification failed: embedding dimension mismatch for chunk id ${record.chunkId}`);
    }
  }
}

function embeddingDimension(record: EmbeddingRecord | undefined) {
  if (!record?.embedding?.length) return 0;
  if (!record.embedding.every((value) => Number.isFinite(value))) return 0;
  return record.embedding.length;
}
