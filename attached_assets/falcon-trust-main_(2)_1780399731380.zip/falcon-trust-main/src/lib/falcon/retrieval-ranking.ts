import type { Chunk, Citation } from "./types";

type EvidenceCandidate = {
  query: string;
  text: string;
  title?: string;
  baseScore: number;
  contentType?: Chunk["contentType"] | Citation["contentType"];
  metadata?: Chunk["metadata"] | Citation["metadata"];
};

const STOP_WORDS = new Set([
  "the", "and", "for", "that", "with", "this", "from", "are", "should", "into", "when", "what", "about",
  "have", "has", "can", "may", "not", "but", "use", "using", "their", "they", "them", "our", "your",
  "documents", "document", "selected", "source", "sources", "say", "says", "corpus",
]);

export function rankEvidenceCandidate(input: EvidenceCandidate) {
  const text = input.text.replace(/\s+/g, " ").trim();
  const title = input.title ?? "";
  const factors: string[] = [];
  let adjustment = 0;

  const overlap = queryOverlapScore(input.query, [title, text].join(" "));
  if (overlap >= 0.45) {
    adjustment += 0.18;
    factors.push("strong-query-overlap");
  } else if (overlap >= 0.25) {
    adjustment += 0.1;
    factors.push("query-overlap");
  } else if (overlap > 0) {
    adjustment += 0.04;
    factors.push("weak-query-overlap");
  }

  const metadataFields = [
    input.metadata?.documentId,
    input.metadata?.chunkId,
    input.metadata?.title,
    input.metadata?.domain,
    input.metadata?.sourcePath,
    input.metadata?.contentType,
  ].filter(Boolean).length;

  if (input.contentType === "body") {
    adjustment += 0.04;
    factors.push("body-evidence");
  } else if (input.contentType === "index" || input.contentType === "reference") {
    adjustment -= 0.4;
    factors.push("index-reference-penalty");
  }

  if (metadataFields >= 5) {
    adjustment += 0.03;
    factors.push("metadata-complete");
  }

  const directBoost = directEvidenceBoost({ query: input.query, text, title });
  if (directBoost.score > 0) {
    adjustment += directBoost.score;
    factors.push(...directBoost.factors);
  }

  if (hasCopyrightOrFrontmatterLeakage(text)) {
    adjustment -= 0.28;
    factors.push("frontmatter-copyright-penalty");
  }

  if (hasJournalFrontmatterOrAdLeakage(text)) {
    adjustment -= 0.32;
    factors.push("journal-frontmatter-ad-penalty");
  }

  if (hasOcrHyphenationArtifact(text)) {
    adjustment -= 0.12;
    factors.push("ocr-hyphenation-penalty");
  }

  if (hasFigureOrLayoutLeakage(text)) {
    adjustment -= 0.14;
    factors.push("figure-layout-penalty");
  }

  if (looksLikeBibliographicReference(text)) {
    adjustment -= 0.34;
    factors.push("bibliographic-reference-penalty");
  }

  const adjustedScore = Math.max(0, input.baseScore + adjustment);
  return {
    baseScore: Number(input.baseScore.toFixed(3)),
    adjustedScore: Number(adjustedScore.toFixed(3)),
    adjustment: Number(adjustment.toFixed(3)),
    factors,
    queryOverlap: Number(overlap.toFixed(3)),
  };
}

export function directEvidenceBoost(input: { query: string; text: string; title?: string }) {
  const query = input.query.toLowerCase();
  const text = input.text.replace(/\s+/g, " ").toLowerCase();
  const title = (input.title ?? "").toLowerCase();
  const factors: string[] = [];
  let score = 0;

  const queryTerms = contentTerms(query);
  if (!queryTerms.length) return { score: 0, factors };

  const matchedTerms = queryTerms.filter((term) => text.includes(term));
  const coverage = matchedTerms.length / queryTerms.length;

  if (coverage >= 0.65) {
    score += 0.18;
    factors.push("direct-query-coverage");
  } else if (coverage >= 0.45) {
    score += 0.1;
    factors.push("partial-query-coverage");
  }

  const exactPhraseHits = queryPhrases(query).filter((phrase) => text.includes(phrase)).length;
  if (exactPhraseHits >= 2) {
    score += 0.18;
    factors.push("multiple-exact-phrase-overlap");
  } else if (exactPhraseHits === 1) {
    score += 0.08;
    factors.push("exact-phrase-overlap");
  }

  if (asksForListAnswer(query) && hasListLikeAnswerEvidence(text)) {
    score += 0.28;
    factors.push("list-answer-evidence");
  }

  if (asksForDefinitionOrPurpose(query) && hasDefinitionOrPurposeEvidence(text)) {
    score += 0.16;
    factors.push("definition-purpose-evidence");
  }

  if (asksForContractReviewTerms(query) && hasContractReviewTermEvidence(text)) {
    score += 0.45;
    factors.push("contract-review-term-evidence");
  }

  if (coverage >= 0.45 && title && queryTerms.some((term) => title.includes(term))) {
    score += 0.06;
    factors.push("title-query-alignment");
  }

  return {
    score: Number(Math.min(score, 0.7).toFixed(3)),
    factors,
  };
}

export function hasCopyrightOrFrontmatterLeakage(text: string) {
  return /\b(?:please\s+visit\s+www\.copyright\.com|all\s+rights\s+reserved|copyright\s+clearance\s+center|no\s+part\s+of\s+this\s+(?:book|publication)|library\s+(?:of|~\()?\s*con(?:g|j)ress|cataloging-in-publication|lccn|isbn|first\s+published|published\s+by\s+routledge|taylor\s*&\s*francis)\b/i.test(text);
}

export function hasJournalFrontmatterOrAdLeakage(text: string) {
  const compact = text.replace(/\s+/g, " ").trim();
  if (/\beditorial board\b/i.test(compact)) return true;
  if (/\bvisit our website\b/i.test(compact) && /\ball rights reserved\b/i.test(compact)) return true;

  const markerCount = [
    /uploaded (?:demo )?pdf/i,
    /\bissn\s+\d{4}-\d{3}[\dx]\b/i,
    /\bvolume\s+\d+\s*,?\s*number\s+\d+\b/i,
    /-{2,}\s*page\s+\d+\s+of\s+\d+\s*-{2,}/i,
    /\bjournal\s*of\s+emergency\s+management\b/i,
    /\b(?:www\.[a-z0-9.-]+|https?:\/\/)\b/i,
    /\bcopyright\b/i,
  ].filter((pattern) => pattern.test(compact)).length;

  return markerCount >= 3;
}

export function hasFigureOrLayoutLeakage(text: string) {
  return /\b(?:figure|fig\.|table)\s+\d+(?:\.\d+)?\b/i.test(text) && /\b(?:shows?|pros\s+and\s+cons|cross\s+analysis|diagram|caption)\b/i.test(text);
}

export function hasOcrHyphenationArtifact(text: string) {
  return /\b[A-Za-z]{2,}-\s+[a-z]{2,}\b/.test(text);
}

function looksLikeBibliographicReference(text: string) {
  const compact = text.replace(/\s+/g, " ").trim();
  if (/^(?:references?|bibliography|works cited)\b/i.test(compact)) return true;
  if (/\b(?:accessed\s+at\s+https?:\/\/|doi:|journal|proceedings|briefing\s+paper|university\s+press)\b/i.test(compact)) return true;
  if (/\b(?:accessed\s+at\s+https?:\/\/|doi:|journal|proceedings|briefing\s+paper|university\s+press)\b/i.test(compact) && /\b(?:19|20)\d{2}\b/.test(compact.slice(0, 500))) {
    return true;
  }
  return false;
}

function queryOverlapScore(query: string, text: string) {
  const queryTerms = contentTerms(query);
  if (!queryTerms.length) return 0;
  const textTerms = new Set(contentTerms(text));
  const hits = queryTerms.filter((term) => textTerms.has(term));
  return hits.length / queryTerms.length;
}

function contentTerms(text: string) {
  return Array.from(new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .split(/\s+/)
      .filter((token) => token.length > 2)
      .filter((token) => !STOP_WORDS.has(token)),
  ));
}

function queryPhrases(query: string) {
  const terms = contentTerms(query);
  const phrases: string[] = [];
  for (let size = 4; size >= 2; size -= 1) {
    for (let index = 0; index <= terms.length - size; index += 1) {
      phrases.push(terms.slice(index, index + size).join(" "));
    }
  }
  return Array.from(new Set(phrases));
}

function asksForListAnswer(query: string) {
  return /\b(?:components?|elements?|activities|steps?|strategies|types?|kinds?|parts?|requirements?)\b/.test(query);
}

function hasListLikeAnswerEvidence(text: string) {
  if (/\b(?:three|four|five|six|several|key)\b[^.]{0,120}\b(?:components?|elements?|activities|steps?|strategies|types?|kinds?|parts?|requirements?)\b/i.test(text)) return true;
  if (/:\s*[^.]{3,80},\s*[^.]{3,80}\b(?:and|or)\b\s*[^.]{3,80}[.!?]/i.test(text)) return true;
  return /(?:^|[.;])\s*(?:\d+\.|\([a-z]\)|[-•])\s+\S.{5,}/i.test(text);
}

function asksForDefinitionOrPurpose(query: string) {
  return /\b(?:what is|what are|define|definition|purpose|aims?|goals?|why)\b/.test(query);
}

function hasDefinitionOrPurposeEvidence(text: string) {
  return /\b(?:is|are|means|refers to|defined as|aims? to|goals? (?:are|is|include)|purpose (?:is|of)|intended to|designed to)\b/i.test(text);
}

function asksForContractReviewTerms(query: string) {
  return /\bcontracts?\b/.test(query)
    && /\b(?:terms?|standard(?:ized)?|vendor|contractor|scrutinize|review|accept|as-is|as is|language|clauses?)\b/.test(query);
}

function hasContractReviewTermEvidence(text: string) {
  const reviewSignal = /\b(?:scrutinize|review(?:ing)?|delete unacceptable language|modify|modification|standard(?:ized)? contracts?|contractor(?:’s|'s)? document|contract(?:ual)? language|clauses?)\b/i.test(text);
  const termSignals = [
    /\bindemnification\b/i,
    /\bwaivers?\b/i,
    /\barbitration\b/i,
    /\bcontrary to (?:state|local) law\b/i,
    /\bperformance standards?\b/i,
    /\bobligations? of the contractor\b/i,
  ].filter((pattern) => pattern.test(text)).length;

  return reviewSignal && termSignals >= 2;
}
