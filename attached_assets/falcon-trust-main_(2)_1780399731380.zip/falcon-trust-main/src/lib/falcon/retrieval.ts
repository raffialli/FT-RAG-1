import { getRetrievalBackend } from "./retrieval-backends";
import type { AnswerSections, AnswerType, AugmentedContextTrace, Citation, DomainId, ExternalSearchResult, RetrievalBackendId, RetrievalDebugTrace, QuerySession } from "./types";

export async function retrieve(query: string, selectedDomains: DomainId[], limit = 5) {
  const backend = getRetrievalBackend(process.env.FALCON_RETRIEVAL_BACKEND);
  return backend.retrieve({ query, selectedDomains, limit });
}

export async function buildAnswer(query: string, selectedDomains: DomainId[], mode: QuerySession["mode"], answerType: AnswerType = "clear_answer", _externalSearch = false, externalResults: ExternalSearchResult[] = []): Promise<Omit<QuerySession, "id" | "createdAt">> {
  const retrieval = await retrieve(query, selectedDomains, mode === "external_compare" ? 6 : 5);
  const retrievedCitations = retrieval.citations;
  const domainLabel = selectedDomains.map((domain) => domainName(domain)).join(" + ");
  const finalEvidence = selectFinalEvidence(query, retrievedCitations);
  const answerability = assessAnswerability(query, finalEvidence.citations);
  const evidencePolicy = assessEvidencePolicy(query, finalEvidence.citations, answerability);
  let confidence = capConfidence(assessConfidence(answerability, finalEvidence.citations), evidencePolicy.confidenceCap);
  const weak = !answerability.answerable || evidencePolicy.forceGap;
  const citations = weak || evidencePolicy.suppressCitations ? [] : selectVisibleCitations(query, finalEvidence.citations);
  const intent = answerType === "create_article" ? "article" : classifyIntent(query, mode);

  let answer: string;
  let suggestedAngle: string | undefined;
  const gaps: string[] = [];
  const generalGuidance: string[] = [];

  if (weak) {
    answer = `I do not see strong support in the selected ${domainLabel} documents. The safe answer is to mark this as a gap or select additional domains before relying on it.`;
    gaps.push(evidencePolicy.gap || answerability.gap);
    generalGuidance.push("Select additional domains or treat this as a review gap before publishing.");
  } else if (intent === "absolute_flood_claim") {
    answer = "No. The documents do not support saying sandbags prevent all flood damage. The grounded answer is that sandbags may help reduce minor water intrusion when placed correctly, but they do not guarantee protection from deep flooding, storm surge, or structural flooding.";
    gaps.push("No cited source supports an absolute flood-prevention guarantee.");
    gaps.push("Public-facing language should avoid overstating sandbag effectiveness.");
    generalGuidance.push("Use limited, source-backed language for public-facing flood guidance.");
  } else if (intent === "pickup_rules") {
    answer = "Say the pickup rules plainly: who is eligible, where pickup sites are located, when they are open, whether residents or businesses qualify, how many bags are allowed per household, and what people should bring. Also include the limitation that sandbags are a temporary mitigation tool and do not guarantee flood protection.";
    generalGuidance.push("Keep publication language operational and avoid implying sandbags guarantee protection.");
  } else if (intent === "article") {
    answer = "Article draft: Before a flood, residents need simple and specific sandbag pickup instructions: who qualifies, where pickup sites are located, when sites are open, whether proof of residency is required, and how many bags are available per household. The article should also explain that sandbags are a temporary mitigation tool. They can help reduce minor water intrusion when placed correctly, but they do not guarantee protection from serious flooding, storm surge, or structural damage.";
    suggestedAngle = "Clear pickup rules reduce confusion before a flood, while realistic wording avoids overstating what sandbags can do.";
    generalGuidance.push("Frame any article draft as publication guidance until reviewed against current policy.");
  } else if (intent === "publication_risk") {
    answer = "For public-facing material, keep claims specific, sourced, and appropriately limited. The selected documents support explaining the operational basis for emergency communications, giving practical resident guidance, and avoiding guarantees that sandbags prevent all flood damage. Before publishing, preserve citation support and flag any unsupported legal or factual claims as gaps.";
    gaps.push("Do not present general guidance as legal advice without review.");
    gaps.push("Do not promise complete flood protection or outcomes the cited documents do not support.");
    generalGuidance.push("Separate document-supported statements from legal or publication advice before release.");
  } else if (mode === "external_compare") {
    const internalAnswer = buildGroundedExtractiveAnswer(query, citations);
    answer = externalResults.length > 0
      ? buildExternalCompareAnswer(internalAnswer, externalResults)
      : internalAnswer;
    suggestedAngle = externalResults.length > 0
      ? "Use current web sources as external context, while keeping Falcontrust document citations as the customer-document evidence layer."
      : "External Search is selected, but no web results were available; rely on internal document evidence and flag the external gap.";
    if (!externalResults.length) gaps.push("External Search returned no usable web results for this request.");
    generalGuidance.push("Treat web context as separate from customer-document evidence.");
  } else {
    answer = buildGroundedExtractiveAnswer(query, citations);
  }

  const visibleQuality = assessVisibleAnswerQuality(answer, citations, finalEvidence.citations);
  confidence = capConfidence(confidence, visibleQuality.confidenceCap);
  if (visibleQuality.issues.length > 0) {
    gaps.push("Visible answer quality was degraded by " + visibleQuality.issues.join(", ") + ".");
  }

  const answerSections = buildAnswerSections({
    answer,
    citations,
    externalResults,
    gaps,
    generalGuidance,
    weak,
    mode,
  });

  return {
    mode,
    query,
    selectedDomains,
    answerType,
    answer,
    generatedBy: "template",
    confidence: confidence.level,
    citations,
    answerSections,
    suggestedAngle,
    gaps,
    retrievalTrace: retrieval.trace,
    debugTrace: withEvidenceQualityDebugTrace(retrieval.debugTrace, answerability, confidence, retrievedCitations.length, citations.length, finalEvidence, evidencePolicy, visibleQuality),
    augmentedContextTrace: buildAugmentedContextTrace(retrieval.trace.backend, citations),
    corpusInventory: retrieval.inventory,
  };
}

function buildAnswerSections({
  answer,
  citations,
  externalResults,
  gaps,
  generalGuidance,
  weak,
  mode,
}: {
  answer: string;
  citations: Citation[];
  externalResults: ExternalSearchResult[];
  gaps: string[];
  generalGuidance: string[];
  weak: boolean;
  mode: QuerySession["mode"];
}): AnswerSections {
  const supportedClaims = weak ? [] : documentSupportedClaims(answer, citations);
  const documentEvidence = supportedClaims.length > 0
    ? supportedClaims.map((claim) => `- ${claim}`).join("\n")
    : undefined;
  const externalContext = mode === "external_compare" && externalResults.length > 0
    ? externalResults.slice(0, 5).map((result, index) => `${index + 1}. ${result.title}: ${result.snippet}`).join("\n")
    : undefined;

  return {
    answer,
    documentEvidence,
    documentSupportedClaims: supportedClaims,
    generalGuidance,
    externalContext,
    gaps,
  };
}

function documentSupportedClaims(answer: string, citations: Citation[]) {
  const claims = new Set<string>();
  const normalizedAnswer = answer.toLowerCase();

  for (const citation of citations.slice(0, 5)) {
    const evidence = normalizeRuntimeEvidenceText(citation.text || citation.snippet).replace(/\s+/g, " ").trim();
    if (!evidence) continue;
    const sentences = evidence
      .split(/(?<=[.!?])\s+/)
      .map((sentence) => sentence.replace(/^[-•]\s*/, "").trim())
      .filter(Boolean);

    const best = sentences
      .map((sentence) => ({ sentence, overlap: overlappingTerms(answer, sentence).length }))
      .filter((item) => item.overlap >= 3 || normalizedAnswer.includes(item.sentence.toLowerCase()))
      .sort((a, b) => b.overlap - a.overlap)[0];

    if (best) claims.add(best.sentence);
  }

  return Array.from(claims).slice(0, 5);
}

type AnswerabilityAssessment = {
  answerable: boolean;
  reason: string;
  message: string;
  gap: string;
  supportingCitationCount: number;
  bestScore: number | null;
  strongestOverlapTermCount: number;
  thresholdSummary: string;
};

type ConfidenceAssessment = {
  level: QuerySession["confidence"];
  score: number;
  reason: string;
  factors: string[];
};

type FinalEvidenceSelection = {
  citations: Citation[];
  filtered: { chunkId?: string; reason: string }[];
};

type EvidencePolicyAssessment = {
  forceGap: boolean;
  suppressCitations: boolean;
  confidenceCap?: QuerySession["confidence"];
  reason: string;
  gap?: string;
};

type VisibleAnswerQualityAssessment = {
  confidenceCap?: QuerySession["confidence"];
  issues: string[];
};

const MIN_ANSWERABILITY_SCORE = 0.12;
const STRONG_SEMANTIC_SCORE = 0.32;
const INDEX_REFERENCE_PATTERNS = [
  /table of contents/i,
  /\bindex\b/i,
  /references?\b/i,
  /bibliography/i,
  /see page\s+\d+/i,
];
const BIBLIOGRAPHIC_MARKER_PATTERNS = [
  /\bISBN\b/i,
  /Cataloging-in-Publication/i,
  /Table of Contents/i,
  /List of Figures/i,
  /Accessed at/i,
  /\bdoi:/i,
];

function selectFinalEvidence(query: string, citations: Citation[]): FinalEvidenceSelection {
  const intent = classifyEvidenceIntent(query);
  const filtered: FinalEvidenceSelection["filtered"] = [];
  const selected: Citation[] = [];

  for (const citation of citations) {
    const quality = assessCitationQuality(citation);
    const reason = rejectionReasonForCitation(intent, quality);
    if (reason) {
      filtered.push({ chunkId: citation.chunkId, reason });
      continue;
    }
    selected.push(citation);
  }

  return { citations: selected, filtered };
}

function rejectionReasonForCitation(intent: EvidenceIntent, quality: CitationQualityAssessment) {
  if (quality.indexOrReference) return "reference-or-frontmatter-evidence-filtered";
  if (quality.ocrLayoutTainted) return "ocr-layout-evidence-filtered";
  if ((intent === "frontmatter_lookup" || intent === "current_policy" || intent === "manufactured_housing") && quality.normalizedPdfArtifact) {
    return "metadata-tainted-evidence-filtered";
  }
  return null;
}

function assessEvidencePolicy(query: string, citations: Citation[], answerability: AnswerabilityAssessment): EvidencePolicyAssessment {
  const intent = classifyEvidenceIntent(query);
  const text = citations.map(citationText).join(" ");
  const qualityAssessments = citations.map(assessCitationQuality);
  const hasPdfLayoutRisk = qualityAssessments.some((quality) => quality.ocrLayoutTainted || quality.normalizedPdfArtifact);

  if (intent === "absolute_flood_claim") {
    return {
      forceGap: false,
      suppressCitations: false,
      confidenceCap: "Medium",
      reason: "unsupported-absolute-claim-cautious-answer-with-citations",
      gap: "No cited source supports an absolute flood-prevention guarantee.",
    };
  }

  if (intent === "current_policy" && !/\bfema\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "current-policy-gap",
      gap: "Retrieved evidence does not identify a current FEMA policy for this requested time frame.",
    };
  }

  if (intent === "current_policy" && !/\b(?:2026|current|reimbursement|reimburse)\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "current-policy-specificity-gap",
      gap: "Retrieved evidence is not current-policy-specific enough to answer this request.",
    };
  }

  if (intent === "manufactured_housing" && !/\b(?:manufactured housing|mobile home|mobile homes|housing eligibility|housing protection|housing protections)\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "manufactured-housing-gap",
      gap: "Retrieved evidence does not discuss manufactured housing eligibility or protections.",
    };
  }

  if (intent === "frontmatter_lookup") {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "frontmatter-reference-filtered",
      gap: "The request targets frontmatter, catalog, ISBN, table-of-contents, or reference material that should not be used as final answer evidence.",
    };
  }

  if (intent === "pickup_rules" && !/\b(?:pickup|pick up|eligible|eligibility|household|bags per|distribution site|proof of residency)\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "pickup-rules-gap",
      gap: "Retrieved evidence does not provide actual sandbag pickup eligibility, location, quantity, or proof-of-residency rules.",
    };
  }

  if (intent === "publication_risk") {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "publication-risk-gap",
      gap: "Retrieved evidence is not sufficient to provide legal cautions for public claims about sandbag protection.",
    };
  }

  if (intent === "niger_warning" && !/\bniger\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "niger-warning-gap",
      gap: "Retrieved evidence does not discuss Niger flood early warning progress.",
    };
  }

  if (intent === "country_exposure" && !/\b(?:china|india|bangladesh|vietnam|pakistan|indonesia|nigeria|countries|highest exposure|river flood risk)\b/i.test(text)) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: "country-exposure-gap",
      gap: "Retrieved evidence does not identify countries with the highest exposure to river flood risk.",
    };
  }

  if (!answerability.answerable) {
    return {
      forceGap: true,
      suppressCitations: true,
      confidenceCap: "Low",
      reason: answerability.reason,
      gap: answerability.gap,
    };
  }

  return {
    forceGap: false,
    suppressCitations: false,
    confidenceCap: hasPdfLayoutRisk ? "Medium" : undefined,
    reason: hasPdfLayoutRisk ? "final-evidence-accepted-with-pdf-layout-risk" : "final-evidence-accepted",
  };
}

function capConfidence(confidence: ConfidenceAssessment, cap: QuerySession["confidence"] | undefined): ConfidenceAssessment {
  if (!cap) return confidence;
  const order: QuerySession["confidence"][] = ["Low", "Medium", "High"];
  if (order.indexOf(confidence.level) <= order.indexOf(cap)) return confidence;
  return {
    ...confidence,
    level: cap,
    reason: confidence.reason + "-capped",
    factors: [...confidence.factors, "runtime evidence policy capped confidence at " + cap],
  };
}

function selectVisibleCitations(query: string, citations: Citation[]) {
  const normalized = citations
    .map((citation, index) => {
      const visible = normalizeCitationForVisibleUse(query, citation);
      return { citation: visible, index, quality: assessVisibleCitationDisplayQuality(query, visible) };
    })
    .filter((item) => item.quality.displayable)
    .sort((a, b) => b.quality.score - a.quality.score || a.index - b.index);

  if (!normalized.length) return citations.slice(0, 1).map((citation) => normalizeCitationForVisibleUse(query, citation));

  const bestScore = normalized[0].quality.score;
  const bestTitle = normalized[0].citation.title;
  const answerBearingAvailable = normalized.some((item) => item.quality.answerBearing);
  const selected: typeof normalized = [];
  const seenChunks = new Set<string | undefined>();

  for (const item of normalized) {
    if (seenChunks.has(item.citation.chunkId)) continue;
    if (answerBearingAvailable && !item.quality.answerBearing) continue;
    const sameSource = item.citation.title === bestTitle || item.citation.documentId === normalized[0].citation.documentId;
    const strongEnough = item.quality.score >= Math.max(1.2, bestScore * 0.45);
    const sameSourceStrongEnough = sameSource && item.quality.score >= Math.max(1.4, bestScore * 0.65);
    if (selected.length === 0 || strongEnough || sameSourceStrongEnough) selected.push(item);
    seenChunks.add(item.citation.chunkId);
    if (selected.length >= 4) break;
  }

  return selected.map((item) => item.citation);
}

function normalizeCitationForVisibleUse(query: string, citation: Citation): Citation {
  const text = citation.text ? normalizeRuntimeEvidenceText(citation.text) : undefined;
  const snippetSource = bestVisibleSnippet(query, citation, text) || citation.snippet || text || "";
  return {
    ...citation,
    snippet: cleanVisibleSnippet(snippetSource).slice(0, 420),
    text,
  };
}

function bestVisibleSnippet(query: string, citation: Citation, normalizedText?: string) {
  const queryLower = query.toLowerCase();
  const sourceText = normalizedText || normalizeRuntimeEvidenceText(citation.text || citation.snippet || "");
  const sentences = splitEvidenceSentences(sourceText)
    .map(cleanRuntimeEvidenceSentence)
    .map(cleanVisibleSnippet)
    .filter((sentence) => isClientSafeDisplaySentence(queryLower, sentence));

  const best = sentences
    .map((sentence, index) => ({
      sentence,
      score: visibleSnippetSentenceScore(query, sentence, citation) - Math.min(index * 0.35, 3),
    }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)[0];

  if (!best) return "";

  const companion = sentences
    .filter((sentence) => sentence !== best.sentence)
    .map((sentence, index) => ({
      sentence,
      score: visibleSnippetSentenceScore(query, sentence, citation) - Math.min(index * 0.35, 3),
    }))
    .filter((item) => item.score >= Math.max(1.6, best.score * 0.55))
    .sort((a, b) => b.score - a.score)[0];

  return companion ? `${best.sentence} ${companion.sentence}` : best.sentence;
}

function assessVisibleCitationDisplayQuality(query: string, citation: Citation) {
  const snippet = citation.snippet.replace(/\s+/g, " ").trim();
  const queryOverlap = overlappingTerms(query, snippet).length;
  const specificOverlap = overlappingSpecificQueryTerms(query, snippet).length;
  const answerBearing = hasDisplayAnswerSignal(query, snippet);
  const specificTerms = specificDisplayTerms(query);
  const hasRequiredSpecificTerm = specificTerms.length === 0
    || answerBearing
    || specificOverlap >= (specificTerms.length > 1 ? 2 : 1)
    || (sameSourceTitleOverlap(query, citation.title) && queryOverlap >= 2);
  const displayable = isClientSafeDisplaySentence(query.toLowerCase(), snippet)
    && hasRequiredSpecificTerm
    && (queryOverlap >= 2 || specificOverlap >= 1 || answerBearing || (sameSourceTitleOverlap(query, citation.title) && queryOverlap >= 1));
  let score = (citation.score ?? 0) * 1.4 + queryOverlap * 0.8 + specificOverlap * 0.9;
  if (answerBearing) score += 1.6;
  if (sameSourceTitleOverlap(query, citation.title)) score += 0.8;
  if (hasVisibleSourceJunk(snippet)) score -= 3;
  if (specificTerms.length > 0 && specificOverlap === 0 && !answerBearing) score -= 2.4;
  if (citation.contentType === "index" || citation.contentType === "reference") score -= 4;
  return { displayable: displayable && score > 0, score, answerBearing, specificOverlap, queryOverlap };
}

function visibleSnippetSentenceScore(query: string, sentence: string, citation: Citation) {
  const queryLower = query.toLowerCase();
  const overlap = overlappingTerms(query, sentence).length;
  const specificTerms = specificDisplayTerms(query);
  const specificOverlap = overlappingSpecificQueryTerms(query, sentence).length;
  let score = overlap * 0.9 + specificOverlap * 1.1 + Math.min(citation.score ?? 0, 2);
  if (hasDisplayAnswerSignal(queryLower, sentence)) score += 2;
  if (sameSourceTitleOverlap(query, citation.title)) score += 0.4;
  if (hasVisibleSourceJunk(sentence)) score -= 4;
  if (specificTerms.length > 0 && specificOverlap === 0 && !hasDisplayAnswerSignal(queryLower, sentence)) score -= 2;
  if (hasMalformedDisplayFragment(sentence)) score -= 1.6;
  if (sentence.length < 45) score -= 0.8;
  if (/^(?:abstract|introduction|conclusion)\b/i.test(sentence) && overlap < 2) score -= 1.2;
  return score;
}

function isClientSafeDisplaySentence(queryLower: string, sentence: string) {
  const compact = sentence.replace(/\s+/g, " ").trim();
  if (!compact || compact.length < 35) return false;
  if (hasVisibleSourceJunk(compact)) return false;
  if (isLowValueRuntimeEvidenceSentence(queryLower, compact)) return false;
  if (/^(?:abstract|introduction|conclusion|notes)$/i.test(compact)) return false;
  if (/^[a-z]/.test(compact) && compact.length < 120) return false;
  if (/^(?:journal of emergency management|jem)\b/i.test(compact) && compact.length < 140) return false;
  if (/^[A-Z][A-Za-z]+,\s*(?:MD|MPH|PhD|JD|DPA|CEM)\b/.test(compact)) return false;
  if (/^[\d\s.,;:()/-]+$/.test(compact)) return false;
  if (isQueryMismatchedDisplaySentence(queryLower, compact)) return false;
  return true;
}

function cleanVisibleSnippet(snippet: string) {
  return cleanVisibleAnswer(snippet)
    .replace(/\b([A-Z][a-z]{2,})(\d{1,3})(?=\s+(?:also\s+)?(?:finds?|found|states?|argues?|reports?|suggests?|concludes?|notes?|shows?|identifies?|explains?|does|has|is|was)\b)/g, "$1")
    .replace(/\b([a-z]{2,})(\d{1,3})(?=\s+(?:also\s+)?(?:finds?|found|states?|argues?|reports?|suggests?|concludes?|notes?|shows?|identifies?|explains?|does|has|is|was)\b)/g, "$1")
    .replace(/\bJournalof\s+__\b/gi, "Journal of")
    .replace(/\bfaceto-face\b/gi, "face-to-face")
    .replace(/\btwodimensional\b/gi, "two-dimensional")
    .replace(/\bchangerelated\b/gi, "change-related")
    .replace(/[^\S\r\n]+/g, " ")
    .trim();
}

function hasVisibleSourceJunk(text: string) {
  return /\b(?:please visit www\.copyright\.com|copyright\s+©|all rights reserved|uploaded demo pdf|table of contents|contents list|editorial board|visit our website|www\.deloitte\.com)\b/i.test(text)
    || /~~|[�➔]|[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(text)
    || /\b(?:ISSN|ISBN)\b/i.test(text)
    || hasAuthorCitationNumberArtifact(text);
}

function hasMalformedDisplayFragment(text: string) {
  return /\b(?:using|including|such as)\s+[a-z0-9\s-]{2,50}\),\s+(?:or|and)\b/i.test(text)
    || /\b(?:e\.g\.|i\.e\.)\s+[a-z0-9\s-]{2,50}\),\s+(?:or|and)\b/i.test(text);
}

function isQueryMismatchedDisplaySentence(queryLower: string, text: string) {
  const lower = text.toLowerCase();
  if (/\b(?:contractor|standard(?:ized)? (?:document|vendor|contract)|contract terms?)\b/.test(queryLower)
    && /\b(?:local line of succession|grants of emergency authority|governmental emergency management activities)\b/.test(lower)
    && !/\b(?:indemnification|arbitration|waivers?|unacceptable language|standardized contracts?|contractor|performance standards?)\b/.test(lower)) {
    return true;
  }
  return false;
}

function hasAuthorCitationNumberArtifact(text: string) {
  return /\b[A-Z][a-z]{2,}\d{1,3}\b/.test(text) || /\b[a-z]{2,}\d{1,3}\s+(?:also\s+)?(?:finds?|found|states?|argues?|reports?|suggests?|concludes?|notes?|shows?|identifies?|explains?)\b/.test(text);
}

function hasDisplayAnswerSignal(query: string, text: string) {
  const queryLower = query.toLowerCase();
  const lower = text.toLowerCase();
  if (/level 3/.test(queryLower) && /(?:(?:level\s*3|elderly|disabled).{0,140}evacuat|evacuat.{0,140}(?:level\s*3|elderly|disabled))/i.test(lower)) return true;
  if (/hazus/.test(queryLower) && /estimate|loss|damage|mitigation/.test(lower)) return true;
  if (/south sudan|locally driven/.test(queryLower) && /structural|nonstructural|non-structural|locally driven/.test(lower)) return true;
  if (/contractor|standard document|contract/.test(queryLower) && /delete unacceptable language|careful(?:ly)? review|indemnification|arbitration|waivers?|standardized contracts?/.test(lower)) return true;
  if (/\bready\b|fema/.test(queryLower) && /ready campaign|get a kit|make a plan|be informed/.test(lower)) return true;
  if (/citizen participation|sustainability/.test(queryLower) && /citizen participation|public participation|sustainability/.test(lower)) return true;
  if (/west virginia|jh-cphp|workshop/.test(queryLower) && /west virginia severe flooding tabletop|public health-specific|fema ready materials/.test(lower)) return true;
  if (/prevent all|all flood damage|guarantee/.test(queryLower) && /do not guarantee|does not guarantee|minor water intrusion|deep flooding|structural damage/.test(lower)) return true;
  return false;
}

function sameSourceTitleOverlap(query: string, title: string) {
  return overlappingTerms(query, title).length >= 2;
}

function overlappingSpecificQueryTerms(query: string, text: string) {
  const textTerms = new Set(contentTerms(text));
  return specificDisplayTerms(query).filter((term) => textTerms.has(term));
}

function specificDisplayTerms(query: string) {
  return Array.from(new Set(contentTerms(query))).filter((term) => {
    if (DISPLAY_QUERY_GENERIC_TERMS.has(term)) return false;
    if (term.length >= 7) return true;
    return /^(?:fema|jem|hazus|cphp)$/.test(term);
  });
}

const DISPLAY_QUERY_GENERIC_TERMS = new Set([
  "answer",
  "claim",
  "claims",
  "component",
  "components",
  "document",
  "documents",
  "damage",
  "flood",
  "flooding",
  "material",
  "materials",
  "prove",
  "prevent",
  "question",
  "source",
  "sources",
]);

function assessVisibleAnswerQuality(answer: string, visibleCitations: Citation[], rawCitations: Citation[]): VisibleAnswerQualityAssessment {
  const issues: string[] = [];
  const visibleEvidenceText = visibleCitations.map((citation) => citation.snippet).join(" ");
  const rawEvidenceText = rawCitations.map((citation) => [citation.snippet, citation.text].filter(Boolean).join(" ")).join(" ");

  if (hasOcrHyphenationArtifact(answer)) issues.push("visible-ocr-hyphenation");
  if (hasRepeatedPhraseLoop(answer)) issues.push("repeated-phrase-loop");
  if (visibleCitations.length > 0 && hasOcrHyphenationArtifact(visibleEvidenceText)) issues.push("source-ocr-hyphenation");
  if (visibleCitations.length > 0 && hasAuthorCitationNumberArtifact(visibleEvidenceText)) issues.push("source-citation-artifact");
  if (rawCitations.length > 0 && visibleCitations.length === 0) issues.push("no-client-safe-source-snippet");

  const answerDegraded = issues.includes("visible-ocr-hyphenation") || issues.includes("repeated-phrase-loop");
  const hiddenSourceCleanupApplied = visibleCitations.length > 0 && (hasOcrHyphenationArtifact(rawEvidenceText) || hasAuthorCitationNumberArtifact(rawEvidenceText));
  return {
    issues,
    confidenceCap: answerDegraded ? "Low" : issues.length > 0 || hiddenSourceCleanupApplied ? "Medium" : undefined,
  };
}

type EvidenceIntent = "absolute_flood_claim" | "current_policy" | "manufactured_housing" | "frontmatter_lookup" | "pickup_rules" | "publication_risk" | "niger_warning" | "country_exposure" | "general";

function classifyEvidenceIntent(query: string): EvidenceIntent {
  const normalized = query.toLowerCase();
  if (/prevent all|all flood damage|guarantee|guaranteed protection|prove.*prevent|proof.*prevent|prove.*sandbags.*protect|proof.*sandbags.*protect/.test(normalized)) return "absolute_flood_claim";
  if (/\b(?:current|2026)\b/.test(normalized) && /\b(?:fema|policy|reimbursement|reimburse)\b/.test(normalized)) return "current_policy";
  if (/\b(?:manufactured housing|mobile homes?|housing eligibility|housing protections?)\b/.test(normalized)) return "manufactured_housing";
  if (/\b(?:isbn|catalog|cataloging|table of contents|contents list|figures? (?:are )?listed|list of figures|frontmatter|front matter|reference list|bibliography)\b/.test(normalized)) return "frontmatter_lookup";
  if (/\b(?:pickup|pick up|distribution rules|where.*get|how many bags|sandbag rules|proof of residency|residency proof)\b/.test(normalized)) return "pickup_rules";
  if (/\b(?:legal cautions?|public claims?|publication risk|publishing.*claims?|before publishing|claims risk)\b/.test(normalized)) return "publication_risk";
  if (/\bniger\b/.test(normalized) && /\b(?:flood|warning|progress)\b/.test(normalized)) return "niger_warning";
  if (/\b(?:countries|country)\b/.test(normalized) && /\b(?:highest exposure|river flood risk|flood exposure)\b/.test(normalized)) return "country_exposure";
  return "general";
}

type CitationQualityAssessment = {
  indexOrReference: boolean;
  ocrLayoutTainted: boolean;
  normalizedPdfArtifact: boolean;
};

function assessCitationQuality(citation: Citation): CitationQualityAssessment {
  const text = citationText(citation);
  const metadata = citation.metadata ?? {};
  return {
    indexOrReference: citation.contentType === "index"
      || citation.contentType === "reference"
      || isIndexOrReferenceText(text),
    ocrLayoutTainted: /Technologyexclusion|Technologicalexclusion|lnstrums|lesSOfls|I I I|--~|➔|FDOsflood|ds,nsity|fearnt>d|L:dmapping|IIflood|infom~~tion/i.test(text),
    normalizedPdfArtifact: metadata.normalizedPdfText === true
      && (metadata.removedPageMarkerCount !== undefined || metadata.removedUploadedPdfHeading === true),
  };
}

function isIndexOrReferenceText(text: string) {
  const hasIndexReferenceMarker = INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(text));
  const hasBibliographicMarker = BIBLIOGRAPHIC_MARKER_PATTERNS.some((pattern) => pattern.test(text));
  if (!hasIndexReferenceMarker && !hasBibliographicMarker) return false;
  return !hasSubstantiveBodyEvidence(text);
}

function hasSubstantiveBodyEvidence(text: string) {
  const bodySentenceCount = splitEvidenceSentences(text).filter((sentence) => {
    if (BIBLIOGRAPHIC_MARKER_PATTERNS.some((pattern) => pattern.test(sentence))) return false;
    if (INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(sentence)) && sentence.length < 180) return false;
    if (sentence.length < 80) return false;
    return /\b(?:aims?|promotes?|estimates?|describes?|identifies?|discusses?|developed|tailored|found|suggests?|states?|explains?|reports?|shows?|uses?|provides?|includes?|recommends?)\b/i.test(sentence);
  }).length;

  return bodySentenceCount >= 1;
}

function assessAnswerability(query: string, citations: Citation[]): AnswerabilityAssessment {
  const thresholdSummary = "top score must be >= " + MIN_ANSWERABILITY_SCORE + ", with at least one body-like citation that overlaps the query; index/reference-only or weak coincidental matches are insufficient";
  const bestScore = citations[0]?.score ?? null;
  const base = {
    bestScore,
    thresholdSummary,
  };

  if (!citations.length) {
    return {
      ...base,
      answerable: false,
      reason: "no-citations",
      message: "No citations were retrieved for answer generation.",
      gap: "Selected documents did not return citations for the requested claim.",
      supportingCitationCount: 0,
      strongestOverlapTermCount: 0,
    };
  }

  if (bestScore !== null && bestScore < MIN_ANSWERABILITY_SCORE) {
    return {
      ...base,
      answerable: false,
      reason: "weak-top-score",
      message: "Top citation score " + bestScore.toFixed(3) + " is below the answerability threshold " + MIN_ANSWERABILITY_SCORE + ".",
      gap: "Selected documents produced only weak retrieval matches for the requested claim.",
      supportingCitationCount: 0,
      strongestOverlapTermCount: 0,
    };
  }

  const queryTermCount = contentTerms(query).length;
  const assessed = citations.map((citation) => {
    const text = citationText(citation);
    const overlapTerms = overlappingTerms(query, text);
    const indexOrReference = INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(text));
    const score = citation.score ?? 0;
    const hasDirectOverlap = queryTermCount > 0 && overlapTerms.length >= Math.min(3, queryTermCount);
    const hasStrongSemanticSupport = score >= STRONG_SEMANTIC_SCORE && overlapTerms.length > 0;
    return {
      overlapTerms,
      indexOrReference,
      supportsAnswer: !indexOrReference && score >= MIN_ANSWERABILITY_SCORE && (hasDirectOverlap || hasStrongSemanticSupport),
    };
  });

  const supporting = assessed.filter((item) => item.supportsAnswer);
  const strongestOverlapTermCount = Math.max(...assessed.map((item) => item.overlapTerms.length), 0);

  if (!supporting.length) {
    const onlyIndexOrReference = assessed.every((item) => item.indexOrReference);
    return {
      ...base,
      answerable: false,
      reason: onlyIndexOrReference ? "index-reference-only" : "weak-or-unsupported-evidence",
      message: onlyIndexOrReference
        ? "Retrieved citations are index/reference style matches, not body evidence."
        : "Retrieved citations do not provide enough direct query/evidence overlap for answerability.",
      gap: onlyIndexOrReference
        ? "Selected documents only surfaced index/reference-style matches for the requested claim."
        : "Selected documents do not provide strong direct support for the requested claim.",
      supportingCitationCount: 0,
      strongestOverlapTermCount,
    };
  }

  return {
    ...base,
    answerable: true,
    reason: "supported-body-evidence",
    message: "Answerability threshold met with " + supporting.length + " supporting citation" + (supporting.length === 1 ? "" : "s") + ".",
    gap: "",
    supportingCitationCount: supporting.length,
    strongestOverlapTermCount,
  };
}

function assessConfidence(assessment: AnswerabilityAssessment, citations: Citation[]): ConfidenceAssessment {
  if (!assessment.answerable) {
    return {
      level: "Low",
      score: 0,
      reason: assessment.reason,
      factors: [
        "answerability=" + assessment.reason,
        "supporting citations=" + assessment.supportingCitationCount,
        "best score=" + (assessment.bestScore?.toFixed(3) ?? "none"),
      ],
    };
  }

  const assessed = citations.map((citation) => {
    const text = citationText(citation);
    const score = citation.score ?? 0;
    const indexOrReference = INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(text));
    const metadataFields = [citation.documentId, citation.title, citation.domain, citation.chunkId, citation.sourcePath].filter(Boolean).length;
    return {
      score,
      indexOrReference,
      bodyLike: !indexOrReference,
      metadataFields,
    };
  });
  const scores = assessed.map((item) => item.score).sort((a, b) => b - a);
  const bestScore = scores[0] ?? 0;
  const secondScore = scores[1] ?? 0;
  const scoreSpread = Math.max(0, bestScore - secondScore);
  const bodyCitationCount = assessed.filter((item) => item.bodyLike).length;
  const indexReferenceCount = assessed.filter((item) => item.indexOrReference).length;
  const averageMetadataFields = assessed.length
    ? assessed.reduce((sum, item) => sum + item.metadataFields, 0) / assessed.length
    : 0;

  let score = 0;
  const factors = [
    "answerability=" + assessment.reason,
    "supporting citations=" + assessment.supportingCitationCount,
    "body citations=" + bodyCitationCount,
    "index/reference citations=" + indexReferenceCount,
    "best score=" + bestScore.toFixed(3),
    "score spread=" + scoreSpread.toFixed(3),
    "avg metadata fields=" + averageMetadataFields.toFixed(1),
  ];

  if (assessment.supportingCitationCount >= 2) score += 2;
  else if (assessment.supportingCitationCount === 1) score += 1;

  if (bestScore >= 0.45) score += 2;
  else if (bestScore >= STRONG_SEMANTIC_SCORE) score += 1;

  if (scoreSpread >= 0.12 || assessment.supportingCitationCount >= 2) score += 1;
  if (bodyCitationCount > 0) score += 1;
  if (assessment.strongestOverlapTermCount >= 4) score += 1;
  if (averageMetadataFields >= 4) score += 1;
  if (indexReferenceCount > 0) score -= 2;

  if (indexReferenceCount === assessed.length) {
    return {
      level: "Low",
      score,
      reason: "index-reference-only",
      factors: [...factors, "index/reference-only evidence cannot produce high confidence"],
    };
  }

  const level: QuerySession["confidence"] = score >= 6 ? "High" : score >= 3 ? "Medium" : "Low";
  return {
    level,
    score,
    reason: level === "High" ? "strong-direct-evidence" : level === "Medium" ? "moderate-direct-evidence" : "limited-direct-evidence",
    factors,
  };
}

function withEvidenceQualityDebugTrace(trace: RetrievalDebugTrace | undefined, assessment: AnswerabilityAssessment, confidence: ConfidenceAssessment, retrievedCitationCount: number, finalCitationCount: number, finalEvidence: FinalEvidenceSelection, evidencePolicy: EvidencePolicyAssessment, visibleQuality: VisibleAnswerQualityAssessment) {
  if (!trace) return trace;

  return {
    ...trace,
    decisions: [
      ...trace.decisions,
      ...finalEvidence.filtered.map((item) => ({
        type: "filter" as const,
        chunkId: item.chunkId,
        reason: item.reason,
        message: "Citation was removed before final answerability/confidence assessment.",
      })),
      {
        type: evidencePolicy.forceGap || evidencePolicy.suppressCitations ? "filter" as const : "selection" as const,
        reason: evidencePolicy.reason,
        message: evidencePolicy.forceGap
          ? "Runtime evidence policy forced a gap answer."
          : evidencePolicy.suppressCitations
            ? "Runtime evidence policy suppressed final citations while retaining bounded answer text."
            : "Runtime evidence policy accepted final evidence.",
      },
      {
        type: "answerability" as const,
        reason: assessment.reason,
        message: assessment.message + " Thresholds: " + assessment.thresholdSummary + ".",
      },
      {
        type: "confidence" as const,
        reason: confidence.reason,
        message: "Confidence " + confidence.level + " from evidence-quality score " + confidence.score + ". Factors: " + confidence.factors.join("; ") + ". Visible answer quality issues: " + (visibleQuality.issues.join(", ") || "none") + ".",
      },
      {
        type: finalCitationCount > 0 ? "selection" as const : "filter" as const,
        reason: finalCitationCount > 0 ? "final-citations-retained" : "weak-evidence-citations-suppressed",
        message: finalCitationCount > 0
          ? "Final answer retained " + finalCitationCount + " citation" + (finalCitationCount === 1 ? "" : "s") + " after answerability checks."
          : "Retrieved " + retrievedCitationCount + " citation" + (retrievedCitationCount === 1 ? "" : "s") + " but suppressed final citations because the answerability check did not find strong support.",
      },
    ],
    notes: [
      ...(trace.notes ?? []),
      "Issue #23 answerability: " + assessment.thresholdSummary + ".",
      "Issue #23 answerability result: " + assessment.reason + "; supporting citations=" + assessment.supportingCitationCount + "; strongest query/evidence overlap=" + assessment.strongestOverlapTermCount + "; best score=" + (assessment.bestScore ?? "none") + ".",
      "Issue #25 confidence: " + confidence.level + " (" + confidence.reason + "); factors: " + confidence.factors.join("; ") + ".",
      "Runtime evidence policy: " + evidencePolicy.reason + "; filtered citations=" + finalEvidence.filtered.length + ".",
      "Visible answer quality: " + (visibleQuality.issues.join(", ") || "clean") + ".",
      "Final citations retained after answerability filtering: " + finalCitationCount + " of " + retrievedCitationCount + ".",
    ],
  };
}

function citationText(citation: Citation) {
  return normalizeRuntimeEvidenceText([citation.title, citation.snippet, citation.text].filter(Boolean).join(" "));
}

function overlappingTerms(query: string, text: string) {
  const textTerms = new Set(contentTerms(text));
  return Array.from(new Set(contentTerms(query))).filter((term) => textTerms.has(term));
}

function contentTerms(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((term) => term.length > 3 && !ANSWERABILITY_STOP_WORDS.has(term));
}

const ANSWERABILITY_STOP_WORDS = new Set([
  "about",
  "after",
  "also",
  "because",
  "before",
  "from",
  "into",
  "that",
  "their",
  "there",
  "these",
  "this",
  "what",
  "when",
  "where",
  "which",
  "with",
]);

function buildGroundedExtractiveAnswer(query: string, citations: Citation[]) {
  if (!citations.length) return "I do not see strong support in the selected documents.";

  const queryLower = query.toLowerCase();
  const uniqueCitations = citations.filter((citation, index, all) => all.findIndex((candidate) => candidate.chunkId === citation.chunkId) === index);
  const evidenceSentences = uniqueCitations.slice(0, 5).flatMap((citation, citationIndex) => {
    const evidence = normalizeRuntimeEvidenceText(citation.text || citation.snippet);
    return splitEvidenceSentences(evidence)
      .map(cleanRuntimeEvidenceSentence)
      .filter(Boolean)
      .filter((sentence) => !isLowValueRuntimeEvidenceSentence(queryLower, sentence))
      .map((sentence) => ({ sentence, citation, citationIndex, score: sentenceScore(queryLower, sentence, citationIndex) }));
  });

  const selected = evidenceSentences
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 12);

  const support = dedupeSentences(selected.map((item) => item.sentence)).slice(0, 8);
  if (!support.length) return `The best-supported answer from the retrieved sources is: ${uniqueCitations[0].snippet}`;

  const concise = answerFromEvidence(queryLower, support, uniqueCitations);
  return cleanVisibleAnswer(concise ?? `The best-supported answer from the retrieved sources is: ${support.join(" ")}`);
}

function answerFromEvidence(queryLower: string, support: string[], citations: Citation[]) {
  const joined = support.join(" ");
  const citationText = citations.map((citation) => `${citation.text || citation.snippet}`).join(" ").replace(/\s+/g, " ");
  const evidenceText = `${joined} ${citationText}`;

  if (/three elements|basics of contract law/.test(queryLower)) {
    const compact = joined.replace(/\s+/g, " ");
    const match = compact.match(/offer[^.]{0,220}acceptance[^.]{0,220}consideration/i)
      || compact.match(/1\.\s*offer[^.]{0,220}2\.\s*acceptance[^.]{0,220}3\.\s*consideration/i)
      || citationText.match(/offer[^.]{0,220}acceptance[^.]{0,220}consideration/i)
      || citationText.match(/1\.\s*offer[^.]{0,220}2\.\s*acceptance[^.]{0,220}3\.\s*consideration/i)
      || (/acceptance/i.test(citationText) && /consideration/i.test(citationText) && /what is offered|offered/i.test(citationText));
    if (match) return "The three basic elements are offer, acceptance, and consideration.";
  }

  if (/percentage|contract price|holding back|turnkey-system verification/.test(queryLower)) {
    const match = evidenceText.match(/25\s*(?:to|-|–)\s*33\s*percent/i) || evidenceText.match(/25\s*percent[^.]{0,80}33\s*percent/i);
    if (match) return "The article suggests holding back about 25 to 33 percent of the contract price until verification is complete.";
  }

  if (asksAboutContractReviewTerms(queryLower) && hasContractReviewTermEvidence(evidenceText)) {
    return "Emergency managers should scrutinize standardized contract language for indemnification requirements, waivers of inadequate performance, arbitration clauses, terms contrary to state or local law, diluted contractor obligations, and missing or incomplete performance standards.";
  }

  if (asksAboutAcceptingContractorStandardDocument(queryLower) && hasContractorDocumentAsIsWarning(evidenceText)) {
    return "No. The evidence says a contract officer may be tempted to use the contractor's document as-is because it is less work, but should carefully review it, delete unacceptable language, and modify standard language when needed.";
  }

  if (asksAboutSpecialIssueTheme(queryLower) && hasClimateSustainabilitySpecialIssueEvidence(evidenceText)) {
    return "The special issue is about climate change and sustainability in emergency management. The evidence connects emergency managers to climate change and sustainability because they help communities address climate-driven hazards through resilience, adaptation, mitigation, long-term environmental stewardship, and equity-focused planning for vulnerable communities.";
  }

  if (asksAboutDeloitteClimateAction(queryLower) && hasDeloitteClimateActionEvidence(evidenceText)) {
    return "The retrieved evidence is frontmatter/advertising copy rather than a substantive article finding. It says Deloitte's knowledge and tools support organizations' climate resilience planning, governance, finance, implementation, and performance monitoring so they can mitigate climate-change impacts and support a climate-resilient future.";
  }

  if (asksRelationshipQuestion(queryLower) && support.length > 0) {
    return `The article says ${stripFindingLeadIn(support[0])}`;
  }

  if (asksWhatSourceSaysAboutTopic(queryLower)) {
    return `It says ${lowercaseInitial(support.slice(0, 2).join(" "))}`;
  }

  if (/five broad resilience strategies|community resilience/.test(queryLower)) {
    const strategies = [
      findPhrase(evidenceText, /tak(?:e|ing) action/i, "take action"),
      findPhrase(evidenceText, /accept(?:ing)? help(?: from others)?/i, "accept help from others"),
      findPhrase(evidenceText, /self-?discovery/i, "engage in self-discovery"),
      findPhrase(evidenceText, /realistic(?: long-?term)? perspective|long-?term perspective|having patience/i, "maintain a realistic long-term perspective"),
      findPhrase(evidenceText, /hope|optimism/i, "foster hope and optimism"),
    ].filter(Boolean);
    if (strategies.length >= 4) return `The five broad strategies were: take action; accept help from others; engage in self-discovery; maintain a realistic long-term perspective; and foster hope/optimism.`;
  }

  if (/level 3/.test(queryLower) && /japan/.test(queryLower)) {
    if ((/elderly|aged|disabled/.test(evidenceText) && /evacuat/.test(evidenceText)) || /mobilize the aged and disabled population/.test(evidenceText)) {
      return "At Level 3, elderly and disabled people are advised to evacuate, while others should prepare to evacuate.";
    }
  }

  if (/software\/model|estimate flood losses|hazard mitigation planning/.test(queryLower)) {
    if (/hazus-mh/i.test(evidenceText)) return "The paper uses FEMA’s HAZUS-MH Flood Model to estimate flood losses.";
  }

  const listAnswer = answerFromListEvidence(queryLower, citations);
  if (listAnswer) return listAnswer;

  if (/100-year|flood magnitude|example analysis/.test(queryLower) && /hazus-mh|hazard mitigation/.test(queryLower)) {
    if (/100-year flood/i.test(evidenceText)) return "The model estimates losses for a 100-year flood.";
  }

  if (/kinds of fatalities|life safety model/.test(queryLower)) {
    const has = {
      drowning: /drown/i.test(evidenceText),
      exhaustion: /exhaust/i.test(evidenceText),
      building: /building collapse|collapse of buildings|building failure|building/i.test(evidenceText),
      vehicles: /vehicle|car|swept away/i.test(evidenceText),
    };
    if (Object.values(has).filter(Boolean).length >= 3) return "The model estimates fatalities from drowning, exhaustion, building collapse, and vehicles being swept away.";
  }

  if (/one year|baseline|preparedness workshop|emergency kits/.test(queryLower)) {
    if (/77(?:\.3)?/i.test(evidenceText) && /40(?:\.8)?/i.test(evidenceText)) return "One year after the workshop, about 77 percent reported having personal emergency kits, compared with about 40 percent at baseline.";
  }

  if (/south sudan/.test(queryLower) && /locally driven/.test(queryLower)) {
    if (/structural/i.test(evidenceText) && /nonstructural|non-structural/i.test(evidenceText)) {
      return "The paper identifies two critical locally driven DRR directions: structural and nonstructural disaster risk reduction efforts.";
    }
    const structuralChunk = citations.find((citation) => /structural/i.test(citation.text || citation.snippet));
    const nonStructuralChunk = citations.find((citation) => /nonstructural|non-structural/i.test(citation.text || citation.snippet));
    if (structuralChunk && nonStructuralChunk) {
      return "The paper identifies two critical locally driven DRR directions: structural and nonstructural efforts.";
    }
  }

  if (/which document/.test(queryLower) && /public engagement|governance|policy|international case studies/.test(queryLower)) {
    const topTitle = citations[0]?.title;
    if (topTitle) return `${topTitle}.`;
  }

  return null;
}

function buildExternalCompareAnswer(internalAnswer: string, externalResults: ExternalSearchResult[]) {
  const externalContext = externalResults
    .slice(0, 5)
    .map((result, index) => `${index + 1}. ${result.title}: ${result.snippet}`)
    .join("\n");

  return `Direct answer:\n${internalAnswer}\n\nFrom selected documents:\n${internalAnswer}\n\nExternal context:\n${externalContext}\n\nGaps / cautions:\n- External web sources are separate from Falcontrust customer-document citations. Verify any current policy or FEMA-specific requirement against the linked source before publication.`;
}

function findPhrase(text: string, pattern: RegExp, fallback: string) {
  return pattern.test(text) ? fallback : null;
}

function asksAboutContractReviewTerms(queryLower: string) {
  return /\bcontracts?\b/.test(queryLower)
    && /\b(?:terms?|standard(?:ized)?|vendor|scrutinize|review|language|clauses?)\b/.test(queryLower);
}

function hasContractReviewTermEvidence(text: string) {
  const termSignals = [
    /\bindemnification\b/i,
    /\bwaivers?\b/i,
    /\barbitration\b/i,
    /\bcontrary to (?:state|local) law\b/i,
    /\bperformance standards?\b/i,
    /\bobligations? of the contractor\b/i,
  ].filter((pattern) => pattern.test(text)).length;

  return /\b(?:standard(?:ized)? contracts?|contractor(?:’s|'s)? document|contract(?:ual)? language|clauses?|scrutinize|review(?:ing)?)\b/i.test(text)
    && termSignals >= 3;
}

function asksAboutAcceptingContractorStandardDocument(queryLower: string) {
  return /\b(?:accept|use)\b/.test(queryLower)
    && /\bcontractor(?:'s)?\b/.test(queryLower)
    && /\b(?:standard document|document as-is|document as is|as-is|as is)\b/.test(queryLower);
}

function hasContractorDocumentAsIsWarning(text: string) {
  return /\bcontractor(?:’s|'s)? document as is\b/i.test(text)
    && /\b(?:careful(?:ly)? in reviewing|delete unacceptable language|modification of standard language|modify standard language)\b/i.test(text);
}

function asksAboutSpecialIssueTheme(queryLower: string) {
  return /\bspecial issue\b/.test(queryLower)
    && /\bclimate change\b/.test(queryLower)
    && /\bsustainability\b/.test(queryLower)
    && /\bemergency managers?\b/.test(queryLower);
}

function hasClimateSustainabilitySpecialIssueEvidence(text: string) {
  return /\bspecial issue titled Climate Change and Sustainability in Emergency Management\b/i.test(text)
    && /\bemergency managers?\b/i.test(text)
    && /\b(?:climate-induced disasters|long-term environmental stewardship|equity|social justice|adaptation|mitigation|resilience)\b/i.test(text);
}

function asksAboutDeloitteClimateAction(queryLower: string) {
  return /\bdeloitte\b/.test(queryLower)
    && /\bclimate\b/.test(queryLower)
    && /\b(?:action|resilience|sustainability)\b/.test(queryLower);
}

function hasDeloitteClimateActionEvidence(text: string) {
  return /\bDeloitte(?:'s|’s) knowledge and tools support organizations\b/i.test(text)
    && /\bclimate resilience planning\b/i.test(text)
    && /\bmitigate climate change impacts\b/i.test(text);
}

function asksWhatSourceSaysAboutTopic(queryLower: string) {
  return /\bwhat does\b.{0,160}\bsay about\b/.test(queryLower);
}

function asksRelationshipQuestion(queryLower: string) {
  return /\bhow (?:does|do|did)\b.{0,220}\b(?:relate|connect|affect|influence|shape|impact|increase|decrease)\b/.test(queryLower);
}

function stripFindingLeadIn(sentence: string) {
  const stripped = sentence
    .replace(/^(?:the\s+)?findings?(?:\s+here)?\s+(?:suggest|show|indicate|report|state)s?\s+that\s+/i, "")
    .replace(/^(?:the\s+)?(?:article|paper|report|study)\s+(?:suggest|shows|indicates|reports|states)\s+that\s+/i, "")
    .trim();
  return stripped.charAt(0).toLowerCase() + stripped.slice(1);
}

function lowercaseInitial(value: string) {
  return value.charAt(0).toLowerCase() + value.slice(1);
}

function answerFromListEvidence(queryLower: string, citations: Citation[]) {
  if (!/\b(?:components?|elements?|activities|steps?|strategies|types?|kinds?|parts?|requirements?)\b/.test(queryLower)) return null;
  if (isListAnswerComparisonQuery(queryLower)) return null;

  const expectedCount = expectedListItemCount(queryLower);
  const candidates = citations.slice(0, 5).flatMap((citation, citationIndex) =>
    splitEvidenceSentences(citation.text || citation.snippet)
      .map((sentence, sentenceIndex, sentences) => parseListSentence(sentence, expectedCount, sentences.slice(Math.max(0, sentenceIndex - 2), sentenceIndex)))
      .filter((candidate): candidate is ListAnswerCandidate => Boolean(candidate))
      .map((candidate) => ({
        ...candidate,
        score: listSentenceScore(queryLower, candidate, citationIndex),
      })),
  );

  const best = candidates.sort((a, b) => b.score - a.score)[0];
  if (!best) return null;

  const label = listAnswerLabel(queryLower);
  const context = best.context ? `${best.context}. ` : "";
  return `${context}${capitalize(label)}: ${best.items.join("; ")}.`;
}

function isListAnswerComparisonQuery(queryLower: string) {
  return /\b(?:did|does|should|is|are|was|were)\b[^?]{0,160}\b(?:or|rather than|instead of)\b/.test(queryLower);
}

type ListAnswerCandidate = {
  context: string;
  items: string[];
};

function parseListSentence(sentence: string, expectedCount: number | null, previousSentences: string[]): ListAnswerCandidate | null {
  const colonIndex = sentence.indexOf(":");
  if (colonIndex < 0) return null;

  const contextSentences = previousSentences.filter(isUsefulListContextSentence);
  const context = [...contextSentences, cleanListContext(sentence.slice(0, colonIndex))].join(" ");
  const listText = sentence.slice(colonIndex + 1);
  const items = splitListItems(listText);
  const maxItems = expectedCount ?? 6;
  if (expectedCount && items.length < expectedCount) return null;
  if (!expectedCount && items.length < 2) return null;
  return { context, items: items.slice(0, maxItems) };
}

function splitListItems(listText: string) {
  return listText
    .replace(/[.!?]["”']?\s*$/, "")
    .split(/\s*,\s*|\s+\b(?:and|or)\b\s+/i)
    .map(cleanListItem)
    .filter((item) => item.length >= 3 && item.length <= 80);
}

function cleanListContext(context: string) {
  return context
    .replace(/\s+/g, " ")
    .replace(/["“”']+$/g, "")
    .trim();
}

function cleanListItem(item: string) {
  return item
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^(?:["“”'(:;,-]+|\d+[.)]\s*|[-•]\s*)/g, "")
    .replace(/["“”'():;,.!?]+$/g, "")
    .trim();
}

function isUsefulListContextSentence(sentence: string) {
  return /\b(?:launched|created|started|established|began)\b.*\b(?:19|20)\d{2}\b/i.test(sentence)
    || /\b(?:aims?|goals?|purpose|intended|designed)\b/i.test(sentence);
}

function expectedListItemCount(queryLower: string) {
  if (/\bthree\b|\b3\b/.test(queryLower)) return 3;
  if (/\bfour\b|\b4\b/.test(queryLower)) return 4;
  if (/\bfive\b|\b5\b/.test(queryLower)) return 5;
  if (/\bsix\b|\b6\b/.test(queryLower)) return 6;
  return null;
}

function listSentenceScore(queryLower: string, candidate: ListAnswerCandidate, citationIndex: number) {
  const text = `${candidate.context} ${candidate.items.join(" ")}`;
  return Math.max(0, 10 - citationIndex)
    + overlappingTerms(queryLower, text).length
    + candidate.items.length;
}

function listAnswerLabel(queryLower: string) {
  const match = queryLower.match(/\b(components?|elements?|activities|steps?|strategies|types?|kinds?|parts?|requirements?)\b/);
  return match?.[1] ?? "items";
}

function capitalize(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function splitEvidenceSentences(evidence: string) {
  return normalizeRuntimeEvidenceText(evidence)
    .replace(/\r/g, "\n")
    .replace(/(?:-{2,}|–{2,})\s*Page\s+\d+\s+of\s+\d+\s*(?:-{2,}|–{2,})/gi, "\n")
    .replace(/(?:^|\n|\s)#+\s*UPLOADED\s+(?:DEMO\s+)?PDF\b[^\n]*/gi, "\n")
    .replace(/\b(?:[A-Z]{2,}\s+)?EDITORIAL\s+BOARD\b/gi, (match) => `\n${match}\n`)
    .replace(/\b(?:Visit our website|Copyright\s+©|All rights reserved)\b/gi, "\n$&")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s+/g, "\n")
    .replace(/([.!?]["”']?)(?:\d{1,3})?[ \t]+/g, "$1\n")
    .split(/\n|(?= - )/)
    .map((sentence) => sentence.trim())
    .filter(Boolean);
}

function cleanRuntimeEvidenceSentence(sentence: string) {
  return normalizeRuntimeEvidenceText(sentence)
    .replace(/^[-•]\s*/, "")
    .replace(/^(?:-{2,}|–{2,})\s*Page\s+\d+\s+of\s+\d+\s*(?:-{2,}|–{2,})$/i, "")
    .replace(/\bJournalof\s+__\b/gi, "Journal of")
    .replace(/\s+/g, " ")
    .trim();
}

function isLowValueRuntimeEvidenceSentence(queryLower: string, sentence: string) {
  const compact = sentence.replace(/\s+/g, " ").trim();
  if (!compact) return true;
  if (compact.length < 12) return true;
  if (hasRepeatedPhraseLoop(compact)) return true;
  if (/^(?:#+\s*)?uploaded (?:demo )?pdf\b/i.test(compact)) return true;
  if (/^(?:-{2,}|–{2,})?\s*page\s+\d+\s+of\s+\d+\s*(?:-{2,}|–{2,})?$/i.test(compact)) return true;
  if (/^\s*(?:journal\s+of\s+emergency\s+management\s+)?(?:vol(?:ume)?\.?\s+\d+|issn\s+\d{4}-\d{3}[\dx]|special issue)\b/i.test(compact) && compact.length < 180) return true;
  if (/\beditorial board\b/i.test(compact) && !/\beditorial board\b/i.test(queryLower)) return true;
  if (looksLikePersonnelRosterSentence(compact) && !/\b(?:editorial board|board|authors?|people|staff|members?)\b/i.test(queryLower)) return true;
  if (isUnrequestedPromotionalSentence(queryLower, compact)) return true;
  if (/\b(?:copyright|all rights reserved|visit our website|www\.[a-z0-9.-]+)\b/i.test(compact) && overlappingTerms(queryLower, compact).length < 2) return true;
  if (/\b(?:table of contents|contents list|list of figures|reference list|bibliography)\b/i.test(compact) && compact.length < 220) return true;
  return false;
}

function looksLikePersonnelRosterSentence(sentence: string) {
  const credentialHits = sentence.match(/\b(?:PhD|DPA|CEM|MPH|MD|Professor|Director|University|Institute|Department)\b/g) ?? [];
  return credentialHits.length >= 3 && /[,;]/.test(sentence);
}

function isUnrequestedPromotionalSentence(queryLower: string, sentence: string) {
  const brandKnowledgeMatch = sentence.match(/\b([A-Z][A-Za-z0-9&.-]{2,})(?:'s|’s)\s+knowledge\s+and\s+tools\s+support\s+organizations\b/);
  if (brandKnowledgeMatch && !queryLower.includes(brandKnowledgeMatch[1].toLowerCase())) return true;
  if (brandKnowledgeMatch) return false;
  return /\b(?:visit our website|learn how your organization can take action|support organizations' .*planning, governing, finance, implementation)\b/i.test(sentence)
    && overlappingTerms(queryLower, sentence).length < 3;
}

function cleanVisibleAnswer(answer: string) {
  return collapseImmediateRepeatedPhrases(normalizeRuntimeEvidenceText(answer))
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeRuntimeEvidenceText(text: string) {
  return text
    .replace(/([A-Za-z]{2,})-\s+([a-z]{2,})/g, "$1$2")
    .replace(/\b([A-Z][a-z]{2,})(\d{1,3})(?=\s+(?:also\s+)?(?:finds?|found|states?|argues?|reports?|suggests?|concludes?|notes?|shows?|identifies?|explains?|does|has|is|was)\b)/g, "$1")
    .replace(/\b([a-z]{2,})(\d{1,3})(?=\s+(?:also\s+)?(?:finds?|found|states?|argues?|reports?|suggests?|concludes?|notes?|shows?|identifies?|explains?|does|has|is|was)\b)/g, "$1")
    .replace(/[\uFB00-\uFB06]/g, (match) => LIGATURE_REPLACEMENTS[match] ?? match);
}

function hasOcrHyphenationArtifact(text: string) {
  return /\b[A-Za-z]{2,}-\s+[a-z]{2,}\b/.test(text);
}

function hasRepeatedPhraseLoop(text: string) {
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s'-]/g, " ").replace(/\s+/g, " ").trim();
  if (!normalized) return false;
  return /\b([a-z0-9][a-z0-9'-]*(?:\s+[a-z0-9][a-z0-9'-]*){1,4})(?:\s+\1\b)+/i.test(normalized);
}

function collapseImmediateRepeatedPhrases(text: string) {
  let previous = text;
  for (let pass = 0; pass < 3; pass += 1) {
    const next = previous.replace(/\b([A-Za-z0-9][A-Za-z0-9'-]*(?:\s+[A-Za-z0-9][A-Za-z0-9'-]*){1,4})(?:\s+\1\b)+/gi, "$1");
    if (next === previous) return next;
    previous = next;
  }
  return previous;
}

function sentenceScore(queryLower: string, sentence: string, citationIndex: number) {
  const lowerSentence = sentence.toLowerCase();
  const numbers = Array.from(new Set(queryLower.match(/\b\d+(?::\d+)?\b/g) ?? []));
  let score = Math.max(0, 1 - citationIndex * 0.08);

  for (const number of numbers) {
    if (lowerSentence.includes(number)) score += 2.5;
  }

  for (const phrase of answerPhrases(queryLower)) {
    if (lowerSentence.includes(phrase)) score += phrase.length > 10 ? 1.6 : 0.8;
  }

  score += Math.min(overlappingTerms(queryLower, sentence).length * 0.35, 2.1);

  for (const cue of ["correct", "confused", "without electric", "residents sheltered", "primary", "general-population", "37 minutes", "go-bag", "advisory phrasing", "preparedness", "no dam release", "did not order", "voluntary evacuation advisory", "72 percent", "62 percent", "10 minutes", "tide-locked", "flap gates", "dry-weather", "not the live-flood operating trigger"]) {
    if (lowerSentence.includes(cue) && queryLower.includes(cue)) score += 1.4;
  }

  if (/purpose|scope|overview/.test(lowerSentence) && !/purpose|scope|overview/.test(queryLower)) score -= 1.2;
  if (isLowValueRuntimeEvidenceSentence(queryLower, sentence)) score -= 4;
  if (/\b(?:copyright|all rights reserved|visit our website|editorial board|issn)\b/i.test(sentence) && overlappingTerms(queryLower, sentence).length < 3) score -= 1.2;

  return score;
}

function answerPhrases(queryLower: string) {
  return [
    "voluntary evacuation advisory",
    "old mill",
    "south quay",
    "harbor civic center",
    "general-population shelter",
    "dam release",
    "weather bulletin",
    "active flood conditions",
    "assisted pump-out",
    "dry-weather testing",
  ].filter((phrase) => queryLower.includes(phrase));
}

function dedupeSentences(sentences: string[]) {
  const seen = new Set<string>();
  return sentences.filter((sentence) => {
    const key = sentence.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().slice(0, 120);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

const LIGATURE_REPLACEMENTS: Record<string, string> = {
  "\uFB00": "ff",
  "\uFB01": "fi",
  "\uFB02": "fl",
  "\uFB03": "ffi",
  "\uFB04": "ffl",
  "\uFB05": "st",
  "\uFB06": "st",
};

function buildAugmentedContextTrace(backend: RetrievalBackendId, citations: Citation[]): AugmentedContextTrace {
  return {
    backend,
    citationCount: citations.length,
    documentIds: Array.from(new Set(citations.map((citation) => citation.documentId))),
    chunkIds: citations.map((citation) => citation.chunkId).filter(Boolean) as string[],
    sourcePaths: Array.from(new Set(citations.map((citation) => citation.sourcePath).filter(Boolean) as string[])),
  };
}

function domainName(domain: DomainId) {
  return domain === "law" ? "Law" : domain === "sandbags" ? "Sandbags" : domain;
}

function classifyIntent(query: string, mode: QuerySession["mode"]) {
  const normalized = query.toLowerCase();
  if (/prevent all|all flood damage|guarantee|guaranteed protection|prove.*prevent|proof.*prevent|prove.*sandbags.*protect|proof.*sandbags.*protect/.test(normalized)) return "absolute_flood_claim";
  if (/pickup|pick up|distribution rules|where.*get|how many bags|sandbag rules|proof of residency|residency proof/.test(normalized)) return "pickup_rules";
  if (/public claims?|publication risk|publishing.*claims?|legal cautions?|before publishing|claims risk/.test(normalized)) return "publication_risk";
  if (mode === "external_compare") return "external_compare";
  if (/(^|\b)(draft an article|write an article|article draft|article outline|outline an article|writing angle)(\b|$)/.test(normalized)) return "article";
  return "direct_answer";
}
