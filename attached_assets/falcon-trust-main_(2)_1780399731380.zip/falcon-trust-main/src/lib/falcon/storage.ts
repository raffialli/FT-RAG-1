import { CopyObjectCommand, DeleteObjectCommand, GetObjectCommand, ListObjectsV2Command, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import fs from "node:fs";
import path from "node:path";

function bucketName() {
  return process.env.FALCON_STORAGE_BUCKET ?? "";
}

function s3Enabled() {
  return Boolean(bucketName() && process.env.FALCON_STORAGE_BACKEND === "s3");
}

function s3Client() {
  return new S3Client({ region: process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-2" });
}

export async function listJson(prefix: string, localDir: string) {
  if (!s3Enabled()) {
    if (!fs.existsSync(localDir)) return [];
    return fs
      .readdirSync(localDir)
      .filter((file) => file.endsWith(".json"))
      .sort()
      .map((file) => {
        const fullPath = path.join(localDir, file);
        return { key: fullPath, storageKey: fullPath, storage: "local" as const, body: fs.readFileSync(fullPath, "utf8") };
      });
  }

  const client = s3Client();
  const listed = await client.send(new ListObjectsV2Command({ Bucket: bucketName(), Prefix: prefix }));
  const objects = listed.Contents?.filter((object) => object.Key?.endsWith(".json")) ?? [];
  const records = await Promise.all(
    objects.map(async (object) => {
      const key = object.Key!;
      const response = await client.send(new GetObjectCommand({ Bucket: bucketName(), Key: key }));
      return { key, storageKey: key, storage: "s3" as const, body: await response.Body!.transformToString() };
    }),
  );
  return records.sort((a, b) => a.key.localeCompare(b.key));
}

export async function writeJson(key: string, localPath: string, value: unknown) {
  const body = JSON.stringify(value, null, 2);
  if (!s3Enabled()) {
    fs.mkdirSync(path.dirname(localPath), { recursive: true });
    fs.writeFileSync(localPath, body);
    return { path: path.relative(process.cwd(), localPath), storage: "local" as const };
  }

  await s3Client().send(
    new PutObjectCommand({
      Bucket: bucketName(),
      Key: key,
      Body: body,
      ContentType: "application/json",
    }),
  );
  return { path: `s3://${bucketName()}/${key}`, storage: "s3" as const };
}

export async function readJson(key: string, localPath: string) {
  if (!s3Enabled()) {
    return { path: path.relative(process.cwd(), localPath), storage: "local" as const, body: fs.readFileSync(localPath, "utf8") };
  }

  const response = await s3Client().send(new GetObjectCommand({ Bucket: bucketName(), Key: key }));
  return { path: `s3://${bucketName()}/${key}`, storage: "s3" as const, body: await response.Body!.transformToString() };
}

export async function copyJson(sourceKey: string, sourceLocalPath: string, targetKey: string, targetLocalPath: string) {
  if (!s3Enabled()) {
    fs.mkdirSync(path.dirname(targetLocalPath), { recursive: true });
    fs.copyFileSync(sourceLocalPath, targetLocalPath);
    return { source: path.relative(process.cwd(), sourceLocalPath), target: path.relative(process.cwd(), targetLocalPath), storage: "local" as const };
  }

  await s3Client().send(
    new CopyObjectCommand({
      Bucket: bucketName(),
      CopySource: `${bucketName()}/${sourceKey}`,
      Key: targetKey,
      ContentType: "application/json",
      MetadataDirective: "COPY",
    }),
  );
  return { source: `s3://${bucketName()}/${sourceKey}`, target: `s3://${bucketName()}/${targetKey}`, storage: "s3" as const };
}

export async function deleteJson(key: string, localPath: string) {
  if (!s3Enabled()) {
    if (fs.existsSync(localPath)) fs.unlinkSync(localPath);
    return;
  }
  await s3Client().send(new DeleteObjectCommand({ Bucket: bucketName(), Key: key }));
}
