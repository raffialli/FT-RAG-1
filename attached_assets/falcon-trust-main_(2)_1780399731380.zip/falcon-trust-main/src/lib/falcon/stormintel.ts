export type StormIntelStatus = "new" | "reviewed" | "worth_watching" | "worth_pursuing" | "ignored" | "drafted";

export type StormIntelSourceType = "live" | "fallback";

export type StormIntelEventType = "hurricane" | "tropical_storm" | "flood_watch_warning" | "heavy_rain_flood_risk" | "storm_surge_coastal_flooding";

export type StormIntelTargetConfidence = "verified" | "likely" | "needs_review";

export type StormIntelVerifiedOfficial = {
  name: string;
  title: string;
  jurisdiction: string;
  category: string;
  sourceUrl: string;
  confidence: StormIntelTargetConfidence;
};

export type StormIntelVerifiedPublication = {
  name: string;
  type: string;
  regionServed: string;
  sourceUrl: string;
  confidence: StormIntelTargetConfidence;
};

export type StormIntelVerifiedTargets = {
  regionLabel: string;
  sourceNote: string;
  lastChecked: string;
  officials: StormIntelVerifiedOfficial[];
  publications: StormIntelVerifiedPublication[];
};

export type StormIntelPacket = {
  id: string;
  title: string;
  eventType: StormIntelEventType;
  sourceType: StormIntelSourceType;
  sourceLabel: string;
  sourceStatus: string;
  sourceUrl?: string;
  impactedRegion: string;
  stateRegion: string;
  counties: {
    name: string;
    cities: string[];
  }[];
  expectedTiming: string;
  severity: "Extreme" | "Severe" | "High" | "Medium" | "Low" | "Unknown";
  confidence: "Observed" | "Likely" | "Possible" | "High" | "Medium" | "Low" | "Unknown";
  urgency: "Immediate" | "Expected" | "Future" | "Past" | "Unknown";
  sandbagRelevance: string;
  recommendedAngle: string;
  officials: {
    sourceLabel: string;
    tier1: string[];
    tier2: string[];
  };
  publicationTargets: string[];
  verifiedTargets: StormIntelVerifiedTargets | null;
  initialStatus: StormIntelStatus;
};

type NwsAlertFeature = {
  id?: string;
  properties?: {
    id?: string;
    event?: string;
    headline?: string;
    areaDesc?: string;
    severity?: string;
    certainty?: string;
    urgency?: string;
    onset?: string;
    effective?: string;
    expires?: string;
    ends?: string | null;
    description?: string;
    instruction?: string;
    parameters?: Record<string, string[] | undefined>;
    geocode?: {
      UGC?: string[];
    };
  };
};

type NwsAlertResponse = {
  features?: NwsAlertFeature[];
};

export type StormIntelFeedResult = {
  generatedAt: string;
  source: "live" | "fallback" | "mixed";
  liveCount: number;
  fallbackCount: number;
  packets: StormIntelPacket[];
  notice: string;
  error?: string;
};

const SOUTHEAST_STATES = new Set(["AL", "FL", "GA", "LA", "MS", "NC", "SC", "TN", "VA"]);
const STATE_NAMES: Record<string, string> = {
  AL: "Alabama",
  FL: "Florida",
  GA: "Georgia",
  LA: "Louisiana",
  MS: "Mississippi",
  NC: "North Carolina",
  SC: "South Carolina",
  TN: "Tennessee",
  VA: "Virginia",
};

const STATE_CITY_HINTS: Record<string, string[]> = {
  AL: ["Mobile", "Birmingham", "Montgomery"],
  FL: ["Tampa", "Pensacola", "Fort Myers"],
  GA: ["Savannah", "Brunswick", "Atlanta"],
  LA: ["New Orleans", "Baton Rouge", "Lafayette"],
  MS: ["Biloxi", "Gulfport", "Jackson"],
  NC: ["Wilmington", "New Bern", "Raleigh"],
  SC: ["Charleston", "Myrtle Beach", "Columbia"],
  TN: ["Chattanooga", "Nashville", "Memphis"],
  VA: ["Norfolk", "Virginia Beach", "Richmond"],
};

const RELEVANT_EVENT_PATTERNS = [
  /flood/i,
  /flash flood/i,
  /coastal flood/i,
  /storm surge/i,
  /tropical storm/i,
  /hurricane/i,
  /excessive rainfall/i,
  /heavy rain/i,
];

const EXCLUDED_UNLESS_FLOODING = [/rip current/i, /heat/i, /wind advisory/i, /small craft/i, /beach hazards/i, /red flag/i, /freeze/i, /dense fog/i];

export const stormIntelStatuses: { id: StormIntelStatus; label: string }[] = [
  { id: "new", label: "New" },
  { id: "reviewed", label: "Reviewed" },
  { id: "worth_watching", label: "Worth watching" },
  { id: "worth_pursuing", label: "Worth pursuing" },
  { id: "ignored", label: "Ignored" },
  { id: "drafted", label: "Drafted" },
];

export const futureOnlyStatus = "Contacted";

const seededOfficials = {
  sourceLabel: "Seeded demo targeting categories, not live official records",
  tier1: [
    "Emergency Management Director",
    "Public Works Director",
    "County/City Administrator or Manager",
    "Procurement/Purchasing Director if available",
    "Public Information Officer / Communications Director",
  ],
  tier2: [
    "County Commissioners",
    "City Council",
    "Mayor, where relevant, marked as public/accountability leadership rather than primary operational owner",
  ],
};

const seededPublicationTargets = [
  "local newspapers / online news",
  "local TV/radio/news",
  "county/city public information channels",
  "emergency preparedness/community outlets",
  "chamber/business journals",
];

const tampaBayVerifiedTargets: StormIntelVerifiedTargets = {
  regionLabel: "Tampa Bay / Hillsborough / Pinellas curated public targets",
  sourceNote: "Small demo-safe dataset verified from public government and publication pages. No scraping, outreach, private data, or automation is used.",
  lastChecked: "2026-05-23",
  officials: [
    {
      name: "Jane Castor",
      title: "Mayor",
      jurisdiction: "City of Tampa",
      category: "Mayor / public accountability leadership",
      sourceUrl: "https://www.tampa.gov/mayor",
      confidence: "verified",
    },
    {
      name: "Timothy Dudley, Jr.",
      title: "Department Director",
      jurisdiction: "Hillsborough County Emergency Management",
      category: "Emergency Management",
      sourceUrl: "https://hcfl.gov/departments/emergency",
      confidence: "verified",
    },
    {
      name: "Bonnie M. Wise",
      title: "County Administrator",
      jurisdiction: "Hillsborough County",
      category: "County Administrator / executive operations",
      sourceUrl: "https://hcfl.gov/government/leadership/county-administrator",
      confidence: "verified",
    },
    {
      name: "Cathie Perkins",
      title: "Director",
      jurisdiction: "Pinellas County Emergency Management",
      category: "Emergency Management",
      sourceUrl: "https://pinellas.gov/mediacentral/",
      confidence: "verified",
    },
  ],
  publications: [
    {
      name: "Tampa Bay Times",
      type: "local newspaper / online news",
      regionServed: "Tampa Bay area",
      sourceUrl: "https://www.tampabay.com/contact-us/",
      confidence: "verified",
    },
    {
      name: "WUSF Public Media",
      type: "public media / local newsroom",
      regionServed: "Tampa / west central Florida",
      sourceUrl: "https://www.wusf.org/contactus",
      confidence: "verified",
    },
    {
      name: "Spectrum Bay News 9",
      type: "local TV / regional news",
      regionServed: "Tampa Bay area",
      sourceUrl: "https://baynews9.com/fl/tampa/about/contact-us",
      confidence: "verified",
    },
  ],
};

const acadianaVerifiedTargets: StormIntelVerifiedTargets = {
  regionLabel: "Lafayette / Vermilion Parish curated public targets",
  sourceNote: "Small demo-safe dataset verified from public government, parish, and publication pages for the live Lafayette/Vermilion alert geography. No scraping, outreach, private data, or automation is used.",
  lastChecked: "2026-05-23",
  officials: [
    {
      name: "Chad P. Sonnier",
      title: "Director, Office of Homeland Security and Emergency Preparedness",
      jurisdiction: "Lafayette Parish",
      category: "Emergency Management",
      sourceUrl: "https://www.lafayettela.gov/ohsep/director",
      confidence: "verified",
    },
    {
      name: "Warren Abadie",
      title: "Director of Traffic, Roads, & Bridges and Public Works",
      jurisdiction: "Lafayette Consolidated Government",
      category: "Public Works",
      sourceUrl: "https://lafayettela.gov/directors",
      confidence: "verified",
    },
    {
      name: "Jamie Boudreaux",
      title: "Chief Communications Officer",
      jurisdiction: "Lafayette Consolidated Government",
      category: "Public Information / Communications",
      sourceUrl: "https://www.lafayettela.gov/your-government/lcg-administration/chief-of-staff/communications-and-media/",
      confidence: "verified",
    },
    {
      name: "Karen Fontenot",
      title: "Director, Finance & Management",
      jurisdiction: "Lafayette Consolidated Government",
      category: "Procurement / purchasing oversight",
      sourceUrl: "https://www.lafayettela.gov/finance-management",
      confidence: "verified",
    },
    {
      name: "Homer Stelly",
      title: "Director, Homeland Security / Emergency Preparedness",
      jurisdiction: "Vermilion Parish",
      category: "Emergency Management",
      sourceUrl: "https://www.vppj.org/2012DEPTsecurity.html",
      confidence: "verified",
    },
    {
      name: "Gary Guidry",
      title: "Public Works Director / Parishwide Road Supervisor",
      jurisdiction: "Vermilion Parish",
      category: "Public Works",
      sourceUrl: "https://www.vppj.org/2012DEPTpworks.html",
      confidence: "verified",
    },
    {
      name: "Keith Roy",
      title: "Parish Administrator",
      jurisdiction: "Vermilion Parish Police Jury",
      category: "Parish administrator / executive operations",
      sourceUrl: "https://vppj.org/2012GOVTpj.html",
      confidence: "verified",
    },
  ],
  publications: [
    {
      name: "KATC TV3",
      type: "local TV / regional news",
      regionServed: "Acadiana / Lafayette and surrounding parishes",
      sourceUrl: "https://www.katc.com/about/contact-us",
      confidence: "verified",
    },
    {
      name: "KLFY News 10",
      type: "local TV / regional news",
      regionServed: "Lafayette DMA, including Lafayette and Vermilion parishes",
      sourceUrl: "https://www.nexstar.tv/stations/klfy/",
      confidence: "verified",
    },
    {
      name: "The Daily Advertiser",
      type: "local newspaper / online news",
      regionServed: "Lafayette / Acadiana",
      sourceUrl: "https://static.theadvertiser.com/about/",
      confidence: "verified",
    },
    {
      name: "The Current",
      type: "nonprofit local newsroom",
      regionServed: "Lafayette and South Louisiana",
      sourceUrl: "https://thecurrentla.com/about/",
      confidence: "verified",
    },
    {
      name: "The Acadiana Advocate",
      type: "regional newspaper / online news",
      regionServed: "Lafayette / Acadiana",
      sourceUrl: "https://placeads.theadvocate.com/advocate-adportal/classified/info/contact.htm",
      confidence: "likely",
    },
  ],
};

const verifiedTargetSets: { matchTerms: string[]; targets: StormIntelVerifiedTargets }[] = [
  {
    matchTerms: ["lafayette", "vermilion", "acadiana", "abbeville", "maurice", "kaplan"],
    targets: acadianaVerifiedTargets,
  },
  {
    matchTerms: ["tampa", "tampa bay", "hillsborough", "pinellas", "pasco", "clearwater", "st. petersburg", "st petersburg"],
    targets: tampaBayVerifiedTargets,
  },
];

export const demoFallbackPackets: StormIntelPacket[] = [
  {
    id: "stormintel-demo-tampa-bay-heavy-rain",
    title: "Tampa Bay heavy rain and flash-flood setup",
    eventType: "heavy_rain_flood_risk",
    sourceType: "fallback",
    sourceLabel: "Demo Fallback",
    sourceStatus: "Demo fallback packet; not a live NWS alert",
    impactedRegion: "Tampa Bay and west central Florida",
    stateRegion: "Florida",
    counties: [
      { name: "Hillsborough County, FL", cities: ["Tampa", "Temple Terrace", "Plant City"] },
      { name: "Pinellas County, FL", cities: ["St. Petersburg", "Clearwater", "Largo"] },
      { name: "Pasco County, FL", cities: ["New Port Richey", "Dade City", "Zephyrhills"] },
    ],
    expectedTiming: "Demo scenario: next 24-48 hours",
    severity: "Medium",
    confidence: "Medium",
    urgency: "Expected",
    sandbagRelevance: "Urban drainage, low-road flooding, and public pickup demand may rise before rainfall peaks.",
    recommendedAngle: "Prepare a county-first briefing on sandbag distribution readiness, pickup hours, and public messaging gaps.",
    officials: seededOfficials,
    publicationTargets: seededPublicationTargets,
    verifiedTargets: tampaBayVerifiedTargets,
    initialStatus: "new",
  },
  {
    id: "stormintel-demo-carolina-coastal-flooding",
    title: "Coastal Carolina surge and tidal flooding watch",
    eventType: "storm_surge_coastal_flooding",
    sourceType: "fallback",
    sourceLabel: "Demo Fallback",
    sourceStatus: "Demo fallback packet; not a live NWS alert",
    impactedRegion: "South Carolina and North Carolina coast",
    stateRegion: "South Carolina / North Carolina",
    counties: [
      { name: "Charleston County, SC", cities: ["Charleston", "Mount Pleasant", "Folly Beach"] },
      { name: "Georgetown County, SC", cities: ["Georgetown", "Pawleys Island"] },
      { name: "New Hanover County, NC", cities: ["Wilmington", "Carolina Beach"] },
    ],
    expectedTiming: "Demo scenario: high-tide windows over the next two evenings",
    severity: "High",
    confidence: "Medium",
    urgency: "Expected",
    sandbagRelevance: "Barrier-island roads, tidal creeks, and repetitive-loss neighborhoods may need early sandbag staging.",
    recommendedAngle: "Frame FalconTrust support around pre-positioning sandbags before tide peaks and clarifying resident pickup priorities.",
    officials: seededOfficials,
    publicationTargets: seededPublicationTargets,
    verifiedTargets: null,
    initialStatus: "worth_watching",
  },
  {
    id: "stormintel-demo-louisiana-tropical-rain",
    title: "Louisiana tropical rain band with parish drainage risk",
    eventType: "tropical_storm",
    sourceType: "fallback",
    sourceLabel: "Demo Fallback",
    sourceStatus: "Demo fallback packet; not a live NWS alert",
    impactedRegion: "Southeast Louisiana",
    stateRegion: "Louisiana",
    counties: [
      { name: "Jefferson Parish, LA", cities: ["Kenner", "Metairie", "Gretna"] },
      { name: "St. Tammany Parish, LA", cities: ["Slidell", "Mandeville", "Covington"] },
      { name: "Orleans Parish, LA", cities: ["New Orleans"] },
    ],
    expectedTiming: "Demo scenario: outer rain bands could arrive within 36 hours",
    severity: "Medium",
    confidence: "Low",
    urgency: "Future",
    sandbagRelevance: "Pump capacity, saturated soils, and neighborhood-level drainage concerns make resident sandbag messaging time-sensitive.",
    recommendedAngle: "Track parish-level public works posture and prepare a human-reviewed opportunity packet before any outreach.",
    officials: seededOfficials,
    publicationTargets: seededPublicationTargets,
    verifiedTargets: null,
    initialStatus: "reviewed",
  },
];

export async function loadStormIntelFeed(forceFallback = false): Promise<StormIntelFeedResult> {
  const generatedAt = new Date().toISOString();

  if (forceFallback) {
    return {
      generatedAt,
      source: "fallback",
      liveCount: 0,
      fallbackCount: demoFallbackPackets.length,
      packets: demoFallbackPackets,
      notice: "Forced fallback mode for QA. Demo fallback data is clearly labeled and is not live alert data.",
    };
  }

  try {
    const livePackets = await fetchNwsStormIntelPackets();
    if (livePackets.length > 0) {
      return {
        generatedAt,
        source: "live",
        liveCount: livePackets.length,
        fallbackCount: 0,
        packets: livePackets,
        notice: "Showing read-only NWS/public active alerts filtered for Southeast flood, hurricane, storm surge, and sandbag relevance.",
      };
    }

    return {
      generatedAt,
      source: "fallback",
      liveCount: 0,
      fallbackCount: demoFallbackPackets.length,
      packets: demoFallbackPackets,
      notice: "No relevant live NWS/public alerts matched the StormIntel filter. Showing labeled demo fallback events.",
    };
  } catch (error) {
    return {
      generatedAt,
      source: "fallback",
      liveCount: 0,
      fallbackCount: demoFallbackPackets.length,
      packets: demoFallbackPackets,
      notice: "NWS/public alert fetch failed safely. Showing labeled demo fallback events.",
      error: error instanceof Error ? error.message : "Unknown NWS fetch error",
    };
  }
}

export function eventTypeLabel(value: StormIntelEventType) {
  return value
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

async function fetchNwsStormIntelPackets() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch("https://api.weather.gov/alerts/active", {
      headers: {
        Accept: "application/geo+json",
        "User-Agent": "FalconTrust-StormIntel-Demo/2026-05-23",
      },
      signal: controller.signal,
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error(`NWS active alerts returned HTTP ${response.status}`);
    }

    const data = (await response.json()) as NwsAlertResponse;
    return (data.features ?? [])
      .filter(isRelevantSoutheastAlert)
      .slice(0, 12)
      .map(transformNwsAlert);
  } finally {
    clearTimeout(timeout);
  }
}

function isRelevantSoutheastAlert(feature: NwsAlertFeature) {
  const properties = feature.properties;
  if (!properties) return false;

  const haystack = [properties.event, properties.headline, properties.description, properties.instruction].filter(Boolean).join(" ");
  const relevant = RELEVANT_EVENT_PATTERNS.some((pattern) => pattern.test(haystack));
  if (!relevant) return false;

  const excluded = EXCLUDED_UNLESS_FLOODING.some((pattern) => pattern.test(properties.event ?? ""));
  if (excluded && !/flood|surge|rain/i.test(haystack)) return false;

  const states = getAlertStates(properties);
  return states.some((state) => SOUTHEAST_STATES.has(state));
}

function transformNwsAlert(feature: NwsAlertFeature): StormIntelPacket {
  const properties = feature.properties ?? {};
  const states = getAlertStates(properties);
  const region = states.map((state) => STATE_NAMES[state] ?? state).join(" / ") || "Southeast alert region";
  const title = properties.headline || properties.event || "NWS public alert";
  const eventType = classifyEventType([properties.event, properties.headline, properties.description].filter(Boolean).join(" "));
  const sourceUrl = properties.id ? `https://api.weather.gov/alerts/${encodeURIComponent(properties.id)}` : undefined;

  const packet: Omit<StormIntelPacket, "verifiedTargets"> = {
    id: `stormintel-live-${slugify(properties.id ?? feature.id ?? title)}`,
    title,
    eventType,
    sourceType: "live",
    sourceLabel: "Live NWS/Public Alert",
    sourceStatus: "Read-only NWS/public active alert transformed into a StormIntel review packet",
    sourceUrl,
    impactedRegion: properties.areaDesc || region,
    stateRegion: region,
    counties: buildCountyStructure(properties.areaDesc, states),
    expectedTiming: formatTiming(properties),
    severity: mapSeverity(properties.severity),
    confidence: mapConfidence(properties.certainty),
    urgency: mapUrgency(properties.urgency),
    sandbagRelevance: buildSandbagRelevance(eventType, properties.event),
    recommendedAngle: buildRecommendedAngle(eventType),
    officials: seededOfficials,
    publicationTargets: seededPublicationTargets,
    initialStatus: eventType === "hurricane" || eventType === "storm_surge_coastal_flooding" ? "worth_watching" : "new",
  };

  return { ...packet, verifiedTargets: findVerifiedTargets(packet) };
}

function findVerifiedTargets(packet: Omit<StormIntelPacket, "verifiedTargets">): StormIntelVerifiedTargets | null {
  const searchable = [
    packet.title,
    packet.impactedRegion,
    packet.stateRegion,
    packet.sourceStatus,
    ...packet.counties.map((county) => county.name),
  ]
    .join(" ")
    .toLowerCase();

  return verifiedTargetSets.find((set) => set.matchTerms.some((term) => searchable.includes(term)))?.targets ?? null;
}

function getAlertStates(properties: NonNullable<NwsAlertFeature["properties"]>) {
  const states = new Set<string>();
  const areaMatches = properties.areaDesc?.match(/\b[A-Z]{2}\b/g) ?? [];
  areaMatches.forEach((state) => {
    if (SOUTHEAST_STATES.has(state)) states.add(state);
  });

  for (const ugc of properties.geocode?.UGC ?? []) {
    const prefix = ugc.slice(0, 2);
    if (SOUTHEAST_STATES.has(prefix)) states.add(prefix);
  }

  return Array.from(states);
}

function buildCountyStructure(areaDesc: string | undefined, states: string[]) {
  const fallbackCities = states.flatMap((state) => STATE_CITY_HINTS[state] ?? []).slice(0, 3);
  const cities = fallbackCities.length > 0 ? fallbackCities : ["Review local municipalities"];
  const areas = (areaDesc ?? "Affected NWS alert area")
    .split(";")
    .map((area) => area.trim())
    .filter(Boolean)
    .slice(0, 8);

  return (areas.length > 0 ? areas : ["Affected NWS alert area"]).map((area) => ({
    name: normalizeCountyName(area, states),
    cities,
  }));
}

function normalizeCountyName(value: string, states: string[]) {
  if (/county|parish|borough|city/i.test(value)) return value;
  const suffix = states.length === 1 ? `, ${states[0]}` : "";
  return `${value}${suffix}`;
}

function classifyEventType(text: string): StormIntelEventType {
  if (/hurricane/i.test(text)) return "hurricane";
  if (/tropical storm/i.test(text)) return "tropical_storm";
  if (/storm surge|coastal flood/i.test(text)) return "storm_surge_coastal_flooding";
  if (/flood|flash flood/i.test(text)) return "flood_watch_warning";
  return "heavy_rain_flood_risk";
}

function formatTiming(properties: NonNullable<NwsAlertFeature["properties"]>) {
  const starts = properties.onset ?? properties.effective;
  const ends = properties.ends ?? properties.expires;
  if (starts && ends) return `${formatDate(starts)} to ${formatDate(ends)}`;
  if (starts) return `Starting ${formatDate(starts)}`;
  if (ends) return `Until ${formatDate(ends)}`;
  return "Timing available in source alert details";
}

function formatDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short",
  }).format(date);
}

function mapSeverity(value: string | undefined): StormIntelPacket["severity"] {
  if (value === "Extreme" || value === "Severe") return value;
  if (value === "Moderate") return "Medium";
  if (value === "Minor") return "Low";
  return "Unknown";
}

function mapConfidence(value: string | undefined): StormIntelPacket["confidence"] {
  if (value === "Observed" || value === "Likely" || value === "Possible") return value;
  if (value === "Unlikely") return "Low";
  return "Unknown";
}

function mapUrgency(value: string | undefined): StormIntelPacket["urgency"] {
  if (value === "Immediate" || value === "Expected" || value === "Future" || value === "Past") return value;
  return "Unknown";
}

function buildSandbagRelevance(eventType: StormIntelEventType, eventName: string | undefined) {
  if (eventType === "hurricane" || eventType === "tropical_storm") {
    return "Potential surge, rainfall, and drainage stress can drive early sandbag pickup and staging needs.";
  }
  if (eventType === "storm_surge_coastal_flooding") {
    return "Coastal surge and tidal flooding can create neighborhood-level sandbag demand before peak water levels.";
  }
  if (/flash flood/i.test(eventName ?? "")) {
    return "Flash flooding can compress public works response time and increase urgent resident protection messaging.";
  }
  return "Flooding or heavy rain relevance indicates possible public sandbag distribution, staging, or communications opportunities.";
}

function buildRecommendedAngle(eventType: StormIntelEventType) {
  if (eventType === "hurricane" || eventType === "tropical_storm") {
    return "Build a human-reviewed county-first packet on sandbag readiness, public pickup hours, and pre-landfall communications gaps.";
  }
  if (eventType === "storm_surge_coastal_flooding") {
    return "Focus the review on coastal roads, repetitive-loss areas, and pre-positioned sandbag communication before tide or surge peaks.";
  }
  return "Prepare a concise FalconTrust opportunity brief around drainage hotspots, sandbag pickup clarity, and emergency communications readiness.";
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}
