export type DomainId = "law" | "sandbags" | string;

export type Domain = {
  id: DomainId;
  name: string;
  description: string;
};

export type DemoDocument = {
  id: string;
  title: string;
  domain: DomainId;
  path: string;
  text: string;
  source?: "static" | "uploaded";
  sourceFileName?: string;
  uploadedAt?: string;
  storageKey?: string;
  textMetadata?: Record<string, string | number | boolean | null>;
};

export type Chunk = {
  id: string;
  documentId: string;
  title: string;
  domain: DomainId;
  text: string;
  index: number;
  tokens: string[];
  sourcePath?: string;
  contentType?: "body" | "index" | "reference" | "unknown";
  metadata?: Record<string, string | number | boolean | null>;
};

export type EmbeddingConfig = {
  provider: "bedrock";
  region: string;
  model: string;
  enabled: boolean;
};

export type EmbeddingRecord = {
  chunkId: string;
  documentId: string;
  title: string;
  domain: DomainId;
  text: string;
  index: number;
  sourcePath?: string;
  contentType?: "body" | "index" | "reference" | "unknown";
  embedding: number[];
  metadata?: Record<string, string | number | boolean | null>;
};

export type VectorIndex = {
  version: number;
  provider: "bedrock";
  model: string;
  region: string;
  updatedAt?: string;
  records: EmbeddingRecord[];
};

export type PublicEmbeddingStatus = {
  config: EmbeddingConfig;
  vectorStore: "s3-json";
  indexPath: string;
  chunkCount: number;
  vectorCount: number;
  staleCount: number;
  lastIndexedAt?: string;
  ready: boolean;
  backend?: RetrievalBackendId;
  activeIndexKey?: string;
  displayMode?: "active-backend" | "chunk-index-match";
  notes?: string[];
};

export type EmbeddingMutationResult = {
  strategy: "full-rebuild" | "incremental-upsert" | "incremental-delete";
  embeddedChunkCount: number;
  removedVectorCount: number;
  previousVectorCount: number;
  nextVectorCount: number;
  status: PublicEmbeddingStatus;
};

export type Citation = {
  documentId: string;
  title: string;
  domain: DomainId;
  snippet: string;
  score: number;
  chunkId?: string;
  chunkIndex?: number;
  viewerUrl?: string;
  sourcePath?: string;
  source?: "static" | "uploaded";
  sourceFileName?: string;
  contentType?: "body" | "index" | "reference" | "unknown";
  metadata?: Record<string, string | number | boolean | null>;
  text?: string;
};

export type AnswerType = "clear_answer" | "create_article";

export type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  apiKey?: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};

export type PublicArticleConfig = Omit<ArticleConfig, "apiKey"> & {
  apiKeyConfigured: boolean;
  apiKeyMasked: string;
};

export type ExternalSearchResult = {
  title: string;
  url: string;
  snippet: string;
  source: "tavily" | "demo_llm";
  score?: number;
  publishedDate?: string;
};

export type AnswerSections = {
  answer: string;
  documentEvidence?: string;
  documentSupportedClaims?: string[];
  generalGuidance?: string[];
  externalContext?: string;
  gaps?: string[];
};

export type ExternalSearchStatus = {
  enabled: boolean;
  provider: "tavily";
  configured: boolean;
  attempted: boolean;
  ok: boolean;
  resultCount: number;
  warning?: string;
};

export type RetrievalBackendId = "lexical-file" | "manifest-chunk-map" | "pgvector" | "bedrock-s3-vector";

export type RetrievalTrace = {
  backend: RetrievalBackendId;
  selectedDomains: DomainId[];
  queryTokens: string[];
  chunkCandidates: number;
  matchedCandidates: number;
  limit: number;
  notes?: string[];
};

export type RetrievalDebugChunk = {
  chunkId: string;
  documentId: string;
  title: string;
  domain: DomainId;
  chunkIndex?: number;
  sourcePath?: string;
  contentType: "body" | "index" | "reference" | "unknown";
  score: number | null;
  snippet: string;
  textPreview: string;
  metadata: Record<string, string | number | boolean | null>;
  selected: boolean;
  rank?: number;
  reasons: string[];
};

export type RetrievalDebugDecision = {
  type: "selection" | "filter" | "answerability" | "confidence";
  chunkId?: string;
  reason: string;
  message: string;
};

export type RetrievalDebugTrace = {
  enabled: true;
  safeForLogging: true;
  backend: RetrievalBackendId;
  selectedDomains: DomainId[];
  limit: number;
  candidateCount: number;
  matchedCandidateCount: number;
  finalChunkCount: number;
  candidates: RetrievalDebugChunk[];
  finalChunks: RetrievalDebugChunk[];
  decisions: RetrievalDebugDecision[];
  notes?: string[];
};

export type AugmentedContextTrace = {
  backend: RetrievalBackendId;
  citationCount: number;
  documentIds: string[];
  chunkIds: string[];
  sourcePaths: string[];
};

export type CorpusInventory = {
  backend: RetrievalBackendId;
  documentCount: number;
  chunkCount: number;
  namespace?: string;
  notes?: string[];
};

export type RetrievalResult = {
  citations: Citation[];
  trace: RetrievalTrace;
  debugTrace?: RetrievalDebugTrace;
  inventory?: CorpusInventory;
};

export type QuerySession = {
  id: string;
  mode: "internal_qa" | "external_compare";
  query: string;
  selectedDomains: DomainId[];
  externalSearch?: boolean;
  externalSearchEnabled?: boolean;
  answerType: AnswerType;
  answer: string;
  answerSections?: AnswerSections;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  externalResults?: ExternalSearchResult[];
  externalSearchStatus?: ExternalSearchStatus;
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  articleConfig?: PublicArticleConfig;
  retrievalTrace?: RetrievalTrace;
  debugTrace?: RetrievalDebugTrace;
  augmentedContextTrace?: AugmentedContextTrace;
  corpusInventory?: CorpusInventory;
  createdAt: string;
};
