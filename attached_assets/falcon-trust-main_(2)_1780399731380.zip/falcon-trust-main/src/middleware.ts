import { NextResponse, type NextRequest } from "next/server";
import { ADMIN_COOKIE, AUTH_COOKIE, authEnabled, isConfigured } from "@/lib/falcon/auth";

const PUBLIC_FILE = /\.(.*)$/;

export function middleware(request: NextRequest) {
  if (!authEnabled()) return NextResponse.next();

  const { pathname } = request.nextUrl;
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/api/auth") ||
    pathname === "/login" ||
    PUBLIC_FILE.test(pathname)
  ) {
    return NextResponse.next();
  }

  if (!isConfigured()) {
    return new NextResponse("Falcon auth is enabled but credentials are not configured.", { status: 503 });
  }

  const hasAppSession = request.cookies.get(AUTH_COOKIE)?.value === "1";
  const hasAdminSession = request.cookies.get(ADMIN_COOKIE)?.value === "1";

  if (pathname.startsWith("/api/admin") || pathname === "/api/upload") {
    if (!hasAdminSession) return NextResponse.json({ error: "Admin authentication required" }, { status: 403 });
    return NextResponse.next();
  }

  if (pathname === "/admin" || pathname.startsWith("/admin/")) {
    if (!hasAdminSession) {
      const url = request.nextUrl.clone();
      url.pathname = "/login";
      url.searchParams.set("next", pathname);
      url.searchParams.set("admin", "1");
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  if (!hasAppSession) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "App authentication required" }, { status: 401 });
    }

    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image).*)"],
};
