import { expect, type Page, test } from "@playwright/test";

const deployedBaseUrl = process.env.PLAYWRIGHT_BASE_URL ?? process.env.E2E_BASE_URL;
const sitePassword = process.env.FALCONTRUST_SITE_PASSWORD;
const hasDeployedConfig = Boolean(deployedBaseUrl && sitePassword);
const smokeQuery = "What storm preparedness guidance is available for Acadiana residents?";

test.describe("AWS deployed smoke", () => {
  test.skip(!hasDeployedConfig, "Set PLAYWRIGHT_BASE_URL or E2E_BASE_URL plus FALCONTRUST_SITE_PASSWORD to run deployed smoke.");

  test("login, navigation, query UI, and debug API behave on deployed AWS", async ({ page }) => {
    const browserErrors: string[] = [];
    page.on("console", (message) => {
      if (message.type() === "error") browserErrors.push(message.text());
    });
    page.on("pageerror", (error) => browserErrors.push(error.message));

    await page.goto("/");
    await expect(page).toHaveURL(/\/login(?:\?|$)/);
    await page.getByLabel(/password/i).fill(sitePassword ?? "");
    await page.getByRole("button", { name: /continue/i }).click();

    await expect(page.getByRole("heading", { name: /Ask Falcontrust documents a question/i })).toBeVisible();
    await expect(page.getByText("Searchable domains")).toBeVisible();
    await expect(page.getByRole("textbox")).toBeVisible();
    await expect(page.getByRole("button", { name: "Run RAG search" })).toBeVisible();

    await page.getByRole("link", { name: "Add-ons" }).click();
    await expect(page.getByRole("heading", { name: /FalconTrust add-ons shell/i })).toBeVisible();
    await page.getByRole("link", { name: "FalconChat" }).click();
    await expect(page.getByRole("heading", { level: 2, name: "FalconChat" })).toBeVisible();
    await page.getByRole("link", { name: "Search" }).click();
    await expect(page.getByRole("heading", { name: /Ask Falcontrust documents a question/i })).toBeVisible();

    await expect(page.getByText("Try a tested question")).toBeVisible();
    const sampleQuestion = "Should emergency managers accept a contractor's standard document as-is to save time?";
    const samplePrompt = page.getByRole("button", { name: sampleQuestion });
    await expect(samplePrompt).toBeVisible();
    await samplePrompt.click();
    await expect(page.getByRole("textbox")).toHaveValue(sampleQuestion);

    await page.getByRole("textbox").fill(smokeQuery);
    await page.getByRole("button", { name: "Run RAG search" }).click();
    await expect(page.getByRole("heading", { name: /confidence/i })).toBeVisible({ timeout: 30_000 });

    const sourceBadge = page.getByRole("button", { name: /\d+ sources?/i });
    await expect(sourceBadge).toBeVisible();
    await sourceBadge.click();
    await expect(page.getByRole("heading", { name: "Customer document sources" })).toBeVisible();
    await expect(page.locator("#supporting-sources article").first()).toBeVisible();

    const cautionBadge = page.getByText(/\d+ cautions?/i).first();
    await expect(cautionBadge).toBeVisible();
    if (!((await cautionBadge.textContent()) ?? "").startsWith("0 ")) {
      await expect(page.getByText("Gaps / cautions")).toBeVisible();
    }

    const normalQuery = await postQuery(page, { query: smokeQuery, domains: ["stormintel"], answerType: "clear_answer", externalSearch: false });
    expect(normalQuery.status).toBe(200);
    expect(normalQuery.hasDebugTrace).toBe(false);
    expect(normalQuery.citations).toBeGreaterThan(0);

    const debugQuery = await postQuery(page, { query: smokeQuery, domains: ["stormintel"], answerType: "clear_answer", externalSearch: false, debug: true });
    expect(debugQuery.status).toBe(200);
    expect(debugQuery.hasDebugTrace).toBe(true);
    expect(debugQuery.safeForLogging).toBe(true);
    expect(debugQuery.finalChunkCount).toBeGreaterThan(0);
    expect(debugQuery.decisionTypes).toContain("answerability");

    const includeDebugQuery = await postQuery(page, { query: smokeQuery, domains: ["stormintel"], answerType: "clear_answer", externalSearch: false, includeDebug: true });
    expect(includeDebugQuery.status).toBe(200);
    expect(includeDebugQuery.hasDebugTrace).toBe(true);
    expect(includeDebugQuery.safeForLogging).toBe(true);
    expect(includeDebugQuery.finalChunkCount).toBeGreaterThan(0);

    expect(browserErrors).toEqual([]);
  });
});

async function postQuery(page: Page, payload: Record<string, unknown>) {
  return await page.evaluate(async (body) => {
    const res = await fetch("/api/query", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    return {
      status: res.status,
      hasDebugTrace: Object.prototype.hasOwnProperty.call(json, "debugTrace") && json.debugTrace !== undefined,
      citations: Array.isArray(json.citations) ? json.citations.length : 0,
      safeForLogging: json.debugTrace?.safeForLogging,
      finalChunkCount: Array.isArray(json.debugTrace?.finalChunks) ? json.debugTrace.finalChunks.length : 0,
      decisionTypes: Array.isArray(json.debugTrace?.decisions)
        ? [...new Set(json.debugTrace.decisions.map((decision: { type?: string }) => decision.type).filter(Boolean))]
        : [],
    };
  }, payload);
}
