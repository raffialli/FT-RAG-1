import { expect, test } from "@playwright/test";

test("app shell loads", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByText("Falcontrust", { exact: true })).toBeVisible();
  await expect(page.getByRole("link", { name: "Add-ons" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Admin" })).toBeVisible();
});

test("main search/RAG page loads offline", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByRole("heading", { name: /Ask Falcontrust documents a question/i })).toBeVisible();
  await expect(page.getByText("Searchable domains")).toBeVisible();
  await expect(page.getByRole("textbox")).toBeVisible();
  await expect(page.getByRole("button", { name: "Run RAG search" })).toBeVisible();
});

test("tested question pills render and fill the query box", async ({ page }) => {
  const prompts = [
    "What is FEMA’s Ready campaign and what are its three key components?",
    "Should emergency managers accept a contractor's standard document as-is to save time?",
    "Which clauses should emergency managers watch for in contractor standard contracts?",
    "In Japan's five-level flood warning system, what should elderly and disabled residents do at Level 3?",
  ];

  await page.goto("/");

  await expect(page.getByText("Try a tested question")).toBeVisible();
  for (const prompt of prompts) {
    await expect(page.getByRole("button", { name: prompt })).toBeVisible();
  }

  await page.getByRole("button", { name: prompts[1] }).click();
  await expect(page.getByRole("textbox")).toHaveValue(prompts[1]);
});

test("basic query UI renders and submits with an offline API response", async ({ page }) => {
  await page.route("**/api/query", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockQueryResponse()),
    });
  });

  await page.goto("/");
  await page.getByRole("textbox").fill("What should residents know before a flood?");
  await page.getByRole("button", { name: "Run RAG search" }).click();

  await expect(page.getByRole("heading", { name: "Medium confidence" })).toBeVisible();
  await expect(page.getByText("Use the verified pickup rules and limits.")).toBeVisible();
});

test("citation/source and caution areas render without live secrets", async ({ page }) => {
  await page.route("**/api/query", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockQueryResponse()),
    });
  });

  await page.goto("/");
  await page.getByRole("textbox").fill("Show the source-backed flood guidance.");
  await page.getByRole("button", { name: "Run RAG search" }).click();

  await page.getByRole("button", { name: /1 source/i }).click();
  await expect(page.getByRole("heading", { name: "Customer document sources" })).toBeVisible();
  await expect(page.getByText("Flood Preparedness Memo")).toBeVisible();
  await expect(page.getByText("Gaps / cautions")).toBeVisible();
  await page.getByText("Gaps / cautions").click();
  await expect(page.getByText("Verify current policy before publication.")).toBeVisible();
});

test("answer sections render document evidence separately from general guidance", async ({ page }) => {
  await page.route("**/api/query", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockQueryResponse()),
    });
  });

  await page.goto("/");
  await page.getByRole("textbox").fill("Separate evidence from guidance.");
  await page.getByRole("button", { name: "Run RAG search" }).click();

  await expect(page.getByRole("heading", { name: "Document-supported evidence" })).toBeVisible();
  await expect(page.getByRole("listitem").filter({ hasText: "Residents should follow official pickup windows and household limits." })).toBeVisible();
  await expect(page.getByRole("heading", { name: "General guidance" })).toBeVisible();
  await expect(page.getByText("Confirm dates and policy details before publishing.")).toBeVisible();
});

test("query API returns answer sections that separate evidence from guidance", async ({ request }) => {
  const response = await request.post("/api/query", {
    data: {
      query: "What should residents know about sandbag pickup rules?",
      domains: ["sandbags"],
      answerType: "clear_answer",
    },
  });

  expect(response.ok()).toBeTruthy();
  const body = await response.json();

  expect(body.answerSections?.answer).toEqual(expect.any(String));
  expect(Array.isArray(body.answerSections?.documentSupportedClaims)).toBe(true);
  expect(body.answerSections.documentSupportedClaims.length).toBeGreaterThan(0);
  expect(Array.isArray(body.answerSections?.generalGuidance)).toBe(true);
  expect(body.answerSections.generalGuidance.length).toBeGreaterThan(0);
  expect(body.answerSections.generalGuidance.join(" ")).toMatch(/publication|guarantee|guidance/i);
});

test("debug query mode returns offline-safe retrieval trace", async ({ request }) => {
  const response = await request.post("/api/query", {
    data: {
      query: "What should residents know about sandbag pickup rules?",
      domains: ["sandbags"],
      debug: true,
    },
  });

  expect(response.ok()).toBeTruthy();
  const body = await response.json();

  expect(body.debugTrace).toBeTruthy();
  expect(body.debugTrace.safeForLogging).toBe(true);
  expect(body.debugTrace.candidateCount).toBeGreaterThan(0);
  expect(body.debugTrace.finalChunks.length).toBeGreaterThan(0);
  expect(body.debugTrace.finalChunks[0]).toEqual(expect.objectContaining({
    chunkId: expect.any(String),
    documentId: expect.any(String),
    score: expect.any(Number),
    textPreview: expect.any(String),
    metadata: expect.any(Object),
    selected: true,
  }));
  expect(body.debugTrace.decisions.some((decision: { type: string }) => decision.type === "answerability")).toBe(true);
});

test("admin upload refreshes document status while large upload is still pending", async ({ page }) => {
  let uploadStarted = false;
  let uploadCompleted = false;

  await page.route("**/api/corpus**", async (route) => {
    const uploadState = uploadStarted && !uploadCompleted ? "indexing" : uploadCompleted ? "indexed" : "none";
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockAdminCorpus(uploadState)),
    });
  });
  await page.route("**/api/admin/history", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ sessions: [] }) });
  });
  await page.route("**/api/admin/article-config", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ config: mockArticleConfig() }) });
  });
  await page.route("**/api/admin/embeddings**", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ status: mockEmbeddingStatus(uploadStarted ? "indexed" : "none") }) });
  });
  await page.route("**/api/upload", async (route) => {
    uploadStarted = true;
    await new Promise((resolve) => setTimeout(resolve, 7000));
    uploadCompleted = true;
    await route.fulfill({
      status: 201,
      contentType: "application/json",
      body: JSON.stringify({
        document: {
          id: "law-upload-large-review",
          title: "Large Review Upload",
          domain: "law",
          source: "uploaded",
          sourceFileName: "large-review.pdf",
          uploadedAt: "2026-06-01T13:40:43.789Z",
        },
        indexing: { status: "completed", embeddingStatus: mockEmbeddingStatus("indexed") },
      }),
    });
  });

  await page.goto("/admin");
  await expect(page.getByText("Existing Review Memo")).toBeVisible();

  await page.locator('input[type="file"]').setInputFiles({
    name: "large-review.pdf",
    mimeType: "application/pdf",
    buffer: Buffer.from("%PDF-1.4\nlarge review upload"),
  });
  await page.getByRole("button", { name: "Upload and index PDF" }).click();

  await expect(page.getByText("Large Review Upload")).toBeVisible({ timeout: 6000 });
  await expect(page.getByText("Indexing in progress")).toBeVisible();
  await expect(page.getByText(/indexing 0\/178 chunks/)).toBeVisible();
  expect(uploadCompleted).toBe(false);

  await expect(page.getByText(/Document and vector counters have settled/)).toBeVisible({ timeout: 10000 });
  await expect(page.getByText("Indexed", { exact: true }).nth(1)).toBeVisible();
  expect(uploadCompleted).toBe(true);
});

test("admin upload interruption keeps polling and clears warning when indexing settles", async ({ page }) => {
  let uploadStarted = false;
  let corpusCallsAfterUpload = 0;

  await page.route("**/api/corpus**", async (route) => {
    let uploadState: UploadMockState = "none";
    if (uploadStarted) {
      corpusCallsAfterUpload += 1;
      uploadState = corpusCallsAfterUpload >= 4 ? "indexed" : "indexing";
    }
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockAdminCorpus(uploadState)),
    });
  });
  await page.route("**/api/admin/history", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ sessions: [] }) });
  });
  await page.route("**/api/admin/article-config", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ config: mockArticleConfig() }) });
  });
  await page.route("**/api/admin/embeddings**", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ status: mockEmbeddingStatus(uploadStarted && corpusCallsAfterUpload >= 4 ? "indexed" : "none") }) });
  });
  await page.route("**/api/upload", async (route) => {
    uploadStarted = true;
    await route.abort("failed");
  });

  await page.goto("/admin");
  await page.locator('input[type="file"]').setInputFiles({
    name: "large-review.pdf",
    mimeType: "application/pdf",
    buffer: Buffer.from("%PDF-1.4\nlarge review upload"),
  });
  await page.getByRole("button", { name: "Upload and index PDF" }).click();

  await expect(page.getByText("Large Review Upload")).toBeVisible({ timeout: 6000 });
  await expect(page.getByText("Indexing in progress")).toBeVisible();
  await expect(page.getByText(/backend counters have settled/i)).toBeVisible({ timeout: 12000 });
  await expect(page.getByText(/blindly retry/i)).toBeHidden();
});

test("admin surfaces vector mismatches and dry-run reindex diagnostics copy", async ({ page }) => {
  await page.route("**/api/corpus**", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockAdminCorpus("mismatch")),
    });
  });
  await page.route("**/api/admin/history", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ sessions: [] }) });
  });
  await page.route("**/api/admin/article-config", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ config: mockArticleConfig() }) });
  });
  await page.route("**/api/admin/embeddings**", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ status: mockEmbeddingStatus("mismatch") }) });
  });

  await page.goto("/admin");

  await expect(page.getByText("Indexed + extra vectors")).toBeVisible();
  await expect(page.getByText(/active vectors 210; canonical chunks 178/)).toBeVisible();
  await expect(page.getByText(/Active vector records can differ from canonical corpus chunks/)).toBeVisible();
  await expect(page.getByText(/dry-run diagnostics only/i)).toBeVisible();
  await expect(page.getByText(/does not embed, write vectors, or repair missing chunks/i)).toBeVisible();
});

test("admin leaves incomplete document indexed status in progress instead of needs index", async ({ page }) => {
  await page.route("**/api/corpus**", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify(mockAdminCorpus("indexing")),
    });
  });
  await page.route("**/api/admin/history", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ sessions: [] }) });
  });
  await page.route("**/api/admin/article-config", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ config: mockArticleConfig() }) });
  });
  await page.route("**/api/admin/embeddings**", async (route) => {
    await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ status: mockEmbeddingStatus("none") }) });
  });

  await page.goto("/admin");

  await expect(page.getByText("Indexing in progress")).toBeVisible();
  await expect(page.getByText(/indexing 0\/178 chunks/)).toBeVisible();
  await expect(page.getByText("Needs index")).toBeHidden();
});

function mockQueryResponse() {
  return {
    id: "offline-playwright-smoke",
    query: "What should residents know before a flood?",
    selectedDomains: ["law", "sandbags"],
    externalSearch: false,
    externalSearchEnabled: false,
    answerType: "clear_answer",
    answer: "Use the verified pickup rules and limits.",
    answerSections: {
      answer: "Use the verified pickup rules and limits.",
      documentSupportedClaims: ["Residents should follow official pickup windows and household limits."],
      generalGuidance: ["Confirm dates and policy details before publishing."],
      gaps: ["Verify current policy before publication."],
    },
    confidence: "Medium",
    citations: [
      {
        documentId: "flood-preparedness",
        title: "Flood Preparedness Memo",
        domain: "sandbags",
        snippet: "Residents should follow official pickup windows and household limits.",
        score: 0.64,
        chunkId: "flood-preparedness-1",
        chunkIndex: 1,
        viewerUrl: "/documents?doc=flood-preparedness&chunk=flood-preparedness-1",
      },
    ],
    generatedBy: "template",
    createdAt: "2026-05-28T00:00:00.000Z",
    gaps: ["Verify current policy before publication."],
  };
}

type UploadMockState = "none" | "indexing" | "indexed" | "mismatch";

function mockAdminCorpus(uploadState: UploadMockState) {
  const documents = [
    {
      id: "law-existing-review",
      title: "Existing Review Memo",
      domain: "law",
      path: "uploads/law/law-existing-review.json",
      source: "uploaded",
      sourceFileName: "existing-review.pdf",
      uploadedAt: "2026-06-01T12:00:00.000Z",
      canDelete: true,
      chunkCount: 3,
      canonicalChunkCount: 3,
      indexedChunkCount: 3,
      indexed: true,
    },
  ];
  if (uploadState !== "none") {
    const indexedChunkCount = uploadState === "indexing" ? 0 : uploadState === "mismatch" ? 210 : 178;
    documents.push({
      id: "law-upload-large-review",
      title: "Large Review Upload",
      domain: "law",
      path: "uploads/law/law-upload-large-review.json",
      source: "uploaded",
      sourceFileName: "large-review.pdf",
      uploadedAt: "2026-06-01T13:40:43.789Z",
      canDelete: true,
      chunkCount: indexedChunkCount || 178,
      canonicalChunkCount: 178,
      indexedChunkCount,
      indexed: uploadState !== "indexing",
    });
  }

  const chunkCount = documents.reduce((sum, document) => sum + (document.canonicalChunkCount ?? document.chunkCount), 0);
  return {
    domains: [{ id: "law", name: "Law", description: "Legal review documents." }],
    documents,
    inventory: {
      backend: "bedrock-s3-vector",
      documentCount: documents.length,
      chunkCount,
      namespace: "vectors/test-vector-index.json",
    },
  };
}

function mockEmbeddingStatus(uploadState: UploadMockState) {
  const chunkCount = uploadState === "none" ? 3 : uploadState === "mismatch" ? 213 : 181;
  return {
    config: { provider: "bedrock", region: "us-east-2", model: "amazon.titan-embed-text-v2:0", enabled: true },
    vectorStore: "s3-json",
    indexPath: "s3://test/vectors/test-vector-index.json",
    chunkCount,
    vectorCount: chunkCount,
    staleCount: 0,
    lastIndexedAt: "2026-06-01T13:42:43.804Z",
    ready: true,
    backend: "bedrock-s3-vector",
    activeIndexKey: "vectors/test-vector-index.json",
    displayMode: "active-backend",
  };
}

function mockArticleConfig() {
  return {
    provider: "ollama",
    endpoint: "https://placeholder.invalid",
    model: "qwen3.5:35b-a3b",
    apiKeyConfigured: false,
    apiKeyMasked: "",
    audience: "Reviewers",
    tone: "clear",
    length: "medium",
    structure: "Brief article",
    extraInstructions: "Stay grounded.",
    includeCitations: true,
  };
}
