# FalconTrust RAG Regression Harness

This directory holds offline regression contracts for FalconTrust retrieval and answer-quality issues.

The base CI suite must stay pure and non-networked:

- no AWS, Bedrock, S3, database, or API credentials;
- no customer documents or generated vector artifacts;
- deterministic fixtures only.

Optional live/cloud checks should be added as manual GitHub Actions jobs later. Expected secrets for that future path:

- AWS_ACCESS_KEY_ID
- AWS_SECRET_ACCESS_KEY
- AWS_REGION
- any app-specific read-only bucket/index identifiers needed for the live environment

Those checks should not run on ordinary pull requests until explicitly enabled.

## Fixture Layout

- `fixtures/rag-eval-cases.json` contains the initial issue #21 offline regression set.
- `regression-harness.mjs` evaluates synthetic chunks and answers without calling app APIs or cloud services.
- `regression-harness.test.mjs` asserts the fixture expectations and category coverage.
- Issue #22 also uses these fixtures to assert the stable debug trace shape needed for later remediation review.
- Issue #23 adds answerability-threshold fixtures that require cited body evidence, reject weak coincidental matches, and keep index/reference-only matches as insufficient support.

Each fixture should include:

- `id`: stable lowercase identifier used in test output.
- `category`: defect class covered by the fixture.
- `description`: short reason the fixture exists.
- `query`: user-style prompt.
- `chunks`: deterministic synthetic retrieval chunks with `id`, `kind`, and `text`.
- `answer`: synthetic current or expected answer shape.
- `expect`: harness-level assertions.
- `futureIssue`: issue number for later behavior work, or `null` when the fixture is already a baseline contract.

## Issue #21 Categories

The initial fixture set covers:

1. Answerable body-evidence case.
2. Unanswerable/no-support case.
3. Index/reference false-positive case.
4. Citation-count confidence trap.
5. Template-vs-evidence separation case.
6. OCR/layout-noise baseline fixture.

Issue #21 intentionally records current/baseline behavior where later remediation issues own the actual behavior change. Do not wire live AWS, Bedrock, S3, Tavily, customer documents, or production vector indexes into this default suite.

## Adding Future Cases

Future remediation issues should add a fixture before changing behavior. Prefer one small case per defect class, then update only the production behavior needed to make that fixture pass.

If a future expected behavior is not implemented yet, keep the fixture as baseline/current behavior or mark the future assertion as skipped/TODO in the test with a comment naming the owning issue. Do not hide behavior gaps by requiring live services in default CI.

## Debug Trace Contract

Debug traces are for reviewer/developer visibility, not customer-facing behavior. They must remain safe to log in local/dev review and include enough data to explain retrieval decisions:

- candidate chunks and final chunks are distinct;
- each chunk includes a stable id, document id, score, content type, safe text preview, source path when available, and metadata;
- decisions explain selected, filtered, and answerability outcomes;
- default CI stays offline and uses synthetic fixture data.

## Answerability Threshold Contract

Issue #23 keeps answerability separate from citation count. A response should stay low-support/gap unless the selected citations include body-like evidence that directly overlaps the query and supports the answer. Index/reference-only hits, low-score hits, and body chunks that merely share a few coincidental terms are not enough. Debug traces should make this decision visible with an answerability reason such as `supported-body-evidence`, `weak-or-unsupported-evidence`, `index-reference-only`, `weak-top-score`, or `no-citations`.
