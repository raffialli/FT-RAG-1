import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import ts from "typescript";
import test from "node:test";

let activeCitations = [];

const goldenCases = [
  {
    id: "fema-ready",
    query: "What is FEMA's Ready campaign and what are its three key components?",
    citations: () => [workshopCitation(), readyCampaignCitation(), floodWarningListCitation()],
    expected: "Customer-document answer from Kohn PDF: launch year 2003, public-awareness purpose, and the three components get a kit, make a plan, be informed. Must not use web fallback or unrelated FEWS list evidence.",
    assert: (answer, result) => {
      assert.match(answer, /2003/i);
      assert.match(answer, /increase public awareness and participation in disaster preparedness/i);
      assert.match(answer, /get a kit/i);
      assert.match(answer, /make a plan/i);
      assert.match(answer, /be informed/i);
      assert.doesNotMatch(answer, /detection; forecasting; warning/i);
      assert.ok(result.citations.length > 0);
      assert.ok(result.citations.every((citation) => citation.title !== "Flood Risk Management Global Case Studies"));
      assert.doesNotMatch(result.citations.map((citation) => citation.snippet).join(" "), /detection, forecasting|DOI:|Barnett, MD/i);
    },
  },
  {
    id: "jh-cphp-workshop",
    query: "What did the JH-CPHP workshop use FEMA materials for?",
    citations: () => [workshopCitation(), readyCampaignCitation()],
    expected: "Workshop answer remains grounded in adapting FEMA materials into public-health-specific context and the West Virginia Severe Flooding Tabletop.",
    assert: (answer, result) => {
      assert.match(answer, /public health-specific/i);
      assert.match(answer, /West Virginia Severe Flooding Tabletop/i);
      assert.doesNotMatch(answer, /^Components:/i);
      assert.ok(result.citations.length > 0);
      assert.ok(result.citations.every((citation) => citation.title === "Personal Preparedness Curriculum for Public Health Workers"));
    },
  },
  {
    id: "nearby-workshop-overfit",
    query: "Did the West Virginia workshop mainly teach Ready components, or adapt FEMA materials for public health responders?",
    citations: () => [workshopCitation(), readyCampaignCitation()],
    expected: "Nearby workshop-vs-Ready query should not collapse into the Ready components list.",
    assert: (answer) => {
      assert.match(answer, /public health-specific|West Virginia Severe Flooding Tabletop|adapted existing FEMA/i);
      assert.doesNotMatch(answer, /^Components:/i);
      assert.doesNotMatch(answer, /get a kit; make a plan; be informed/i);
    },
  },
  {
    id: "japan-level-3",
    query: "In Japan's flood warning system, what does Level 3 mean and who should evacuate then?",
    citations: () => [japanWarningCitation()],
    expected: "Known-good Japan warning answer: Level 3 means elderly/disabled evacuate while others prepare.",
    assert: (answer) => {
      assert.match(answer, /Level 3/i);
      assert.match(answer, /elderly|aged/i);
      assert.match(answer, /disabled/i);
      assert.match(answer, /evacuat/i);
    },
  },
  {
    id: "jem-citizen-participation",
    query: "According to the JEM special issue article, how does disaster experience relate to citizen participation in sustainability efforts?",
    citations: () => [jemCitizenParticipationCitation()],
    expected: "Known-good JEM answer: disaster experience is significant to increasing reported citizen-participation impact on sustainability efforts.",
    assert: (answer) => {
      assert.match(answer, /^The article says increased disaster experience is significant/i);
      assert.match(answer, /disaster experience/i);
      assert.match(answer, /citizen participation/i);
      assert.match(answer, /sustainability/i);
    },
  },
  {
    id: "jem-citizen-participation-visible-readability",
    query: "What does the JEM 2024 Special Issue say about citizen participation?",
    citations: () => [jemCitizenParticipationOcrCitation()],
    expected: "Human-visible answer should be readable, not repetitive, and confidence should not remain High when the source evidence has OCR hyphenation artifacts.",
    assert: (answer, result) => {
      assert.match(answer, /citizen participation/i);
      assert.match(answer, /sustainability efforts/i);
      assert.doesNotMatch(answer, /citi-\s*zen/i);
      assert.doesNotMatch(answer, /implemen-\s*tation/i);
      assert.doesNotMatch(answer, /sustain-\s*ability/i);
      assert.doesNotMatch(answer, /statisti-\s*cally/i);
      assert.doesNotMatch(answer, /\b(citizen participation)(?:\s+\1\b)+/i);
      assert.notEqual(result.confidence, "High");
      assert.equal(result.citations[0]?.sourceFileName, "JEM 2024 Special Issue.pdf");
      assert.match(result.citations[0]?.snippet ?? "", /citizen participation/i);
      assert.doesNotMatch(result.citations[0]?.snippet ?? "", /citi-\s*zen|sustain-\s*ability|statisti-\s*cally/i);
      assert.doesNotMatch(result.gaps.join(" "), /source-ocr-hyphenation/i);
    },
  },
  {
    id: "jem-citizen-participation-citation-number-cleanup",
    query: "What does the JEM 2024 Special Issue say about citizen participation?",
    citations: () => [jemCitizenParticipationCitationNumberCitation(), jemCitizenParticipationOcrCitation()],
    expected: "Author/citation-number artifacts such as Kinzer28 should not appear in the final answer or visible source snippets.",
    assert: (answer, result) => {
      assert.match(answer, /citizen participation/i);
      assert.doesNotMatch(answer, /Kinzer28|kinzer28/i);
      assert.ok(result.citations.length > 0);
      assert.match(result.citations[0]?.snippet ?? "", /public participation|citizen participation/i);
      assert.doesNotMatch(result.citations.map((citation) => citation.snippet).join(" "), /Kinzer28|kinzer28|citi-\s*zen|sustain-\s*ability/i);
    },
  },
  {
    id: "jem-special-issue-frontmatter-cleanup",
    query: "What is the JEM 2024 Special Issue about, and why are emergency managers connected to climate change and sustainability?",
    citations: () => [jemCoverAdCitation(), jemClimateBodyCitation()],
    expected: "The JEM theme answer should use body evidence about climate/sustainability and emergency management, not cover/ad/frontmatter residue.",
    assert: (answer) => {
      assert.match(answer, /^The special issue is about climate change and sustainability in emergency management/i);
      assert.match(answer, /climate change/i);
      assert.match(answer, /sustainability/i);
      assert.match(answer, /emergency managers/i);
      assert.match(answer, /adaptive capacity|long-term environmental stewardship|equity|social justice/i);
      assert.doesNotMatch(answer, /UPLOADED DEMO PDF/i);
      assert.doesNotMatch(answer, /Deloitte/i);
      assert.doesNotMatch(answer, /ISSN/i);
      assert.doesNotMatch(answer, /Journalof __/i);
    },
  },
  {
    id: "jem-deloitte-frontmatter-cleanup",
    query: "What does the JEM special issue say about Deloitte climate action?",
    citations: () => [jemCoverAdCitation(), jemEditorialBoardCitation(), jemClimateBodyCitation()],
    expected: "A Deloitte/frontmatter query may cite the ad copy narrowly, but must not swallow cover, page, or editorial-board residue.",
    assert: (answer) => {
      assert.match(answer, /frontmatter\/advertising copy/i);
      assert.match(answer, /Deloitte/i);
      assert.match(answer, /climate resilience planning|mitigate climate change impacts|climate-resilient future/i);
      assert.doesNotMatch(answer, /UPLOADED DEMO PDF/i);
      assert.doesNotMatch(answer, /JEM EDITORIAL BOARD/i);
      assert.doesNotMatch(answer, /C\\. Ryan Akers/i);
      assert.doesNotMatch(answer, /ISSN/i);
    },
  },
  {
    id: "sandbags-overclaim",
    query: "Do sandbags prevent all flood damage?",
    citations: () => [sandbagLimitCitation()],
    expected: "Known-good cautious answer: do not claim sandbags prevent all damage; no web fallback needed.",
    assert: (answer, result) => {
      assert.match(answer, /^No\./i);
      assert.match(answer, /do not guarantee|does not guarantee/i);
      assert.match(answer, /minor water intrusion|deep flooding|structural damage/i);
      assert.ok(result.citations.length > 0);
      assert.match(result.citations[0]?.snippet ?? "", /do not guarantee|minor water intrusion|deep flooding|structural damage/i);
    },
  },
  {
    id: "contract-terms",
    query: "What contract terms should emergency managers scrutinize in standardized vendor contracts?",
    citations: () => [contractTermsCitation(), ordinanceCitation()],
    expected: "Contract review answer should identify standard-language risk terms from body evidence, not local ordinance duties.",
    assert: (answer, result) => {
      assert.match(answer, /indemnification/i);
      assert.match(answer, /waivers?/i);
      assert.match(answer, /arbitration/i);
      assert.match(answer, /contrary to state or local law/i);
      assert.match(answer, /performance standards/i);
      assert.doesNotMatch(answer, /local line of succession/i);
      assert.ok(result.citations.length > 0);
      assert.doesNotMatch(result.citations.map((citation) => citation.snippet).join(" "), /local line of succession/i);
    },
  },
  {
    id: "contractor-standard-document-as-is",
    query: "Should emergency managers accept a contractor's standard document as-is to save time?",
    citations: () => [ordinanceCitation(), contractTermsCitation()],
    expected: "As-is contractor document answer should say no and cite review/delete/modify cautionary evidence.",
    assert: (answer, result) => {
      assert.match(answer, /^No\./i);
      assert.match(answer, /less work/i);
      assert.match(answer, /carefully review|careful/i);
      assert.match(answer, /delete unacceptable language|modify standard language|modified/i);
      assert.doesNotMatch(answer, /local line of succession/i);
      assert.ok(result.citations.length > 0);
      assert.doesNotMatch(result.citations.map((citation) => citation.snippet).join(" "), /local line of succession/i);
    },
  },
  {
    id: "copyright-boilerplate-source-snippet-cleanup",
    query: "In Japan's flood warning system, what does Level 3 mean and who should evacuate then?",
    citations: () => [japanCopyrightBoilerplateCitation(), japanWarningCitation()],
    expected: "Copyright/frontmatter boilerplate should not be the visible source snippet when the same evidence contains an answer-bearing sentence.",
    assert: (answer, result) => {
      assert.match(answer, /Level 3/i);
      assert.ok(result.citations.length > 0);
      assert.match(result.citations[0]?.snippet ?? "", /Level 3|elderly|disabled|evacuat/i);
      assert.doesNotMatch(result.citations.map((citation) => citation.snippet).join(" "), /copyright\.com|Please visit/i);
    },
  },
];

async function loadRetrievalModule() {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");
  const output = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      esModuleInterop: true,
    },
  }).outputText;
  const cjsModule = { exports: {} };
  const sandbox = {
    module: cjsModule,
    exports: cjsModule.exports,
    process: { env: {} },
    require: (id) => {
      if (id !== "./retrieval-backends") throw new Error(`Unexpected require: ${id}`);
      return {
        getRetrievalBackend: () => ({
          id: "qa-golden-fixture",
          retrieve: async () => ({
            citations: activeCitations,
            trace: {
              backend: "qa-golden-fixture",
              selectedDomains: ["sandbags"],
              citationCount: activeCitations.length,
              documentIds: Array.from(new Set(activeCitations.map((citation) => citation.documentId))),
              chunkIds: activeCitations.map((citation) => citation.chunkId),
              sourcePaths: Array.from(new Set(activeCitations.map((citation) => citation.sourcePath).filter(Boolean))),
            },
            debugTrace: {
              backend: "qa-golden-fixture",
              selectedDomains: ["sandbags"],
              queryTokens: [],
              candidateCount: activeCitations.length,
              finalChunkCount: activeCitations.length,
              chunkIds: activeCitations.map((citation) => citation.chunkId),
              candidates: [],
              finalChunks: [],
              decisions: [],
              notes: ["Local golden answer-quality fixture; no web fallback."],
            },
          }),
        }),
      };
    },
  };
  vm.runInNewContext(output, sandbox, { filename: "retrieval.cjs" });
  return cjsModule.exports;
}

for (const goldenCase of goldenCases) {
  test(`answer-quality golden: ${goldenCase.id}`, async () => {
    const { buildAnswer } = await loadRetrievalModule();
    activeCitations = goldenCase.citations();

    const result = await buildAnswer(goldenCase.query, ["sandbags"], "internal_qa");

    assert.equal(result.generatedBy, "template");
    assert.equal(result.mode, "internal_qa");
    if (!goldenCase.allowNoFinalCitations) {
      assert.ok(result.citations.length > 0, goldenCase.expected);
    }
    goldenCase.assert(result.answer, result);
  });
}

function readyCampaignCitation() {
  return citation({
    chunkId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1",
    documentId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    sourcePath: "uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json",
    sourceFileName: "bdevito67,+JEM-12-1-04-Kohn.pdf",
    score: 1.15,
    text: "Barnett, MD, MPH JEM DOI:10.5055/jem.2014.0162 threats, government and response agencies have emphasized the need for personal emergency preparedness. For example, the Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities about different types of emergencies and their appropriate responses: \"get a kit, make a plan and be informed.\"",
  });
}

function workshopCitation() {
  return citation({
    chunkId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13",
    documentId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    sourcePath: "uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json",
    sourceFileName: "bdevito67,+JEM-12-1-04-Kohn.pdf",
    score: 1.1,
    text: "JH-CPHP experts adapted existing FEMA Ready content into an interactive, public health-specific, face-to-face module. JH-CPHP experts tailored existing FEMA materials into a public health-specific context and developed a scenario-based exercise called the West Virginia Severe Flooding Tabletop.",
  });
}

function floodWarningListCitation() {
  return citation({
    chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-85",
    documentId: "sandbags-upload-flood-risk-management-global-case-studies",
    title: "Flood Risk Management Global Case Studies",
    sourcePath: "uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json",
    sourceFileName: "Flood Risk Management-OCR.pdf",
    score: 0.92,
    text: "The early warning system chain aims to achieve preparedness and loss minimisation measures when a flood occurs. Parker outlines five key components of the chain: detection, forecasting and warning.",
  });
}

function japanWarningCitation() {
  return citation({
    chunkId: "japan-warning-level-3",
    title: "Current Flood Warning System in Japan and Evacuation Effectiveness",
    sourceFileName: "Flood Risk Management-OCR.pdf",
    score: 0.9,
    text: "At Level 3, elderly and disabled people are advised to evacuate, while others should prepare to evacuate.",
  });
}

function jemCitizenParticipationCitation() {
  return citation({
    chunkId: "jem-citizen-participation",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 0.88,
    text: "The findings here suggest that increased disaster experience is significant to increasing the impact that local governments report citizen participation to have on sustainability efforts.",
  });
}

function jemCitizenParticipationOcrCitation() {
  return citation({
    chunkId: "law-upload-1780321243789-jem-2024-special-issue-chunk-72",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 0.91,
    text: "Public participation and citizen participation are discussed as implementation mechanisms for sustainability efforts. The findings here suggest that increased disaster experience is statisti- cally significant to increasing the impact that local governments report citi- zen participation to have on sustain- ability efforts. Citizen participation citizen participation can shape implemen- tation, but the article text repeats citizen participation in this OCR chunk.",
  });
}

function jemCitizenParticipationCitationNumberCitation() {
  return citation({
    chunkId: "law-upload-1780321243789-jem-2024-special-issue-chunk-71",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 0.94,
    text: "Kinzer28 finds that public participation, through the form of a citizen advisory committee, does have a positive impact on sustainability outcomes during implementation. However, Kinzer28 also notes that the effect depends on implementation context rather than the mere presence or absence of citizen participation.",
  });
}

function japanCopyrightBoilerplateCitation() {
  return citation({
    chunkId: "japan-warning-level-3-copyright",
    title: "Current Flood Warning System in Japan and Evacuation Effectiveness",
    sourceFileName: "bdevito67,+JEM_21-1-04-Huang.pdf",
    score: 1.1,
    text: "Please visit www.copyright.com for additional licensing options. In the system, Level 1 is an early warning issued by the JMA for the possibility of heavy rain. Level 2 warning is also issued by the JMA for heavy rain and flooding alert. Level 3 indicates that danger is approaching, and elderly and disabled people are advised to evacuate while others prepare to evacuate.",
  });
}

function jemCoverAdCitation() {
  return citation({
    chunkId: "law-upload-1780321243789-jem-2024-special-issue-chunk-1",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 1.2,
    text: "# UPLOADED DEMO PDF — JEM 2024 Special Issue ® Volume 21, Number 7 ISSN 1543-5865 SPECIAL ISSUE Climate Change and Sustainability in Emergency Management Research and Applied Science in a Changing World Journalof __ EMERGENCY MANAGEME --- Page 1 of 126 --- --- Page 2 of 126 --- Now is the time for climate action. The United States is facing a climate crisis that requires a whole-of-society approach. Deloitte's knowledge and tools support organizations' climate resilience planning, governing, finance, implementation, and performance monitoring processes—to quickly and effectively mitigate climate change impacts and help to support a climate-resilient future for all. Visit our website to learn how your organization can take action. www.deloitte.com/us/sustainable-future Copyright © 2023 Deloitte Development LLC. All rights reserved.",
  });
}

function jemEditorialBoardCitation() {
  return citation({
    chunkId: "law-upload-1780321243789-jem-2024-special-issue-chunk-3",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 1.1,
    text: "--- Page 4 of 126 --- JEM EDITORIAL BOARD C. Ryan Akers, PhD Associate Extension Professor, Community Preparedness and Disaster Management; MyPI National, Project Director; Mississippi State University Extension Starkville, Mississippi Barbara Audley, DPA Western Washington University (Ret.), Bellingham, Washington.",
  });
}

function jemClimateBodyCitation() {
  return citation({
    chunkId: "law-upload-1780321243789-jem-2024-special-issue-chunk-8",
    documentId: "law-upload-1780321243789-jem-2024-special-issue",
    title: "JEM 2024 Special Issue",
    domain: "law",
    sourcePath: "uploads/law/law-upload-1780321243789-jem-2024-special-issue.json",
    sourceFileName: "JEM 2024 Special Issue.pdf",
    score: 1.0,
    text: "Special Issue on Climate Change and Sustainability in Emergency Management. Dear Reader: We are excited to bring forth this special issue titled Climate Change and Sustainability in Emergency Management. By adopting a proactive and holistic approach to sustainability, emergency managers can minimize the likelihood and severity of climate-induced disasters while promoting long-term environmental stewardship. Furthermore, emergency managers must prioritize equity and social justice in climate change adaptation and mitigation efforts to ensure that vulnerable communities are not disproportionately impacted.",
  });
}

function sandbagLimitCitation() {
  return citation({
    chunkId: "sandbag-limits",
    title: "Sandbag Use Guidance",
    score: 0.78,
    text: "Sandbags may help reduce minor water intrusion when placed correctly, but they do not guarantee complete protection from deep flooding or structural damage.",
  });
}

function contractTermsCitation() {
  return citation({
    chunkId: "law-upload-legal-duties-and-emergency-management-contracts-chunk-3",
    documentId: "law-upload-legal-duties-and-emergency-management-contracts",
    title: "Legal Duties and Emergency Management Contracts",
    domain: "law",
    sourcePath: "uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json",
    sourceFileName: "Legal Duties and Emergency Management Contracts.pdf",
    score: 0.9,
    text: "Sometimes, the contract officer will be tempted to use the contractor's document as is, because it means less work for that busy individual. One must be extremely careful in reviewing such texts and be ready to delete unacceptable language. These documents are often worded to contain indemnification requirements, waivers of inadequate performance, arbitration clauses, and other language that dilutes the obligations of the contractor. They may also include requirements that are contrary to state or local law. The emergency manager and attorney should carefully scrutinize the contents of standardized contracts. Modification of standard language is often in order. Performance standards are one key part of drafting a contract.",
  });
}

function ordinanceCitation() {
  return citation({
    chunkId: "law-upload-legal-duties-and-emergency-management-contracts-chunk-2",
    documentId: "law-upload-legal-duties-and-emergency-management-contracts",
    title: "Legal Duties and Emergency Management Contracts",
    domain: "law",
    sourcePath: "uploads/law/law-upload-legal-duties-and-emergency-management-contracts.json",
    sourceFileName: "Legal Duties and Emergency Management Contracts.pdf",
    score: 1.1,
    text: "The local emergency manager is obliged to understand and obey all relevant local ordinances related to his or her functions. The ordinance creates a structure for governmental emergency management activities, delineates the local line of succession, specifies grants of emergency authority, and provides a structure for emergency management activities.",
  });
}

function citation(input) {
  const documentId = input.documentId ?? "qa-fixture-document";
  const domain = input.domain ?? "sandbags";
  const sourcePath = input.sourcePath ?? `uploads/${domain}/qa-fixture-document.json`;
  return {
    documentId,
    title: input.title ?? "QA Fixture Document",
    domain,
    snippet: input.text.slice(0, 260),
    score: input.score,
    chunkId: input.chunkId,
    chunkIndex: 0,
    sourcePath,
    sourceFileName: input.sourceFileName ?? "qa-fixture.pdf",
    contentType: "body",
    text: input.text,
    metadata: {
      chunkId: input.chunkId,
      chunkIndex: 0,
      contentType: "body",
      documentId,
      domain,
      sourceFileName: input.sourceFileName ?? "qa-fixture.pdf",
      sourcePath,
      title: input.title ?? "QA Fixture Document",
    },
  };
}
