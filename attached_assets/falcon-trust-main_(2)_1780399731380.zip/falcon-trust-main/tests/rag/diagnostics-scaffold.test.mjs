import assert from "node:assert/strict";
import { existsSync, readFileSync, rmSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { spawn, spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, "..", "..");
const fixturePath = join(__dirname, "fixtures", "rag-diagnostics-queries.json");

test("issue #37 golden query fixture covers required baseline categories", () => {
  const queries = JSON.parse(readFileSync(fixturePath, "utf8"));
  const categories = new Set(queries.map((query) => query.category));
  const ids = new Set(queries.map((query) => query.id));

  assert.ok(queries.length >= 20 && queries.length <= 30, `expected 20-30 queries, got ${queries.length}`);
  for (const category of ["supported", "weakly-supported", "unsupported", "ocr-heavy", "reference-leakage", "frontmatter-leakage", "chunk-readability"]) {
    assert.ok(categories.has(category), `missing category ${category}`);
  }
  for (const id of ["mobile-warning-artifact", "sandbags-prevent-all-damage", "sandbag-pickup-rules", "fews-mobile-warning", "legal-public-claims-sandbags"]) {
    assert.ok(ids.has(id), `missing required query ${id}`);
  }
});

test("issue #37 diagnostics command writes offline JSON and Markdown reports", () => {
  const outputDir = join(repoRoot, "reports", "rag-diagnostics-test");
  rmSync(outputDir, { recursive: true, force: true });

  const result = spawnSync(process.execPath, ["scripts/rag-diagnostics.mjs"], {
    cwd: repoRoot,
    env: diagnosticsEnv({
      FALCON_RAG_DIAGNOSTICS_MODE: "offline",
      FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR: outputDir,
    }),
    encoding: "utf8",
  });

  assert.equal(result.status, 0, result.stderr || result.stdout);
  const jsonPath = join(outputDir, "baseline.json");
  const markdownPath = join(outputDir, "baseline.md");
  assert.equal(existsSync(jsonPath), true);
  assert.equal(existsSync(markdownPath), true);

  const report = JSON.parse(readFileSync(jsonPath, "utf8"));
  assert.equal(report.mode, "offline");
  assert.ok(report.queryCount >= 20);
  assert.equal(report.ragas.enabled, false);
  assert.equal(report.ragas.status, "disabled");
  assert.ok(report.knownArtifactCases.some((query) => query.id === "mobile-warning-artifact"));
  assert.deepEqual(report.fixtureDiagnostics.filter((item) => item.failureClasses.length).map((item) => item.id), []);
  assert.ok(existsSync(join(outputDir, "latest-offline.json")));
  assert.ok(readFileSync(markdownPath, "utf8").includes("Recommended Work Buckets"));
});

test("issue #39 live diagnostics mode captures query evidence and classifications", async () => {
  const outputDir = join(repoRoot, "reports", "rag-diagnostics-test-live");
  rmSync(outputDir, { recursive: true, force: true });

  const server = await startMockQueryServer();
  try {
    const result = await spawnNode(["scripts/rag-diagnostics.mjs"], {
      cwd: repoRoot,
      env: diagnosticsEnv({
        FALCON_RAG_DIAGNOSTICS_MODE: "live",
        FALCON_RAG_DIAGNOSTICS_LIVE_URL: server.url,
        FALCON_RAG_DIAGNOSTICS_ENV: "mock",
        FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR: outputDir,
        FALCON_RAG_DIAGNOSTICS_TIMEOUT_MS: "5000",
      }),
    });

    assert.equal(result.status, 0, result.stderr || result.stdout);
    const report = JSON.parse(readFileSync(join(outputDir, "baseline.json"), "utf8"));
    assert.equal(report.mode, "live");
    assert.equal(report.liveDiagnostics.results.length, 25);
    assert.equal(report.liveDiagnostics.aggregate.total, 25);
    assert.ok(report.liveDiagnostics.aggregate.byFailureClass.source_chunk_ocr_layout >= 1);
    assert.ok(report.liveDiagnostics.aggregate.byFailureClass.confidence_calibration >= 1);
    assert.ok(report.liveDiagnostics.aggregate.byFailureClass.unsupported_gap_missing >= 1);

    const artifact = report.liveDiagnostics.results.find((item) => item.id === "mobile-warning-artifact");
    assert.ok(artifact);
    assert.equal(artifact.sessionId, "mock-mobile-warning-artifact");
    assert.equal(artifact.correlation.requestId, "mock-request-mobile-warning-artifact");
    assert.ok(artifact.citations.some((citation) => citation.chunkId === "sandbags-upload-flood-risk-management-global-case-studies-chunk-90"));
    assert.equal(artifact.citations[0].contentType, "body");
    assert.equal(artifact.citations[0].sourcePath, "mock/source.pdf");
    assert.equal(artifact.citations[0].metadata.documentId, "sandbags-upload-flood-risk-management-global-case-studies");
    assert.equal(artifact.citations[0].metadata.chunkIndex, 89);
    assert.equal(artifact.citations[0].metadata.contentType, "body");
    assert.deepEqual(artifact.evidenceHealth.citationHealth[0].missingMetadata, []);
    assert.ok(artifact.failureClasses.includes("source_chunk_ocr_layout"));

    const unsupported = report.liveDiagnostics.results.find((item) => item.id === "sandbags-prevent-all-damage");
    assert.equal(unsupported.failureClasses.includes("unsupported_gap_missing"), false);
    assert.equal(unsupported.confidence, "Medium");
    assert.equal(unsupported.citations.length, 1);

    const hazus = report.liveDiagnostics.results.find((item) => item.id === "hazus-flood-loss-model");
    assert.ok(hazus);
    assert.equal(hazus.failureClasses.includes("source_chunk_ocr_layout"), false);
    assert.equal(hazus.failureClasses.includes("reference_frontmatter_leakage"), false);
    assert.equal(hazus.citations[0].flags.badSentenceEnding, true);
    assert.equal(hazus.citations[0].flags.frontmatterLeakage, false);

    const metadata = report.liveDiagnostics.results.find((item) => item.id === "metadata-source-display");
    assert.ok(metadata);
    assert.equal(metadata.failureClasses.includes("source_chunk_ocr_layout"), false);
    assert.equal(metadata.citations[0].flags.continuationStart, false);
    assert.equal(metadata.citations[1].flags.continuationStart, false);
    assert.equal(report.ragas.enabled, false);
  } finally {
    await server.close();
  }
});

test("issue #39 offline diagnostics test is isolated from parent live env", () => {
  const outputDir = join(repoRoot, "reports", "rag-diagnostics-test-contaminated-parent");
  rmSync(outputDir, { recursive: true, force: true });

  const contaminatedParentEnv = {
    ...process.env,
    FALCON_RAG_DIAGNOSTICS_MODE: "live",
    FALCON_RAG_DIAGNOSTICS_LIVE_URL: "http://127.0.0.1:1",
    FALCON_RAG_DIAGNOSTICS_APP_PASSWORD: "do-not-use",
    FALCON_RAG_DIAGNOSTICS_COOKIE: "do-not-use",
    FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR: join(repoRoot, "reports", "rag-diagnostics-wrong-dir"),
  };
  const result = spawnSync(process.execPath, ["scripts/rag-diagnostics.mjs"], {
    cwd: repoRoot,
    env: diagnosticsEnv({
      FALCON_RAG_DIAGNOSTICS_MODE: "offline",
      FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR: outputDir,
    }, contaminatedParentEnv),
    encoding: "utf8",
  });

  assert.equal(result.status, 0, result.stderr || result.stdout);
  const report = JSON.parse(readFileSync(join(outputDir, "baseline.json"), "utf8"));
  assert.equal(report.mode, "offline");
  assert.equal(report.endpoint, null);
  assert.equal(existsSync(join(outputDir, "latest-offline.json")), true);
});

function diagnosticsEnv(overrides, baseEnv = process.env) {
  const env = { ...baseEnv };
  for (const key of [
    "FALCON_RAG_DIAGNOSTICS_MODE",
    "FALCON_RAG_DIAGNOSTICS_LIVE_URL",
    "FALCON_RAG_DIAGNOSTICS_APP_PASSWORD",
    "FALCON_RAG_DIAGNOSTICS_COOKIE",
    "FALCON_RAG_DIAGNOSTICS_REPORT_DIR",
    "FALCON_RAG_DIAGNOSTICS_OUTPUT_DIR",
    "FALCON_RAG_DIAGNOSTICS_ENV",
    "FALCON_RAG_DIAGNOSTICS_TIMEOUT_MS",
    "FALCON_RAG_DIAGNOSTICS_INCLUDE_DEBUG",
    "FALCON_RAGAS_ENABLED",
    "FALCON_RAGAS_PROVIDER",
    "FALCON_RAGAS_MODEL",
  ]) {
    delete env[key];
  }
  return { ...env, ...overrides };
}

function spawnNode(args, options) {
  return new Promise((resolveSpawn) => {
    const child = spawn(process.execPath, args, options);
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      stdout += chunk;
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk;
    });
    child.on("close", (status, signal) => {
      resolveSpawn({ status, signal, stdout, stderr });
    });
  });
}

async function startMockQueryServer() {
  const { createServer } = await import("node:http");
  const server = createServer((request, response) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
    });
    request.on("end", () => {
      const input = JSON.parse(body || "{}");
      const id = queryId(input.query);
      const payload = buildMockResponse(id, input);
      response.setHeader("content-type", "application/json");
      response.setHeader("x-falcon-request-id", "mock-request-" + id);
      response.end(JSON.stringify(payload));
    });
  });

  await new Promise((resolveListen) => server.listen(0, "127.0.0.1", resolveListen));
  const address = server.address();
  return {
    url: "http://127.0.0.1:" + address.port,
    close: () => new Promise((resolveClose) => {
      server.closeAllConnections();
      server.close(resolveClose);
    }),
  };
}

function queryId(query) {
  if (query.includes("mobile flood early warning")) return "mobile-warning-artifact";
  if (query.includes("prevent all flood damage")) return "sandbags-prevent-all-damage";
  if (query.includes("estimate flood losses")) return "hazus-flood-loss-model";
  if (query.includes("public engagement")) return "metadata-source-display";
  return query.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "query";
}

function buildMockResponse(id, input) {
  if (id === "sandbags-prevent-all-damage") {
    return {
      id: "mock-" + id,
      createdAt: "2026-05-30T03:00:00.000Z",
      query: input.query,
      selectedDomains: input.domains,
      mode: "internal_qa",
      answer: "No. The selected documents do not support a claim that sandbags prevent all flood damage.",
      confidence: "Medium",
      generatedBy: "template",
      citations: [
        {
          documentId: "sandbag-policy",
          title: "Sandbag Policy",
          chunkId: "sandbag-policy-body-1",
          chunkIndex: 1,
          score: 0.42,
          snippet: "Sandbags may reduce minor water intrusion, but the document does not support saying they prevent all flood damage.",
          sourcePath: "mock/sandbag-policy.md",
          contentType: "body",
          metadata: {
            documentId: "sandbag-policy",
            chunkId: "sandbag-policy-body-1",
            chunkIndex: 1,
            title: "Sandbag Policy",
            domain: "sandbags",
            sourcePath: "mock/sandbag-policy.md",
            contentType: "body",
          },
        },
      ],
      retrievalTrace: { backend: "mock", selectedDomains: input.domains, candidateCount: 1, finalChunkCount: 1, chunkIds: ["sandbag-policy-body-1"] },
    };
  }

  if (id === "hazus-flood-loss-model") {
    return {
      id: "mock-" + id,
      createdAt: "2026-05-30T03:00:00.000Z",
      query: input.query,
      selectedDomains: input.domains,
      mode: "internal_qa",
      answer: "HAZUS-MH helps estimate socioeconomic flood damages for hazard mitigation planning.",
      confidence: "Medium",
      generatedBy: "template",
      citations: [
        {
          documentId: "sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model",
          title: "Hazard Mitigation Planning Using HAZUS-MH Flood Model",
          chunkId: "sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2",
          chunkIndex: 1,
          score: 0.73,
          snippet: "ArcReader mapping program. Critical map layers from HAZUS-MH are saved using ArcGIS Map Publisher and are opened by local officials",
          sourcePath: "mock/hazus.json",
          contentType: "body",
          metadata: {
            documentId: "sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model",
            chunkId: "sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2",
            chunkIndex: 1,
            title: "Hazard Mitigation Planning Using HAZUS-MH Flood Model",
            domain: "sandbags",
            sourcePath: "mock/hazus.json",
            sourceFileName: "hazus.pdf",
            contentType: "body",
            normalizedPdfText: true,
          },
        },
      ],
      retrievalTrace: { backend: "mock", selectedDomains: input.domains, candidateCount: 1, finalChunkCount: 1, chunkIds: ["sandbags-upload-hazard-mitigation-planning-using-hazus-mh-flood-model-chunk-2"] },
    };
  }

  if (id === "metadata-source-display") {
    return {
      id: "mock-" + id,
      createdAt: "2026-05-30T03:00:00.000Z",
      query: input.query,
      selectedDomains: input.domains,
      mode: "internal_qa",
      answer: "Flood Risk Management Global Case Studies discusses public engagement, governance, and policy.",
      confidence: "Medium",
      generatedBy: "template",
      citations: [
        {
          documentId: "sandbags-upload-flood-risk-management-global-case-studies",
          title: "Flood Risk Management Global Case Studies",
          chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-27",
          chunkIndex: 26,
          score: 0.69,
          snippet: "While the WFD stipulates that the public must be able to respond to plans for at least six months, the FD does not provide such a timescale.",
          sourcePath: "mock/global-case-studies.json",
          contentType: "body",
          metadata: {
            documentId: "sandbags-upload-flood-risk-management-global-case-studies",
            chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-27",
            chunkIndex: 26,
            title: "Flood Risk Management Global Case Studies",
            domain: "sandbags",
            sourcePath: "mock/global-case-studies.json",
            sourceFileName: "global-case-studies.pdf",
            contentType: "body",
            normalizedPdfText: true,
          },
        },
        {
          documentId: "sandbags-upload-flood-risk-management-global-case-studies",
          title: "Flood Risk Management Global Case Studies",
          chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-124",
          chunkIndex: 123,
          score: 0.62,
          snippet: "From the information provided by the interviewee, the department appears equipped to detect and forecast weather events.",
          sourcePath: "mock/global-case-studies.json",
          contentType: "body",
          metadata: {
            documentId: "sandbags-upload-flood-risk-management-global-case-studies",
            chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-124",
            chunkIndex: 123,
            title: "Flood Risk Management Global Case Studies",
            domain: "sandbags",
            sourcePath: "mock/global-case-studies.json",
            sourceFileName: "global-case-studies.pdf",
            contentType: "body",
            normalizedPdfText: true,
          },
        },
      ],
      retrievalTrace: { backend: "mock", selectedDomains: input.domains, candidateCount: 2, finalChunkCount: 2, chunkIds: ["sandbags-upload-flood-risk-management-global-case-studies-chunk-27", "sandbags-upload-flood-risk-management-global-case-studies-chunk-124"] },
    };
  }

  const artifactText = id === "mobile-warning-artifact"
    ? "132 Abigail Tevera -> I I I --, I Flood identification I ---- FIGURE 11.1 lnstrums,nt ds,nsity lesSOflsfearnt>d"
    : "Flood warning body evidence says warning messages should reach residents before roads close.";

  return {
    id: "mock-" + id,
    createdAt: "2026-05-30T03:00:00.000Z",
    query: input.query,
    selectedDomains: input.domains,
    mode: "internal_qa",
    answer: artifactText,
    confidence: "High",
    generatedBy: "template",
    citations: [
      {
        documentId: "sandbags-upload-flood-risk-management-global-case-studies",
        title: "Flood Risk Management Global Case Studies",
        chunkId: id === "mobile-warning-artifact" ? "sandbags-upload-flood-risk-management-global-case-studies-chunk-90" : "mock-body-chunk",
        chunkIndex: id === "mobile-warning-artifact" ? 89 : 1,
        score: id === "mobile-warning-artifact" ? 0.512 : 0.7,
        snippet: artifactText,
        sourcePath: "mock/source.pdf",
        contentType: "body",
        metadata: {
          documentId: "sandbags-upload-flood-risk-management-global-case-studies",
          chunkId: id === "mobile-warning-artifact" ? "sandbags-upload-flood-risk-management-global-case-studies-chunk-90" : "mock-body-chunk",
          chunkIndex: id === "mobile-warning-artifact" ? 89 : 1,
          title: "Flood Risk Management Global Case Studies",
          domain: "sandbags",
          sourcePath: "mock/source.pdf",
          sourceFileName: "source.pdf",
          contentType: "body",
          normalizedPdfText: true,
        },
      },
    ],
    retrievalTrace: { backend: "mock", selectedDomains: input.domains, candidateCount: 1, finalChunkCount: 1, chunkIds: ["mock-body-chunk"] },
  };
}
