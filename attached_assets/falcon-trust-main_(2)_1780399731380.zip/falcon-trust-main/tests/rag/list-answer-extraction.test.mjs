import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import ts from "typescript";
import test from "node:test";

let activeCitations = [];

async function loadRetrievalModule() {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");
  const output = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      esModuleInterop: true,
    },
  }).outputText;
  const cjsModule = { exports: {} };
  const sandbox = {
    module: cjsModule,
    exports: cjsModule.exports,
    process: { env: {} },
    require: (id) => {
      if (id !== "./retrieval-backends") throw new Error(`Unexpected require: ${id}`);
      return {
        getRetrievalBackend: () => ({
          id: "qa-fixture",
          retrieve: async () => ({
            citations: activeCitations,
            trace: {
              backend: "qa-fixture",
              selectedDomains: ["sandbags"],
              citationCount: activeCitations.length,
              documentIds: Array.from(new Set(activeCitations.map((citation) => citation.documentId))),
              chunkIds: activeCitations.map((citation) => citation.chunkId),
              sourcePaths: Array.from(new Set(activeCitations.map((citation) => citation.sourcePath).filter(Boolean))),
            },
            debugTrace: {
              backend: "qa-fixture",
              selectedDomains: ["sandbags"],
              queryTokens: [],
              candidateCount: activeCitations.length,
              finalChunkCount: activeCitations.length,
              chunkIds: activeCitations.map((citation) => citation.chunkId),
              candidates: [],
              finalChunks: [],
              decisions: [],
              notes: ["Local answer extraction fixture."],
            },
          }),
        }),
      };
    },
  };
  vm.runInNewContext(output, sandbox, { filename: "retrieval.cjs" });
  return cjsModule.exports;
}

test("Ready list answer preserves comma-and list items from one evidence sentence", async () => {
  const { buildAnswer } = await loadRetrievalModule();
  activeCitations = [workshopCitation(), readyCampaignCitation(), floodWarningListCitation()];

  const result = await buildAnswer(
    "What is FEMA's Ready campaign and what are its three key components?",
    ["sandbags"],
    "internal_qa",
  );

  assert.match(result.answer, /launched its national Ready campaign in 2003/i);
  assert.match(result.answer, /increase public awareness and participation in disaster preparedness/i);
  assert.match(result.answer, /get a kit/i);
  assert.match(result.answer, /make a plan/i);
  assert.match(result.answer, /be informed/i);
  assert.doesNotMatch(result.answer, /public-health-specific; face-to-face module/i);
  assert.doesNotMatch(result.answer, /detection; forecasting; warning/i);
});

test("nearby workshop query answers workshop context instead of Ready components", async () => {
  const { buildAnswer } = await loadRetrievalModule();
  activeCitations = [workshopCitation(), readyCampaignCitation()];

  const result = await buildAnswer(
    "What did the JH-CPHP workshop use FEMA materials for?",
    ["sandbags"],
    "internal_qa",
  );

  assert.match(result.answer, /public health-specific/i);
  assert.match(result.answer, /scenario-based exercise/i);
  assert.match(result.answer, /West Virginia Severe Flooding Tabletop/i);
  assert.doesNotMatch(result.answer, /^Components:/i);
});

test("comparison queries with list terms do not collapse into nearby component lists", async () => {
  const { buildAnswer } = await loadRetrievalModule();
  activeCitations = [workshopCitation(), readyCampaignCitation()];

  const result = await buildAnswer(
    "Did the West Virginia workshop mainly teach Ready components, or adapt FEMA materials for public health responders?",
    ["sandbags"],
    "internal_qa",
  );

  assert.match(result.answer, /public health-specific/i);
  assert.match(result.answer, /West Virginia Severe Flooding Tabletop|tailored existing FEMA materials/i);
  assert.doesNotMatch(result.answer, /^Components:/i);
  assert.doesNotMatch(result.answer, /get a kit; make a plan; be informed/i);
});

test("general list extraction handles comma-and lists without neighboring text", async () => {
  const { buildAnswer } = await loadRetrievalModule();
  activeCitations = [
    citation({
      chunkId: "operations-plan-chunk-1",
      text: "The operations plan has three steps: inspect valves, record levels and notify operators. The workshop team later discussed unrelated staffing changes.",
      score: 0.9,
    }),
    citation({
      chunkId: "operations-plan-chunk-2",
      text: "The workshop team used the plan for training and tabletop exercises.",
      score: 0.4,
    }),
  ];

  const result = await buildAnswer("What are the three steps in the operations plan?", ["sandbags"], "internal_qa");

  assert.match(result.answer, /inspect valves/i);
  assert.match(result.answer, /record levels/i);
  assert.match(result.answer, /notify operators/i);
  assert.doesNotMatch(result.answer, /staffing changes/i);
  assert.doesNotMatch(result.answer, /tabletop exercises/i);
});

function readyCampaignCitation() {
  return citation({
    chunkId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-1",
    documentId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    sourcePath: "uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json",
    sourceFileName: "bdevito67,+JEM-12-1-04-Kohn.pdf",
    score: 1.15,
    text: "Barnett, MD, MPH JEM DOI:10.5055/jem.2014.0162 threats, government and response agencies have emphasized the need for personal emergency preparedness. For example, the Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities about different types of emergencies and their appropriate responses: \"get a kit, make a plan and be informed.\"",
  });
}

function workshopCitation() {
  return citation({
    chunkId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers-chunk-13",
    documentId: "sandbags-upload-personal-preparedness-curriculum-for-public-health-workers",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    sourcePath: "uploads/sandbags/sandbags-upload-personal-preparedness-curriculum-for-public-health-workers.json",
    sourceFileName: "bdevito67,+JEM-12-1-04-Kohn.pdf",
    score: 0.98,
    text: "JH-CPHP experts adapted existing FEMA Ready content into an interactive, public health-specific, face-to-face module. JH-CPHP experts tailored existing FEMA materials into a public health-specific context and developed a scenario-based exercise called the West Virginia Severe Flooding Tabletop.",
  });
}

function floodWarningListCitation() {
  return citation({
    chunkId: "sandbags-upload-flood-risk-management-global-case-studies-chunk-85",
    documentId: "sandbags-upload-flood-risk-management-global-case-studies",
    title: "Flood Risk Management Global Case Studies",
    sourcePath: "uploads/sandbags/sandbags-upload-flood-risk-management-global-case-studies.json",
    sourceFileName: "Flood Risk Management-OCR.pdf",
    score: 0.92,
    text: "The early warning system 'chain' The FEWS chain is a cumulative set of actions that aims to achieve appropriate preparedness and loss minimisation measures when a flood occurs. Parker outlines five key components of the chain: detection, forecasting and warning.",
  });
}

function citation(input) {
  const documentId = input.documentId ?? "qa-fixture-document";
  const sourcePath = input.sourcePath ?? "uploads/sandbags/qa-fixture-document.json";
  return {
    documentId,
    title: input.title ?? "QA Fixture Document",
    domain: "sandbags",
    snippet: input.text.slice(0, 260),
    score: input.score,
    chunkId: input.chunkId,
    chunkIndex: 0,
    sourcePath,
    contentType: "body",
    text: input.text,
    metadata: {
      chunkId: input.chunkId,
      chunkIndex: 0,
      contentType: "body",
      documentId,
      domain: "sandbags",
      sourceFileName: input.sourceFileName ?? "qa-fixture.pdf",
      sourcePath,
      title: input.title ?? "QA Fixture Document",
    },
  };
}
