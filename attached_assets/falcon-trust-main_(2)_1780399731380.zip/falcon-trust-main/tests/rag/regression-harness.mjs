const INDEX_REFERENCE_PATTERNS = [
  /table of contents/i,
  /index\b/i,
  /references?\b/i,
  /bibliography/i,
  /see page\s+\d+/i,
];

export function evaluateRagCase({ query, chunks, answer }) {
  const supportingChunks = chunks.filter((chunk) => chunk.kind === "body" && textOverlaps(query, chunk.text));
  const citationChunks = chunks.filter((chunk) => answer.citationIds.includes(chunk.id));
  const bodyCitations = citationChunks.filter((chunk) => chunk.kind === "body");
  const referenceOnlyCitations = citationChunks.length > 0 && bodyCitations.length === 0;
  const hasIndexFalsePositive = citationChunks.some((chunk) => chunk.kind !== "body" || INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(chunk.text)));
  const answerSupported = bodyCitations.some((chunk) => answerIncludesEvidence(answer.text, chunk.text));
  const answerable = supportingChunks.length > 0 && answerSupported && !hasIndexFalsePositive && !referenceOnlyCitations;
  const separatesGuidanceFromDocumentSupport = separatesSections(answer);
  const answerabilityReason = answerable
    ? "supported-body-evidence"
    : citationChunks.length === 0
      ? "no-citations"
      : bodyCitations.length === 0 || hasIndexFalsePositive
        ? "no-body-evidence"
        : "weak-or-unsupported-evidence";
  const confidence = scoreConfidence({ citationChunks, answerable, answerabilityReason, answer });
  const filteredReferenceCount = chunks.filter((chunk) => isReferenceLikeChunk(chunk) && !answer.citationIds.includes(chunk.id)).length;
  const selectedBodyCitationCount = citationChunks.filter((chunk) => chunk.kind === "body").length;

  return {
    answerable,
    supportingBodyChunkCount: supportingChunks.length,
    answerSupported,
    hasIndexFalsePositive,
    referenceOnlyCitations,
    citationCount: citationChunks.length,
    shouldReturnGap: !answerable,
    answerabilityReason,
    separatesGuidanceFromDocumentSupport,
    confidence: confidence.level,
    confidenceReason: confidence.reason,
    confidenceFactors: confidence.factors,
    filteredReferenceCount,
    selectedBodyCitationCount,
    shouldBeHighConfidence: confidence.level === "High",
  };
}

export function buildRagDebugTrace(ragCase) {
  const evaluation = evaluateRagCase(ragCase);
  const citationIds = new Set(ragCase.answer.citationIds);
  const finalChunks = ragCase.chunks.filter((chunk) => citationIds.has(chunk.id));
  const candidates = ragCase.chunks.map((chunk, index) => {
    const selected = citationIds.has(chunk.id);
    const score = selected ? Number((1 - index * 0.1).toFixed(3)) : 0;
    return {
      chunkId: chunk.id,
      documentId: chunk.documentId ?? ragCase.id,
      title: chunk.title ?? ragCase.id,
      domain: chunk.domain ?? "offline-fixture",
      chunkIndex: chunk.chunkIndex ?? index,
      sourcePath: chunk.sourcePath ?? `tests/rag/fixtures/rag-eval-cases.json#${ragCase.id}`,
      contentType: chunk.kind ?? "unknown",
      score,
      snippet: chunk.text.replace(/\s+/g, " ").slice(0, 420),
      textPreview: chunk.text.replace(/\s+/g, " ").slice(0, 240),
      metadata: {
        fixtureId: ragCase.id,
        category: ragCase.category,
        futureIssue: ragCase.futureIssue,
        kind: chunk.kind ?? null,
      },
      selected,
      rank: selected ? finalChunks.findIndex((candidate) => candidate.id === chunk.id) + 1 : undefined,
      reasons: selected
        ? ["selected fixture citation for final answer"]
        : isReferenceLikeChunk(chunk)
          ? ["index/reference candidate downranked or filtered before final answer"]
          : ["available fixture candidate but not cited in final answer"],
    };
  });

  return {
    enabled: true,
    safeForLogging: true,
    backend: "offline-fixture",
    selectedDomains: Array.from(new Set(candidates.map((candidate) => candidate.domain))),
    limit: ragCase.answer.citationIds.length,
    candidateCount: candidates.length,
    matchedCandidateCount: finalChunks.length,
    finalChunkCount: finalChunks.length,
    candidates,
    finalChunks: candidates.filter((candidate) => candidate.selected),
    decisions: [
      ...candidates.map((candidate) => ({
        type: candidate.selected ? "selection" : "filter",
        chunkId: candidate.chunkId,
        reason: candidate.selected
          ? "selected-for-answer"
          : candidate.contentType === "index" || candidate.contentType === "reference"
            ? "index-reference-downranked"
            : "not-cited-by-answer",
        message: candidate.selected
          ? "Fixture answer cited this chunk for final answer evidence."
          : candidate.contentType === "index" || candidate.contentType === "reference"
            ? "Fixture candidate looked like index/reference/bibliography material and should not displace body evidence."
          : "Fixture candidate remained available but was not cited by the answer.",
      })),
      {
        type: "answerability",
        reason: evaluation.answerabilityReason,
        message: evaluation.answerable
          ? "Fixture includes cited body evidence that supports the answer."
          : "Fixture does not include enough cited body evidence and should remain a gap/low-support response.",
      },
      {
        type: "confidence",
        reason: evaluation.confidenceReason,
        message: `Fixture confidence ${evaluation.confidence} from evidence-quality factors: ${evaluation.confidenceFactors.join("; ")}.`,
      },
    ],
    notes: [
      "Issue #23 answerability threshold: require cited body evidence that overlaps the query and supports the answer; index/reference or weak coincidental matches are insufficient.",
      `Issue #25 confidence: ${evaluation.confidence}; factors: ${evaluation.confidenceFactors.join("; ")}.`,
    ],
  };
}

function scoreConfidence({ citationChunks, answerable, answerabilityReason, answer }) {
  if (!answerable) {
    return {
      level: "Low",
      reason: answerabilityReason,
      factors: [
        `answerability=${answerabilityReason}`,
        `citation count=${citationChunks.length}`,
      ],
    };
  }

  const scores = citationChunks.map((chunk) => chunk.score ?? 0).sort((a, b) => b - a);
  const bestScore = scores[0] ?? 0;
  const scoreSpread = Math.max(0, bestScore - (scores[1] ?? 0));
  const bodyCitations = citationChunks.filter((chunk) => chunk.kind === "body").length;
  const referenceCitations = citationChunks.filter((chunk) => chunk.kind !== "body" || INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(chunk.text))).length;
  const metadataFields = citationChunks.map((chunk) => [chunk.documentId, chunk.title, chunk.domain, chunk.sourcePath, chunk.sectionHeading].filter(Boolean).length);
  const avgMetadata = metadataFields.length ? metadataFields.reduce((sum, value) => sum + value, 0) / metadataFields.length : 0;
  const directSupport = answer.sections?.documentSupportedClaims?.length ?? 0;
  let score = 0;

  if (citationChunks.length >= 2) score += 2;
  else if (citationChunks.length === 1) score += 1;
  if (bestScore >= 0.45) score += 2;
  else if (bestScore >= 0.32) score += 1;
  if (scoreSpread >= 0.12 || citationChunks.length >= 2) score += 1;
  if (bodyCitations > 0) score += 1;
  if (directSupport > 0) score += 1;
  if (avgMetadata >= 4) score += 1;
  if (referenceCitations > 0) score -= 2;

  const factors = [
    `citation count=${citationChunks.length}`,
    `body citations=${bodyCitations}`,
    `reference citations=${referenceCitations}`,
    `best score=${bestScore.toFixed(3)}`,
    `score spread=${scoreSpread.toFixed(3)}`,
    `direct supported claims=${directSupport}`,
    `avg metadata fields=${avgMetadata.toFixed(1)}`,
  ];

  if (referenceCitations === citationChunks.length) {
    return { level: "Low", reason: "index-reference-only", factors };
  }

  return {
    level: score >= 6 ? "High" : score >= 3 ? "Medium" : "Low",
    reason: score >= 6 ? "strong-direct-evidence" : score >= 3 ? "moderate-direct-evidence" : "limited-direct-evidence",
    factors,
  };
}

function isReferenceLikeChunk(chunk) {
  return chunk.kind !== "body" || INDEX_REFERENCE_PATTERNS.some((pattern) => pattern.test(chunk.text));
}

function separatesSections(answer) {
  if (!answer.sections) return false;
  const supported = answer.sections.documentSupportedClaims;
  const guidance = answer.sections.generalGuidance;
  return Array.isArray(supported) && supported.length > 0 && Array.isArray(guidance);
}

function textOverlaps(query, text) {
  const queryTerms = contentTerms(query);
  const textTerms = new Set(contentTerms(text));
  return queryTerms.filter((term) => textTerms.has(term)).length >= Math.min(3, queryTerms.length);
}

function answerIncludesEvidence(answerText, evidenceText) {
  const answerTerms = new Set(contentTerms(answerText));
  const evidenceTerms = Array.from(new Set(contentTerms(evidenceText)));
  return evidenceTerms.filter((term) => answerTerms.has(term)).length >= 4;
}

function contentTerms(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((term) => term.length > 3 && !STOP_WORDS.has(term));
}

const STOP_WORDS = new Set([
  "about",
  "after",
  "also",
  "because",
  "before",
  "from",
  "into",
  "that",
  "their",
  "there",
  "these",
  "this",
  "what",
  "when",
  "where",
  "which",
  "with",
]);
