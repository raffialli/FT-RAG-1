import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { buildRagDebugTrace, evaluateRagCase } from "./regression-harness.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const fixturePath = join(__dirname, "fixtures", "rag-eval-cases.json");
const cases = JSON.parse(readFileSync(fixturePath, "utf8"));

test("fixture set covers the required issue #21 regression categories", () => {
  const categories = new Set(cases.map((ragCase) => ragCase.category));

  assert.deepEqual(
    [
      "answerable-body-evidence",
      "unanswerable-no-support",
      "index-reference-false-positive",
      "citation-count-confidence-trap",
      "template-vs-evidence-separation",
      "bibliography-reference-filtering",
      "ocr-layout-noise",
    ].filter((category) => !categories.has(category)),
    [],
  );
});

for (const ragCase of cases) {
  test(`rag fixture: ${ragCase.id}`, () => {
    const result = evaluateRagCase(ragCase);

    for (const [field, expected] of Object.entries(ragCase.expect)) {
      if (field === "containsOcrNoise") {
        assert.equal(hasOcrNoise(ragCase), expected, `${ragCase.id} expected OCR/layout noise fixture marker`);
        continue;
      }

      assert.equal(result[field], expected, `${ragCase.id} expected ${field}=${expected}, got ${result[field]}`);
    }
  });
}

test("citation-count fixture protects against count-only high confidence", () => {
  const ragCase = cases.find((candidate) => candidate.id === "citation-count-confidence-trap");
  const result = evaluateRagCase(ragCase);

  assert.equal(result.citationCount, 3);
  assert.equal(result.shouldBeHighConfidence, false);
});

test("issue #25 scores confidence from evidence quality instead of citation count", () => {
  const referenceTrap = evaluateRagCase(cases.find((candidate) => candidate.id === "citation-count-confidence-trap"));
  const weakSupport = evaluateRagCase(cases.find((candidate) => candidate.id === "weak-coincidental-answerability"));
  const oneCitation = evaluateRagCase(cases.find((candidate) => candidate.id === "confidence-one-citation-moderate-support"));
  const twoCitation = evaluateRagCase(cases.find((candidate) => candidate.id === "confidence-two-citation-strong-support"));

  assert.equal(referenceTrap.confidence, "Low");
  assert.equal(weakSupport.confidence, "Low");
  assert.equal(oneCitation.confidence, "Medium");
  assert.equal(twoCitation.confidence, "High");
});

test("issue #25 debug trace explains confidence factors", () => {
  const ragCase = cases.find((candidate) => candidate.id === "confidence-two-citation-strong-support");
  const trace = buildRagDebugTrace(ragCase);
  const confidenceDecision = trace.decisions.find((decision) => decision.type === "confidence");

  assert.ok(confidenceDecision);
  assert.equal(confidenceDecision.reason, "strong-direct-evidence");
  assert.match(confidenceDecision.message, /evidence-quality factors/);
  assert.ok(trace.notes.some((note) => /Issue #25 confidence: High/.test(note)));
});

test("issue #26 downranks reference-style candidates while preserving body evidence", () => {
  const ragCase = cases.find((candidate) => candidate.id === "index-reference-filter-preserves-body");
  const result = evaluateRagCase(ragCase);
  const trace = buildRagDebugTrace(ragCase);

  assert.equal(result.filteredReferenceCount, 1);
  assert.equal(result.selectedBodyCitationCount, 1);
  assert.equal(result.hasIndexFalsePositive, false);
  assert.ok(trace.decisions.some((decision) => decision.chunkId === "shelter-index-1" && decision.reason === "index-reference-downranked"));
  assert.ok(trace.finalChunks.some((chunk) => chunk.chunkId === "shelter-body-2" && chunk.contentType === "body"));
});

test("issue #27 excludes academic reference-list evidence while preserving useful body evidence", () => {
  const ragCase = cases.find((candidate) => candidate.id === "academic-reference-list-excluded-preserves-body");
  const result = evaluateRagCase(ragCase);
  const trace = buildRagDebugTrace(ragCase);

  assert.equal(result.answerable, true);
  assert.equal(result.filteredReferenceCount, 1);
  assert.equal(result.selectedBodyCitationCount, 1);
  assert.equal(result.hasIndexFalsePositive, false);
  assert.equal(result.referenceOnlyCitations, false);
  assert.ok(trace.decisions.some((decision) => decision.chunkId === "preparedness-academic-references-1" && decision.reason === "index-reference-downranked"));
  assert.deepEqual(trace.finalChunks.map((chunk) => chunk.chunkId), ["preparedness-body-1"]);
});

test("OCR fixture records baseline noisy text patterns without requiring cleanup behavior yet", () => {
  const ragCase = cases.find((candidate) => candidate.category === "ocr-layout-noise");
  const text = ragCase.chunks.map((chunk) => chunk.text).join("\n");

  assert.match(text, /Sand-\nbag/);
  assert.match(text, /Resi-\ndents/);
  assert.match(text, /identiﬁcation/);
  assert.match(text, /Page 12/);
  assert.match(text, /FALCON COUNTY FLOOD RESPONSE BULLETIN/);
});

test("debug traces expose stable offline candidate and final chunk metadata", () => {
  for (const ragCase of cases) {
    const trace = buildRagDebugTrace(ragCase);

    assert.equal(trace.enabled, true);
    assert.equal(trace.safeForLogging, true);
    assert.equal(trace.candidateCount, ragCase.chunks.length);
    assert.equal(trace.finalChunkCount, ragCase.answer.citationIds.length);
    assert.equal(trace.candidates.length, ragCase.chunks.length);
    assert.ok(trace.decisions.some((decision) => decision.type === "answerability"));

    for (const chunk of trace.candidates) {
      assert.equal(typeof chunk.chunkId, "string");
      assert.equal(typeof chunk.documentId, "string");
      assert.equal(typeof chunk.score, "number");
      assert.equal(typeof chunk.textPreview, "string");
      assert.equal(chunk.textPreview.length > 0, true);
      assert.equal(chunk.metadata.category, ragCase.category);
      assert.match(chunk.sourcePath, /rag-eval-cases\.json|fixtures\//);
      assert.ok(["body", "index", "reference", "unknown"].includes(chunk.contentType));
    }
  }
});

test("debug trace distinguishes candidate chunks from final answer chunks", () => {
  const ragCase = cases.find((candidate) => candidate.id === "index-reference-false-positive");
  const trace = buildRagDebugTrace(ragCase);

  assert.equal(trace.candidateCount, 2);
  assert.equal(trace.finalChunkCount, 2);
  assert.deepEqual(trace.finalChunks.map((chunk) => chunk.chunkId), ragCase.answer.citationIds);
  assert.ok(trace.finalChunks.every((chunk) => chunk.selected));
  assert.ok(trace.decisions.some((decision) => decision.reason === "selected-for-answer"));
});

test("issue #23 rejects weak coincidental evidence while preserving direct support", () => {
  const weakCase = cases.find((candidate) => candidate.id === "weak-coincidental-answerability");
  const strongCase = cases.find((candidate) => candidate.id === "strong-direct-answerability");

  const weak = evaluateRagCase(weakCase);
  const strong = evaluateRagCase(strongCase);

  assert.equal(weak.supportingBodyChunkCount, 1);
  assert.equal(weak.answerSupported, false);
  assert.equal(weak.answerable, false);
  assert.equal(weak.shouldReturnGap, true);
  assert.equal(weak.answerabilityReason, "weak-or-unsupported-evidence");

  assert.equal(strong.answerSupported, true);
  assert.equal(strong.answerable, true);
  assert.equal(strong.shouldReturnGap, false);
  assert.equal(strong.answerabilityReason, "supported-body-evidence");
});

test("issue #23 answerability decision is visible in debug traces", () => {
  const weakCase = cases.find((candidate) => candidate.id === "weak-coincidental-answerability");
  const strongCase = cases.find((candidate) => candidate.id === "strong-direct-answerability");

  const weakTrace = buildRagDebugTrace(weakCase);
  const strongTrace = buildRagDebugTrace(strongCase);

  assert.ok(weakTrace.decisions.some((decision) => decision.type === "answerability" && decision.reason === "weak-or-unsupported-evidence"));
  assert.ok(strongTrace.decisions.some((decision) => decision.type === "answerability" && decision.reason === "supported-body-evidence"));
  assert.ok(weakTrace.notes.some((note) => /Issue #23 answerability threshold/.test(note)));
});

function hasOcrNoise(ragCase) {
  const text = ragCase.chunks.map((chunk) => chunk.text).join("\n");

  return [
    /\w-\n\w/,
    /ﬁ|ﬂ/,
    /\bPage\s+\d+\b/i,
    /(FALCON COUNTY FLOOD RESPONSE BULLETIN[\s\S]*){2,}/,
  ].some((pattern) => pattern.test(text));
}
