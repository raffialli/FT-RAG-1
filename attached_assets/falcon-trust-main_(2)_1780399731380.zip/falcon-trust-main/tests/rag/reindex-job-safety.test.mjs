import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join, resolve } from "node:path";
import test from "node:test";

const repoRoot = resolve(new URL("../..", import.meta.url).pathname);

test("admin embeddings POST no longer runs synchronous full reindex inline", () => {
  const route = readFileSync(join(repoRoot, "src/app/api/admin/embeddings/route.ts"), "utf8");

  assert.equal(route.includes("await reindexEmbeddings()"), false);
  assert.match(route, /Synchronous full reindex is disabled/);
  assert.match(route, /\/api\/admin\/embeddings\/jobs/);
});

test("reindex job route defaults to dry-run and requires explicit candidate confirmation", () => {
  const jobs = readFileSync(join(repoRoot, "src/lib/falcon/reindex-jobs.ts"), "utf8");

  assert.match(jobs, /mode === "dry-run"/);
  assert.match(jobs, /confirm !== "write-temp-vector"/);
  assert.match(jobs, /Reindex job already running/);
  assert.match(jobs, /vectors\/reindex-candidates/);
  assert.match(jobs, /verifyCandidateVectorIndex/);
  assert.match(jobs, /promotion remains manual/);
});
