import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("runtime buildAnswer suppresses final citations for weak unsupported evidence", async () => {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");

  assert.match(source, /const retrievedCitations = retrieval\.citations;/);
  assert.match(source, /const finalEvidence = selectFinalEvidence\(query, retrievedCitations\);/);
  assert.match(source, /const answerability = assessAnswerability\(query, finalEvidence\.citations\);/);
  assert.match(source, /const evidencePolicy = assessEvidencePolicy\(query, finalEvidence\.citations, answerability\);/);
  assert.match(source, /let confidence = capConfidence\(assessConfidence\(answerability, finalEvidence\.citations\), evidencePolicy\.confidenceCap\);/);
  assert.match(source, /const citations = weak \|\| evidencePolicy\.suppressCitations \? \[\] : selectVisibleCitations\(query, finalEvidence\.citations\);/);
  assert.match(source, /const visibleQuality = assessVisibleAnswerQuality\(answer, citations, finalEvidence\.citations\);/);
  assert.match(source, /confidence = capConfidence\(confidence, visibleQuality\.confidenceCap\);/);
  assert.match(source, /buildAugmentedContextTrace\(retrieval\.trace\.backend, citations\)/);
  assert.match(source, /weak-evidence-citations-suppressed/);
});

test("runtime policy filters live-vector evidence before answerability", async () => {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");

  assert.match(source, /function selectFinalEvidence\(query: string, citations: Citation\[\]\): FinalEvidenceSelection/);
  assert.match(source, /reference-or-frontmatter-evidence-filtered/);
  assert.match(source, /ocr-layout-evidence-filtered/);
  assert.match(source, /metadata-tainted-evidence-filtered/);
  assert.match(source, /Runtime evidence policy: /);
});

test("runtime policy has focused guards for live Dev false positives", async () => {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");

  assert.match(source, /current-policy-gap/);
  assert.match(source, /current-policy-specificity-gap/);
  assert.match(source, /manufactured-housing-gap/);
  assert.match(source, /frontmatter-reference-filtered/);
  assert.match(source, /unsupported-absolute-claim-cautious-answer-with-citations/);
  assert.match(source, /runtime evidence policy capped confidence/);
});

test("runtime policy covers remaining live Dev unsupported and reference-risk asks", async () => {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");

  assert.match(source, /pickup-rules-gap/);
  assert.match(source, /publication-risk-gap/);
  assert.match(source, /niger-warning-gap/);
  assert.match(source, /country-exposure-gap/);
  assert.match(source, /final-evidence-accepted-with-pdf-layout-risk/);
  assert.match(source, /figures\? \(\?:are \)\?listed/);
});

test("runtime source display has client-safe visible snippet cleanup", async () => {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval.ts", import.meta.url), "utf8");

  assert.match(source, /function selectVisibleCitations\(query: string, citations: Citation\[\]\)/);
  assert.match(source, /function bestVisibleSnippet\(query: string, citation: Citation/);
  assert.match(source, /function cleanVisibleSnippet\(snippet: string\)/);
  assert.match(source, /function hasVisibleSourceJunk\(text: string\)/);
  assert.match(source, /please visit www\\?\.copyright\\?\.com/i);
  assert.match(source, /hasAuthorCitationNumberArtifact/);
});

test("runtime citation filtering does not treat ordinary contents wording as index evidence", async () => {
  const embeddingsSource = await readFile(new URL("../../src/lib/falcon/embeddings.ts", import.meta.url), "utf8");
  const backendsSource = await readFile(new URL("../../src/lib/falcon/retrieval-backends.ts", import.meta.url), "utf8");

  assert.doesNotMatch(embeddingsSource, /table of contents\|contents\|index/);
  assert.doesNotMatch(backendsSource, /table of contents\|contents\|index/);
  assert.match(embeddingsSource, /table of contents\|contents list\|index/);
  assert.match(backendsSource, /table of contents\|contents list\|index/);
});
