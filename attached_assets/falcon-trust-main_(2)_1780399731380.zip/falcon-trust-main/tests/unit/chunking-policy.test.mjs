import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import vm from "node:vm";
import ts from "typescript";
import test from "node:test";

async function loadCorpusModule() {
  const source = await readFile(new URL("../../src/lib/falcon/corpus.ts", import.meta.url), "utf8");
  const output = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      esModuleInterop: true,
    },
  }).outputText;
  const cjsModule = { exports: {} };
  const sandbox = {
    module: cjsModule,
    exports: cjsModule.exports,
    process,
    require(specifier) {
      if (specifier === "node:fs") return { __esModule: true, default: { existsSync: () => false, readdirSync: () => [], readFileSync: () => "" } };
      if (specifier === "node:path") return { __esModule: true, default: path };
      if (specifier === "./domains") return { loadDomains: async () => [] };
      if (specifier === "./storage") return { deleteJson: async () => {}, listJson: async () => [], writeJson: async () => ({ path: "stub" }) };
      throw new Error("Unexpected require: " + specifier);
    },
  };
  vm.runInNewContext(output, sandbox, { filename: "corpus.cjs" });
  return cjsModule.exports;
}

test("semantic chunking starts sections at headings and page markers", async () => {
  const { splitSemanticSections } = await loadCorpusModule();
  const filler = "Residents should review routes and prepare kits. ".repeat(30);
  const text = `# Flood Guide\n\n${filler}\n\n## Evacuation Routes\n\n${filler}\n\nPage 2\n\n${filler}`;
  const sections = splitSemanticSections(text);

  assert.equal(sections.length, 3);
  assert.match(sections[0], /^# Flood Guide/);
  assert.match(sections[1], /^## Evacuation Routes/);
  assert.match(sections[2], /^Page 2/);
});

test("long chunk splitting prefers paragraph boundaries and bounded overlap", async () => {
  const { splitLongSection, CHUNKING_POLICY } = await loadCorpusModule();
  const paragraph = "This paragraph contains evacuation route guidance and shelter timing details. ".repeat(14);
  const section = Array.from({ length: 10 }, (_, index) => `Paragraph ${index + 1}. ${paragraph}`).join("\n\n");
  const chunks = splitLongSection(section, 900, 120);

  assert.ok(chunks.length > 1);
  assert.ok(chunks.every((chunk) => chunk.length <= 930));
  assert.ok(chunks.slice(0, -1).every((chunk) => /\.$/.test(chunk.trim())));
  assert.equal(CHUNKING_POLICY.reindexRequired.includes("rebuilding"), true);
});

test("long chunk overlap starts on sentence or word boundaries", async () => {
  const { splitLongSection } = await loadCorpusModule();
  const lead = "Flood warning teams should maintain redundant alert channels for disconnected neighborhoods. ".repeat(22);
  const boundaryText = [
    "In a study of a mobile-enabled FEWS in Bangladesh, recipients demonstrated a preference for SMS warnings.",
    "In Bhutan, SMS warnings were specifically preferred by women working beyond the reach of sirens or loudspeakers.",
    "This example reinforces the need to understand local context alongside recipient preferences.",
  ].join(" ");
  const section = `${lead}${boundaryText} ${"Preparedness officers should keep community groups involved in response planning. ".repeat(24)}`;
  const chunks = splitLongSection(section, 1800, 220);

  assert.ok(chunks.length > 1);
  assert.ok(chunks.slice(1).every((chunk) => !/^ile-enabled\b/.test(chunk)));
  assert.ok(chunks.slice(1).every((chunk) => !/^[a-z][a-z-]+\b/.test(chunk)));
  assert.ok(chunks.slice(1).every((chunk) => /^[A-Z0-9#]/.test(chunk)));
});

test("long chunk overlap avoids mid-sentence starts and excessive duplicate evidence", async () => {
  const { splitLongSection } = await loadCorpusModule();
  const lead = "Warning authorities should adapt messages to local risk perception and trusted messengers. ".repeat(22);
  const boundaryText = [
    "Mileti theorised that improved flood warning response occurs when sender and receiver characteristics are alike.",
    "This could be adapted to argue that benefits are achieved by aligning the knowledge of sender and receiver.",
    "Disparities of knowledge between disseminators and receivers are addressed in well-resourced systems.",
  ].join(" ");
  const section = `${lead}${boundaryText} ${"Local authorities and community groups should collaboratively develop response plans before flood season. ".repeat(24)}`;
  const chunks = splitLongSection(section, 1800, 360);

  assert.ok(chunks.length > 1);
  assert.ok(chunks.slice(1).every((chunk) => !/^characteristics are alike\b/.test(chunk)));
  assert.ok(chunks.slice(1).every((chunk) => /^[A-Z0-9#]/.test(chunk)));
  assert.ok(Math.max(...chunks.slice(1).map((chunk, index) => sharedBoundaryText(chunks[index], chunk).length)) < 500);
});

test("default long chunk overlap keeps observed flood-warning starts readable", async () => {
  const { splitLongSection } = await loadCorpusModule();
  const lead = Array.from(
    { length: 19 },
    (_, index) => `Preparedness context ${index + 1} says the national early warning system failed to reach ethnic minority groups because the centralised communication system was made ineffective through power shortages, equipment failures and linguistic barriers.`,
  ).join(" ");
  const observed = [
    "However, mobile telephone technology is now ubiquitous in developing countries such as Kenya and Bangladesh.",
    "Its application to flood warnings is increasingly evident, but is still seen as underutilised as an effective warning tool.",
    "In a study of a mobile-enabled FEWS in Bangladesh, recipients demonstrated a preference for SMS warnings, particularly using voice SMS or symbols to overcome language and literacy issues.",
    "Mileti theorised that improved flood warning response occurs when sender and receiver characteristics are alike.",
    "This could be adapted to argue that benefits are achieved by aligning the knowledge of sender and receiver.",
    "Disparities of knowledge between disseminators and receivers are addressed in well-resourced systems.",
  ].join(" ");
  const tail = Array.from(
    { length: 20 },
    (_, index) => `Response planning note ${index + 1} says local authorities should collaboratively develop response plans and keep trusted community groups involved before flood season.`,
  ).join(" ");
  const section = lead + observed + " " + tail;
  const chunks = splitLongSection(section);
  const starts = chunks.slice(1).map((chunk) => chunk.slice(0, 140));
  const maxDuplicateOverlap = Math.max(...chunks.slice(1).map((chunk, index) => sharedBoundaryText(chunks[index], chunk).length));

  assert.ok(chunks.length > 1);
  assert.ok(starts.every((start) => !/^ile-enabled\b/i.test(start)));
  assert.ok(starts.every((start) => !/^characteristics are alike\b/i.test(start)));
  assert.ok(starts.every((start) => !/^[a-z][a-z-]+\b/.test(start)));
  assert.ok(maxDuplicateOverlap <= 240, "expected adjacent overlap <= 240 chars, got " + maxDuplicateOverlap);
});

test("uploaded PDF normalization removes layout artifacts and preserves evidence text", async () => {
  const { normalizeUploadedPdfText } = await loadCorpusModule();
  const raw = `# UPLOADED PDF — Community Resilience and Recovery After Major Flood
Journal of Emergency Management Vol. 6, No. 5, September/October 2008 73

--- Page 2 of 10 ---
bers of various nonprofit organizations, business lead-
ers, and religious leaders, as well as vulnerable resi-
dents who were directly affected by the flood.

Procedure
We followed a three-step recruitment process.
First, we contacted public officials.`;

  const normalized = normalizeUploadedPdfText(raw, { title: "Community Resilience and Recovery After Major Flood", sourceFileName: "community.pdf" });

  assert.doesNotMatch(normalized.text, /UPLOADED PDF|--- Page 2 of 10 ---|Journal of Emergency Management/);
  assert.doesNotMatch(normalized.text, /lead-\s*ers|resi-\s*dents/);
  assert.match(normalized.text, /business leaders/);
  assert.match(normalized.text, /vulnerable residents/);
  assert.match(normalized.text, /Procedure We followed a three-step recruitment process\./);
  assert.equal(normalized.metadata.removedPageMarkerCount, 1);
  assert.equal(normalized.metadata.sourceFileName, "community.pdf");
});

test("uploaded PDF normalization removes repeated headers, standalone page labels, ligatures, and fused OCR terms", async () => {
  const { normalizeUploadedPdfText } = await loadCorpusModule();
  const raw = `# UPLOADED PDF — Flood Warning Fixture
FALCON COUNTY FLOOD RESPONSE BULLETIN
Page 12

	Mobile Technologyexclusion and Technologicalexclusion can affect alert access. Resi-
	dents should bring identi\uFB01cation.
	122 Mahala Mclindin
	All Rights Reserved

FALCON COUNTY FLOOD RESPONSE BULLETIN
Page 13`;

  const normalized = normalizeUploadedPdfText(raw, { title: "Flood Warning Fixture", sourceFileName: "fixture.pdf" });

	assert.doesNotMatch(normalized.text, /FALCON COUNTY FLOOD RESPONSE BULLETIN|^Page\s+\d+$/m);
	assert.doesNotMatch(normalized.text, /Technologyexclusion|Technologicalexclusion|identi\uFB01cation|Resi-\s*dents|122 Mahala Mclindin|All Rights Reserved/);
	assert.match(normalized.text, /Technology exclusion/);
	assert.match(normalized.text, /Technological exclusion/);
	assert.match(normalized.text, /Residents should bring identification/);
});

test("uploaded PDF normalization removes figure layout noise and page-author artifacts while preserving body evidence", async () => {
  const { normalizeUploadedPdfText } = await loadCorpusModule();
  const raw = `# UPLOADED PDF — Flood Risk Management Global Case Studies
--- Page 132 of 310 ---
132 Abigail Tevera
I I I --, I Flood identification I ---- ➔ FIGURE 11.1 lnstrums,nt ds,nsity lesSOflsfearnt>d

Mobile flood early warning systems can send alerts before roads close and can help residents prepare to move to safer locations.
Technologyexclusion Technology also plays a role when warning channels are unevenly available.

--- Page 133 of 310 ---
The case study body says communities still need trusted local messengers and clear instructions.`;

  const normalized = normalizeUploadedPdfText(raw, { title: "Flood Risk Management Global Case Studies", sourceFileName: "global-case-studies.pdf" });

  assert.doesNotMatch(normalized.text, /132 Abigail Tevera|FIGURE 11\.1|I I I|lnstrums|ds,nsity|lesSOfls|fearnt>d|➔/);
  assert.doesNotMatch(normalized.text, /Technologyexclusion/);
  assert.match(normalized.text, /Mobile flood early warning systems can send alerts before roads close/);
  assert.match(normalized.text, /Technology exclusion\. Technology also plays a role/);
  assert.match(normalized.text, /trusted local messengers and clear instructions/);
});

test("chunking normalized OCR cleanup preserves body chunks and keeps reference filtering intact", async () => {
  const { normalizeUploadedPdfText, chunkDocument } = await loadCorpusModule();
  const raw = `# UPLOADED PDF — OCR Cleanup Chunk Fixture
--- Page 89 of 200 ---
132 Abigail Tevera
I I I --, I Flood identification I ---- FIGURE 11.1 lnstrums,nt ds,nsity lesSOflsfearnt>d

Mobile flood early warning systems can use SMS alerts, trusted community messengers, and clear evacuation instructions before roads close. This body evidence should remain available for retrieval and answer grounding.

References
Niger making progress towards a flood early warning system, WMO, Geneva. Accessed at https://public.wmo.int/en/media/news/niger-making-progress-towards-flood-early-warning-system
WRI (2018). Flood exposure briefing paper.`;
  const normalized = normalizeUploadedPdfText(raw, { title: "OCR Cleanup Chunk Fixture", sourceFileName: "ocr-cleanup.pdf" });
  const chunks = chunkDocument({
    id: "ocr-cleanup-fixture",
    title: "OCR Cleanup Chunk Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/ocr-cleanup.json",
    source: "uploaded",
    text: normalized.text,
  });
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.ok(chunks.length > 0);
  assert.match(joined, /SMS alerts, trusted community messengers/);
  assert.doesNotMatch(joined, /132 Abigail Tevera|FIGURE 11\.1|lnstrums|lesSOfls|Niger making progress|public\.wmo\.int|WRI \(2018\)/);
});

test("chunking excludes obvious index-only PDF sections but keeps body evidence", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = "Residents should review evacuation routes, prepare go-bags, and confirm shelter timing before flood season. ".repeat(12);
  const index = "Index dredging 81, 83-4 dykes 74, 154-5 early warning systems see warning systems emergency intentional flooding 153-64 resilience 19, 22-3, 62, 66";
  const document = {
    id: "sandbags-upload-fixture",
    title: "Flood Preparedness Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/fixture.json",
    source: "uploaded",
    text: `# Flood Preparedness Fixture\n\n${body}\n\n${index}`,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.ok(chunks.length > 0);
  assert.match(joined, /prepare go-bags/);
  assert.doesNotMatch(joined, /Index dredging/);
});

test("chunking excludes academic reference lists while preserving same-document body evidence", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = [
    "The preparedness curriculum reported that one year after the workshop, 77 percent of respondents reported having personal emergency kits compared with 40 percent at baseline.",
    "The same body section said the training improved practical preparedness activities and confidence for public health workers.",
  ].join(" ").repeat(8);
  const references = [
    "REFERENCES",
    "1. Tate E, Cauwenberghs K: An innovative flood forecasting system for the Demer basin: A case study. Int J River Basin Manag. 2005; 3(4): 1-5.",
    "2. Thielen J, Bartholmes J, Ramos M-H, et al.: The European flood alert system Part 1: Concept and development. Hydrol Earth Syst Sci. 2009; 13: 125-140.",
    "3. Barnett DJ, Thompson CB, Errett NA, et al.: Determinants of emergency response willingness in the local public health workforce. BMC Public Health. 2012; 12(1): 164.",
    "4. Russell LA, Goltz JD, Bourque LB: Preparedness and hazard mitigation actions before and after two earthquakes. Journal of Emergency Management. 1995; 8(2): 31-42.",
  ].join("\n");
  const document = {
    id: "personal-preparedness-fixture",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    domain: "sandbags",
    path: "uploads/sandbags/personal-preparedness.json",
    source: "uploaded",
    text: "# Personal Preparedness Curriculum for Public Health Workers\n\n" + body + "\n\n" + references,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.ok(chunks.length > 0);
  assert.match(joined, /77 percent of respondents reported having personal emergency kits/);
  assert.doesNotMatch(joined, /Tate E, Cauwenberghs K|Barnett DJ, Thompson CB|REFERENCES/);
});

test("chunking splits and excludes short reference sections instead of merging them into body chunks", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = "Flood preparedness teams should publish plain-language pickup rules and update them before storm season. ".repeat(8);
  const references = [
    "References",
    "1. Tate E, Cauwenberghs K: An innovative flood forecasting system for the Demer basin: A case study. Int J River Basin Manag. 2005; 3(4): 1-5.",
    "2. Barnett DJ, Thompson CB, Errett NA, et al.: Determinants of emergency response willingness. BMC Public Health. 2012; 12(1): 164.",
    "3. Russell LA, Goltz JD, Bourque LB: Preparedness actions before and after two earthquakes. Journal of Emergency Management. 1995; 8(2): 31-42.",
  ].join("\n");
  const document = {
    id: "short-reference-split-fixture",
    title: "Short Reference Split Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/short-reference.json",
    source: "uploaded",
    text: "# Short Reference Split Fixture\n\n" + body + "\n\n" + references,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.match(joined, /plain-language pickup rules/);
  assert.doesNotMatch(joined, /Tate E, Cauwenberghs K|References/);
});

test("chunking excludes table-of-contents style sections", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = "Emergency managers should keep resident pickup instructions concise, current, and locally specific. ".repeat(8);
  const toc = "Table of Contents\nIntroduction ........ 1\nWarning Systems ........ 14\nPickup Sites ........ 27\nAppendix A ........ 88";
  const document = {
    id: "toc-fixture",
    title: "TOC Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/toc.json",
    source: "uploaded",
    text: "# TOC Fixture\n\n" + body + "\n\n" + toc,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.match(joined, /resident pickup instructions/);
  assert.doesNotMatch(joined, /Table of Contents|Pickup Sites/);
});

test("chunking does not drop an entire uploaded PDF when references are embedded in one normalized section", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = [
    "Community resilience after a major flood depends on evacuation planning, trusted local organizations, and recovery coordination.",
    "Residents described the need to stay united, work together, and prepare before flood season through practical preparedness steps.",
  ].join(" ").repeat(70);
  const references = [
    "REFERENCES",
    "1. Tate E, Cauwenberghs K: An innovative flood forecasting system for the Demer basin: A case study. Int J River Basin Manag. 2005; 3(4): 1-5.",
    "2. Thielen J, Bartholmes J, Ramos M-H, et al.: The European flood alert system Part 1: Concept and development. Hydrol Earth Syst Sci. 2009; 13: 125-140.",
    "3. Barnett DJ, Thompson CB, Errett NA, et al.: Determinants of emergency response willingness in the local public health workforce. BMC Public Health. 2012; 12(1): 164.",
    "4. Russell LA, Goltz JD, Bourque LB: Preparedness and hazard mitigation actions before and after two earthquakes. Journal of Emergency Management. 1995; 8(2): 31-42.",
  ].join(" ");
  const document = {
    id: "community-resilience-normalized-pdf-fixture",
    title: "Community Resilience and Recovery After Major Flood",
    domain: "sandbags",
    path: "uploads/sandbags/community-resilience.json",
    source: "uploaded",
    text: "# Community Resilience and Recovery After Major Flood " + body + " " + references,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.ok(chunks.length > 0);
  assert.match(joined, /Community resilience after a major flood/);
  assert.doesNotMatch(joined, /Tate E, Cauwenberghs K|Barnett DJ, Thompson CB|REFERENCES/);
});

test("chunking excludes standalone bibliography chunks when the references heading was split away", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = "Flood pickup rules should give residents locally specific instructions before flood season. ".repeat(10);
  const detachedReferences = [
    "Niger making progress towards a flood early warning system, WMO, Geneva. Accessed at https://public.wmo.int/en/media/news/niger-making-progress-towards-flood-early-warning-system",
    "WMO (World Meteorological Organisation) (2018). Multi-hazard Early Warning Systems: A checklist.",
    "Plate, E. (2007). Early warning and flood forecasting for large rivers with the lower Mekong as example. Journal of Hydro-environment Research.",
  ].join(" ");
  const document = {
    id: "detached-reference-fixture",
    title: "Detached Reference Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/detached-reference.json",
    source: "uploaded",
    text: "# Detached Reference Fixture\n\n" + body + "\n\n" + detachedReferences,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.match(joined, /Flood pickup rules/);
  assert.doesNotMatch(joined, /Niger making progress|public\.wmo\.int|World Meteorological Organisation/);
});

test("chunking excludes publication frontmatter and catalog metadata", async () => {
  const { chunkDocument } = await loadCorpusModule();
  const body = "Community flood managers should use the case study body text for planning evidence. ".repeat(10);
  const frontmatter = [
    "All rights reserved. No part of this book may be reprinted or reproduced without permission in writing from the publishers.",
    "Library of Congress Cataloging-in-Publication Data. Identifiers: LCCN 2018043435 ISBN 9781138541900 hardback ISBN 9781351010009 e-book.",
    "Subjects: Flood damage prevention--Case studies. Classification: LCC TC530 .F583 2019. Routledge Taylor & Francis.",
  ].join(" ");
  const document = {
    id: "frontmatter-fixture",
    title: "Frontmatter Fixture",
    domain: "sandbags",
    path: "uploads/sandbags/frontmatter.json",
    source: "uploaded",
    text: "# Frontmatter Fixture\n\n" + body + "\n\n" + frontmatter,
  };

  const chunks = chunkDocument(document);
  const joined = chunks.map((chunk) => chunk.text).join("\n");

  assert.match(joined, /case study body text/);
  assert.doesNotMatch(joined, /All rights reserved|Cataloging-in-Publication|ISBN|Routledge/);
});

test("issue #28 chunk metadata is stable and preserves cleanup provenance", async () => {
  const { chunkDocument, normalizeUploadedPdfText } = await loadCorpusModule();
  const normalized = normalizeUploadedPdfText(
    [
      "# UPLOADED PDF - Community Guide",
      "--- Page 1 of 2 ---",
      "Community warning teams should preserve useful mobile-warning body evidence for retrieval. ".repeat(10),
    ].join("\n"),
    { title: "Community Guide", sourceFileName: "community-guide.pdf" },
  );
  const document = {
    id: "sandbags-upload-community-guide",
    title: "Community Guide",
    domain: "sandbags",
    path: "uploads/sandbags/community-guide.json",
    source: "uploaded",
    sourceFileName: "community-guide.pdf",
    uploadedAt: "2026-05-30T00:00:00.000Z",
    text: normalized.text,
    textMetadata: normalized.metadata,
  };

  const [chunk] = chunkDocument(document);

  assert.equal(chunk.sourcePath, "uploads/sandbags/community-guide.json");
  assert.equal(chunk.contentType, "body");
  assert.equal(chunk.metadata.documentId, document.id);
  assert.equal(chunk.metadata.chunkId, chunk.id);
  assert.equal(chunk.metadata.chunkIndex, 0);
  assert.equal(chunk.metadata.title, "Community Guide");
  assert.equal(chunk.metadata.domain, "sandbags");
  assert.equal(chunk.metadata.source, "uploaded");
  assert.equal(chunk.metadata.sourcePath, "uploads/sandbags/community-guide.json");
  assert.equal(chunk.metadata.sourceFileName, "community-guide.pdf");
  assert.equal(chunk.metadata.contentType, "body");
  assert.equal(chunk.metadata.normalizedPdfText, true);
});

function sharedBoundaryText(left, right) {
  const tail = left.slice(-500);
  for (let length = Math.min(tail.length, right.length); length > 0; length -= 1) {
    if (right.startsWith(tail.slice(tail.length - length))) return right.slice(0, length);
  }
  return "";
}
