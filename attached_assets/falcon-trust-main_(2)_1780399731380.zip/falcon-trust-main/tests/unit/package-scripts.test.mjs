import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("package exposes the base CI scripts", async () => {
  const packageJson = JSON.parse(await readFile(new URL("../../package.json", import.meta.url), "utf8"));

  for (const scriptName of ["build", "lint", "typecheck", "test", "test:unit", "test:rag", "test:e2e", "test:e2e:ci", "test:ci"]) {
    assert.equal(typeof packageJson.scripts?.[scriptName], "string", "missing script: " + scriptName);
    assert.notEqual(packageJson.scripts[scriptName].trim(), "", "empty script: " + scriptName);
  }
});
