import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import ts from "typescript";
import test from "node:test";

async function loadRankingModule() {
  const source = await readFile(new URL("../../src/lib/falcon/retrieval-ranking.ts", import.meta.url), "utf8");
  const output = ts.transpileModule(source, {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2022,
      esModuleInterop: true,
    },
  }).outputText;
  const cjsModule = { exports: {} };
  const sandbox = {
    module: cjsModule,
    exports: cjsModule.exports,
  };
  vm.runInNewContext(output, sandbox, { filename: "retrieval-ranking.cjs" });
  return cjsModule.exports;
}

test("issue #29 reranks useful mobile-warning body evidence above figure/layout residue", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "What does the corpus say about mobile flood early warning systems?";
  const usefulBody = rankEvidenceCandidate({
    query,
    baseScore: 0.42,
    contentType: "body",
    title: "Flood Risk Management Global Case Studies",
    text: "However, this is not always achievable because the degree of success of a flood warning system is dependent on technical and human factors. Mobile telephone technology is increasingly evident in flood warnings.",
    metadata: metadata(),
  });
  const figureResidue = rankEvidenceCandidate({
    query,
    baseScore: 0.5,
    contentType: "body",
    title: "Flood Risk Management Global Case Studies",
    text: "Figure 10 shows the pros and cons of the current flood warning system in Japan, and the cross analysis is given as follows: Leverage strengths opportunities.",
    metadata: metadata(),
  });

  assert.ok(usefulBody.adjustedScore > figureResidue.adjustedScore);
  assert.ok(usefulBody.factors.includes("body-evidence"));
  assert.ok(figureResidue.factors.includes("figure-layout-penalty"));
});

test("issue #29 downranks copyright/frontmatter leakage even when lexical score is high", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "What should residents know about sandbag pickup rules?";
  const pickupBody = rankEvidenceCandidate({
    query,
    baseScore: 0.33,
    contentType: "body",
    title: "Sandbag Pickup Bulletin",
    text: "Residents should bring identification to the sandbag pickup site and check posted pickup hours before arriving.",
    metadata: metadata(),
  });
  const copyrightLeak = rankEvidenceCandidate({
    query,
    baseScore: 0.46,
    contentType: "body",
    title: "Current Flood Warning System in Japan and Evacuation Effectiveness",
    text: "Please visit www.copyright.com for additional licensing options. 63 needed for preparing evacuation, the longer is the lead time required.",
    metadata: metadata(),
  });

  assert.ok(pickupBody.adjustedScore > copyrightLeak.adjustedScore);
  assert.ok(copyrightLeak.factors.includes("frontmatter-copyright-penalty"));
});

test("issue #29 preserves unsupported/no behavior by not rewarding citation count alone", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "Do sandbags prevent all flood damage?";
  const weakReference = rankEvidenceCandidate({
    query,
    baseScore: 0.38,
    contentType: "body",
    title: "Flood Risk Management Global Case Studies",
    text: "GDV Association of German Insurers 2016. Die wichtigsten Umfrageergebnisse zum Naturgefahrenschutz im Uberblick. Accessed at https://example.invalid/reference.",
    metadata: metadata(),
  });
  const limitedBody = rankEvidenceCandidate({
    query,
    baseScore: 0.28,
    contentType: "body",
    title: "Sandbag Use Guidance",
    text: "Sandbags may help reduce minor water intrusion when placed correctly, but they do not guarantee complete protection from deep flooding or structural damage.",
    metadata: metadata(),
  });

  assert.ok(limitedBody.adjustedScore > weakReference.adjustedScore);
  assert.ok(weakReference.factors.includes("bibliographic-reference-penalty"));
  assert.ok(!limitedBody.factors.includes("frontmatter-copyright-penalty"));
});

test("FEMA Ready campaign direct evidence outranks adjacent FEMA workshop material", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "What is FEMA's Ready campaign and what are its three key components?";
  const readyCampaign = rankEvidenceCandidate({
    query,
    baseScore: 0.2,
    contentType: "body",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    text: "The Federal Emergency Management Agency (FEMA) launched its national Ready campaign in 2003. The campaign aims to increase public awareness and participation in disaster preparedness throughout the United States. Ready promotes three preparedness activities about different types of emergencies and their appropriate responses: get a kit, make a plan and be informed.",
    metadata: metadata(),
  });
  const workshopMaterials = rankEvidenceCandidate({
    query,
    baseScore: 0.55,
    contentType: "body",
    title: "Personal Preparedness Curriculum for Public Health Workers",
    text: "JH-CPHP experts adapted existing FEMA Ready content into an interactive, public health-specific, face-to-face module. JH-CPHP's experts tailored existing FEMA materials into a public health-specific context and developed a scenario-based exercise.",
    metadata: metadata(),
  });

  assert.ok(readyCampaign.adjustedScore > workshopMaterials.adjustedScore);
  assert.ok(readyCampaign.factors.includes("direct-query-coverage"));
  assert.ok(readyCampaign.factors.includes("list-answer-evidence"));
  assert.ok(readyCampaign.factors.includes("definition-purpose-evidence"));
  assert.equal(readyCampaign.factors.some((factor) => factor.includes("ready-campaign")), false);
});

test("direct evidence boost stays bounded and uses general list evidence signals", async () => {
  const { directEvidenceBoost } = await loadRankingModule();
  const boost = directEvidenceBoost({
    query: "What are the three key components of the public preparedness campaign?",
    title: "Preparedness Curriculum",
    text: "The campaign aims to increase public awareness and participation in preparedness. It promotes three preparedness activities: get supplies, make a plan, and stay informed.",
  });

  assert.ok(boost.score > 0);
  assert.ok(boost.score <= 0.7);
  assert.ok(boost.factors.includes("list-answer-evidence"));
  assert.equal(boost.factors.some((factor) => /ready|fema/i.test(factor)), false);
});

test("contract review term evidence can enter the candidate pool despite weak vector rank", async () => {
  const { directEvidenceBoost, rankEvidenceCandidate } = await loadRankingModule();
  const query = "What contract terms should emergency managers scrutinize in standardized vendor contracts?";
  const contractTerms = "Sometimes, the contract officer will be tempted to use the contractor's document as is, because it means less work. One must be extremely careful in reviewing such texts and be ready to delete unacceptable language. These documents are often worded to contain indemnification requirements, waivers of inadequate performance, arbitration clauses, and other language that dilutes the obligations of the contractor. They may also include requirements that are contrary to state or local law. The emergency manager and attorney should carefully scrutinize the contents of standardized contracts. Performance standards are one key part of drafting a contract.";
  const ordinanceDuties = "State emergency management law typically relates to setting up agencies, specifying local organization roles, assigning authority to declare an emergency, mutual aid, drafting plans, evacuation, emergency welfare services, and warning services.";

  const direct = directEvidenceBoost({
    query,
    title: "Legal Duties and Emergency Management Contracts",
    text: contractTerms,
  });
  const rankedTerms = rankEvidenceCandidate({
    query,
    baseScore: 0.32,
    contentType: "body",
    title: "Legal Duties and Emergency Management Contracts",
    text: contractTerms,
    metadata: metadata(),
  });
  const rankedOrdinance = rankEvidenceCandidate({
    query,
    baseScore: 0.6,
    contentType: "body",
    title: "Legal Duties and Emergency Management Contracts",
    text: ordinanceDuties,
    metadata: metadata(),
  });

  assert.ok(direct.score >= 0.45);
  assert.ok(direct.factors.includes("contract-review-term-evidence"));
  assert.ok(rankedTerms.adjustedScore > rankedOrdinance.adjustedScore);
});

test("runtime ranking demotes journal frontmatter/ad residue below body evidence", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "What is the special issue about and why are emergency managers connected to climate change and sustainability?";
  const bodyEvidence = rankEvidenceCandidate({
    query,
    baseScore: 0.62,
    contentType: "body",
    title: "JEM 2024 Special Issue",
    text: "Special Issue on Climate Change and Sustainability in Emergency Management. Emergency managers can minimize the likelihood and severity of climate-induced disasters while promoting long-term environmental stewardship and prioritizing equity in climate adaptation and mitigation efforts.",
    metadata: metadata(),
  });
  const frontmatterAd = rankEvidenceCandidate({
    query,
    baseScore: 0.72,
    contentType: "body",
    title: "JEM 2024 Special Issue",
    text: "# UPLOADED DEMO PDF — JEM 2024 Special Issue Volume 21, Number 7 ISSN 1543-5865 --- Page 1 of 126 --- Now is the time for climate action. Visit our website to learn how your organization can take action. www.example.com Copyright 2023 Example Development LLC. All rights reserved.",
    metadata: metadata(),
  });

  assert.ok(bodyEvidence.adjustedScore > frontmatterAd.adjustedScore);
  assert.ok(frontmatterAd.factors.includes("journal-frontmatter-ad-penalty"));
});

test("runtime ranking mildly demotes OCR-hyphenated evidence when cleaner equivalent evidence exists", async () => {
  const { rankEvidenceCandidate } = await loadRankingModule();
  const query = "What did the implementation report say about sustainability?";
  const cleanEvidence = rankEvidenceCandidate({
    query,
    baseScore: 0.42,
    contentType: "body",
    title: "Implementation Report",
    text: "The report says implementation planning improved sustainability outcomes across the program.",
    metadata: metadata(),
  });
  const hyphenatedEvidence = rankEvidenceCandidate({
    query,
    baseScore: 0.46,
    contentType: "body",
    title: "Implementation Report",
    text: "The report says implemen- tation planning improved sustain- ability outcomes across the program.",
    metadata: metadata(),
  });

  assert.ok(cleanEvidence.adjustedScore > hyphenatedEvidence.adjustedScore);
  assert.ok(hyphenatedEvidence.factors.includes("ocr-hyphenation-penalty"));
});

test("direct evidence boost does not treat title-only phrase matches as substantive evidence", async () => {
  const { directEvidenceBoost } = await loadRankingModule();
  const titleOnly = directEvidenceBoost({
    query: "What does the JEM special issue say about Deloitte climate action?",
    title: "JEM 2024 Special Issue",
    text: "JEM Editorial Board. C. Ryan Akers, PhD. Barbara Audley, DPA. Paul Barnes, PhD.",
  });
  const bodyMatch = directEvidenceBoost({
    query: "What does the JEM special issue say about Deloitte climate action?",
    title: "JEM 2024 Special Issue",
    text: "Now is the time for climate action. Deloitte's knowledge and tools support organizations' climate resilience planning and help mitigate climate change impacts.",
  });

  assert.ok(bodyMatch.score > titleOnly.score);
  assert.equal(titleOnly.factors.includes("exact-phrase-overlap"), false);
});

function metadata() {
  return {
    documentId: "sandbags-upload-fixture",
    chunkId: "sandbags-upload-fixture-chunk-1",
    title: "Fixture",
    domain: "sandbags",
    sourcePath: "uploads/sandbags/fixture.json",
    contentType: "body",
  };
}
