"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = { id: string; name: string; description: string };
type DocumentSummary = { id: string; title: string; domain: string; path: string; chunkCount: number };
type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};
type AdminSession = {
  id: string;
  mode: string;
  query: string;
  selectedDomains: string[];
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: { title: string; domain: string; snippet: string; score: number }[];
  createdAt: string;
};

export default function AdminPage() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [history, setHistory] = useState<AdminSession[]>([]);
  const [adminLoading, setAdminLoading] = useState(true);
  const [uploadDomain, setUploadDomain] = useState("law");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [articleConfig, setArticleConfig] = useState<ArticleConfig | null>(null);
  const [articleMessage, setArticleMessage] = useState<string | null>(null);
  const [savingArticle, setSavingArticle] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAdmin() {
    const [corpusRes, historyRes, configRes] = await Promise.all([fetch("/api/corpus"), fetch("/api/admin/history"), fetch("/api/admin/article-config")]);
    if (!corpusRes.ok) throw new Error("Failed to load corpus");
    if (!historyRes.ok) throw new Error("Failed to load history");
    if (!configRes.ok) throw new Error("Failed to load article config");
    const corpus = await corpusRes.json();
    const historyData = await historyRes.json();
    const configData = await configRes.json();
    setDomains(corpus.domains);
    setDocuments(corpus.documents);
    setHistory(historyData.sessions);
    setArticleConfig(configData.config);
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadAdmin()
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize admin"))
        .finally(() => setAdminLoading(false));
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const totalChunks = useMemo(() => documents.reduce((sum, doc) => sum + doc.chunkCount, 0), [documents]);

  async function saveArticleConfig(event: React.FormEvent) {
    event.preventDefault();
    if (!articleConfig) return;
    setSavingArticle(true);
    setError(null);
    setArticleMessage(null);
    try {
      const res = await fetch("/api/admin/article-config", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(articleConfig),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setArticleConfig(data.config);
      setArticleMessage("Article generator settings saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save article config");
    } finally {
      setSavingArticle(false);
    }
  }

  async function submitUpload(event: React.FormEvent) {
    event.preventDefault();
    if (!uploadFile) {
      setUploadMessage("Choose a text-based PDF first.");
      return;
    }
    setUploading(true);
    setError(null);
    setUploadMessage(null);
    try {
      const form = new FormData();
      form.set("domain", uploadDomain);
      form.set("file", uploadFile);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setUploadMessage(`Uploaded and indexed: ${data.document.title}`);
      setUploadFile(null);
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <div className="mx-auto w-full max-w-7xl px-4 py-5 sm:px-6 lg:px-10">
        <nav className="mb-8 flex flex-col gap-4 rounded-[28px] border border-[var(--line)] bg-[var(--surface)] px-5 py-5 shadow-[var(--shadow)] backdrop-blur md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] text-lg font-bold text-[var(--navy)]">
              FT
            </div>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-[var(--blue)]">Falcon Trust Limited Demo</p>
              <h1 className="mt-1 text-xl font-semibold text-[var(--navy)]">Admin Operations Console</h1>
              <p className="mt-1 text-sm text-slate-600">Document intake, article settings, and review history for the civic command-center skin.</p>
            </div>
          </div>
          <div className="flex items-center gap-3 self-start rounded-full border border-[var(--line)] bg-white px-1.5 py-1.5 text-sm shadow-sm">
            <Link href="/" className="rounded-full px-5 py-2 font-medium text-slate-600 transition hover:bg-[var(--blue-pale)] hover:text-[var(--navy)]">Search</Link>
            <span className="rounded-full bg-[var(--navy)] px-5 py-2 font-semibold text-white">Admin</span>
          </div>
        </nav>

        {error && <div className="mb-6 rounded-2xl border border-[rgba(177,72,87,0.22)] bg-[var(--danger)] p-4 text-sm text-[#7b2431]">{error}</div>}

        <section className="grid gap-4 md:grid-cols-3">
          <Metric label="Domains" value={adminLoading ? "Loading…" : String(domains.length)} detail="Selectable search scopes" />
          <Metric label="Documents" value={adminLoading ? "Loading…" : String(documents.length)} detail="Preloaded + uploaded" />
          <Metric label="Chunks" value={adminLoading ? "Loading…" : String(totalChunks)} detail="Retrieved citation units" />
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="space-y-6">
            <form onSubmit={submitUpload} className="rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-sm">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm uppercase tracking-[0.2em] text-[var(--blue)]">Local corpus management</p>
                  <h2 className="mt-2 text-2xl font-semibold text-[var(--navy)]">Upload text-based PDF</h2>
                </div>
                <span className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-1 text-xs font-medium text-[var(--navy)]">Limited demo only</span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-600">Files are extracted into .demo-data and included in retrieval. Keep uploads to simple text-based PDFs; scanned/image-only PDFs remain intentionally out of scope.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-[0.8fr_1.2fr]">
                <select value={uploadDomain} onChange={(event) => setUploadDomain(event.target.value)} className="rounded-2xl border border-[var(--line)] bg-white px-4 py-3 text-sm text-[var(--foreground)] outline-none focus:border-[var(--blue)] focus:ring-4 focus:ring-[rgba(46,111,174,0.14)]">
                  {domains.map((domain) => <option key={domain.id} value={domain.id}>{domain.name}</option>)}
                </select>
                <input type="file" accept="application/pdf,.pdf" onChange={(event) => setUploadFile(event.target.files?.[0] ?? null)} className="rounded-2xl border border-[var(--line)] bg-white px-4 py-3 text-sm text-slate-700 file:mr-4 file:rounded-full file:border-0 file:bg-[var(--navy)] file:px-3 file:py-1 file:text-sm file:font-semibold file:text-white" />
              </div>
              <button type="submit" disabled={uploading} className="mt-4 w-full rounded-2xl bg-[var(--blue)] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[var(--navy)] disabled:cursor-not-allowed disabled:opacity-60">
                {uploading ? "Extracting and indexing PDF..." : "Upload and index PDF locally"}
              </button>
              {uploadMessage && <p className="mt-3 rounded-xl border border-[rgba(56,122,87,0.18)] bg-[var(--success)] p-3 text-sm text-[#1f5b40]">{uploadMessage}</p>}
            </form>

            <div className="rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-sm">
              <p className="text-sm uppercase tracking-[0.2em] text-[var(--blue)]">Domains</p>
              <div className="mt-5 space-y-3">
                {domains.map((domain) => {
                  const domainDocs = documents.filter((doc) => doc.domain === domain.id);
                  const chunks = domainDocs.reduce((sum, doc) => sum + doc.chunkCount, 0);
                  return (
                    <article key={domain.id} className="rounded-2xl border border-[var(--line)] bg-white p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold text-[var(--navy)]">{domain.name}</h3>
                          <p className="mt-1 text-sm leading-6 text-slate-600">{domain.description}</p>
                        </div>
                        <div className="rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-2 text-right text-sm text-slate-600"><div>{domainDocs.length} docs</div><div>{chunks} chunks</div></div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {articleConfig && (
              <form onSubmit={saveArticleConfig} className="rounded-[28px] border border-[rgba(46,111,174,0.2)] bg-[var(--surface)] p-6 shadow-sm">
                <p className="text-sm uppercase tracking-[0.2em] text-[var(--blue)]">Article configurator</p>
                <h2 className="mt-2 text-2xl font-semibold text-[var(--navy)]">Create Article settings</h2>
                <p className="mt-2 text-sm leading-6 text-slate-600">Controls the local Ollama prompt used when the Search page is set to Create Article.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <Field label="Ollama endpoint" value={articleConfig.endpoint} onChange={(value) => setArticleConfig({ ...articleConfig, endpoint: value })} />
                  <Field label="Model" value={articleConfig.model} onChange={(value) => setArticleConfig({ ...articleConfig, model: value })} />
                  <Field label="Audience" value={articleConfig.audience} onChange={(value) => setArticleConfig({ ...articleConfig, audience: value })} />
                  <Field label="Tone" value={articleConfig.tone} onChange={(value) => setArticleConfig({ ...articleConfig, tone: value })} />
                  <label className="text-sm text-slate-600">
                    Length
                    <select value={articleConfig.length} onChange={(event) => setArticleConfig({ ...articleConfig, length: event.target.value as ArticleConfig["length"] })} className="mt-1 w-full rounded-2xl border border-[var(--line)] bg-white px-4 py-3 text-sm text-[var(--foreground)] outline-none focus:border-[var(--blue)] focus:ring-4 focus:ring-[rgba(46,111,174,0.14)]">
                      <option value="short">Short</option>
                      <option value="medium">Medium</option>
                      <option value="long">Long</option>
                    </select>
                  </label>
                  <label className="flex items-center gap-3 rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] px-4 py-3 text-sm text-slate-700">
                    <input type="checkbox" checked={articleConfig.includeCitations} onChange={(event) => setArticleConfig({ ...articleConfig, includeCitations: event.target.checked })} />
                    Include inline citation markers
                  </label>
                </div>
                <TextAreaField label="Structure" value={articleConfig.structure} onChange={(value) => setArticleConfig({ ...articleConfig, structure: value })} />
                <TextAreaField label="Extra instructions" value={articleConfig.extraInstructions} onChange={(value) => setArticleConfig({ ...articleConfig, extraInstructions: value })} />
                <button type="submit" disabled={savingArticle} className="mt-4 w-full rounded-2xl bg-[var(--blue)] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[var(--navy)] disabled:cursor-not-allowed disabled:opacity-60">
                  {savingArticle ? "Saving article settings..." : "Save article configurator"}
                </button>
                {articleMessage && <p className="mt-3 rounded-xl border border-[rgba(56,122,87,0.18)] bg-[var(--success)] p-3 text-sm text-[#1f5b40]">{articleMessage}</p>}
              </form>
            )}

            <div className="rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-sm">
              <div className="flex items-center justify-between gap-4">
                <p className="text-sm uppercase tracking-[0.2em] text-[var(--blue)]">Documents</p>
                <span className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-1 text-xs text-[var(--navy)]">Indexed corpus</span>
              </div>
              <div className="mt-5 space-y-3">
                {documents.map((doc) => (
                  <div key={doc.id} className="rounded-2xl border border-[var(--line)] bg-white p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div><h3 className="font-medium text-[var(--navy)]">{doc.title}</h3><p className="mt-1 text-sm text-slate-500">{domainName(domains, doc.domain)} · {doc.chunkCount} chunks</p></div>
                      <span className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-1 text-xs text-[var(--navy)]">Indexed</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-sm">
              <div className="flex items-center justify-between gap-4">
                <p className="text-sm uppercase tracking-[0.2em] text-[var(--blue)]">Query history</p>
                <span className="rounded-full border border-[var(--line)] bg-white px-3 py-1 text-xs text-slate-500">Last 8 sessions</span>
              </div>
              <div className="mt-5 space-y-4">
                {history.length === 0 ? <p className="text-sm text-slate-500">No queries recorded yet.</p> : history.slice(0, 8).map((item) => (
                  <article key={item.id} className="rounded-3xl border border-[var(--line)] bg-white p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div><p className="text-xs uppercase tracking-[0.18em] text-[var(--blue)]">{item.mode}</p><h3 className="mt-1 font-semibold text-[var(--navy)]">{item.query}</h3></div>
                      <span className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-2 py-1 text-xs text-slate-500">{new Date(item.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="mt-3 text-sm leading-6 text-slate-600">{item.answer}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="text-sm text-slate-600">
      {label}
      <input value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 w-full rounded-2xl border border-[var(--line)] bg-white px-4 py-3 text-sm text-[var(--foreground)] outline-none focus:border-[var(--blue)] focus:ring-4 focus:ring-[rgba(46,111,174,0.14)]" />
    </label>
  );
}

function TextAreaField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="mt-4 block text-sm text-slate-600">
      {label}
      <textarea value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 min-h-24 w-full rounded-2xl border border-[var(--line)] bg-white px-4 py-3 text-sm leading-6 text-[var(--foreground)] outline-none focus:border-[var(--blue)] focus:ring-4 focus:ring-[rgba(46,111,174,0.14)]" />
    </label>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-5 shadow-sm"><p className="text-sm text-slate-500">{label}</p><p className="mt-2 text-3xl font-semibold text-[var(--navy)]">{value}</p><p className="mt-2 text-sm text-slate-600">{detail}</p></div>;
}

function domainName(domains: Domain[], id: string) {
  return domains.find((domain) => domain.id === id)?.name ?? id;
}
