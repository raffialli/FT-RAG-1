import { NextResponse } from "next/server";
import { readArticleConfig, writeArticleConfig } from "@/lib/falcon/article-config";

export async function GET() {
  return NextResponse.json({ config: readArticleConfig() });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const config = writeArticleConfig(body);
  return NextResponse.json({ config });
}
