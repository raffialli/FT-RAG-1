import { NextResponse } from "next/server";
import { readHistory } from "@/lib/falcon/history";

export function GET() {
  return NextResponse.json({ sessions: readHistory() });
}
