import { NextResponse } from "next/server";
import { DOMAINS, chunkDocument, loadDocuments } from "@/lib/falcon/corpus";

export function GET() {
  const documents = loadDocuments().map((document) => ({
    id: document.id,
    title: document.title,
    domain: document.domain,
    path: document.path,
    chunkCount: chunkDocument(document).length,
  }));

  return NextResponse.json({ domains: DOMAINS, documents });
}
