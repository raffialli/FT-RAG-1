import { NextResponse } from "next/server";
import { normalizeDomains } from "@/lib/falcon/corpus";
import { generateArticleDraft } from "@/lib/falcon/article-generator";
import { appendHistory } from "@/lib/falcon/history";
import { buildAnswer } from "@/lib/falcon/retrieval";
import type { AnswerType } from "@/lib/falcon/types";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const query = typeof body.query === "string" ? body.query.trim() : "";
  if (!query) return new NextResponse("Missing query", { status: 400 });

  const selectedDomains = normalizeDomains(body.domains);
  const answerType: AnswerType = body.answerType === "create_article" ? "create_article" : "clear_answer";
  const base = buildAnswer(query, selectedDomains, "internal_qa", answerType);

  if (answerType === "create_article" && base.citations.length > 0) {
    const generated = await generateArticleDraft({ query, citations: base.citations, fallbackAnswer: base.answer });
    const session = appendHistory({
      ...base,
      answer: generated.answer,
      generatedBy: generated.generatedBy,
      articleConfig: generated.config,
      gaps: "warning" in generated ? [...(base.gaps ?? []), `Article generation warning: ${generated.warning}`] : base.gaps,
    });
    return NextResponse.json(session);
  }

  const session = appendHistory(base);
  return NextResponse.json(session);
}
