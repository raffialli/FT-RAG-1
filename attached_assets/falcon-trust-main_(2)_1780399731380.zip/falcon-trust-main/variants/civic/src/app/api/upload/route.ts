import { NextResponse } from "next/server";
import { PDFParse } from "pdf-parse";
import { isDomainId, writeUploadedDocument } from "@/lib/falcon/corpus";

export async function POST(request: Request) {
  const form = await request.formData();
  const domain = form.get("domain");
  const file = form.get("file");

  if (!isDomainId(domain)) {
    return new NextResponse("Domain must be law or sandbags", { status: 400 });
  }

  if (!(file instanceof File)) {
    return new NextResponse("Missing PDF file", { status: 400 });
  }

  if (!file.name.toLowerCase().endsWith(".pdf") && file.type !== "application/pdf") {
    return new NextResponse("Only text-based PDF uploads are supported in the limited demo", { status: 400 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const text = await extractPdfText(buffer);

  if (text.length < 40) {
    return new NextResponse("No usable text found. The limited demo supports text-based PDFs only; OCR is out of scope.", {
      status: 422,
    });
  }

  const title = file.name.replace(/\.pdf$/i, "").replace(/[-_]+/g, " ");
  const record = writeUploadedDocument({ domain, title, text: `# UPLOADED DEMO PDF — ${title}\n\n${text}`, sourceFileName: file.name });
  return NextResponse.json({ document: record });
}

async function extractPdfText(buffer: Buffer) {
  try {
    const parser = new PDFParse({ data: buffer });
    try {
      const result = await parser.getText();
      return result.text.trim();
    } finally {
      await parser.destroy();
    }
  } catch {
    return extractSimplePdfLiterals(buffer);
  }
}

function extractSimplePdfLiterals(buffer: Buffer) {
  // Controlled limited-demo fallback: enough for simple text PDFs generated for the demo.
  // It is not OCR and not a full PDF parser.
  const raw = buffer.toString("latin1");
  const matches = Array.from(raw.matchAll(/\(([^()]{3,})\)\s*Tj/g)).map((match) => decodePdfLiteral(match[1]));
  const arrayMatches = Array.from(raw.matchAll(/\[((?:\s*\([^()]*\)\s*)+)\]\s*TJ/g)).flatMap((match) =>
    Array.from(match[1].matchAll(/\(([^()]*)\)/g)).map((part) => decodePdfLiteral(part[1])),
  );
  return [...matches, ...arrayMatches].join(" ").replace(/\s+/g, " ").trim();
}

function decodePdfLiteral(value: string) {
  return value
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\");
}
