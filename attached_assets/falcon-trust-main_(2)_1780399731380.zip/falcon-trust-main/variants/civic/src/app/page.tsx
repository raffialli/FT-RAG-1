"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = {
  id: string;
  name: string;
  description: string;
};

type Citation = {
  documentId: string;
  title: string;
  domain: string;
  snippet: string;
  score: number;
};

type AnswerType = "clear_answer" | "create_article";

type QueryResponse = {
  id: string;
  query: string;
  selectedDomains: string[];
  answerType: AnswerType;
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  createdAt: string;
};

const examplePrompts = [
  "What should we say about sandbag pickup rules before a flood?",
  "What legal or public-claims risks should we keep in mind when writing about sandbags?",
  "Do these documents prove sandbags prevent all flood damage?",
];

export default function Home() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<string[]>(["law", "sandbags"]);
  const [query, setQuery] = useState("What should we say about sandbag pickup rules before a flood?");
  const [answerType, setAnswerType] = useState<AnswerType>("clear_answer");
  const [result, setResult] = useState<QueryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetch("/api/corpus")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to load domains");
          return res.json();
        })
        .then((data) => setDomains(data.domains))
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize demo"));
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  const selectedLabel = useMemo(
    () => selectedDomains.map((id) => domains.find((domain) => domain.id === id)?.name ?? id).join(" • "),
    [domains, selectedDomains],
  );

  function toggleDomain(domainId: string) {
    setSelectedDomains((current) => {
      if (current.includes(domainId)) {
        const next = current.filter((id) => id !== domainId);
        return next.length ? next : current;
      }
      return [...current, domainId];
    });
  }

  async function submitQuery(event?: React.FormEvent) {
    event?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/query", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query, domains: selectedDomains, answerType }),
      });
      if (!res.ok) throw new Error(await res.text());
      setResult(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Query failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-4 py-5 sm:px-6 lg:px-10">
        <nav className="mb-8 flex flex-col gap-4 rounded-[28px] border border-[var(--line)] bg-[var(--surface)] px-5 py-5 shadow-[var(--shadow)] backdrop-blur md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] text-lg font-bold text-[var(--navy)]">
              FT
            </div>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-[var(--blue)]">Falcon Trust Limited Demo</p>
              <h1 className="mt-1 text-xl font-semibold text-[var(--navy)]">Civic Research Command Center</h1>
              <p className="mt-1 text-sm text-slate-600">Trusted internal workspace for public-facing communications review.</p>
            </div>
          </div>
          <div className="flex items-center gap-3 self-start rounded-full border border-[var(--line)] bg-white px-1.5 py-1.5 text-sm shadow-sm">
            <span className="rounded-full bg-[var(--navy)] px-5 py-2 font-semibold text-white">Search</span>
            <Link href="/admin" className="rounded-full px-5 py-2 font-medium text-slate-600 transition hover:bg-[var(--blue-pale)] hover:text-[var(--navy)]">
              Admin
            </Link>
          </div>
        </nav>

        <section className="grid flex-1 gap-6 lg:grid-cols-[1.2fr_0.8fr] lg:items-start">
          <div className="rounded-[32px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-[var(--shadow)] md:p-8">
            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-[var(--blue)]">
                Public service communications
              </div>
              <div className="rounded-full border border-[var(--line)] bg-white px-3 py-1 text-xs text-slate-600">
                Citation-grounded limited demo
              </div>
            </div>

            <h2 className="mt-5 max-w-3xl text-4xl font-semibold tracking-tight text-[var(--navy)] md:text-5xl">
              Draft safer, clearer answers from approved Falcon Trust document sets.
            </h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-slate-600 md:text-lg">
              Select the policy domains you want included, ask a question, and review grounded snippets before publishing any public guidance.
            </p>

            <div className="mt-6 grid gap-4 md:grid-cols-3">
              <InfoCard title="Scope-controlled" body="Keep responses constrained to the selected policy and operations domains." />
              <InfoCard title="Evidence first" body="Every answer returns source snippets so reviewers can verify claims fast." />
              <InfoCard title="Demo-safe" body="Search and draft flows stay local for this limited evaluation environment." />
            </div>

            <form onSubmit={submitQuery} className="mt-8 rounded-[28px] border border-[var(--line)] bg-white p-4 shadow-sm md:p-5">
              <div>
                <p className="text-sm font-semibold text-[var(--navy)]">Choose active domains</p>
                <p className="mt-1 text-sm text-slate-500">At least one domain must remain selected.</p>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {domains.map((domain) => {
                  const selected = selectedDomains.includes(domain.id);
                  return (
                    <button
                      key={domain.id}
                      type="button"
                      onClick={() => toggleDomain(domain.id)}
                      className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
                        selected
                          ? "border-[var(--navy)] bg-[var(--navy)] text-white shadow-sm"
                          : "border-[var(--line)] bg-[var(--blue-pale)] text-[var(--navy)] hover:border-[var(--blue)] hover:bg-white"
                      }`}
                      aria-pressed={selected}
                    >
                      {domain.name}
                    </button>
                  );
                })}
              </div>

              <div className="mt-5 grid gap-3 border-t border-[var(--line)] pt-5 md:grid-cols-2">
                <AnswerTypeButton
                  active={answerType === "clear_answer"}
                  title="Clear answer"
                  description="Direct, reviewer-friendly response"
                  onClick={() => setAnswerType("clear_answer")}
                />
                <AnswerTypeButton
                  active={answerType === "create_article"}
                  title="Create article"
                  description="Structured draft for public comms"
                  onClick={() => setAnswerType("create_article")}
                />
              </div>

              <label className="mt-5 block text-sm font-semibold text-[var(--navy)]">
                Research prompt
                <textarea
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  className="mt-2 min-h-44 w-full resize-y rounded-[24px] border border-[var(--line)] bg-[var(--blue-pale)] p-5 text-base leading-7 text-[var(--foreground)] outline-none placeholder:text-slate-500 focus:border-[var(--blue)] focus:bg-white focus:ring-4 focus:ring-[rgba(46,111,174,0.14)]"
                  placeholder="Ask a question or paste a topic for comparison..."
                />
              </label>

              <div className="mt-4 flex flex-col gap-3 rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] px-4 py-3 md:flex-row md:items-center md:justify-between">
                <p className="text-sm text-slate-600">
                  Active search lanes: <span className="font-semibold text-[var(--navy)]">{selectedLabel || "selected domains"}</span>
                </p>
                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-2xl bg-[var(--blue)] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[var(--navy)] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loading ? "Searching..." : answerType === "create_article" ? "Create article" : "Get clear answer"}
                </button>
              </div>
            </form>

            <div className="mt-6 flex flex-wrap gap-2">
              {examplePrompts.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => setQuery(prompt)}
                  className="rounded-full border border-[var(--line)] bg-white px-3 py-2 text-xs text-slate-600 transition hover:border-[var(--blue)] hover:text-[var(--navy)]"
                >
                  {prompt}
                </button>
              ))}
            </div>

            {error && <div className="mt-6 rounded-2xl border border-[rgba(177,72,87,0.22)] bg-[var(--danger)] p-4 text-sm text-[#7b2431]">{error}</div>}

            {result && <div className="mt-6"><ResultPanel result={result} /></div>}
          </div>

          <aside className="space-y-5">
            <SidebarCard title="Review workflow" tone="navy">
              <ol className="space-y-3 text-sm leading-6 text-slate-600">
                <li><span className="font-semibold text-[var(--navy)]">1.</span> Select the domains relevant to the public question.</li>
                <li><span className="font-semibold text-[var(--navy)]">2.</span> Choose direct answer or article draft mode.</li>
                <li><span className="font-semibold text-[var(--navy)]">3.</span> Validate returned citations before reuse.</li>
              </ol>
            </SidebarCard>
            <SidebarCard title="Environment posture" tone="blue">
              <p className="text-sm leading-6 text-slate-600">
                This skin is tuned for a government-style command center: clear hierarchy, calm color cues, and accessible contrast for review work.
              </p>
            </SidebarCard>
            <SidebarCard title="Operator notes" tone="teal">
              <p className="text-sm leading-6 text-slate-600">
                Search and Admin retain the same behavior and APIs. This variant changes presentation only for the Falcon Trust limited demo.
              </p>
            </SidebarCard>
          </aside>
        </section>
      </div>
    </main>
  );
}

function AnswerTypeButton({ active, title, description, onClick }: { active: boolean; title: string; description: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-[24px] border px-4 py-4 text-left transition ${
        active
          ? "border-[var(--navy)] bg-[var(--blue-pale)] text-[var(--navy)] shadow-sm"
          : "border-[var(--line)] bg-white text-slate-600 hover:border-[var(--blue)] hover:text-[var(--navy)]"
      }`}
    >
      <span className="block text-sm font-semibold">{title}</span>
      <span className={`mt-1 block text-xs ${active ? "text-slate-600" : "text-slate-500"}`}>{description}</span>
    </button>
  );
}

function ResultPanel({ result }: { result: QueryResponse }) {
  const resultTitle = result.answerType === "create_article" ? "Article draft" : "Clear answer";
  return (
    <section className="rounded-[28px] border border-[rgba(47,141,163,0.22)] bg-[var(--surface-strong)] p-5 shadow-sm md:p-6">
      <div className="flex flex-col gap-3 border-b border-[var(--line)] pb-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--teal)]">{resultTitle}</p>
          <h3 className="mt-1 text-2xl font-semibold text-[var(--navy)]">{result.confidence} confidence</h3>
          {result.generatedBy && <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">Generated by {result.generatedBy === "ollama" ? "local Ollama" : result.generatedBy}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {result.selectedDomains.map((domain) => (
            <span key={domain} className="rounded-full border border-[var(--line)] bg-[var(--blue-pale)] px-3 py-1 text-xs font-medium text-[var(--navy)]">
              {domain}
            </span>
          ))}
        </div>
      </div>
      <div className="mt-4 whitespace-pre-wrap text-base leading-7 text-slate-700">{result.answer}</div>
      {result.suggestedAngle && (
        <div className="mt-4 rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] p-4 text-sm leading-6 text-slate-700">
          <span className="font-semibold text-[var(--navy)]">Suggested angle: </span>{result.suggestedAngle}
        </div>
      )}
      {result.gaps && result.gaps.length > 0 && (
        <div className="mt-4 rounded-2xl border border-[rgba(181,134,28,0.18)] bg-[var(--warning)] p-4 text-sm leading-6 text-[#6c5412]">
          <p className="font-semibold">Gaps / caution</p>
          <ul className="mt-1 list-disc pl-5">
            {result.gaps.map((gap) => <li key={gap}>{gap}</li>)}
          </ul>
        </div>
      )}
      <div className="mt-6 border-t border-[var(--line)] pt-5">
        <div className="mb-3">
          <h4 className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--teal)]">Supporting sources</h4>
          <p className="mt-1 text-sm text-slate-500">Retrieved snippets used to ground the answer above.</p>
        </div>
        <div className="space-y-3">
          {result.citations.map((citation, index) => (
            <article key={`${citation.documentId}-${index}`} className="rounded-2xl border border-[var(--line)] bg-[var(--blue-pale)] p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-[var(--line)] bg-white px-2 py-1 text-xs text-slate-600">{citation.domain}</span>
                <h4 className="font-semibold text-[var(--navy)]">{citation.title}</h4>
                <span className="text-xs text-slate-500">score {citation.score.toFixed(2)}</span>
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-600">{citation.snippet}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function InfoCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-[24px] border border-[var(--line)] bg-[var(--blue-pale)] p-4">
      <h3 className="text-sm font-semibold text-[var(--navy)]">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-600">{body}</p>
    </div>
  );
}

function SidebarCard({ title, tone, children }: { title: string; tone: "navy" | "blue" | "teal"; children: React.ReactNode }) {
  const accents = {
    navy: "border-[var(--line)] bg-[var(--surface)]",
    blue: "border-[rgba(46,111,174,0.18)] bg-white",
    teal: "border-[rgba(47,141,163,0.18)] bg-[var(--surface)]",
  };

  return (
    <div className={`rounded-[28px] border p-5 shadow-sm ${accents[tone]}`}>
      <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--navy)]">{title}</h3>
      <div className="mt-3">{children}</div>
    </div>
  );
}
