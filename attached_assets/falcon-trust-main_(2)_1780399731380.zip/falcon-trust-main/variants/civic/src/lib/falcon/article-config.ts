import fs from "node:fs";
import path from "node:path";
import type { ArticleConfig } from "./types";

const dataDir = path.join(process.cwd(), ".demo-data");
const configPath = path.join(dataDir, "article-config.json");

export const defaultArticleConfig: ArticleConfig = {
  provider: "ollama",
  endpoint: process.env.OLLAMA_BASE_URL ?? "http://192.168.0.168:11435",
  model: process.env.OLLAMA_ARTICLE_MODEL ?? "qwen3.5:35b-a3b",
  audience: "Miami-Dade residents and municipal communications staff",
  tone: "clear, practical, public-service oriented",
  length: "medium",
  structure: "news-style public guidance article with headline, deck, body, practical checklist, and caveat section",
  extraInstructions: "Write a useful article, not a legal memo. Keep claims grounded in the provided sources and clearly state any limits.",
  includeCitations: true,
};

export function readArticleConfig(): ArticleConfig {
  if (!fs.existsSync(configPath)) return defaultArticleConfig;
  try {
    return normalizeArticleConfig(JSON.parse(fs.readFileSync(configPath, "utf8")));
  } catch {
    return defaultArticleConfig;
  }
}

export function writeArticleConfig(config: Partial<ArticleConfig>): ArticleConfig {
  fs.mkdirSync(dataDir, { recursive: true });
  const next = normalizeArticleConfig({ ...readArticleConfig(), ...config });
  fs.writeFileSync(configPath, JSON.stringify(next, null, 2));
  return next;
}

export function normalizeArticleConfig(input: Partial<ArticleConfig>): ArticleConfig {
  return {
    provider: "ollama",
    endpoint: stringValue(input.endpoint, defaultArticleConfig.endpoint),
    model: stringValue(input.model, defaultArticleConfig.model),
    audience: stringValue(input.audience, defaultArticleConfig.audience),
    tone: stringValue(input.tone, defaultArticleConfig.tone),
    length: normalizeLength(input.length),
    structure: stringValue(input.structure, defaultArticleConfig.structure),
    extraInstructions: stringValue(input.extraInstructions, defaultArticleConfig.extraInstructions),
    includeCitations: input.includeCitations !== false,
  };
}

function stringValue(value: unknown, fallback: string) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 1000) : fallback;
}

function normalizeLength(value: unknown): ArticleConfig["length"] {
  return value === "short" || value === "long" ? value : "medium";
}
