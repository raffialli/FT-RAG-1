import { readArticleConfig } from "./article-config";
import type { ArticleConfig, Citation } from "./types";

type GenerateArticleInput = {
  query: string;
  citations: Citation[];
  fallbackAnswer: string;
};

export async function generateArticleDraft({ query, citations, fallbackAnswer }: GenerateArticleInput) {
  const config = readArticleConfig();
  try {
    return await generateWithOllama(query, citations, config);
  } catch (error) {
    const reason = error instanceof Error ? error.message : "Unknown Ollama generation error";
    return {
      answer: `${fallbackAnswer}\n\n[Local LLM article generation was unavailable: ${reason}]`,
      config,
      generatedBy: "template_fallback" as const,
      warning: reason,
    };
  }
}

async function generateWithOllama(query: string, citations: Citation[], config: ArticleConfig) {
  const prompt = buildPrompt(query, citations, config);
  const response = await fetch(`${config.endpoint.replace(/\/$/, "")}/api/generate`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      model: config.model,
      prompt,
      stream: false,
      think: false,
      options: {
        temperature: 0.35,
        top_p: 0.9,
        num_predict: config.length === "long" ? 1400 : config.length === "short" ? 650 : 950,
      },
    }),
    signal: AbortSignal.timeout(120000),
  });

  if (!response.ok) throw new Error(`Ollama returned ${response.status}: ${await response.text()}`);
  const data = (await response.json()) as { response?: string };
  const answer = data.response?.trim();
  if (!answer) throw new Error("Ollama returned an empty article");
  return { answer, config, generatedBy: "ollama" as const };
}

function buildPrompt(query: string, citations: Citation[], config: ArticleConfig) {
  const sourceBlock = citations
    .map((citation, index) => `[${index + 1}] ${citation.title} (${citation.domain}, score ${citation.score})\n${citation.snippet}`)
    .join("\n\n");

  return `You are drafting a customer-demo article for Falcon Trust.

User request/topic:
${query}

Article configuration:
- Audience: ${config.audience}
- Tone: ${config.tone}
- Length: ${config.length}
- Structure: ${config.structure}
- Extra instructions: ${config.extraInstructions}

Grounding rules:
- Use only the provided source snippets for factual claims.
- Do not invent dates, addresses, phone numbers, policy details, names, statistics, or legal conclusions.
- If a detail is missing, write generally or say it should be confirmed by the municipality.
- Avoid promising that sandbags prevent flooding.
- Include practical, public-facing guidance.
${config.includeCitations ? "- Cite source numbers inline where useful, like [1] or [2]." : "- Do not include inline citation markers."}

Required output:
- Headline
- Short deck/subtitle
- Full article body with multiple paragraphs
- Practical checklist or key points
- Caveat/limits section

Source snippets:
${sourceBlock}

Write the article now.`;
}
