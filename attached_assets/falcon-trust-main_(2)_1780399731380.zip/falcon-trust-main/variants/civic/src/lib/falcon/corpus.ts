import fs from "node:fs";
import path from "node:path";
import type { Chunk, DemoDocument, Domain, DomainId } from "./types";

export const DOMAINS: Domain[] = [
  {
    id: "law",
    name: "Law",
    description: "Legal authority, public-claims risk, publication review, and careful wording guidance.",
  },
  {
    id: "sandbags",
    name: "Sandbags",
    description: "Flood readiness, sandbag usage, distribution logistics, placement, and disposal guidance.",
  },
];

const corpusRoot = path.join(process.cwd(), "demo-corpus");
export const uploadRoot = path.join(process.cwd(), ".demo-data", "uploads");

export function isDomainId(value: unknown): value is DomainId {
  return value === "law" || value === "sandbags";
}

export function normalizeDomains(input: unknown): DomainId[] {
  if (!Array.isArray(input)) return ["law", "sandbags"];
  const selected = input.filter(isDomainId);
  return selected.length ? Array.from(new Set(selected)) : ["law", "sandbags"];
}

export function loadDocuments(): DemoDocument[] {
  return [...loadStaticDocuments(), ...loadUploadedDocuments()];
}

function loadStaticDocuments(): DemoDocument[] {
  return DOMAINS.flatMap((domain) => {
    const dir = path.join(corpusRoot, domain.id);
    if (!fs.existsSync(dir)) return [];
    return fs
      .readdirSync(dir)
      .filter((file) => file.endsWith(".md"))
      .sort()
      .map((file) => {
        const fullPath = path.join(dir, file);
        const text = fs.readFileSync(fullPath, "utf8");
        const firstHeading = text.match(/^#\s+(.+)$/m)?.[1] ?? file.replace(/\.md$/, "");
        const title = firstHeading.replace(/^DEMO SAMPLE\s+—\s+/, "");
        return {
          id: `${domain.id}-${file.replace(/\.md$/, "")}`,
          title,
          domain: domain.id,
          path: path.relative(process.cwd(), fullPath),
          text,
        };
      });
  });
}

function loadUploadedDocuments(): DemoDocument[] {
  if (!fs.existsSync(uploadRoot)) return [];

  return DOMAINS.flatMap((domain) => {
    const dir = path.join(uploadRoot, domain.id);
    if (!fs.existsSync(dir)) return [];

    return fs
      .readdirSync(dir)
      .filter((file) => file.endsWith(".json"))
      .sort()
      .map((file) => {
        const fullPath = path.join(dir, file);
        const record = JSON.parse(fs.readFileSync(fullPath, "utf8")) as {
          id: string;
          title: string;
          text: string;
          sourceFileName?: string;
        };

        return {
          id: record.id,
          title: record.title,
          domain: domain.id,
          path: path.relative(process.cwd(), fullPath),
          text: record.text,
        };
      });
  });
}

export function writeUploadedDocument(input: { domain: DomainId; title: string; text: string; sourceFileName: string }) {
  const safeTitle = input.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || "uploaded-document";
  const id = `${input.domain}-upload-${Date.now()}-${safeTitle}`;
  const dir = path.join(uploadRoot, input.domain);
  fs.mkdirSync(dir, { recursive: true });
  const record = {
    id,
    title: input.title,
    text: input.text,
    sourceFileName: input.sourceFileName,
    uploadedAt: new Date().toISOString(),
  };
  const fullPath = path.join(dir, `${id}.json`);
  fs.writeFileSync(fullPath, JSON.stringify(record, null, 2));
  return { ...record, domain: input.domain, path: path.relative(process.cwd(), fullPath) };
}

export function tokenize(text: string) {
  return Array.from(
    new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, " ")
        .split(/\s+/)
        .filter((token) => token.length > 2)
        .filter((token) => !STOP_WORDS.has(token)),
    ),
  );
}

export function chunkDocument(document: DemoDocument): Chunk[] {
  const sections = document.text
    .split(/\n(?=##\s+)/g)
    .map((section) => section.trim())
    .filter(Boolean);

  return sections.map((section, index) => ({
    id: `${document.id}-chunk-${index + 1}`,
    documentId: document.id,
    title: document.title,
    domain: document.domain,
    text: section,
    index,
    tokens: tokenize(section),
  }));
}

export function loadChunks(): Chunk[] {
  return loadDocuments().flatMap(chunkDocument);
}

const STOP_WORDS = new Set([
  "the", "and", "for", "that", "with", "this", "from", "are", "should", "into", "when", "what", "about",
  "have", "has", "can", "may", "not", "but", "use", "using", "their", "they", "them", "our", "your",
  "documents", "document", "demo", "sample", "falcon", "trust", "research", "workspace",
]);
