import fs from "node:fs";
import path from "node:path";
import type { QuerySession } from "./types";

const dataDir = path.join(process.cwd(), ".demo-data");
const historyPath = path.join(dataDir, "query-history.json");

export function readHistory(): QuerySession[] {
  if (!fs.existsSync(historyPath)) return [];
  try {
    return JSON.parse(fs.readFileSync(historyPath, "utf8")) as QuerySession[];
  } catch {
    return [];
  }
}

export function appendHistory(session: Omit<QuerySession, "id" | "createdAt">): QuerySession {
  fs.mkdirSync(dataDir, { recursive: true });
  const next: QuerySession = {
    ...session,
    id: `session-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  };
  const history = [next, ...readHistory()].slice(0, 50);
  fs.writeFileSync(historyPath, JSON.stringify(history, null, 2));
  return next;
}
