import { loadChunks, tokenize } from "./corpus";
import type { AnswerType, Citation, DomainId, QuerySession } from "./types";

export function retrieve(query: string, selectedDomains: DomainId[], limit = 5): Citation[] {
  const queryTokens = tokenize(query);
  const chunks = loadChunks().filter((chunk) => selectedDomains.includes(chunk.domain));

  return chunks
    .map((chunk) => {
      const overlap = queryTokens.filter((token) => chunk.tokens.includes(token));
      const phraseBonus = phraseScore(query, chunk.text);
      const score = overlap.length / Math.max(queryTokens.length, 1) + phraseBonus;
      return { chunk, score };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ chunk, score }) => ({
      documentId: chunk.documentId,
      title: chunk.title,
      domain: chunk.domain,
      snippet: cleanSnippet(chunk.text),
      score: Number(score.toFixed(3)),
    }));
}

export function buildAnswer(query: string, selectedDomains: DomainId[], mode: QuerySession["mode"], answerType: AnswerType = "clear_answer"): Omit<QuerySession, "id" | "createdAt"> {
  const citations = retrieve(query, selectedDomains, mode === "external_compare" ? 6 : 5);
  const domainLabel = selectedDomains.map((domain) => domainName(domain)).join(" + ");
  const weak = citations.length === 0 || citations[0]?.score < 0.12;
  const intent = answerType === "create_article" ? "article" : classifyIntent(query, mode);

  let answer: string;
  let suggestedAngle: string | undefined;
  const gaps: string[] = [];

  if (weak) {
    answer = `I do not see strong support in the selected ${domainLabel} documents. The safe answer is to mark this as a gap or select additional domains before relying on it.`;
    gaps.push("Selected documents do not provide strong direct support for the requested claim.");
  } else if (intent === "absolute_flood_claim") {
    answer = "No. The documents do not support saying sandbags prevent all flood damage. The grounded answer is that sandbags may help reduce minor water intrusion when placed correctly, but they do not guarantee protection from deep flooding, storm surge, or structural flooding.";
    gaps.push("No cited source supports an absolute flood-prevention guarantee.");
    gaps.push("Public-facing language should avoid overstating sandbag effectiveness.");
  } else if (intent === "pickup_rules") {
    answer = "Say the pickup rules plainly: who is eligible, where pickup sites are located, when they are open, whether residents or businesses qualify, how many bags are allowed per household, and what people should bring. Also include the limitation that sandbags are a temporary mitigation tool and do not guarantee flood protection.";
  } else if (intent === "article") {
    answer = "Article draft: Before a flood, residents need simple and specific sandbag pickup instructions: who qualifies, where pickup sites are located, when sites are open, whether proof of residency is required, and how many bags are available per household. The article should also explain that sandbags are a temporary mitigation tool. They can help reduce minor water intrusion when placed correctly, but they do not guarantee protection from serious flooding, storm surge, or structural damage.";
    suggestedAngle = "Clear pickup rules reduce confusion before a flood, while realistic wording avoids overstating what sandbags can do.";
  } else if (mode === "external_compare") {
    answer = `The selected ${domainLabel} documents provide useful internal support for this outside topic. The strongest matches point to sandbag distribution rules, public education, eligibility notices, and careful public-claims language.`;
    suggestedAngle = "Clear sandbag pickup rules reduce confusion and improve emergency readiness, but public messaging should avoid promising complete flood protection.";
    gaps.push("The demo corpus does not include real resident survey data or actual municipal complaint records.");
  } else {
    answer = "The direct answer from the selected documents is: provide clear, practical guidance; keep claims realistic; and cite the operational/legal basis. The most relevant support covers emergency distribution authority, public education, placement/disposal guidance, and warnings against promising complete flood protection.";
  }

  return {
    mode,
    query,
    selectedDomains,
    answerType,
    answer,
    generatedBy: "template",
    confidence: weak ? "Low" : citations.length >= 3 ? "High" : "Medium",
    citations,
    suggestedAngle,
    gaps,
  };
}

function phraseScore(query: string, text: string) {
  const lowerQuery = query.toLowerCase();
  const lowerText = text.toLowerCase();
  const phrases = ["sandbag", "sandbags", "municipal", "flood", "public", "claims", "distribution", "disposal", "residents", "article", "legal"];
  return phrases.reduce((score, phrase) => {
    return lowerQuery.includes(phrase) && lowerText.includes(phrase) ? score + 0.08 : score;
  }, 0);
}

function cleanSnippet(text: string) {
  return text
    .replace(/^#+\s+/gm, "")
    .replace(/\n+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 420);
}

function domainName(domain: DomainId) {
  return domain === "law" ? "Law" : "Sandbags";
}

function classifyIntent(query: string, mode: QuerySession["mode"]) {
  const normalized = query.toLowerCase();
  if (/prevent all|all flood damage|guarantee|guaranteed protection|prove.*prevent|proof.*prevent|prove.*sandbags.*protect|proof.*sandbags.*protect/.test(normalized)) return "absolute_flood_claim";
  if (/pickup|pick up|distribution rules|where.*get|how many bags|sandbag rules|proof of residency|residency proof/.test(normalized)) return "pickup_rules";
  if (/article|outline|draft|journal|publish|publication|writing angle/.test(normalized)) return "article";
  if (mode === "external_compare") return "external_compare";
  return "direct_answer";
}
