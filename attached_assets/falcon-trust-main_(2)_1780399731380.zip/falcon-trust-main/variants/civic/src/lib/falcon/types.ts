export type DomainId = "law" | "sandbags";

export type Domain = {
  id: DomainId;
  name: string;
  description: string;
};

export type DemoDocument = {
  id: string;
  title: string;
  domain: DomainId;
  path: string;
  text: string;
};

export type Chunk = {
  id: string;
  documentId: string;
  title: string;
  domain: DomainId;
  text: string;
  index: number;
  tokens: string[];
};

export type Citation = {
  documentId: string;
  title: string;
  domain: DomainId;
  snippet: string;
  score: number;
};

export type AnswerType = "clear_answer" | "create_article";

export type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};

export type QuerySession = {
  id: string;
  mode: "internal_qa" | "external_compare";
  query: string;
  selectedDomains: DomainId[];
  answerType: AnswerType;
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  articleConfig?: ArticleConfig;
  createdAt: string;
};
