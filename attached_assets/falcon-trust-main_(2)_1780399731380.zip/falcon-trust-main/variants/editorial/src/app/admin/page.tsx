"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = { id: string; name: string; description: string };
type DocumentSummary = { id: string; title: string; domain: string; path: string; chunkCount: number };
type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};
type AdminSession = {
  id: string;
  mode: string;
  query: string;
  selectedDomains: string[];
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: { title: string; domain: string; snippet: string; score: number }[];
  createdAt: string;
};

export default function AdminPage() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [history, setHistory] = useState<AdminSession[]>([]);
  const [adminLoading, setAdminLoading] = useState(true);
  const [uploadDomain, setUploadDomain] = useState("law");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [articleConfig, setArticleConfig] = useState<ArticleConfig | null>(null);
  const [articleMessage, setArticleMessage] = useState<string | null>(null);
  const [savingArticle, setSavingArticle] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAdmin() {
    const [corpusRes, historyRes, configRes] = await Promise.all([fetch("/api/corpus"), fetch("/api/admin/history"), fetch("/api/admin/article-config")]);
    if (!corpusRes.ok) throw new Error("Failed to load corpus");
    if (!historyRes.ok) throw new Error("Failed to load history");
    if (!configRes.ok) throw new Error("Failed to load article config");
    const corpus = await corpusRes.json();
    const historyData = await historyRes.json();
    const configData = await configRes.json();
    setDomains(corpus.domains);
    setDocuments(corpus.documents);
    setHistory(historyData.sessions);
    setArticleConfig(configData.config);
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadAdmin()
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize admin"))
        .finally(() => setAdminLoading(false));
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const totalChunks = useMemo(() => documents.reduce((sum, doc) => sum + doc.chunkCount, 0), [documents]);

  async function saveArticleConfig(event: React.FormEvent) {
    event.preventDefault();
    if (!articleConfig) return;
    setSavingArticle(true);
    setError(null);
    setArticleMessage(null);
    try {
      const res = await fetch("/api/admin/article-config", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(articleConfig),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setArticleConfig(data.config);
      setArticleMessage("Article generator settings saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save article config");
    } finally {
      setSavingArticle(false);
    }
  }

  async function submitUpload(event: React.FormEvent) {
    event.preventDefault();
    if (!uploadFile) {
      setUploadMessage("Choose a text-based PDF first.");
      return;
    }
    setUploading(true);
    setError(null);
    setUploadMessage(null);
    try {
      const form = new FormData();
      form.set("domain", uploadDomain);
      form.set("file", uploadFile);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setUploadMessage(`Uploaded and indexed: ${data.document.title}`);
      setUploadFile(null);
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <main className="editorial-shell min-h-screen bg-transparent text-[color:var(--foreground)]">
      <div className="mx-auto w-full max-w-7xl px-5 py-6 lg:px-10 lg:py-8">
        <nav className="mb-8 flex flex-col gap-4 rounded-[30px] border border-[color:var(--line)] bg-[color:var(--surface)] px-5 py-4 shadow-[0_20px_80px_rgba(74,39,28,0.08)] backdrop-blur lg:flex-row lg:items-center lg:justify-between lg:px-7">
          <div className="space-y-2">
            <p className="font-ui-mono text-[11px] uppercase tracking-[0.36em] text-[color:var(--accent)]">Falcon Trust · limited demo</p>
            <div>
              <h1 className="font-display text-3xl font-semibold tracking-[0.02em] text-[color:var(--foreground)]">Admin review desk</h1>
              <p className="mt-1 max-w-2xl text-sm leading-6 text-[color:var(--ink-soft)]">Same admin functions, restyled for a warmer executive walkthrough and cleaner internal review.</p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 lg:justify-end">
            <div className="hidden rounded-full border border-[color:var(--line)] bg-white/55 px-4 py-2 text-xs text-[color:var(--ink-soft)] md:block">
              Upload control · article settings · session trace
            </div>
            <div className="flex rounded-full border border-[color:var(--line)] bg-[#f4ecdf] p-1 text-sm shadow-inner">
              <Link href="/" className="rounded-full px-4 py-2 text-[color:var(--ink-soft)] transition hover:text-[color:var(--foreground)]">Search</Link>
              <span className="rounded-full bg-[color:var(--accent)] px-4 py-2 font-medium text-[#fff7ef]">Admin</span>
            </div>
          </div>
        </nav>

        {error && <div className="mb-6 rounded-[24px] border border-[#b86b57]/35 bg-[#fff1ec] p-4 text-[#7d3427]">{error}</div>}

        <section className="grid gap-4 md:grid-cols-3">
          <Metric label="Domains" value={adminLoading ? "Loading…" : String(domains.length)} detail="Selectable research lanes" />
          <Metric label="Documents" value={adminLoading ? "Loading…" : String(documents.length)} detail="Preloaded plus controlled uploads" />
          <Metric label="Chunks" value={adminLoading ? "Loading…" : String(totalChunks)} detail="Grounding units behind citations" />
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[0.92fr_1.08fr]">
          <div className="space-y-6">
            <form onSubmit={submitUpload} className="rounded-[32px] border border-[color:var(--line)] bg-[color:var(--surface-strong)] p-6 shadow-[0_20px_80px_rgba(74,39,28,0.08)]">
              <p className="font-ui-mono text-[11px] uppercase tracking-[0.3em] text-[color:var(--accent)]">Corpus operations</p>
              <h2 className="font-display mt-3 text-4xl font-semibold text-[color:var(--foreground)]">Upload a text-based PDF</h2>
              <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)]">Local demo only. Files are extracted into .demo-data and included in retrieval. Keep it to text-based PDFs; scanned/image-only files remain intentionally out of scope.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-[0.8fr_1.2fr]">
                <select value={uploadDomain} onChange={(event) => setUploadDomain(event.target.value)} className="rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm text-[color:var(--foreground)] outline-none focus:border-[color:var(--accent)]">
                  {domains.map((domain) => <option key={domain.id} value={domain.id}>{domain.name}</option>)}
                </select>
                <input type="file" accept="application/pdf,.pdf" onChange={(event) => setUploadFile(event.target.files?.[0] ?? null)} className="rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm text-[color:var(--foreground)] file:mr-4 file:rounded-full file:border-0 file:bg-[color:var(--accent)] file:px-3 file:py-1 file:text-sm file:font-medium file:text-[#fff7ef]" />
              </div>
              <button type="submit" disabled={uploading} className="mt-4 w-full rounded-full bg-[color:var(--accent)] px-4 py-3 text-sm font-medium text-[#fff7ef] shadow-[0_14px_34px_rgba(110,34,49,0.22)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60">
                {uploading ? "Extracting and indexing PDF..." : "Upload and index PDF locally"}
              </button>
              {uploadMessage && <p className="mt-3 rounded-[18px] border border-[rgba(163,111,31,0.24)] bg-[color:var(--success-soft)] p-3 text-sm text-[color:var(--foreground)]">{uploadMessage}</p>}
            </form>

            <div className="rounded-[32px] border border-[color:var(--line)] bg-[color:var(--surface)] p-6 shadow-[0_20px_80px_rgba(74,39,28,0.08)]">
              <p className="font-ui-mono text-[11px] uppercase tracking-[0.3em] text-[color:var(--accent)]">Domain inventory</p>
              <div className="mt-5 space-y-3">
                {domains.map((domain) => {
                  const domainDocs = documents.filter((doc) => doc.domain === domain.id);
                  const chunks = domainDocs.reduce((sum, doc) => sum + doc.chunkCount, 0);
                  return (
                    <article key={domain.id} className="rounded-[24px] border border-[color:var(--line)] bg-[#fffaf4] p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-display text-3xl font-semibold text-[color:var(--foreground)]">{domain.name}</h3>
                          <p className="mt-1 text-sm leading-6 text-[color:var(--ink-soft)]">{domain.description}</p>
                        </div>
                        <div className="text-right text-sm text-[color:var(--ink-soft)]"><div>{domainDocs.length} docs</div><div>{chunks} chunks</div></div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {articleConfig && (
              <form onSubmit={saveArticleConfig} className="rounded-[32px] border border-[rgba(110,34,49,0.18)] bg-[rgba(110,34,49,0.05)] p-6 shadow-[0_20px_80px_rgba(74,39,28,0.08)]">
                <p className="font-ui-mono text-[11px] uppercase tracking-[0.3em] text-[color:var(--accent)]">Article configurator</p>
                <h2 className="font-display mt-3 text-4xl font-semibold text-[color:var(--foreground)]">Create Article settings</h2>
                <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)]">Controls the same local Ollama prompt used when the Search page is set to Create Article.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <Field label="Ollama endpoint" value={articleConfig.endpoint} onChange={(value) => setArticleConfig({ ...articleConfig, endpoint: value })} />
                  <Field label="Model" value={articleConfig.model} onChange={(value) => setArticleConfig({ ...articleConfig, model: value })} />
                  <Field label="Audience" value={articleConfig.audience} onChange={(value) => setArticleConfig({ ...articleConfig, audience: value })} />
                  <Field label="Tone" value={articleConfig.tone} onChange={(value) => setArticleConfig({ ...articleConfig, tone: value })} />
                  <label className="text-sm text-[color:var(--ink-soft)]">
                    Length
                    <select value={articleConfig.length} onChange={(event) => setArticleConfig({ ...articleConfig, length: event.target.value as ArticleConfig["length"] })} className="mt-1 w-full rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm text-[color:var(--foreground)] outline-none focus:border-[color:var(--accent)]">
                      <option value="short">Short</option>
                      <option value="medium">Medium</option>
                      <option value="long">Long</option>
                    </select>
                  </label>
                  <label className="flex items-center gap-3 rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm text-[color:var(--foreground)]">
                    <input type="checkbox" checked={articleConfig.includeCitations} onChange={(event) => setArticleConfig({ ...articleConfig, includeCitations: event.target.checked })} />
                    Include inline citation markers
                  </label>
                </div>
                <TextAreaField label="Structure" value={articleConfig.structure} onChange={(value) => setArticleConfig({ ...articleConfig, structure: value })} />
                <TextAreaField label="Extra instructions" value={articleConfig.extraInstructions} onChange={(value) => setArticleConfig({ ...articleConfig, extraInstructions: value })} />
                <button type="submit" disabled={savingArticle} className="mt-4 w-full rounded-full bg-[color:var(--accent)] px-4 py-3 text-sm font-medium text-[#fff7ef] shadow-[0_14px_34px_rgba(110,34,49,0.22)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60">
                  {savingArticle ? "Saving article settings..." : "Save article configurator"}
                </button>
                {articleMessage && <p className="mt-3 rounded-[18px] border border-[rgba(163,111,31,0.24)] bg-[color:var(--success-soft)] p-3 text-sm text-[color:var(--foreground)]">{articleMessage}</p>}
              </form>
            )}

            <div className="rounded-[32px] border border-[color:var(--line)] bg-[color:var(--surface)] p-6 shadow-[0_20px_80px_rgba(74,39,28,0.08)]">
              <p className="font-ui-mono text-[11px] uppercase tracking-[0.3em] text-[color:var(--accent)]">Indexed documents</p>
              <div className="mt-5 space-y-3">
                {documents.map((doc) => (
                  <div key={doc.id} className="rounded-[24px] border border-[color:var(--line)] bg-[#fffaf4] p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <h3 className="font-display text-2xl font-semibold text-[color:var(--foreground)]">{doc.title}</h3>
                        <p className="mt-1 text-sm text-[color:var(--ink-soft)]">{domainName(domains, doc.domain)} · {doc.chunkCount} chunks</p>
                      </div>
                      <span className="rounded-full border border-[color:var(--line)] bg-[#f0e3d1] px-3 py-1 text-xs text-[color:var(--foreground)]">Indexed</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[32px] border border-[color:var(--line)] bg-[color:var(--surface)] p-6 shadow-[0_20px_80px_rgba(74,39,28,0.08)]">
              <p className="font-ui-mono text-[11px] uppercase tracking-[0.3em] text-[color:var(--accent)]">Query history</p>
              <div className="mt-5 space-y-4">
                {history.length === 0 ? <p className="text-sm text-[color:var(--ink-soft)]">No queries recorded yet.</p> : history.slice(0, 8).map((item) => (
                  <article key={item.id} className="rounded-[28px] border border-[color:var(--line)] bg-[#fffaf4] p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-ui-mono text-[11px] uppercase tracking-[0.22em] text-[color:var(--accent)]">{item.mode}</p>
                        <h3 className="mt-1 font-display text-2xl font-semibold text-[color:var(--foreground)]">{item.query}</h3>
                      </div>
                      <span className="rounded-full border border-[color:var(--line)] bg-[#f0e3d1] px-2 py-1 text-xs text-[color:var(--ink-soft)]">{new Date(item.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)]">{item.answer}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="text-sm text-[color:var(--ink-soft)]">
      {label}
      <input value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 w-full rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm text-[color:var(--foreground)] outline-none focus:border-[color:var(--accent)]" />
    </label>
  );
}

function TextAreaField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="mt-4 block text-sm text-[color:var(--ink-soft)]">
      {label}
      <textarea value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 min-h-24 w-full rounded-[22px] border border-[color:var(--line)] bg-[#fffdfa] px-4 py-3 text-sm leading-6 text-[color:var(--foreground)] outline-none focus:border-[color:var(--accent)]" />
    </label>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-[28px] border border-[color:var(--line)] bg-[color:var(--surface)] p-5 shadow-[0_16px_60px_rgba(74,39,28,0.08)]">
      <p className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--accent)]">{label}</p>
      <p className="font-display mt-3 text-5xl font-semibold text-[color:var(--foreground)]">{value}</p>
      <p className="mt-2 text-sm leading-6 text-[color:var(--ink-soft)]">{detail}</p>
    </div>
  );
}

function domainName(domains: Domain[], id: string) {
  return domains.find((domain) => domain.id === id)?.name ?? id;
}
