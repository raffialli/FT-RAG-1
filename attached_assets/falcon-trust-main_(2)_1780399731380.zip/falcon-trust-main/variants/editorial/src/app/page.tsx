"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = {
  id: string;
  name: string;
  description: string;
};

type Citation = {
  documentId: string;
  title: string;
  domain: string;
  snippet: string;
  score: number;
};

type AnswerType = "clear_answer" | "create_article";

type QueryResponse = {
  id: string;
  query: string;
  selectedDomains: string[];
  answerType: AnswerType;
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  createdAt: string;
};

const examplePrompts = [
  "What should we say about sandbag pickup rules before a flood?",
  "What legal or public-claims risks should we keep in mind when writing about sandbags?",
  "Do these documents prove sandbags prevent all flood damage?",
];

export default function Home() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<string[]>(["law", "sandbags"]);
  const [query, setQuery] = useState("What should we say about sandbag pickup rules before a flood?");
  const [answerType, setAnswerType] = useState<AnswerType>("clear_answer");
  const [result, setResult] = useState<QueryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetch("/api/corpus")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to load domains");
          return res.json();
        })
        .then((data) => setDomains(data.domains))
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize demo"));
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  const selectedLabel = useMemo(
    () => selectedDomains.map((id) => domains.find((domain) => domain.id === id)?.name ?? id).join(" · "),
    [domains, selectedDomains],
  );

  function toggleDomain(domainId: string) {
    setSelectedDomains((current) => {
      if (current.includes(domainId)) {
        const next = current.filter((id) => id !== domainId);
        return next.length ? next : current;
      }
      return [...current, domainId];
    });
  }

  async function submitQuery(event?: React.FormEvent) {
    event?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/query", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query, domains: selectedDomains, answerType }),
      });
      if (!res.ok) throw new Error(await res.text());
      setResult(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Query failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="editorial-shell min-h-screen bg-transparent text-[color:var(--foreground)]">
      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-5 py-6 lg:px-10 lg:py-8">
        <nav className="mb-8 flex flex-col gap-4 rounded-[30px] border border-[color:var(--line)] bg-[color:var(--surface)] px-5 py-4 shadow-[0_20px_80px_rgba(74,39,28,0.08)] backdrop-blur lg:flex-row lg:items-center lg:justify-between lg:px-7">
          <div className="space-y-2">
            <p className="font-ui-mono text-[11px] uppercase tracking-[0.36em] text-[color:var(--accent)]">Falcon Trust · limited demo</p>
            <div>
              <h1 className="font-display text-3xl font-semibold tracking-[0.02em] text-[color:var(--foreground)]">Research Workspace</h1>
              <p className="mt-1 max-w-2xl text-sm leading-6 text-[color:var(--ink-soft)]">A more polished client-presentation view of the Falcon Trust document research desk.</p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 lg:justify-end">
            <div className="hidden rounded-full border border-[color:var(--line)] bg-white/55 px-4 py-2 text-xs text-[color:var(--ink-soft)] md:block">
              Domain-scoped answers · grounded snippets · admin review
            </div>
            <div className="flex rounded-full border border-[color:var(--line)] bg-[#f4ecdf] p-1 text-sm shadow-inner">
              <span className="rounded-full bg-[color:var(--accent)] px-4 py-2 font-medium text-[#fff7ef]">Search</span>
              <Link href="/admin" className="rounded-full px-4 py-2 text-[color:var(--ink-soft)] transition hover:text-[color:var(--foreground)]">
                Admin
              </Link>
            </div>
          </div>
        </nav>

        <section className="grid flex-1 gap-8 lg:grid-cols-[0.82fr_1.18fr] lg:items-start">
          <aside className="rounded-[34px] border border-[color:var(--line)] bg-[color:var(--surface)] p-6 shadow-[0_18px_70px_rgba(74,39,28,0.08)] lg:sticky lg:top-8 lg:p-8">
            <div className="rounded-[28px] border border-[color:var(--line)] bg-[linear-gradient(180deg,rgba(255,255,255,0.55),rgba(255,249,240,0.92))] p-5">
              <p className="font-ui-mono text-[11px] uppercase tracking-[0.34em] text-[color:var(--accent)]">Editorial brief</p>
              <h2 className="font-display mt-3 text-4xl leading-none font-semibold text-[color:var(--foreground)] md:text-5xl">Ask Falcon Trust documents with a cleaner client-facing narrative.</h2>
              <p className="mt-4 text-base leading-7 text-[color:var(--ink-soft)]">
                Choose the legal or sandbag research lanes you want included, then ask for a direct answer or a draft-style article pass. Results stay grounded in the selected evidence set.
              </p>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-3 lg:grid-cols-1">
              <DeskNote title="Scope control" body="Answers honor only the highlighted domains unless you explicitly broaden the lens." />
              <DeskNote title="Presentation polish" body="Warm ivory, ink, and burgundy styling is tuned for customer walkthroughs and screenshots." />
              <DeskNote title="Same demo engine" body="Search and Admin flows are unchanged underneath; this is a visual/editorial skin only." />
            </div>
          </aside>

          <div className="space-y-6 pb-10">
            <form onSubmit={submitQuery} className="rounded-[34px] border border-[color:var(--line)] bg-[color:var(--surface-strong)] p-5 shadow-[0_24px_90px_rgba(74,39,28,0.1)] md:p-7">
              <div className="flex flex-col gap-4 border-b border-[color:var(--line)] pb-5 md:flex-row md:items-end md:justify-between">
                <div>
                  <p className="font-ui-mono text-[11px] uppercase tracking-[0.34em] text-[color:var(--accent)]">Search desk</p>
                  <h3 className="font-display mt-2 text-3xl font-semibold text-[color:var(--foreground)]">Compose the retrieval scope</h3>
                </div>
                <p className="max-w-md text-sm leading-6 text-[color:var(--ink-soft)]">Use the same limited-demo retrieval workflow, presented like a premium legal research workbench.</p>
              </div>

              <div className="mt-5 grid gap-5 xl:grid-cols-[1.08fr_0.92fr]">
                <div>
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <p className="text-sm font-medium text-[color:var(--foreground)]">Included domains</p>
                    <span className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--ink-soft)]">{selectedDomains.length} selected</span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {domains.map((domain) => {
                      const selected = selectedDomains.includes(domain.id);
                      return (
                        <button
                          key={domain.id}
                          type="button"
                          onClick={() => toggleDomain(domain.id)}
                          className={`rounded-[24px] border px-4 py-4 text-left transition ${
                            selected
                              ? "border-[color:var(--accent)] bg-[color:var(--accent-soft)] shadow-[0_10px_30px_rgba(110,34,49,0.12)]"
                              : "border-[color:var(--line)] bg-white/55 hover:border-[color:var(--line-strong)] hover:bg-white/75"
                          }`}
                          aria-pressed={selected}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="font-display text-2xl font-semibold text-[color:var(--foreground)]">{domain.name}</p>
                              <p className="mt-1 text-sm leading-6 text-[color:var(--ink-soft)]">{domain.description}</p>
                            </div>
                            <span className={`mt-1 rounded-full px-3 py-1 font-ui-mono text-[10px] uppercase tracking-[0.24em] ${selected ? "bg-[color:var(--accent)] text-[#fff7ef]" : "bg-[#efe5d5] text-[color:var(--ink-soft)]"}`}>
                              {selected ? "Included" : "Optional"}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-[28px] border border-[color:var(--line)] bg-[#f7efe2] p-4">
                  <p className="text-sm font-medium text-[color:var(--foreground)]">Response mode</p>
                  <div className="mt-3 grid gap-3">
                    <AnswerTypeButton
                      active={answerType === "clear_answer"}
                      title="Clear answer"
                      description="Prioritize a direct, scoped response with citations first."
                      onClick={() => setAnswerType("clear_answer")}
                    />
                    <AnswerTypeButton
                      active={answerType === "create_article"}
                      title="Create article"
                      description="Use the same evidence set for a more presentation-ready article draft."
                      onClick={() => setAnswerType("create_article")}
                    />
                  </div>

                  <div className="mt-5 rounded-[22px] border border-[color:var(--line)] bg-white/70 p-4">
                    <p className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--accent)]">Current scope</p>
                    <p className="mt-2 font-display text-2xl text-[color:var(--foreground)]">{selectedLabel || "Select domains"}</p>
                    <p className="mt-2 text-sm leading-6 text-[color:var(--ink-soft)]">Switching domains changes retrieval behavior without altering the underlying search API.</p>
                  </div>
                </div>
              </div>

              <label className="mt-5 block">
                <span className="mb-3 block text-sm font-medium text-[color:var(--foreground)]">Question or external topic</span>
                <textarea
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  className="min-h-44 w-full resize-y rounded-[30px] border border-[color:var(--line)] bg-[#fffdfa] p-5 text-base leading-7 text-[color:var(--foreground)] outline-none placeholder:text-[#9b8d85] focus:border-[color:var(--accent)] focus:ring-4 focus:ring-[rgba(110,34,49,0.08)]"
                  placeholder="Ask a question or paste a link/topic for comparison..."
                />
              </label>

              <div className="mt-5 flex flex-col gap-4 border-t border-[color:var(--line)] pt-5 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--accent)]">Desk note</p>
                  <p className="mt-1 text-sm leading-6 text-[color:var(--ink-soft)]">This variant preserves the limited demo logic while reframing the story for a more premium legal-research presentation.</p>
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="rounded-full bg-[color:var(--accent)] px-6 py-3 text-sm font-medium text-[#fff7ef] shadow-[0_14px_34px_rgba(110,34,49,0.22)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loading ? "Reviewing evidence..." : answerType === "create_article" ? "Create article draft" : "Retrieve clear answer"}
                </button>
              </div>
            </form>

            <div className="rounded-[30px] border border-[color:var(--line)] bg-[color:var(--surface)] p-5 shadow-[0_16px_60px_rgba(74,39,28,0.08)]">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--accent)]">Prompt starters</p>
                  <p className="mt-1 text-sm text-[color:var(--ink-soft)]">Useful for customer walkthroughs or quick evidence checks.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {examplePrompts.map((prompt) => (
                    <button
                      key={prompt}
                      type="button"
                      onClick={() => setQuery(prompt)}
                      className="rounded-full border border-[color:var(--line)] bg-[#fffaf4] px-3 py-2 text-xs text-[color:var(--ink-soft)] transition hover:border-[color:var(--line-strong)] hover:text-[color:var(--foreground)]"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {error && <div className="rounded-[24px] border border-[#b86b57]/35 bg-[#fff1ec] p-4 text-[#7d3427]">{error}</div>}

            {result && <ResultPanel result={result} />}
          </div>
        </section>
      </div>
    </main>
  );
}

function AnswerTypeButton({ active, title, description, onClick }: { active: boolean; title: string; description: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-[24px] border px-4 py-4 text-left transition ${
        active ? "border-[color:var(--accent)] bg-[color:var(--accent)] text-[#fff7ef] shadow-[0_12px_28px_rgba(110,34,49,0.18)]" : "border-[color:var(--line)] bg-white/65 text-[color:var(--foreground)] hover:border-[color:var(--line-strong)]"
      }`}
    >
      <span className="font-display block text-2xl font-semibold">{title}</span>
      <span className={`mt-1 block text-sm leading-6 ${active ? "text-[#f5ddd1]" : "text-[color:var(--ink-soft)]"}`}>{description}</span>
    </button>
  );
}

function DeskNote({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-[24px] border border-[color:var(--line)] bg-[#fffaf3] p-4">
      <p className="font-ui-mono text-[11px] uppercase tracking-[0.24em] text-[color:var(--accent)]">{title}</p>
      <p className="mt-2 text-sm leading-6 text-[color:var(--ink-soft)]">{body}</p>
    </div>
  );
}

function ResultPanel({ result }: { result: QueryResponse }) {
  const resultTitle = result.answerType === "create_article" ? "Article draft" : "Clear answer";
  return (
    <section className="rounded-[34px] border border-[color:var(--line)] bg-[color:var(--surface-strong)] p-6 shadow-[0_24px_90px_rgba(74,39,28,0.1)] md:p-7">
      <div className="flex flex-col gap-4 border-b border-[color:var(--line)] pb-5 md:flex-row md:items-start md:justify-between">
        <div>
          <p className="font-ui-mono text-[11px] uppercase tracking-[0.32em] text-[color:var(--accent)]">{resultTitle}</p>
          <h3 className="font-display mt-2 text-4xl font-semibold text-[color:var(--foreground)]">{result.confidence} confidence</h3>
          {result.generatedBy && <p className="mt-2 text-xs uppercase tracking-[0.18em] text-[color:var(--ink-soft)]">Generated by {result.generatedBy === "ollama" ? "local Ollama" : result.generatedBy}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {result.selectedDomains.map((domain) => (
            <span key={domain} className="rounded-full border border-[color:var(--line)] bg-[#f2e8d7] px-3 py-1 text-xs text-[color:var(--foreground)]">
              {domain}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-5 whitespace-pre-wrap text-base leading-8 text-[color:var(--foreground)]">{result.answer}</div>

      {result.suggestedAngle && (
        <div className="mt-5 rounded-[24px] border border-[rgba(199,164,90,0.4)] bg-[rgba(199,164,90,0.12)] p-4 text-sm leading-7 text-[color:var(--foreground)]">
          <span className="font-semibold">Suggested angle: </span>
          {result.suggestedAngle}
        </div>
      )}

      {result.gaps && result.gaps.length > 0 && (
        <div className="mt-5 rounded-[24px] border border-[rgba(110,34,49,0.18)] bg-[rgba(110,34,49,0.06)] p-4 text-sm leading-7 text-[color:var(--foreground)]">
          <p className="font-semibold">Gaps / caution</p>
          <ul className="mt-2 list-disc pl-5">
            {result.gaps.map((gap) => (
              <li key={gap}>{gap}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-7 border-t border-[color:var(--line)] pt-5">
        <div className="mb-4 flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
          <div>
            <h4 className="font-ui-mono text-[11px] uppercase tracking-[0.32em] text-[color:var(--accent)]">Supporting sources</h4>
            <p className="mt-1 text-sm text-[color:var(--ink-soft)]">Retrieved snippets remain the same; only the presentation layer has been elevated.</p>
          </div>
        </div>
        <div className="space-y-3">
          {result.citations.map((citation, index) => (
            <article key={`${citation.documentId}-${index}`} className="rounded-[26px] border border-[color:var(--line)] bg-[#fffaf4] p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-[#efe2ce] px-2 py-1 text-xs text-[color:var(--foreground)]">{citation.domain}</span>
                <h4 className="font-display text-2xl font-semibold text-[color:var(--foreground)]">{citation.title}</h4>
                <span className="font-ui-mono text-[11px] uppercase tracking-[0.18em] text-[color:var(--ink-soft)]">score {citation.score.toFixed(2)}</span>
              </div>
              <p className="mt-3 text-sm leading-7 text-[color:var(--ink-soft)]">{citation.snippet}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
