"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = { id: string; name: string; description: string };
type DocumentSummary = { id: string; title: string; domain: string; path: string; chunkCount: number };
type ArticleConfig = {
  provider: "ollama";
  endpoint: string;
  model: string;
  audience: string;
  tone: string;
  length: "short" | "medium" | "long";
  structure: string;
  extraInstructions: string;
  includeCitations: boolean;
};
type AdminSession = {
  id: string;
  mode: string;
  query: string;
  selectedDomains: string[];
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: { title: string; domain: string; snippet: string; score: number }[];
  createdAt: string;
};

export default function AdminPage() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [history, setHistory] = useState<AdminSession[]>([]);
  const [adminLoading, setAdminLoading] = useState(true);
  const [uploadDomain, setUploadDomain] = useState("law");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadMessage, setUploadMessage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [articleConfig, setArticleConfig] = useState<ArticleConfig | null>(null);
  const [articleMessage, setArticleMessage] = useState<string | null>(null);
  const [savingArticle, setSavingArticle] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAdmin() {
    const [corpusRes, historyRes, configRes] = await Promise.all([fetch("/api/corpus"), fetch("/api/admin/history"), fetch("/api/admin/article-config")]);
    if (!corpusRes.ok) throw new Error("Failed to load corpus");
    if (!historyRes.ok) throw new Error("Failed to load history");
    if (!configRes.ok) throw new Error("Failed to load article config");
    const corpus = await corpusRes.json();
    const historyData = await historyRes.json();
    const configData = await configRes.json();
    setDomains(corpus.domains);
    setDocuments(corpus.documents);
    setHistory(historyData.sessions);
    setArticleConfig(configData.config);
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadAdmin()
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize admin"))
        .finally(() => setAdminLoading(false));
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const totalChunks = useMemo(() => documents.reduce((sum, doc) => sum + doc.chunkCount, 0), [documents]);

  async function saveArticleConfig(event: React.FormEvent) {
    event.preventDefault();
    if (!articleConfig) return;
    setSavingArticle(true);
    setError(null);
    setArticleMessage(null);
    try {
      const res = await fetch("/api/admin/article-config", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(articleConfig),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setArticleConfig(data.config);
      setArticleMessage("Article generator settings saved.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save article config");
    } finally {
      setSavingArticle(false);
    }
  }

  async function submitUpload(event: React.FormEvent) {
    event.preventDefault();
    if (!uploadFile) {
      setUploadMessage("Choose a text-based PDF first.");
      return;
    }
    setUploading(true);
    setError(null);
    setUploadMessage(null);
    try {
      const form = new FormData();
      form.set("domain", uploadDomain);
      form.set("file", uploadFile);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setUploadMessage(`Uploaded and indexed: ${data.document.title}`);
      setUploadFile(null);
      await loadAdmin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto w-full max-w-7xl px-5 py-5 lg:px-10 lg:py-8">
        <nav className="glass-panel mb-8 flex items-center justify-between rounded-[30px] px-5 py-4 lg:px-6">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-200/90">Falcon Trust</p>
            <h1 className="mt-1 text-lg font-semibold text-white">Admin Panel</h1>
          </div>
          <div className="flex rounded-full border border-white/10 bg-black/30 p-1.5 text-sm shadow-lg shadow-black/20">
            <Link href="/" className="rounded-full px-5 py-2 text-slate-300 transition hover:bg-white/5 hover:text-white">Search</Link>
            <span className="rounded-full bg-gradient-to-r from-cyan-300 to-violet-400 px-5 py-2 font-semibold text-slate-950">Admin</span>
          </div>
        </nav>

        <section className="mb-8 grid gap-6 xl:grid-cols-[1.1fr_0.7fr] xl:items-end">
          <div>
            <div className="inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.28em] text-cyan-100">
              Limited demo · admin surface
            </div>
            <h2 className="gradient-text mt-5 text-4xl font-semibold tracking-tight md:text-6xl">Control the local Falcon Trust demo without changing core behavior.</h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-slate-300">
              Corpus uploads, article-generator settings, and query history all stay wired to the same limited-demo flows. This skin just gives the admin experience more polish and hierarchy.
            </p>
          </div>
          <div className="glass-panel-strong rounded-[30px] p-6">
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-cyan-200">Guardrails</p>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-300">
              <li>• Search/Admin routing and APIs remain unchanged.</li>
              <li>• Upload flow still targets local text-based PDFs only.</li>
              <li>• No Phase 1 expansion—visual refresh only.</li>
            </ul>
          </div>
        </section>

        {error && <div className="mb-6 rounded-2xl border border-red-400/30 bg-red-400/10 p-4 text-red-100">{error}</div>}

        <section className="grid gap-4 md:grid-cols-3">
          <Metric label="Domains" value={adminLoading ? "Loading…" : String(domains.length)} detail="Selectable search scopes" />
          <Metric label="Documents" value={adminLoading ? "Loading…" : String(documents.length)} detail="Preloaded + uploaded" />
          <Metric label="Chunks" value={adminLoading ? "Loading…" : String(totalChunks)} detail="Retrieved citation units" />
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="space-y-6">
            <form onSubmit={submitUpload} className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Local corpus management</p>
              <h2 className="mt-2 text-2xl font-semibold text-white">Upload text-based PDF</h2>
              <p className="mt-2 text-sm leading-6 text-slate-300">Local demo only. Files are extracted into .demo-data and included in retrieval. Use simple text-based PDFs; scanned/image-only PDFs are intentionally out of scope for this limited demo.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-[0.8fr_1.2fr]">
                <select value={uploadDomain} onChange={(event) => setUploadDomain(event.target.value)} className="rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50">
                  {domains.map((domain) => <option key={domain.id} value={domain.id}>{domain.name}</option>)}
                </select>
                <input type="file" accept="application/pdf,.pdf" onChange={(event) => setUploadFile(event.target.files?.[0] ?? null)} className="rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-slate-200 file:mr-4 file:rounded-full file:border-0 file:bg-gradient-to-r file:from-cyan-300 file:to-violet-400 file:px-3 file:py-1 file:text-sm file:font-semibold file:text-slate-950" />
              </div>
              <button type="submit" disabled={uploading} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                {uploading ? "Extracting and indexing PDF..." : "Upload and index PDF locally"}
              </button>
              {uploadMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{uploadMessage}</p>}
            </form>

            <div className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Domains</p>
              <div className="mt-5 space-y-3">
                {domains.map((domain) => {
                  const domainDocs = documents.filter((doc) => doc.domain === domain.id);
                  const chunks = domainDocs.reduce((sum, doc) => sum + doc.chunkCount, 0);
                  return (
                    <article key={domain.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold text-white">{domain.name}</h3>
                          <p className="mt-1 text-sm leading-6 text-slate-300">{domain.description}</p>
                        </div>
                        <div className="text-right text-sm text-slate-300"><div>{domainDocs.length} docs</div><div>{chunks} chunks</div></div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {articleConfig && (
              <form onSubmit={saveArticleConfig} className="glass-panel glow-ring rounded-[28px] border border-cyan-400/20 bg-cyan-400/8 p-6">
                <p className="text-sm uppercase tracking-[0.2em] text-cyan-200">Article configurator</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">Create Article settings</h2>
                <p className="mt-2 text-sm leading-6 text-slate-300">Controls the local Ollama prompt used when the Search page is set to Create Article.</p>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <Field label="Ollama endpoint" value={articleConfig.endpoint} onChange={(value) => setArticleConfig({ ...articleConfig, endpoint: value })} />
                  <Field label="Model" value={articleConfig.model} onChange={(value) => setArticleConfig({ ...articleConfig, model: value })} />
                  <Field label="Audience" value={articleConfig.audience} onChange={(value) => setArticleConfig({ ...articleConfig, audience: value })} />
                  <Field label="Tone" value={articleConfig.tone} onChange={(value) => setArticleConfig({ ...articleConfig, tone: value })} />
                  <label className="text-sm text-slate-300">
                    Length
                    <select value={articleConfig.length} onChange={(event) => setArticleConfig({ ...articleConfig, length: event.target.value as ArticleConfig["length"] })} className="mt-1 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50">
                      <option value="short">Short</option>
                      <option value="medium">Medium</option>
                      <option value="long">Long</option>
                    </select>
                  </label>
                  <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-slate-200">
                    <input type="checkbox" checked={articleConfig.includeCitations} onChange={(event) => setArticleConfig({ ...articleConfig, includeCitations: event.target.checked })} />
                    Include inline citation markers
                  </label>
                </div>
                <TextAreaField label="Structure" value={articleConfig.structure} onChange={(value) => setArticleConfig({ ...articleConfig, structure: value })} />
                <TextAreaField label="Extra instructions" value={articleConfig.extraInstructions} onChange={(value) => setArticleConfig({ ...articleConfig, extraInstructions: value })} />
                <button type="submit" disabled={savingArticle} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-4 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60">
                  {savingArticle ? "Saving article settings..." : "Save article configurator"}
                </button>
                {articleMessage && <p className="mt-3 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-3 text-sm text-emerald-100">{articleMessage}</p>}
              </form>
            )}

            <div className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Documents</p>
              <div className="mt-5 space-y-3">
                {documents.map((doc) => (
                  <div key={doc.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div><h3 className="font-medium text-white">{doc.title}</h3><p className="mt-1 text-sm text-slate-400">{domainName(domains, doc.domain)} · {doc.chunkCount} chunks</p></div>
                      <span className="rounded-full border border-white/10 bg-white/6 px-3 py-1 text-xs text-slate-200">Indexed</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-panel rounded-[28px] p-6">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Query history</p>
              <div className="mt-5 space-y-4">
                {history.length === 0 ? <p className="text-sm text-slate-400">No queries recorded yet.</p> : history.slice(0, 8).map((item) => (
                  <article key={item.id} className="rounded-3xl border border-white/10 bg-black/30 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div><p className="text-xs uppercase tracking-[0.18em] text-cyan-200">{item.mode}</p><h3 className="mt-1 font-semibold text-white">{item.query}</h3></div>
                      <span className="rounded-full border border-white/10 bg-white/6 px-2 py-1 text-xs text-slate-300">{new Date(item.createdAt).toLocaleTimeString()}</span>
                    </div>
                    <p className="mt-3 text-sm leading-6 text-slate-300">{item.answer}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="text-sm text-slate-300">
      {label}
      <input value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm text-white outline-none focus:border-cyan-300/50" />
    </label>
  );
}

function TextAreaField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="mt-4 block text-sm text-slate-300">
      {label}
      <textarea value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 min-h-24 w-full rounded-2xl border border-white/10 bg-black/35 px-4 py-3 text-sm leading-6 text-white outline-none focus:border-cyan-300/50" />
    </label>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <div className="glass-panel rounded-3xl p-5"><p className="text-sm text-slate-400">{label}</p><p className="mt-2 text-3xl font-semibold text-white">{value}</p><p className="mt-2 text-sm text-slate-300">{detail}</p></div>;
}

function domainName(domains: Domain[], id: string) {
  return domains.find((domain) => domain.id === id)?.name ?? id;
}
