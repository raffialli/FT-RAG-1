"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type Domain = {
  id: string;
  name: string;
  description: string;
};

type Citation = {
  documentId: string;
  title: string;
  domain: string;
  snippet: string;
  score: number;
};

type AnswerType = "clear_answer" | "create_article";

type QueryResponse = {
  id: string;
  query: string;
  selectedDomains: string[];
  answerType: AnswerType;
  answer: string;
  confidence: "High" | "Medium" | "Low";
  citations: Citation[];
  suggestedAngle?: string;
  gaps?: string[];
  generatedBy?: "template" | "ollama" | "template_fallback";
  createdAt: string;
};

const examplePrompts = [
  "What should we say about sandbag pickup rules before a flood?",
  "What legal or public-claims risks should we keep in mind when writing about sandbags?",
  "Do these documents prove sandbags prevent all flood damage?",
];

export default function Home() {
  const [domains, setDomains] = useState<Domain[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<string[]>(["law", "sandbags"]);
  const [query, setQuery] = useState("What should we say about sandbag pickup rules before a flood?");
  const [answerType, setAnswerType] = useState<AnswerType>("clear_answer");
  const [result, setResult] = useState<QueryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetch("/api/corpus")
        .then((res) => {
          if (!res.ok) throw new Error("Failed to load domains");
          return res.json();
        })
        .then((data) => setDomains(data.domains))
        .catch((err) => setError(err instanceof Error ? err.message : "Failed to initialize demo"));
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  const selectedLabel = useMemo(
    () => selectedDomains.map((id) => domains.find((domain) => domain.id === id)?.name ?? id).join(" + "),
    [domains, selectedDomains],
  );

  function toggleDomain(domainId: string) {
    setSelectedDomains((current) => {
      if (current.includes(domainId)) {
        const next = current.filter((id) => id !== domainId);
        return next.length ? next : current;
      }
      return [...current, domainId];
    });
  }

  async function submitQuery(event?: React.FormEvent) {
    event?.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/query", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query, domains: selectedDomains, answerType }),
      });
      if (!res.ok) throw new Error(await res.text());
      setResult(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Query failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen text-slate-100">
      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-5 py-5 lg:px-10 lg:py-8">
        <nav className="glass-panel mb-10 flex items-center justify-between rounded-[30px] px-5 py-4 lg:px-6">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-200/90">Falcon Trust</p>
            <h1 className="mt-1 text-lg font-semibold text-white">Research Workspace</h1>
          </div>
          <div className="flex rounded-full border border-white/10 bg-black/30 p-1.5 text-sm shadow-lg shadow-black/20">
            <span className="rounded-full bg-gradient-to-r from-cyan-300 to-violet-400 px-5 py-2 font-semibold text-slate-950">Search</span>
            <Link href="/admin" className="rounded-full px-5 py-2 text-slate-300 transition hover:bg-white/5 hover:text-white">
              Admin
            </Link>
          </div>
        </nav>

        <section className="mx-auto grid w-full max-w-7xl flex-1 gap-8 pb-10 xl:grid-cols-[1.1fr_0.7fr] xl:items-start">
          <div className="flex flex-col justify-center gap-8">
            <div className="text-left">
              <div className="inline-flex rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.28em] text-cyan-100">
                Limited demo · local AI research surface
              </div>
              <h2 className="gradient-text mt-6 max-w-4xl text-5xl font-semibold tracking-tight md:text-7xl md:leading-[1.02]">
                Domain-scoped answers with a sharper, AI-native command center.
              </h2>
              <p className="mt-5 max-w-3xl text-base leading-7 text-slate-300 md:text-lg">
                Choose one or more trusted Falcon Trust domains, ask the question, and get an answer grounded in retrieved snippets. Same demo behavior—just a sleeker skin for the limited showcase.
              </p>
            </div>

            <form onSubmit={submitQuery} className="glass-panel glow-ring rounded-[34px] p-4 md:p-6">
              <div className="mb-5 flex flex-wrap gap-2">
              {domains.map((domain) => {
                const selected = selectedDomains.includes(domain.id);
                return (
                  <button
                    key={domain.id}
                    type="button"
                    onClick={() => toggleDomain(domain.id)}
                    className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
                      selected
                        ? "border-cyan-300/60 bg-gradient-to-r from-cyan-300 to-violet-400 text-slate-950 shadow-lg shadow-cyan-950/20"
                        : "border-white/10 bg-slate-950/40 text-slate-300 hover:border-cyan-300/40 hover:text-white"
                    }`}
                    aria-pressed={selected}
                  >
                    {domain.name}
                  </button>
                );
              })}
            </div>

            <div className="mb-5 flex flex-wrap gap-2 border-t border-white/10 pt-5">
              <AnswerTypeButton
                active={answerType === "clear_answer"}
                title="Clear answer"
                description="Direct answer first"
                onClick={() => setAnswerType("clear_answer")}
              />
              <AnswerTypeButton
                active={answerType === "create_article"}
                title="Create article"
                description="Draft-style response"
                onClick={() => setAnswerType("create_article")}
              />
            </div>

            <textarea
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="min-h-48 w-full resize-y rounded-[28px] border border-white/10 bg-black/35 p-5 text-base leading-7 text-white outline-none ring-cyan-300/30 placeholder:text-slate-500 focus:border-cyan-300/50 focus:ring-4"
              placeholder="Ask a question or paste a link/topic for comparison..."
            />

            <div className="mt-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <p className="text-sm text-slate-400">Searching: <span className="font-semibold text-cyan-200">{selectedLabel || "selected domains"}</span></p>
              <button
                type="submit"
                disabled={loading}
                className="rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-violet-400 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? "Searching..." : answerType === "create_article" ? "Create article" : "Get clear answer"}
              </button>
            </div>
          </form>

          <div className="flex flex-wrap gap-2 xl:justify-start">
            {examplePrompts.map((prompt) => (
              <button
                key={prompt}
                type="button"
                onClick={() => setQuery(prompt)}
                className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:border-cyan-300/40 hover:bg-white/8 hover:text-white"
              >
                {prompt}
              </button>
            ))}
          </div>

          {error && <div className="rounded-2xl border border-red-400/30 bg-red-400/10 p-4 text-red-100">{error}</div>}

          {result && <ResultPanel result={result} />}
          </div>

          <aside className="space-y-4 xl:pt-12">
            <div className="glass-panel-strong rounded-[30px] p-6">
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-cyan-200">How this demo behaves</p>
              <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-300">
                <li>• Search and Admin use the same limited-demo APIs and corpus.</li>
                <li>• Answers stay constrained to selected domains and cited snippets.</li>
                <li>• Create Article still uses the existing local article-generation flow.</li>
              </ul>
            </div>
            <div className="glass-panel rounded-[30px] p-6">
              <p className="text-xs font-semibold uppercase tracking-[0.28em] text-violet-200">Demo posture</p>
              <h3 className="mt-3 text-2xl font-semibold text-white">Modern AI SaaS look, same mechanics underneath.</h3>
              <p className="mt-3 text-sm leading-6 text-slate-300">
                This variant is intentionally visual-only: stronger hierarchy, glass surfaces, violet/cyan accents, and a bolder layout without changing functionality.
              </p>
            </div>
          </aside>
        </section>
      </div>
    </main>
  );
}

function AnswerTypeButton({ active, title, description, onClick }: { active: boolean; title: string; description: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-2xl border px-4 py-3 text-left transition ${
        active ? "border-cyan-300/60 bg-gradient-to-r from-cyan-300 to-violet-400 text-slate-950 shadow-lg shadow-cyan-950/20" : "border-white/10 bg-slate-950/40 text-slate-300 hover:border-cyan-300/40 hover:text-white"
      }`}
    >
      <span className="block text-sm font-semibold">{title}</span>
      <span className={`block text-xs ${active ? "text-slate-800" : "text-slate-400"}`}>{description}</span>
    </button>
  );
}

function ResultPanel({ result }: { result: QueryResponse }) {
  const resultTitle = result.answerType === "create_article" ? "Article draft" : "Clear answer";
  return (
    <section className="glass-panel rounded-[32px] border border-emerald-300/20 bg-emerald-400/8 p-5 shadow-xl shadow-emerald-950/20 md:p-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">{resultTitle}</p>
          <h3 className="mt-1 text-2xl font-semibold text-white">{result.confidence} confidence</h3>
          {result.generatedBy && <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-300">Generated by {result.generatedBy === "ollama" ? "local Ollama" : result.generatedBy}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {result.selectedDomains.map((domain) => (
            <span key={domain} className="rounded-full border border-white/10 bg-slate-950/35 px-3 py-1 text-xs text-slate-200">
              {domain}
            </span>
          ))}
        </div>
      </div>
      <div className="mt-4 whitespace-pre-wrap text-base leading-7 text-slate-100">{result.answer}</div>
      {result.suggestedAngle && (
        <div className="mt-4 rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4 text-sm leading-6 text-cyan-50">
          <span className="font-semibold">Suggested angle: </span>{result.suggestedAngle}
        </div>
      )}
      {result.gaps && result.gaps.length > 0 && (
        <div className="mt-4 rounded-2xl border border-amber-400/20 bg-amber-400/10 p-4 text-sm leading-6 text-amber-50">
          <p className="font-semibold">Gaps / caution</p>
          <ul className="mt-1 list-disc pl-5">
            {result.gaps.map((gap) => <li key={gap}>{gap}</li>)}
          </ul>
        </div>
      )}
      <div className="mt-6 border-t border-white/10 pt-5">
        <div className="mb-3">
          <h4 className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">Supporting sources</h4>
          <p className="mt-1 text-sm text-slate-300">These are the retrieved document snippets used to ground the answer above.</p>
        </div>
        <div className="space-y-3">
          {result.citations.map((citation, index) => (
            <article key={`${citation.documentId}-${index}`} className="rounded-2xl border border-white/10 bg-black/30 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-white/8 px-2 py-1 text-xs text-slate-200">{citation.domain}</span>
              <h4 className="font-semibold text-white">{citation.title}</h4>
              <span className="text-xs text-slate-400">score {citation.score.toFixed(2)}</span>
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-300">{citation.snippet}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
